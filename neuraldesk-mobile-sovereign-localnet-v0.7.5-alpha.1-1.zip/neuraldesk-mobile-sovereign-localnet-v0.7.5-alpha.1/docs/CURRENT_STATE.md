A v0.7.5-alpha.1 é uma candidata **NOT_PROMOTED** de convergência histórica profunda sobre a árvore integral v0.7.4-alpha.2. A v0.7.3-alpha.1 continua sendo a última release externamente atestada. Nenhum peso neural promovido foi alterado.

## Delta executável v0.7.5

1. `nd_generative` ganhou sessão streaming computacional com prefill/decode bounded, KV persistente, backpressure, cancelamento e deadline; final token sequence preserva greedy.
2. `NDGenTextStreamSession` entrega delta UTF-8 seguro usando NDTK v2; bytes parciais de code points são retidos.
3. `nd_resource` + Kotlin ganharam capability profile RAM/cores/ABI e provider routing; somente CPU_C99 possui executor atual; GPU/NPU falham fechado.
4. `nd_run_journal` ganhou `PROGRESS` e `DRAIN`; recovery de runs abandonados continua ativo sem conteúdo bruto.
5. `governance_v075` porta rights/provenance/reference-only/leakage policy para os bytes atuais sem fabricar o Golden 250 histórico.
6. Data-Scale Pretraining v2 suporta gradient accumulation, effective batch 64 e checkpoint somente em optimizer boundary; resume equivalence passou em model/AdamW/FP32/Q8/Q4.

A matriz completa de todas as linhagens recuperáveis está em `HISTORICAL_CAPABILITY_CONVERGENCE_V075.md`.

# Current State — NeuralDesk Mobile Sovereign LocalNet v0.7.5-alpha.1

A v0.7.4-alpha.2 é uma candidata de desenvolvimento reconstruída diretamente do ZIP final atestado v0.7.3-alpha.1 após perda do workspace v0.7.4-alpha.1. A v0.7.3 permanece rollback final. O delta alpha.2 adiciona somente mecânica generativa C99, corpus/tokenizer governados e treinamento stage-only; nenhum backbone generativo está promovido ou ativado no assistant.

## Delta executável v0.7.3

- JNI: single-flight por handle, mutex/condition, cancelamento, deadline monotônico e `free()` aguardando idle;
- `NDExecutionControl`: checkpoints cooperativos mantendo APIs antigas como wrappers;
- Resource Governor: output/threads/deadline/thermal backoff efetivamente calculados por perfil;
- Android: `PowerManager.currentThermalStatus` (API 29+) alimenta o governor; fila `newSingleThreadExecutor` serializa o mesmo handle;
- assets: `InputStream` + buffer 64 KiB + SHA-256 incremental + `fsync` + `ATOMIC_MOVE`, sem whole-model `ByteArray` na rota normal;
- Local RAG: dedup/replace por documento, máximo 16 chunks/doc, LRU de documento inteiro, token hashes pré-computados e persistência `NDRAG001` fail-closed;
- Research Memory Android: opt-in default-off, AES-GCM/Android Keystore, máximo 128 itens e sem persistir a resposta gerada.

## Não-regressão targeted já observada

C99 `-Werror` PASS; execution control PASS; Resource Governor PASS; RAG persistence/corruption/LRU PASS; JNI host PASS; Kotlin host/asset probe PASS; Android wiring PASS; calculadora 16/16; multiobjetivo 320/320; conversational correctness 12/12; dialogue grounding 7/7; robust intent 11/11; Semantic Core 11/11; Live QA 35/35; fail-closed herdado 12 corrupções rejeitadas.

Esses resultados targeted ainda **não** autorizam a release: os receipts completos de VERIFY/SANITIZER e a reextração final são obrigatórios.

## Orchestrator canônico

`semantic_intent_frame_and_safety_precheck -> memory_command_or_conversation_policy -> bounded_recent_history_topic_shift_and_non_entailment_guard -> plan_goals -> supplied_context_or_local_rag_bm25_semantic_rerank_grounding -> exact_tool_or_text_utility -> structured_explicit_memory_then_text_memory -> internal_neural_knowledge_with_acronym_preservation_then_sparse_kb_if_neural_refuses -> active_local_open_knowledge_ndos_if_internal_refuses -> uncertainty -> safety_output_postcheck -> compose`

**Limite do streaming:** `nd_assistant_answer_stream_controlled` preserva callback/cancelamento e checkpoints, mas o assistant determinístico ainda materializa a resposta bounded antes de dividi-la. Não existe decoder autoregressivo promovido nesta árvore; portanto “true token streaming” continua não implementado.

## Estado executável

A v0.6.2-alpha.1 é uma candidata móvel híbrida local-first, derivada da reconstrução v0.6.0-alpha.2. O runtime canônico é C99 e não contém LLM generativo geral aprovado nem backend externo de IA para inferência.

### Componentes neurais preservados da v0.5

- Knowledge Retriever: 275.338 parâmetros, 202 classes (201 fatos + unknown).
- Relation Classifier: 132.826 parâmetros, 26 classes (25 relações + unknown).
- Context Pointer v2: 134.930 parâmetros, condicionado pelo `relation_id` e sujeito a candidate acceptance.
- Total neural: **543.094 parâmetros FP32**.

### Conhecimento auditável

- `.ndkb`: 201 registros first-party.
- `.ndos`: 31 registros humanos Pirá 2.0 / CC BY 4.0, **0 parâmetros neurais**.
- O `.ndos` é recuperação lexical/estatística local, não treinamento neural e não deve ser contado como aumento de parâmetros.

## Ordem operacional

`comando de memória/política conversacional -> contexto bounded de follow-up -> planner -> contexto/grounding -> ferramenta exata -> memória -> retriever neural+KB -> sparse KB somente após recusa neural -> NDOS se o conhecimento interno recusar -> incerteza -> composição`.

O novo fallback nunca precede fontes de maior autoridade. Ausência de score/margem suficientes mantém a resposta em incerteza explícita.

## Delta comportamental v0.6.1

- **12/12** no benchmark pós-implementação de conversational correctness;
- calculadora **16/16**, incluindo `(37 × 19) + 15 = 718`, precedência e parênteses;
- Live QA herdado preservado em **35/35** após endurecer o fallback sparse contra `Noveria-999`;
- planner único compartilhado por assistant e grounding;
- follow-up mantém somente um turno anterior de pergunta/resposta; isso é estado conversacional bounded, **não treino online**;
- os pesos neurais, datasets promovidos e hashes dos cinco assets não mudaram.

A melhoria desta candidata é arquitetural/semântica. Não deve ser descrita como aumento de parâmetros, pré-treino, fine-tuning ou aprendizagem de pesos durante o diálogo.

## Estado do NDOS

- magic: `NDOSV001`;
- 65.536 buckets;
- `topK=96`;
- `acceptScore=0.33`;
- `acceptMargin=0.08`;
- 31 records;
- SHA-256 `b4967b52e02daf3dea5833ee5f7df63ecbf4edc3bf88d95b7f407423f44419c7`.

Gates específicos executados: 53/53 Python↔C; 28/28 raw top-1 humano; 25/25 aceitas corretas; 0/25 negativos aceitos; holdout 3/3 raw e 2/2 aceitas corretas; 4/4 corrupções rejeitadas; 2/2 reproduções byte-idênticas.

## Limites

- o shard de 31 registros não é um modelo geral e não transforma o NeuralDesk em modelo de fronteira;
- recuperação correta de uma paráfrase não prova conhecimento universal;
- não houve novo treinamento dos quatro modelos neurais nesta release;
- o Pirá não é usado como backend remoto; somente bytes locais auditáveis participam;
- certificação física Android/APK em aparelho real continua fora da evidência desta árvore.

Primeira leitura obrigatória antes de qualquer mudança: `../memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md`.

## Hardening da auditoria completa — 2026-08-24

A leitura cruzada documentação↔código encontrou e corrigiu três classes de drift: cópia Android stale por nome, strings públicas de versão antigas e evidence final de v0.5 sobrevivendo na árvore alpha.2. Também foi alinhado o enforcement dos trainers de Retriever/Pointer ao Golden obrigatório.

A release só pode voltar ao estado `RELEASE_GATES_PASS` depois de reexecutar os gates completos sobre **esta** árvore, gerar logs versionados, regenerar `REPORT.json`/inventário/checksums e verificar o ZIP reextraído.

## Estado de fechamento da auditoria

O estado de promoção não deve ser inferido deste parágrafo estático. A fonte machine-readable é `verification/AUDIT_STATUS.json`; `verification/REPORT.json` só pode existir depois de VERIFY + SANITIZER vinculados ao mesmo digest corrente. A autorização final não fica gravada no manifest candidato: ela só existe na attestação externa do ZIP depois de reextração, VERIFY e SANITIZER sobre os bytes entregáveis.

## Gate retomável vinculado aos inputs

A v0.6.1 mantém os mesmos testes, mas permite executar o fechamento em fases determinísticas quando a janela externa não comporta o agregador monolítico. Cada fase concluída gera um receipt externo à release por `scripts/verification_checkpoint.py`, contendo versão, fase e SHA-256 canônico dos inputs. A fase final exige todos os receipts da mesma versão/digest. Mudança em código, documentação, manifest, modelos ou datasets invalida automaticamente a retomada. Esse mecanismo não transforma timeout em PASS e não autoriza pular cobertura.



## v0.6.2-alpha.1 — estado corrente

- memória explícita continua persistindo texto NDM1, mas reconstrói um índice bounded de fatos estruturados;
- histórico conversacional volátil: até 8 turnos recentes, sem atualização de pesos;
- follow-up exige continuidade sem nova âncora explícita;
- siglas explícitas do usuário são preservadas token-a-token no candidato de conhecimento;
- implicações universais não suportadas recebem resposta conservadora;
- `nd_dialogue_grounding_v062_test`: 7/7; conversational correctness herdado: 12/12; Live QA precisa permanecer 35/35;
- cinco modelos/543.094 parâmetros e datasets promovidos permanecem byte-idênticos à v0.6.1.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

## v0.7.4-alpha.2 — diálogo independente e estado Micro v3 (2026-08-25)

- diálogo contínuo ChatGPT ↔ NeuralDesk: 30 turnos, UTF-8 natural, **16 PASS / 4 PARTIAL / 10 FAIL**; transcript e rubric em `evaluation/dialogue_v074/`;
- run ASCII stress preservado separadamente para robustez de normalização;
- nenhuma resposta do diálogo foi usada para atualizar pesos nesta etapa; FAIL/PARTIAL são `REFERENCE_ONLY_NOT_TRAINED_IN_THIS_RELEASE`;
- falhas principais: relation binding para `código`, memória multiatributo/update, non-entailment explícito, technical quantization routing, open-knowledge/RAG contamination, keywords, resumo de histórico e porcentagem natural;
- Micro v3/NDGM v5: 11.229.760 parâmetros, `dim=320`, 10 camadas, 10 Q heads, 2 KV heads, FFN 896, contexto 256;
- mechanics C99, Q8/Q4 fixture parity e PyTorch↔C99 já foram validados antes do screening;
- training stage-only atual: **pretrain 350/367**, SFT 0/321; checkpoint externo atual SHA-256 `c1f6745b896386e76243749ce1d2a3eea0278215411b472170df0ec6df224b24`;
- `models/` não contém Micro v3 e `assistantActivated=false`; promoção e serving permanecem proibidos.
