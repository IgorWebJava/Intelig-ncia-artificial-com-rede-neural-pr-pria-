<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.governance; current: docs/governance/CURRENT_GOVERNANCE.md -->
# Governance Documentation Index

## Current
- `CURRENT_GOVERNANCE.md`
- `DOCUMENT_LIFECYCLE_POLICY.md`
- `HISTORICAL_BASELINE_POLICY.md`

## Historical/reference
All V7.x/V8.x versioned governance files are preserved as evolution baselines and defer to `CURRENT_GOVERNANCE.md`.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
