<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent Projects & Multi-Agent Studio — Current State

Documentation: `V8.11`  
Implementation: `8.11.0`  
Module ID: `neuraldesk.agents`  
Canonical UI: `modules/agents/ui/agents.html`  
UI profile: `intelligence-experience-v2`  
Workspace runtime: `workspace-runtime-v2`  
Design System: `neuraldesk-intelligence-design-v2`  
Testing: `module-quality-v2`  
Engine Bridge: `cooperative-engine-bridge-v1`  
Template scope: `interface + local UI runtime + cooperative engine bridge; no executable Neural Engine`

## Purpose

This is the authoritative current documentation for the `agents` interface module. It documents what is implemented in the template and how each represented mechanic maps to future Neural Engine capabilities.

## Specialized working mechanic

**Agent Design Studio**

## Runtime truth boundary

Implemented now: canonical HTML/CSS, module-owned JavaScript for local UI interaction/state, responsive behavior, accessibility structure, previews and tests.

Not implemented here: production AI inference, persistent backend state, real agent/tool execution, external side effects, Neural Engine execution, distributed training or model serving.

## Provides capabilities

- `agents.catalog.v1`
- `agents.definition.v1`
- `agents.version.v1`
- `agents.run.v1`
- `agents.team.v1`
- `agents.handoff.v1`
- `agents.workflow.v1`
- `agents.skill.bind.v1`
- `agents.template.v1`
- `agents.evaluate.v1`

## Requires capabilities

- `project.manage.v1`
- `agent.skill.catalog.v1`
- `agent.skill.create.v1`
- `agent.skill.version.v1`
- `ai.execute.v1`
- `tools.catalog.v1`
- `tools.execute.v1`
- `knowledge.retrieve.v1`
- `training.evaluate.v1`
- `media.asset.v1`
- `approval.request.v1`
- `config.resolve.v1`
- `audit.write.v1`
- `telemetry.emit.v1`
- `ui.adaptive.v1`
- `ui.multimodal.surface.v1`
- `ui.runtime.interaction.v1`
- `ui.workspace.shell.v1`
- `ui.command_palette.v1`
- `ui.global.search.v1`
- `ui.task.center.v1`
- `ui.notification.center.v1`
- `ui.workflow.canvas.v1`
- `ui.context-lens.v1`
- `ui.provenance.v1`
- `ui.trust-layer.v1`
- `ui.density.v1`
- `ui.version-diff.v1`
- `ui.adaptive-inspector.v1`
- `ui.specialized-workspace.v1`


## Future Neural Engine owners

The following future engine modules are responsible for making this interface executable:

- `neural-engine.agent-runtime`
- `neural-engine.skill-runtime`
- `neural-engine.tool-runtime`
- `neural-engine.workflow-event-runtime`
- `neural-engine.model-router`
- `neural-engine.knowledge-rag-runtime`
- `neural-engine.approval-policy-guardrails`
- `neural-engine.evaluation-verification-runtime`
- `neural-engine.training-optimization-runtime`


Mechanic-level traceability: `neural-engine/registry/ui-mechanic-traceability.json` (11 mechanics mapped for this UI module).

## Data and integration

- API namespace: `/agents`
- Event namespace: `agents.*`
- Data ownership: `data/ownership.md`
- Cross-module rule: public versioned contracts/capabilities only.
- Direct browser database access: forbidden.
- Direct provider SDK dependency in domain UI: forbidden.

## Quality contract

- `module-quality-v2` module-owned tests;
- 5 canonical responsive viewport classes;
- browser visual tests;
- preview freshness validation;
- documentation synchronization;
- Neural Engine traceability validation.

## Read next

1. `MECHANICS_AND_FUNCTIONALITY.md`
2. `AI_MODULE_HANDOFF.md`
3. `MODULE_ARCHITECTURE.md`
4. `CONTRACTS_AND_CAPABILITIES.md`
5. `DATA_OWNERSHIP_AND_CONSISTENCY.md`
6. `UI_RUNTIME_AND_DESIGN_SYSTEM.md`
7. `TESTING_AND_QUALITY.md`
8. `../../../neural-engine/architecture/UI_MECHANIC_TRACEABILITY.md`

## Future executable readiness

Primary roadmap wave: **P03**. See `FUTURE_EXECUTABLE_READINESS.md`. No new executable capability is introduced by V8.7.


## V8.14 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


## V8.11 module release
Canonical module version: `8.11.0`. Engine Bridge profile: `cooperative-engine-bridge-v1`.


## V8.13 Agent Platform integration
This module preserves V8.11 mechanics and adds `agent-platform-patterns-v1` UI/contracts. AutoGPT Platform research is pattern-only; future engine execution remains NOT IMPLEMENTED.


## V8.14 synchronized identity
- Module ID: `neuraldesk.agents`
- Module version: `8.12.0`
- Canonical UI: `modules/agents/ui/agents.html`
- Experience: `intelligence-experience-v2`
- Runtime: `workspace-runtime-v2`
- Design System: `neuraldesk-intelligence-design-v2`
- Agent Platform patterns: `agent-platform-patterns-v1`
- Neural Engine execution: `NOT_IMPLEMENTED`

## V8.14 authoritative module snapshot
- Module ID: `neuraldesk.agents`
- Module version: `8.13.0`
- Canonical UI: `modules/agents/ui/agents.html`
- UI profile: `intelligence-experience-v2`
- Runtime profile: `workspace-runtime-v2`
- Design system: `neuraldesk-intelligence-design-v2`
- Coding Intelligence: `coding-intelligence-patterns-v1`
- Neural Engine execution: `NOT_IMPLEMENTED`

## AI Workspace V8.14

Additive surface using `open-webui-ai-workspace-patterns-v1`; future engine execution remains NOT_IMPLEMENTED. Existing V8.13 semantics are preserved.


## V8.14 authoritative synchronization

neuraldesk-documentation-sync: V8.14
- Module: `neuraldesk.agents`
- Module version: `8.14.0`
- Canonical UI: `modules/agents/ui/agents.html`
- Experience: `intelligence-experience-v2`
- Runtime: `workspace-runtime-v2`
- Design system: `neuraldesk-intelligence-design-v2`
- AI Workspace: `open-webui-ai-workspace-patterns-v1`
- Neural Engine execution: `NOT_IMPLEMENTED`
