<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.chat; current: modules/chat/docs/UI_RUNTIME_AND_DESIGN_SYSTEM.md -->
# Autonomous Assistant Workspace Template — UI Runtime & Design System

```text
Experience:    intelligence-experience-v2
Runtime:       workspace-runtime-v2
Design System: neuraldesk-intelligence-design-v2
Runtime file:  modules/chat/ui/runtime/module-runtime.js
CSS file:      modules/chat/ui/chat.css
```

## Runtime scope

Allowed: local interface interactions, tabs, drawers, filters, inspector state, density selection, command/search UI, demo workflow nodes and toasts.

Not implemented here: AI/provider calls, database access, real tool/agent execution, background tasks, production persistence or external side effects.

## Design principles

- readable typography;
- progressive disclosure;
- specialized mechanic per module;
- adaptive inspectors;
- Context / Provenance / Trust;
- Comfortable / Balanced / Dense;
- responsive and accessible interaction.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
