<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# NeuralDesk AI Template V4 — Advanced Knowledge Center

Implementada a evolução da Base de Conhecimento para Knowledge Center profissional, mantendo a restrição **HTML + CSS בלבד**.

Inclui health, sources, documents, collections, knowledge items, semantic search, retrieval inspector, query planning, hybrid retrieval, reranking, context budget, graph, permissions, versions, quality, freshness, grounding, lineage, activity e ingestion wizard.

Todos os dados e estados são demonstrativos e preparados para integração posterior ao sistema real.
