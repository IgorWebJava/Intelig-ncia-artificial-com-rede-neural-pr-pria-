# Reconstruction Lineage — v0.6.1-alpha.1

## Por que existe alpha.2

A árvore de desenvolvimento descrita por um README posterior de v0.6 alpha.1 não estava persistida no runtime de continuação. Ao mesmo tempo, havia um pacote histórico v0.6 materializado com arquitetura `.ndsh` e 1.281 registros, diferente do `NDOS v1`/31 registros descrito posteriormente.

Reutilizar o ZIP histórico como se fosse a reconstrução posterior criaria uma falsa equivalência. Recriar um arquivo e atribuir a ele o hash perdido também violaria o protocolo.

## Decisão

1. preservar o ZIP v0.5 íntegro como baseline;
2. executar o precheck de lições;
3. usar o v0.6 histórico apenas como lineage de dados e referência de integração;
4. selecionar/materializar 31 registros humanos rastreáveis, incluindo `A160`, sem campos automáticos e sem test split;
5. implementar um formato NDOS novo e verificável;
6. corrigir o planner científico;
7. executar novos negativos, holdout, corrupções e paridade;
8. atribuir nova identidade `0.6.0-alpha.2` e hashes próprios.

## O que não é afirmado

- alpha.2 não é byte-idêntica à alpha.1 perdida;
- o SHA descrito historicamente para um `.ndos` perdido não foi recuperado;
- o `.ndsh` histórico não foi silenciosamente renomeado para `.ndos`;
- os 1.281 registros históricos não são declarados ativos no runtime alpha.2;
- resultados históricos não substituem gates reexecutados.

## Baseline

v0.5 ZIP preservada: SHA-256 `9e0381977230c7502ca0fdb74fe4fb1d7adbdec12d1f7ca735151cc80ac3ad02`.

## Auditoria posterior da alpha.2

Em 2026-08-24 a árvore reconstruída foi relida sem confiar em documentação ou código isoladamente. A auditoria não alterou os cinco assets promovidos, mas endureceu lifecycle Android, identidade pública, trainer gates e evidence de release. Esses ajustes fazem parte da mesma identidade alpha.2 candidata porque não houve freeze final válido da reconstrução antes desta auditoria; qualquer ZIP final deve ser produzido somente após os novos gates.

## Continuação v0.6.1-alpha.1

A v0.6.1 é filha da árvore auditada alpha.2 e preserva seus cinco assets/hashes. Ela existe porque os diálogos pós-implementação demonstraram falhas reproduzíveis de cálculo, planner, memória relacional, retrieval lexical e follow-up. O novo número de versão separa corretamente esse delta funcional da reconstrução alpha.2, sem reescrever sua história.


## Sucessor v0.6.2-alpha.1

A v0.6.2 deriva exclusivamente do ZIP final v0.6.1-alpha.1 aprovado e reproduzível, SHA-256 `199a8233ed2f6fb779063ac9551f5e32762d3b43e33eb7b0b4db6bad089ad112`. A nova candidata não altera pesos nem datasets; sua diferença está no runtime de diálogo/memória e nos gates adicionais.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
