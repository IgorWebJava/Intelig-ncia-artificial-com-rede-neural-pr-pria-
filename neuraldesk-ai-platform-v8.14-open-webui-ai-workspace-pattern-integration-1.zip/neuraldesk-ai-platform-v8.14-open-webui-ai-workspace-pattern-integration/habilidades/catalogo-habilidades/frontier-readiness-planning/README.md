<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Frontier Competitive Readiness Planning

Use this skill when converting market/competitive gaps into a future implementation roadmap.

Required behavior:
- separate current executable reality from future targets;
- define parity, differentiation and evidence gates;
- map UI mechanics to engine owners;
- assign implementation waves and dependencies;
- define benchmarks, security, cost and rollback;
- prohibit general superiority claims without reproducible evidence;
- preserve documentation-only boundaries when the release does not implement code.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
