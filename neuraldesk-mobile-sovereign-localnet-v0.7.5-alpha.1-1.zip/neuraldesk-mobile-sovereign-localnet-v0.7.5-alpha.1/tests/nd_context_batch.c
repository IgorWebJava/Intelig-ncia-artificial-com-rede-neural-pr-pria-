#include "nd_context_qa.h"
#include "nd_context_synth.h"
#include "nd_relation.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int contains_all(const char *s, const char *spec) {
    if (!spec || !*spec || strcmp(spec, "-") == 0) return 1;
    char *copy = strdup(spec);
    if (!copy) return 0;
    int ok = 1;
    for (char *p = strtok(copy, ";"); p; p = strtok(NULL, ";")) {
        if (*p && strstr(s, p) == NULL) { ok = 0; break; }
    }
    free(copy);
    return ok;
}

static int contains_none(const char *s, const char *spec) {
    if (!spec || !*spec || strcmp(spec, "-") == 0) return 1;
    char *copy = strdup(spec);
    if (!copy) return 0;
    int ok = 1;
    for (char *p = strtok(copy, ";"); p; p = strtok(NULL, ";")) {
        if (*p && strstr(s, p) != NULL) { ok = 0; break; }
    }
    free(copy);
    return ok;
}

int main(int argc, char **argv) {
    if (argc != 3 && argc != 4) {
        fprintf(stderr, "usage: %s CONTEXT_QA DATASET.tsv [RELATION_MODEL]\n", argv[0]);
        return 2;
    }
    char err[256];
    NDContextQA qa;
    if (nd_context_qa_load(argv[1], &qa, err, sizeof(err)) != 0) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }
    NDRelationClassifier relation;
    NDRelationClassifier *relation_ptr = NULL;
    memset(&relation, 0, sizeof(relation));
    if (argc == 4) {
        if (nd_relation_load(argv[3], &relation, err, sizeof(err)) != 0) {
            fprintf(stderr, "relation: %s\n", err);
            nd_context_qa_free(&qa);
            return 1;
        }
        relation_ptr = &relation;
    }
    FILE *f = fopen(argv[2], "rb");
    if (!f) {
        perror("dataset");
        nd_relation_free(&relation);
        nd_context_qa_free(&qa);
        return 1;
    }
    char *line = NULL; size_t cap = 0; ssize_t got;
    size_t total = 0, pass = 0;
    while ((got = getline(&line, &cap, f)) >= 0) {
        while (got > 0 && (line[got-1] == '\n' || line[got-1] == '\r')) line[--got] = 0;
        if (got == 0 || line[0] == '#') continue;
        char *required = line;
        char *forbidden = strchr(required, '\t');
        if (!forbidden) { fprintf(stderr, "bad row %zu\n", total+1); break; }
        *forbidden++ = 0;
        char *question = strchr(forbidden, '\t');
        if (!question) { fprintf(stderr, "bad row %zu\n", total+1); break; }
        *question++ = 0;
        char *context = strchr(question, '\t');
        if (!context) { fprintf(stderr, "bad row %zu\n", total+1); break; }
        *context++ = 0;
        char out[16384]; NDContextSynthesisResult r;
        int rc = nd_context_synthesize_ex(&qa, relation_ptr, question, context, 1, out, sizeof(out), &r, err, sizeof(err));
        total++;
        int ok = (rc == 0) && contains_all(out, required) && contains_none(out, forbidden);
        if (ok) pass++;
        else if (total <= 20 || total - pass <= 20) {
            fprintf(stderr, "FAIL %zu\nQ: %s\nOUT: %s\nREQ: %s\nFORBID: %s\nERR: %s\n", total, question, rc ? "<error>" : out, required, forbidden, rc ? err : "-");
        }
    }
    free(line);
    fclose(f);
    nd_relation_free(&relation);
    nd_context_qa_free(&qa);
    printf("context_synthesis %zu/%zu PASS\n", pass, total);
    return (total > 0 && pass == total) ? 0 : 1;
}
