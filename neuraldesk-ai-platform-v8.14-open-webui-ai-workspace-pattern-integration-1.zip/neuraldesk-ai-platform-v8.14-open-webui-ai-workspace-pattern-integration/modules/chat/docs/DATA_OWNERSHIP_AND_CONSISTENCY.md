<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.chat; current: modules/chat/docs/DATA_OWNERSHIP_AND_CONSISTENCY.md -->
# Autonomous Assistant Workspace Template — Data Ownership & Consistency

Authoritative ownership is documented in `modules/chat/data/ownership.md`.

## Invariants

- one authoritative owner per mutable dataset;
- no cross-module private SQL;
- no browser direct database credentials;
- cross-module reads use APIs/read models;
- cross-module changes use versioned APIs/events;
- distributed durable changes use transactional state + outbox before event publication;
- references to external module entities use stable public IDs.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
