<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.audit; current: modules/audit/docs/MECHANICS_AND_FUNCTIONALITY.md -->
# Mechanics and Functionality — System Audit, Trace & Control Center

## Scope

This document is the authoritative functional map for the current `audit` template UI. It distinguishes visual/template behavior from future executable engine behavior.

## Specialized mechanic

**Investigation Workspace**

## Mechanic → future engine traceability

| UI mechanic | Current template status | Future engine status | Future engine owners |
|---|---|---|---|
| Explorer | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.identity-security-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Timeline | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Relations | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.identity-security-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Evidence Package | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.artifact-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Traces | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Changes | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.identity-security-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Integrity | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Visual Diff | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.identity-security-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Context Lens | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.context-compiler`, `neural-engine.project-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Provenance | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Trust Layer | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.approval-policy-guardrails`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |

## Truthfulness rule

A visible control, status, timeline, agent/tool indicator or result card must not be documented as executable unless the corresponding future engine modules are actually implemented and integration tests prove the capability.

## Source of truth

- UI: module canonical HTML/CSS/JS.
- Capability contracts: `module.manifest.json` and `contracts/`.
- Future engine traceability: `neural-engine/registry/ui-mechanic-traceability.json`.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
