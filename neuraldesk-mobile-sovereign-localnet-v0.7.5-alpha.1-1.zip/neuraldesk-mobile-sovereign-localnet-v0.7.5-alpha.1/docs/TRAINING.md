# v0.7.5 training addendum — Data-Scale gradient accumulation

O trainer Data-Scale mantém Micro v3 / NDGM v5 e o token cache first-party. A política atual usa microbatch 8 (`1 rich + 7 context`) × accumulation 8, produzindo effective batch 64 (`8 rich + 56 context`) com rich loss weight 1.0 e context 0.15. Loss é escalada pelo número real de microbatches; um único gradient clip/AdamW ocorre por grupo. Checkpoint e run budget só podem cair em optimizer boundary. Um gate debug provou `uninterrupted == pause→resume` para model state, AdamW e FP32/Q8/Q4.

# Training and Reproducibility — v0.7.2-alpha.1

Os quatro especialistas herdados preservam pesos/hashes. O novo Semantic Ranker possui **131.200 parâmetros**, 524.832 bytes e SHA-256 `007c52491728d1402977c478f15f89160737096fe08004e4db374fb54493f669`, com **746/749** no gate relativo. Checkpoint/resume é transitório e integrity-bound; drift/tamper falham fechado. Não existe Generative Micro promovido nesta release.

## Pré-condição obrigatória

Todo caminho canônico de treino executa `scripts/pre_generation_lessons_check.py`. O operador/IA deve primeiro ler e analisar integralmente `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md`.

## 1. Knowledge Retriever

- trainer: `training/train_knowledge_retriever.py`;
- seed: 101;
- features: 4096;
- hidden: 64;
- classes: 202 = 201 registros + unknown;
- parâmetros: 275.338;
- treino: 1.830;
- Golden: 856;
- steps: 1.400;
- batch: 64;
- saída: `.ndkr` + `.ndkb`.

Hash promovido: `76a54e...ab539`; KB: `d6d696...70652`. O trainer exige **100% do Golden antes de escrever** o asset solicitado; o gate de release continua revalidando 856/856 no runtime C.

## 2. Relation Classifier

- trainer: `training/train_relation_classifier.py`;
- seed: 507;
- features: 2048;
- hidden: 64;
- classes: 26 = 25 relações + unknown;
- parâmetros: 132.826;
- treino estratificado: 5.025;
- Golden: 4.008;
- steps: 900;
- batch: 96.

O gate exige >=99% separadamente em `question`, `sentence` e `unknown`; o checkpoint promovido atingiu 100% nas três visões. O runtime C também passou 4.008/4.008.

Hash promovido: `452245...d883`.

## 3. Context Pointer v2

- trainer: `training/train_context_pointer.py`;
- seed: 3;
- vocab byte-level: 259;
- embedding: 48;
- hidden: 96;
- radius: 12;
- relation embeddings: 25 × 96;
- parâmetros: 134.930;
- treino: 52.500;
- Golden: 2.000;
- steps: 700;
- batch: 32;
- max span: 160 bytes.

Golden: 2.000/2.000. O trainer exige **100% do Golden antes de exportar**. Probes livres raw: 9/12. O runtime final usa candidate acceptance, cuja suíte passa 12/12 com 6 fallbacks grounded.

Hash promovido: `de85e6...79ef`.

## Determinismo estrito

Os trainers canônicos usam uma thread e algoritmos determinísticos; MKLDNN é desativado onde aplicável. Cada asset promovido foi gerado em duas execuções independentes e comparado byte a byte com o asset distribuído. Evidência: `evaluation/REPRODUCIBILITY_V05.json`.

## Materialização de datasets

`python3 training/materialize_datasets.py` deve ser executado quando o gerador muda. `tests/verify_materialized_datasets.py` compara bytes dos snapshots distribuídos com a saída atual dos geradores, impedindo dataset stale.

## Comando canônico

```bash
python3 training/train_release.py
```

Esse fluxo materializa dados e treina somente os três especialistas neurais promovidos. Scripts de response-policy/reranker rejeitados foram removidos da release.

## 4. Open Knowledge NDOS v1 — materialização, não treino neural

A v0.6.0-alpha.2 adiciona `training/build_open_knowledge_shard.py`. Esse builder **não treina uma rede**. Ele materializa um índice TF-IDF determinístico a partir de 31 pares humanos Pirá 2.0.

- input: `training/data/open_knowledge/pira_reconstruction_records_v1.jsonl`;
- output: `models/neuraldesk-open-knowledge-pira-v0.6.ndos`;
- parâmetros neurais: 0;
- buckets: 65.536;
- top-k: 96;
- thresholds: score 0,33 / margin 0,08;
- rebuild: 2× byte-idêntico ao asset canônico.

As paráfrases humanas de validação e holdout não entram no asset. Campos automáticos do Pirá e o test split não são usados.

## Gate do gerador versus gate da release

Retriever e Pointer agora bloqueiam exportação quando o Golden obrigatório não atinge 100%; Relation Classifier mantém >=99% por `question`, `sentence` e `unknown`. Esses checks impedem sobrescrever um path promovível com candidato claramente inferior, mas **não substituem** `scripts/verify.sh`, reprodução byte-idêntica, testes C, holdouts e sanitizer.

## v0.6.1: nenhuma nova campanha de pesos

A Conversational Correctness & Semantic Planning v0.6.1 altera orquestração e gates, **não** datasets promovidos ou checkpoints. Os assets retriever/relation/pointer continuam exatamente os bytes v0.5, e o NDOS continua exatamente o asset reconstruído alpha.2. Qualquer futura mudança de pesos volta a exigir duas reproduções byte-idênticas e todos os Goldens/holdouts correspondentes.


## Weight averaging v0.7.2

`training/weight_averaging.py` transforma dois ou mais checkpoints integrity-bound compatíveis em um `AVERAGING_CANDIDATE_NOT_PROMOTED`. Bindings, model keys, shapes e dtypes devem coincidir; source checkpoints permanecem imutáveis. A ferramenta não faz claim de qualidade e não substitui `scripts/model_authority.py`.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
