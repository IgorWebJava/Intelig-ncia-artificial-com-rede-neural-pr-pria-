# Decisões Arquiteturais Correntes — V8.7

1. Interface e Neural Engine são camadas distintas.
2. Interface atual permanece V8.2; V8.7 é sincronização documental.
3. Neural Engine é documentation-only até fase explícita de implementação.
4. Módulos dependem de capabilities/contracts, nunca de implementações privadas.
5. Nenhum domain module depende diretamente de provider SDK.
6. Pesquisa externa é candidato/provider, não source of truth arquitetural.
7. Adoção de otimização exige benchmark local, qualidade, safety e rollback.
8. Toda mecânica de UI deve possuir futuros engine owners em traceability registry.
9. Memória, documentação e skills em arquivo são continuidade portátil e têm precedência sobre lembrança informal.
10. Cada release final deve ser entregue como um ZIP completo único e preservar versões anteriores.


## ADR-V8.7-01 — Parity before proprietary frontier-scale training

Decision: reach product parity first through provider-agnostic frontier model adapters, durable projects/memory, RAG, tools, agents and production control plane. NeuralDesk-owned models begin with specialized workloads; frontier-scale foundation-model research is a later evidence-gated program.

## ADR-V8.7-02 — Evidence-gated competitive claims

Decision: feature presence never proves superiority. Parity/differentiation/superiority states require reproducible benchmarks with quality and safety floors.

## ADR-V8.7-03 — Dependency waves over big-bang implementation

Decision: future Neural Engine implementation follows P00–P08 instead of building all 64 modules simultaneously.

## V8.8 — Kimi K3 Engineering Research Integration

Research from `FareedKhan-dev/kimi-k3-in-c`, the official `MoonshotAI/Kimi-K3` repository and the Kimi K3 technical report was integrated as provider-agnostic documentation. The Neural Engine remains non-executable. Key additions: memory-aware weight streaming, expert-weight cache, strict model artifact validation, deterministic/reference parity, KDA, Attention Residuals, Stable LatentMoE, expert balance training and long-horizon agentic RL.

## V8.9 — Native Omni-Modal Boundaries

- semantic reasoning/content and speech expression are separate governable capabilities;
- audio/video use a canonical absolute timebase;
- modality admission/degradation is explicit;
- backend modality support is negotiated, never assumed;
- multimodal training is subject to per-modality non-regression gates.


## V8.10 — DeepSeek Harness Agent Runtime Architecture Integration

- Documentation-only release; canonical V8.2 interface unchanged.
- Neural Engine: 94 future modules / 391 capabilities.
- Added semantic session durability, replay, guarded tool effects, provider-federated subagents, compaction/spill, schema evolution, runtime invariants, benchmark ablation and governed dynamic extension patterns.
- No Neural Engine runtime/source implementation introduced.


## ADR V8.11 — Cooperative non-regressive Engine/UI evolution
Decision: all future evolution follows `preserve → extend → bridge`. V8.10 semantic UI baseline is protected automatically. Root aliases remain redirects. Every Neural Engine module requires an interface/headless owner. Engine Bridge is truthful local UI only and does not imply executable engine behavior.


### ADR-MEM-070 — Coding Task Packet + Green Contract
Autonomous coding work must begin from a typed Task Packet and cannot be declared complete without Green Contract evidence.

### ADR-MEM-071 — Branch freshness before blame
Verification/regression diagnosis must classify the branch as fresh/stale/diverged before attributing failures to the current change.

### ADR-MEM-072 — Recovery before escalation, bounded
Known coding-runtime failures may use a versioned recovery recipe for a bounded number of attempts; exhaustion escalates deterministically.

### ADR-MEM-073 — Coding operational telemetry stays out of model context by default
Worker/hook/Git lifecycle telemetry is routed as typed operational events and enters model context only when explicitly relevant.

## ADR-MEM-0V814 — AI Workspace patterns are additive and provider-neutral
**Decision:** integrate Open WebUI-derived patterns as independent NeuralDesk contracts under `open-webui-ai-workspace-patterns-v1`. No copied upstream source; legacy Pipelines are not adopted; extension execution must be isolated and authorized.
