<!-- neuraldesk-documentation-sync: V8.8 -->

# Data Ownership — neuraldesk.app-shell

    ## Owned data

    - `route_aliases`
- `navigation_preferences`

    ## Invariant

    This module is the authoritative owner of the mutable data listed above.

    Other modules must not query or write this module's private tables directly.

    ```text
    Other Module
    → Versioned API or Versioned Event
    → neuraldesk.app-shell
    → Owned Data
    ```

    External references use IDs/contracts, not cross-module database foreign keys.
