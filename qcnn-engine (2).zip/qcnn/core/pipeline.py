import time
from typing import List, Dict, Optional, Any
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext, CollapseResult

class QcnnPipeline:
    """
    Orquestrador Modular do Motor QCNN.
    Permite registrar, conectar e desconectar plugins dinamicamente.
    """

    def __init__(self):
        self._plugins: List[BaseQcnnPlugin] = []
        self._plugin_map: Dict[str, BaseQcnnPlugin] = {}

    def register_plugin(self, plugin: BaseQcnnPlugin) -> 'QcnnPipeline':
        """Conecta um novo plugin ao pipeline."""
        if plugin.plugin_id in self._plugin_map:
            self.unregister_plugin(plugin.plugin_id)
        self._plugins.append(plugin)
        self._plugin_map[plugin.plugin_id] = plugin
        return self

    def unregister_plugin(self, plugin_id: str) -> Optional[BaseQcnnPlugin]:
        """Desconecta um plugin pelo ID."""
        plugin = self._plugin_map.pop(plugin_id, None)
        if plugin and plugin in self._plugins:
            self._plugins.remove(plugin)
        return plugin

    def get_plugin(self, plugin_id: str) -> Optional[BaseQcnnPlugin]:
        return self._plugin_map.get(plugin_id)

    def list_plugins(self) -> List[str]:
        return [p.plugin_id for p in self._plugins]

    def process(self, prompt: str, metadata: Optional[Dict[str, Any]] = None) -> CollapseResult:
        """
        Executa todo o pipeline passando o contexto pelos plugins conectados.
        """
        start_ns = time.perf_counter_ns()
        context = QcnnExecutionContext(prompt=prompt.strip())
        if metadata:
            context.metadata.update(metadata)

        for plugin in self._plugins:
            if plugin.is_enabled:
                context = plugin.execute(context)

        end_ns = time.perf_counter_ns()
        context.latency_ms = (end_ns - start_ns) / 1_000_000.0

        return context.to_collapse_result()
