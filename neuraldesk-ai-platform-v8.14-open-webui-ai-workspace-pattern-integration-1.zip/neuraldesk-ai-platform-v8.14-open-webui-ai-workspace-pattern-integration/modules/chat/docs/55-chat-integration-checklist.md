<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 55 — Checklist de Integração do Chat

## Conversation
- [ ] create conversation
- [ ] history
- [ ] rename
- [ ] archive
- [ ] delete
- [ ] branch

## Context
- [ ] project
- [ ] memory
- [ ] files
- [ ] knowledge
- [ ] web
- [ ] tools

## AI
- [ ] model routing
- [ ] modes
- [ ] streaming
- [ ] stop
- [ ] continue
- [ ] retry
- [ ] regenerate

## Multimodal
- [ ] documents
- [ ] images
- [ ] audio
- [ ] video
- [ ] spreadsheet
- [ ] code

## Agentic
- [ ] agent activity
- [ ] tool calls
- [ ] approval
- [ ] research
- [ ] artifacts

## Governance
- [ ] auth
- [ ] permissions
- [ ] audit
- [ ] safe tool scopes
- [ ] citation traceability
- [ ] project isolation

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
