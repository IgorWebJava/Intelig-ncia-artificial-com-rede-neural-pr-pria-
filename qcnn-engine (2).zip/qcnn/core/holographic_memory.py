import time
import math
from typing import Dict, List, Any, Optional

class HolographicMemoryStore:
    """
    Repositório de Memória Holográfica Independente por Módulo/Subagente.
    Princípio Hermético-Fractal: "O que está dentro é como o que está fora".
    Cada módulo preserva seus próprios padrões, vetores de ativação e histórico.
    """

    def __init__(self, owner_id: str, dimension: int = 10000, capacity: int = 100):
        self.owner_id = owner_id
        self.dimension = dimension
        self.capacity = capacity
        self._records: List[Dict[str, Any]] = []
        self._concept_index: Dict[str, Dict[str, Any]] = {}

    def memorize(self, concept: str, frequency: float, state: str = "10 (Ativo)", 
                 vector_hdc: Optional[List[int]] = None, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Armazena uma memória estruturada com timestamp, frequência de ressonância e vetor HDC.
        """
        record = {
            "concept": concept,
            "frequency": frequency,
            "state": state,
            "vector_hdc": vector_hdc,
            "timestamp": time.time(),
            "metadata": metadata or {},
            "entropy": self._compute_entropy(concept, frequency)
        }
        
        self._records.append(record)
        self._concept_index[concept.lower().strip()] = record
        
        # Mantém a capacidade máxima proporcional
        if len(self._records) > self.capacity:
            oldest = self._records.pop(0)
            self._concept_index.pop(oldest["concept"].lower().strip(), None)
            
        return record

    def recall(self, concept: str) -> Optional[Dict[str, Any]]:
        """Recupera memória direta por conceito."""
        return self._concept_index.get(concept.lower().strip())

    def recall_by_frequency(self, target_hz: float, tolerance_hz: float = 20.0) -> List[Dict[str, Any]]:
        """Recupera memórias que ressoam em frequência harmônica próxima."""
        matches = []
        for rec in self._records:
            if abs(rec["frequency"] - target_hz) <= tolerance_hz:
                matches.append(rec)
        return matches

    def calculate_coherence(self) -> float:
        """
        Calcula o índice de coerência holográfica interna (0.0 a 1.0).
        Se a memória estiver vazia ou com alta dispersão, o índice diminui.
        """
        if not self._records:
            return 1.0
        entropies = [r.get("entropy", 0.0) for r in self._records]
        avg_entropy = sum(entropies) / len(entropies)
        return max(0.0, min(1.0, 1.0 - (avg_entropy / 10.0)))

    def snapshot(self) -> Dict[str, Any]:
        """Gera um snapshot fractal do estado da memória."""
        return {
            "owner_id": self.owner_id,
            "dimension": self.dimension,
            "records_count": len(self._records),
            "records": [dict(r) for r in self._records],
            "coherence": self.calculate_coherence()
        }

    def restore_from_snapshot(self, snapshot: Dict[str, Any]) -> bool:
        """Restaura a memória a partir de um snapshot espelho de outra camada."""
        if not snapshot or "records" not in snapshot:
            return False
        self._records = [dict(r) for r in snapshot["records"]]
        self._concept_index = {r["concept"].lower().strip(): r for r in self._records}
        return True

    def _compute_entropy(self, concept: str, freq: float) -> float:
        """Calcula a entropia informacional local da memória."""
        if not concept:
            return 5.0
        char_counts = {}
        for c in concept:
            char_counts[c] = char_counts.get(c, 0) + 1
        entropy = 0.0
        total_chars = len(concept)
        for count in char_counts.values():
            p = count / total_chars
            if p > 0:
                entropy -= p * math.log2(p)
        return float(entropy)

    def count(self) -> int:
        return len(self._records)
