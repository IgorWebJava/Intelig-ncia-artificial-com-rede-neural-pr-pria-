<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.documentation -->
# Project Glossary — NeuralDesk

- **Canonical Module** — replaceable package under `modules/<module>/`.
- **Capability** — stable public functional dependency resolved by registries.
- **Contract** — versioned API/event/config/UI agreement.
- **Intelligence Experience** — `intelligence-experience-v2`, the V8.2 cross-module experience language.
- **Workspace Runtime** — `workspace-runtime-v2`, module-owned browser interaction profile.
- **Intelligence Design System** — `neuraldesk-intelligence-design-v2`.
- **Context Lens** — project/resource context surface shared across modules.
- **Provenance** — visual chain showing where a result/resource came from.
- **Trust Layer** — visual what/why/who/data/risk/permission/reversibility context.
- **Adaptive Inspector** — contextual side surface that can collapse/pin based on workspace/device.
- **Template-only** — surface implemented visually without claiming production backend execution.
- **Artifact Workspace** — output/work surface associated with Chat/project work.
- **Runtime Agent Skill** — user-agent capability package under `platform/agent-skill-registry/`; not the same as development `habilidades/`.
- **Module Preview** — generated browser image stored with the module.
- **Current Documentation** — `CURRENT_*` and module `CURRENT_STATE.md` documents.
- **Historical Baseline** — versioned documentation preserved for evolution history and not authoritative for current state.

- **Frontier Competitive Readiness** — V8.7 documentation program that converts gaps into phased executable requirements and evidence gates.
- **D0–D6** — future Neural Engine maturity ladder from documented to differentiated.
- **UI0–UI6** — future interface/runtime readiness ladder from template to differentiated executable workflow.
- **Parity Target** — market capability that NeuralDesk intends to match; not a proven claim.
- **Differentiation Target** — intended NeuralDesk advantage awaiting evidence.
- **Superiority Claim** — permitted only for a defined workload after reproducible benchmark evidence.
- **Implementation Wave** — dependency stage P00–P08 used to avoid building all engine modules simultaneously.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
