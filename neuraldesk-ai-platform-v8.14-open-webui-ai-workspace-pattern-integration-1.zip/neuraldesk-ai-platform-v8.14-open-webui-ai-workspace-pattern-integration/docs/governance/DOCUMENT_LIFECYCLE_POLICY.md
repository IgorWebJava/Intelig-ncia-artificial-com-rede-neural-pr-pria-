<!-- neuraldesk-documentation-sync: V8.8 -->
# Documentation Lifecycle Policy — V8.7

Every documentation artifact is classified as one of:

- **CURRENT** — authoritative current state.
- **REFERENCE-DETAIL** — useful detailed/domain material reviewed against CURRENT state but not authoritative on conflicts.
- **HISTORICAL-BASELINE** — preserved historical release/baseline.
- **VERIFICATION-EVIDENCE** — generated release/test evidence.
- **MACHINE-READABLE/SUPPORTING** — registries, schemas, manifests, SQL or support artifacts.

## Conflict precedence

CURRENT > REFERENCE-DETAIL > HISTORICAL-BASELINE.

## Review rule

A reference document can retain older terminology for historical/detail value, but it must be classified and point to its CURRENT state source. Current documents must carry the active synchronization release.
