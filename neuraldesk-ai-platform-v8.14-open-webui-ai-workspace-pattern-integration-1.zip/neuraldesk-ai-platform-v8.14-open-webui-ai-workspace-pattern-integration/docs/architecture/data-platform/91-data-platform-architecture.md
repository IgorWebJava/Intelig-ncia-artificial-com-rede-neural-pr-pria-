<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 91 — NeuralDesk Data Platform Architecture

```text
Clients / Pages
      ↓
API Gateway / BFF
      ↓
Application & Domain Services
      ↓
PostgreSQL SSOT
      ↓
Transactional Outbox
      ↓
Event Stream
      ↓
Consumers / Neural Runtime / Read Models
```

The relational database is authoritative for durable configuration and transactional state.

Specialized storage can exist for files, vectors, cache and telemetry.
