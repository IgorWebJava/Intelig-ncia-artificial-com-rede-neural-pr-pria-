import unittest
import sys
import os
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.core.pipeline import QcnnPipeline
from qcnn.plugins.ternary_bitwise import TernaryBitwisePlugin
from qcnn.plugins.milui_expansion import MiluiExpansionPlugin
from qcnn.plugins.adjacency_filter import AdjacencyFilterPlugin
from qcnn.plugins.harmonic_frequency import HarmonicFrequencyPlugin
from qcnn.plugins.hyperdimensional_computing import HyperdimensionalComputingPlugin
from qcnn.plugins.fractal_grammar import FractalGrammarPlugin
from qcnn.plugins.continuous_ingestion import ContinuousIngestionPlugin
from qcnn.plugins.assistant_toolkit import AssistantToolkitPlugin
from qcnn.plugins.multiverse_oracle import MultiverseOraclePlugin
from qcnn.plugins.mycelium_index import MyceliumIndexPlugin
from qcnn.plugins.conceptual_dialogue import ConceptualDialoguePlugin
from qcnn.plugins.organ_multiplexer import OrganMultiplexerPlugin
from qcnn.plugins.octave_regulator import OctaveRegulatorPlugin
from qcnn.plugins.fractal_breaker import FractalBreakerPlugin
from qcnn.plugins.context_crystallizer import ContextCrystallizerPlugin
from qcnn.plugins.metacognitive_auditor import MetaCognitiveAuditorPlugin
from qcnn.plugins.telemetry_meter import TelemetryMeterPlugin

class TestFullIntegratedPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pipeline = QcnnPipeline()
        cls.pipeline.register_plugin(TernaryBitwisePlugin())
        cls.pipeline.register_plugin(MiluiExpansionPlugin())
        cls.pipeline.register_plugin(AdjacencyFilterPlugin())
        cls.pipeline.register_plugin(HarmonicFrequencyPlugin())
        cls.pipeline.register_plugin(HyperdimensionalComputingPlugin(dimension=10000))
        cls.pipeline.register_plugin(FractalGrammarPlugin())
        cls.pipeline.register_plugin(ContinuousIngestionPlugin(knowledge_dir="./conhecimento_local"))
        cls.pipeline.register_plugin(AssistantToolkitPlugin(storage_dir="./storage_android"))
        cls.pipeline.register_plugin(MultiverseOraclePlugin())
        cls.pipeline.register_plugin(MyceliumIndexPlugin())
        cls.pipeline.register_plugin(ConceptualDialoguePlugin(pasta_conhecimento="./conhecimento_local"))
        cls.pipeline.register_plugin(OrganMultiplexerPlugin())
        cls.pipeline.register_plugin(OctaveRegulatorPlugin())
        cls.pipeline.register_plugin(FractalBreakerPlugin())
        cls.pipeline.register_plugin(ContextCrystallizerPlugin(storage_dir="./storage_android"))
        cls.pipeline.register_plugin(MetaCognitiveAuditorPlugin())
        cls.pipeline.register_plugin(TelemetryMeterPlugin())

    def test_pipeline_composition(self):
        self.assertEqual(len(self.pipeline.list_plugins()), 17)

    def test_milui_seed_turn(self):
        res = self.pipeline.process("Descompactar semente Alef")
        self.assertIn("Alef", res.resposta)
        self.assertIn("Hz", res.frequencia)
        self.assertIn("ms", res.latencia)
        self.assertTrue(len(res.arvore) > 0)

    def test_math_calculation_turn(self):
        res = self.pipeline.process("Calcule 15 * 85 + 45")
        self.assertIn("1320", res.resposta)
        self.assertEqual(res.estado, "10 (Ativação Construtiva)")

    def test_unit_conversion_turn(self):
        res = self.pipeline.process("Converta 100 km em milhas")
        self.assertIn("62.14", res.resposta)

    def test_workflow_planner_turn(self):
        res = self.pipeline.process("Crie um plano de ação para desenvolver um robô autônomo")
        self.assertIn("Fase 1", res.resposta)
        self.assertIn("Fase 2", res.resposta)
        self.assertIn("Fase 3", res.resposta)
        self.assertIn("Fase 4", res.resposta)

    def test_multiverse_oracle_decision_turn(self):
        meta = {
            "prisma_risco": 0.85,
            "filosofia": "Estoicismo",
            "rigor_logico": 0.90
        }
        res = self.pipeline.process("Devo expandir a infraestrutura agora ou aguardar?", metadata=meta)
        self.assertEqual(res.estado, "11 (Superposição Multiverso Colapsada)")
        self.assertIn("alpha", res.metadata["multiverse_data"]["cenarios"][0]["id"].lower())
        self.assertTrue("coerencia_simbolica" in res.metadata["meta_cognition"])

    def test_conceptual_natural_dialogue_turn(self):
        res = self.pipeline.process("Fale sobre o conceito de gravidade e relatividade")
        self.assertTrue(len(res.resposta) > 0)
        self.assertIn("Hz", res.frequencia)

if __name__ == "__main__":
    unittest.main()
