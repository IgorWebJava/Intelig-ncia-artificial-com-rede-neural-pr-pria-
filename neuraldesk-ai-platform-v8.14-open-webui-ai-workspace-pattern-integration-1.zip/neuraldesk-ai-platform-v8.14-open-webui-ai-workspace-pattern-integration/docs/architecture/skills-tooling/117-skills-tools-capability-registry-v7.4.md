<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 117 — Skills, Tools & Development Capability Registry — V7.4

The NeuralDesk now has a portable development knowledge layer:

```text
habilidades/
```

It records how to build/validate/release the project, while `memória/` records what the project is and why.

Canonical principle:

```text
Development Need
→ Abstract Capability
→ Current Tool Provider
→ Workflow
→ Quality Gate
```

Concrete tools are replaceable.
