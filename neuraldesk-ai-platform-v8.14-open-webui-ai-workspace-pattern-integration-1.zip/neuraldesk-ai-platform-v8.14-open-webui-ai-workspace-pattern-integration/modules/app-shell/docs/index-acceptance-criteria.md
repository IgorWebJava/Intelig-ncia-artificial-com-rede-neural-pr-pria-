<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CURRENT_STATE.md -->
# Index — Critérios de Aceitação

- [x] `modules/app-shell/ui/index.html` é launcher opcional.
- [x] Carrega somente `modules/app-shell/ui/index.css`.
- [x] Não contém conteúdo funcional das demais páginas.
- [x] Todas as páginas principais podem ser abertas sem o index.
- [x] Não possui JavaScript.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/app-shell/
UI:        modules/app-shell/ui/index.html
CSS:       modules/app-shell/ui/index.css
Manifest:  modules/app-shell/module.manifest.json
Contracts: modules/app-shell/contracts/
Data:      modules/app-shell/data/
Docs:      modules/app-shell/docs/
```

The root `index.html` file, when present, is only a backward-compatible route alias.
