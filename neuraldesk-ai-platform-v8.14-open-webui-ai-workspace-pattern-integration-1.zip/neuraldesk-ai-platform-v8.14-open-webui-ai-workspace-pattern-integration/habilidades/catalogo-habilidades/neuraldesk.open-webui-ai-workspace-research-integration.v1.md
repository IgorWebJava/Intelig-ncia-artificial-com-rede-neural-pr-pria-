# neuraldesk.open-webui-ai-workspace-research-integration.v1

## Purpose
Research AI workspace platforms and integrate useful patterns into NeuralDesk as independent, provider-neutral contracts without copying upstream code or weakening existing architecture.

## Required workflow
1. Verify current primary sources and license.
2. Classify adopt / adapt / reject.
3. Preserve existing semantic baseline.
4. Extend engine blueprint + UI bridge + tests.
5. Keep truth boundary explicit.
6. Run full release gates.
