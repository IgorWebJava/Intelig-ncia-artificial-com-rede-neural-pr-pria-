<!-- neuraldesk-documentation-sync: V8.11 -->
# Cooperative Non-Regression Engine/UI Evolution

Preserve existing semantic mechanics, extend additively, bridge future engine state to UI, validate baseline and update memory/docs/registries/tests/previews together.
