<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Agent Governance V7.5

User-created agents must be project-scoped, permission-controlled, versioned, auditable and evaluated. System agents/templates are cloned/forked into project scope before editable customization. Soft delete precedes permanent purge and dependency check is required.
