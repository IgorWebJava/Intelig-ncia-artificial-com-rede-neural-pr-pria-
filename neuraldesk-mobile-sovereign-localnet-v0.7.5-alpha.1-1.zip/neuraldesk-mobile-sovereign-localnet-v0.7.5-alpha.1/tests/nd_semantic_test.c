#include "nd_semantic.h"
#include <stdio.h>
#include <string.h>

static int check(const char *q, NDIntent want) {
    NDSemanticFrame f;
    if (nd_semantic_analyze(q, &f)) return 1;
    if (f.intent != want) {
        fprintf(stderr, "semantic mismatch q=%s got=%s want=%d\n", q, nd_semantic_intent_name(f.intent), (int)want);
        return 1;
    }
    return 0;
}

int main(void) {
    int fail = 0;
    fail += check("Explique em duas frases o que você consegue fazer neste celular e seu principal limite.", ND_INTENT_ROLE_CAPABILITIES);
    fail += check("Qual a diferença entre treinamento, validação e inferência?", ND_INTENT_DEFINE_INFERENCE);
    fail += check("Os pesos aprendem automaticamente durante a inferência?", ND_INTENT_WEIGHT_UPDATE);
    fail += check("O que RAG quer dizer?", ND_INTENT_DEFINE_RAG);
    fail += check("Quantização e KV cache resolvem a mesma coisa?", ND_INTENT_COMPARE_QUANT_KV);
    fail += check("Quem venceu a Copa do Brasil de 2026?", ND_INTENT_DYNAMIC_EVENT);
    fail += check("Resuma este contexto em duas frases.", ND_INTENT_SUMMARY_CONTEXT);
    fail += check("Resuma os últimos turnos da conversa.", ND_INTENT_SUMMARY_HISTORY);
    fail += check("Escreva um poema original curto.", ND_INTENT_CREATIVE);
    fail += check("42 respostas corretas de 50 correspondem a qual porcentagem?", ND_INTENT_PERCENTAGE);
    fail += check("Isso prova que qualquer outra técnica está necessariamente errada?", ND_INTENT_NON_ENTAILMENT);
    if (fail) return 1;
    puts("SEMANTIC_CORE PASS cases=11");
    return 0;
}
