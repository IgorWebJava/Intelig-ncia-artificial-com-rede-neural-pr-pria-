#include "nd_pilot.h"

#include <string.h>

static void record_event(NDPilotControl *c, unsigned action, int feature, int64_t ts) {
    if (!c) return;
    if (c->audit_count == ND_PILOT_AUDIT_CAP) {
        memmove(&c->audit[0], &c->audit[1], (ND_PILOT_AUDIT_CAP - 1u) * sizeof(c->audit[0]));
        c->audit_count--;
    }
    c->audit[c->audit_count].timestamp = ts;
    c->audit[c->audit_count].action = action;
    c->audit[c->audit_count].feature = feature;
    c->audit_count++;
}

void nd_pilot_init(NDPilotControl *c) {
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->enabled_mask = (1u << ND_PILOT_FEATURE_COUNT) - 1u;
}

int nd_pilot_allowed(const NDPilotControl *c, NDPilotFeature feature) {
    if (!c || feature < 0 || feature >= ND_PILOT_FEATURE_COUNT || c->master_kill) return 0;
    return (c->enabled_mask & (1u << (unsigned)feature)) != 0u;
}

int nd_pilot_set_feature(NDPilotControl *c, NDPilotFeature feature, int enabled, int64_t ts) {
    if (!c || feature < 0 || feature >= ND_PILOT_FEATURE_COUNT) return -1;
    if (enabled) c->enabled_mask |= (1u << (unsigned)feature);
    else c->enabled_mask &= ~(1u << (unsigned)feature);
    record_event(c, enabled ? 1u : 2u, (int)feature, ts);
    return 0;
}

int nd_pilot_set_master_kill(NDPilotControl *c, int enabled, int64_t ts) {
    if (!c) return -1;
    c->master_kill = enabled ? 1 : 0;
    record_event(c, c->master_kill ? 3u : 4u, -1, ts);
    return 0;
}

const char *nd_pilot_feature_name(NDPilotFeature feature) {
    static const char *names[] = {
        "localInference", "imagePreprocessing", "durableTasks",
        "localUtilities", "artifactManager", "benchmarkExport"
    };
    if (feature < 0 || feature >= ND_PILOT_FEATURE_COUNT) return "UNKNOWN";
    return names[(unsigned)feature];
}
