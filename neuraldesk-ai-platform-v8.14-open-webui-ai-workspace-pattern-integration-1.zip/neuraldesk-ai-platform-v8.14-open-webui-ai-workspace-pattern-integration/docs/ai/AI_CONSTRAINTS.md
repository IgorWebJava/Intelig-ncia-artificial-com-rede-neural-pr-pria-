<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.ai-handoff; current: docs/ai/AI_CONSTRAINTS.md -->
# AI Constraints

- preserve `intelligence-experience-v2` / `workspace-runtime-v2` / `neuraldesk-intelligence-design-v2` unless deliberately versioning them;
- no direct browser DB credentials;
- no provider SDK in module/browser runtime;
- no private cross-module table access;
- no shared global executable JS dependency;
- no secrets or private chain-of-thought in docs/skills;
- no claims of production backend/AI/tool/agent execution from template-only states;
- no regression of responsive, multimodal, accessibility, density, Context, Provenance or Trust surfaces;
- root HTML aliases are not canonical implementations;
- runtime Agent Skills and development `habilidades/` remain distinct;
- previous releases are immutable baselines.

## V8.7 frontier readiness

Before planning executable Neural Engine work, read:
- `../frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
- `../frontier-readiness/EXECUTION_ROADMAP.md`
- `../../neural-engine/registry/frontier-readiness.json`

Treat `D0`, `UI0`, parity targets and differentiation targets as documentation states, never as implemented capabilities.



## V8.10 agent-harness research
Before implementing project/session/agent/tool runtime behavior, read `neural-engine/research/deepseek-harness-2026/README.md`, the 12 modules under `neural-engine/modules/11-agent-harness-runtime/`, and the semantic durability/session evolution strategies. Preserve the documentation-only boundary until an executable-engine release is explicitly authorized.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.


## Engine ↔ UI Bridge V8.11
Before changing interface or engine docs, inspect `platform/engine-ui-bridge/registry.json` and run both non-regression/compatibility gates. Do not mark engine states executable while `neural_engine_code_status` is `NOT_IMPLEMENTED`.


## V8.11 non-regression constraints

- `preserve → extend → bridge` is mandatory.
- Root HTML aliases remain compatibility redirects.
- Do not remove route/tab/action/capability semantics captured by the V8.10 baseline without an explicit migration.
- Every future engine module must remain mapped to a UI/headless owner.
- Engine Bridge local simulation must never be represented as real Neural Engine execution.
