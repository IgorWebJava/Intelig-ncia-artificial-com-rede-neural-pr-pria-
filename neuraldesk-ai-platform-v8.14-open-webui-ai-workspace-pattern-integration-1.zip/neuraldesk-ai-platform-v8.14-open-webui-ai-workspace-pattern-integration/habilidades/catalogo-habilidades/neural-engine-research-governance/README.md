<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Neural Engine Research & Benchmark Governance

Use primary technical repositories/papers as research evidence, then require local correctness, quality, performance, resource, safety and rollback evidence before adoption.
