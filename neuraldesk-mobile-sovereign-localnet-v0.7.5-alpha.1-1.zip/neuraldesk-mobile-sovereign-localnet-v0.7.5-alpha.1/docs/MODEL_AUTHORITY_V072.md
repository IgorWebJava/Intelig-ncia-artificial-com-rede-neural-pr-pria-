# Model Authority — v0.7.2-alpha.1

The Ed25519 model authority remains separate from training and activation. v0.7.2 revalidates the unchanged canonical five active assets plus the Semantic Ranker, then emits version-bound promotion and activation evidence. The private key is never bundled.

Weight averaging introduced in v0.7.2 can only create `AVERAGING_CANDIDATE_NOT_PROMOTED`. A candidate produced by averaging has no runtime authority until independent quality gates and `scripts/model_authority.py` promote it. Promotion still does not automatically authorize public/production serving or hardware promotion.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
