<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# End-to-End Reference Architecture

```text
USER INTENT
    |
EXPERIENCE / PROJECT CONTEXT
    |
GOAL CONTRACT
    |
ASSISTANT ORCHESTRATOR
    |
PLANNER + POLICY + CONTEXT COMPILER
    |
CAPABILITY RESOLUTION
    |
+----------------+----------------+----------------+
|                |                |                |
AGENTS          TOOLS          KNOWLEDGE         MODELS
|                |                |                |
+----------------+----------------+----------------+
                 |
             TASK RUNTIME
                 |
     CHECKPOINT / BACKGROUND JOBS
                 |
        SANDBOX / EXECUTION
                 |
             VERIFICATION
                 |
              ARTIFACT
                 |
       PROVENANCE + AUDIT
                 |
              DELIVERY
```

## Data plane

PostgreSQL-like relational SSOT for durable transactional state; event stream/outbox for integration; object storage for files/media; vector/index systems for retrieval; cache for ephemeral acceleration; observability backend for telemetry.

## Model plane

```text
AI Capability
   -> Model Router
      -> External Provider Adapter
      -> Self-hosted Serving Adapter
      -> Portable Local Adapter
      -> NeuralDesk-owned Model Adapter
```

No product module depends directly on a provider SDK.

## Execution plane

Side effects require identity, authorization, policy and idempotency. High-risk operations require approval. Every external action receives correlation/provenance identifiers.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
