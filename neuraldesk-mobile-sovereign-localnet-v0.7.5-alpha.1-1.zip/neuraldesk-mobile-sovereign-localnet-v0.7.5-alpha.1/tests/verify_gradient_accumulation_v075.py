#!/usr/bin/env python3
import hashlib, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'verification/GRADIENT_ACCUMULATION_V075.json'
T=ROOT/'training/pretrain_generative_micro_v074_v3_data_scale_v2.py'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
o=json.loads(E.read_text(encoding='utf-8'))
assert o['status']=='PASS_MODEL_OPTIMIZER_AND_STAGED_FORMATS_EQUAL'
assert o['promotionAuthorized'] is False
tr=o['trainer']
assert sha(T)==tr['sha256']
assert tr['microBatchSize']==8 and tr['accumulationSteps']==8 and tr['effectiveBatchSize']==64
assert tr['effectiveRichPerUpdate']==8 and tr['effectiveContextPerUpdate']==56
assert tr['checkpointAtOptimizerBoundaryOnly'] is True
src=T.read_text(encoding='utf-8')
for needle in [
 "SCHEMA_CONFIG='nd-v075-micro-v3-data-scale-pretrain-v2-accum-config-v1'",
 "if a.checkpoint_every_batches and a.checkpoint_every_batches % a.accumulation_steps != 0",
 "if a.run_batch_budget and a.run_batch_budget % a.accumulation_steps != 0",
 "(z/float(group)).backward()",
 "torch.nn.utils.clip_grad_norm_",
 "opt.step()",
]: assert needle in src, needle
b=o['bindings']
for rel,key in [
 ('training/data/generative_v074_v2/tokenizer-v2.ndtk','tokenizerSha256'),
 ('training/data/generative_v074_v2/causal_replay.jsonl','causalReplaySha256'),
 ('training/data/generative_v074_v2/token_cache_v2/rich_replay.ndtc','richCacheSha256'),
 ('training/data/generative_v074_v2/token_cache_v2/context_replay.ndtc','contextCacheSha256'),
]: assert sha(ROOT/rel)==b[key], rel
d=o['debugCampaign']
for a,bk in [
 ('pauseBoundaryCheckpointSha256Uninterrupted','pauseBoundaryCheckpointSha256Paused'),
 ('finalModelStateSha256Uninterrupted','finalModelStateSha256Resumed'),
 ('finalOptimizerStateSha256Uninterrupted','finalOptimizerStateSha256Resumed'),
 ('fp32Sha256Uninterrupted','fp32Sha256Resumed'),
 ('q8Sha256Uninterrupted','q8Sha256Resumed'),
 ('q4Sha256Uninterrupted','q4Sha256Resumed'),
]: assert d[a]==d[bk], (a,bk)
assert d['optimizerUpdates']==2 and d['debugRichRows']==16 and d['debugContextRows']==112
print('GRADIENT_ACCUMULATION_V075 PASS micro=8 accumulation=8 effective=64 model_adamw_fp32_q8_q4_equal=true checkpointBoundaryOnly=true')
