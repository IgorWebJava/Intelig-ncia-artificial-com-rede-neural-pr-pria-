<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.storage.object-storage

Replaceable adapter template.

Provides:
- `media.object.store.v1`

Domain modules must never import this adapter implementation directly.
Binding occurs through the corresponding platform gateway/registry.
