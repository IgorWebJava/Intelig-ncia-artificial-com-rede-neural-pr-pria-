#include "nd_memory.h"

#include <ctype.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ND_MEMORY_MAGIC 0x314d444eu /* NDM1 */
#define ND_MEMORY_VERSION 1u
#define ND_MAX_TERMS 96u
#define ND_TERM_BYTES 72u

typedef struct {
    char s[ND_TERM_BYTES];
    size_t n;
} Term;

static void seterr(char *e, size_t n, const char *fmt, ...) {
    if (!e || !n) return;
    va_list a;
    va_start(a, fmt);
    vsnprintf(e, n, fmt, a);
    va_end(a);
}

static unsigned char lo(unsigned char c) {
    return (c >= (unsigned char)'A' && c <= (unsigned char)'Z')
               ? (unsigned char)(c + ('a' - 'A'))
               : c;
}

static int starts_ci(const char *s, const char *prefix) {
    while (*prefix) {
        if (!*s || lo((unsigned char)*s) != lo((unsigned char)*prefix)) return 0;
        s++;
        prefix++;
    }
    return 1;
}

static int equals_ci(const char *a, const char *b) {
    while (*a && *b) {
        if (lo((unsigned char)*a) != lo((unsigned char)*b)) return 0;
        a++;
        b++;
    }
    return *a == 0 && *b == 0;
}

static const char *skip_space(const char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    return s;
}


static const char *find_ci_memory(const char *s, const char *needle) {
    size_t n = strlen(needle);
    if (!n) return s;
    for (; *s; s++) {
        size_t i = 0u;
        while (i < n && s[i] && lo((unsigned char)s[i]) == lo((unsigned char)needle[i])) i++;
        if (i == n) return s;
    }
    return NULL;
}

static int contains_ci_memory(const char *s, const char *needle) {
    return find_ci_memory(s, needle) != NULL;
}

static int copy_trimmed_range(const char *begin, const char *end, char *out, size_t cap) {
    while (begin < end && isspace((unsigned char)*begin)) begin++;
    while (end > begin && (isspace((unsigned char)end[-1]) || end[-1] == '.' || end[-1] == ',' || end[-1] == ';')) end--;
    size_t n = (size_t)(end - begin);
    if (!n || n + 1u > cap) return 0;
    memcpy(out, begin, n);
    out[n] = 0;
    return 1;
}

static int extract_structured_subject(const char *text, char *out, size_t cap) {
    size_t n = strlen(text), i = 0u;
    while (i < n) {
        while (i < n && !isalnum((unsigned char)text[i]) && (unsigned char)text[i] < 128u) i++;
        size_t j = i;
        int alpha = 0, digit = 0, separator = 0;
        while (j < n && (isalnum((unsigned char)text[j]) || text[j] == '-' || text[j] == '_' || (unsigned char)text[j] >= 128u)) {
            unsigned char c = (unsigned char)text[j];
            if (isalpha(c) || c >= 128u) alpha = 1;
            if (isdigit(c)) digit = 1;
            if (c == '-' || c == '_') separator = 1;
            j++;
        }
        if (j > i && alpha && digit && separator) return copy_trimmed_range(text + i, text + j, out, cap);
        i = j > i ? j : i + 1u;
    }
    return 0;
}

static void add_fact(NDMemory *m, size_t entry_index, const char *subject,
                     const char *relation, const char *value) {
    if (!m || m->fact_count >= ND_MEMORY_MAX_FACTS || !subject || !relation || !value || !*value) return;
    for (size_t i = 0; i < m->fact_count; i++) {
        NDMemoryFact *f = &m->facts[i];
        if (equals_ci(f->subject, subject) && equals_ci(f->relation, relation) && equals_ci(f->value, value)) return;
    }
    NDMemoryFact *f = &m->facts[m->fact_count++];
    memset(f, 0, sizeof(*f));
    snprintf(f->subject, sizeof(f->subject), "%s", subject);
    snprintf(f->relation, sizeof(f->relation), "%s", relation);
    snprintf(f->value, sizeof(f->value), "%s", value);
    f->entry_index = entry_index;
}

typedef struct {
    const char *pattern;
    const char *relation;
} FactPattern;

static void derive_facts_from_entry(NDMemory *m, size_t entry_index) {
    static const FactPattern patterns[] = {
        {"usa sensor ", "sensor"},
        {"usa rodas de ", "material"},
        {"rodas de ", "material"},
        {"é feito de ", "material"},
        {"e feito de ", "material"},
        {"material é ", "material"},
        {"utiliza sensor ", "sensor"},
        {"usa bateria de ", "battery"},
        {"usa bateria ", "battery"},
        {"a coordenadora é ", "coordinator"},
        {"o coordenador é ", "coordinator"},
        {"a coordenadora e ", "coordinator"},
        {"o coordenador e ", "coordinator"},
        {"é coordenado por ", "coordinator"},
        {"é coordenada por ", "coordinator"},
        {"e coordenado por ", "coordinator"},
        {"e coordenada por ", "coordinator"},
        {"coordenado por ", "coordinator"},
        {"coordenada por ", "coordinator"},
        {"a responsável é ", "responsible"},
        {"o responsável é ", "responsible"},
        {"responsável é ", "responsible"},
        {"responsavel é ", "responsible"},
        {"sob responsabilidade de ", "responsible"},
        {"usa o código ", "code"},
        {"usa o codigo ", "code"},
        {"código é ", "code"},
        {"codigo é ", "code"},
        {"versão é ", "version"},
        {"versao é ", "version"}
    };
    if (!m || entry_index >= m->count || !m->entries[entry_index].text) return;
    const char *text = m->entries[entry_index].text;
    char subject[ND_MEMORY_SUBJECT_BYTES];
    if (!extract_structured_subject(text, subject, sizeof(subject))) return;
    for (size_t i = 0; i < sizeof(patterns) / sizeof(patterns[0]); i++) {
        const char *hit = find_ci_memory(text, patterns[i].pattern);
        if (!hit) continue;
        const char *v = hit + strlen(patterns[i].pattern);
        while (*v && isspace((unsigned char)*v)) v++;
        if (strcmp(patterns[i].pattern, "usa bateria ") == 0 && starts_ci(v, "de ")) continue;
        const char *end = v + strlen(v);
        for (const char *p = v; *p; p++) {
            if (*p == '.' || *p == ';' || *p == ',') {
                end = p;
                break;
            }
            if (p[0] == ' ' && lo((unsigned char)p[1]) == 'e' && p[2] == ' ') {
                end = p;
                break;
            }
        }
        char value[ND_MEMORY_VALUE_BYTES];
        if (copy_trimmed_range(v, end, value, sizeof(value))) add_fact(m, entry_index, subject, patterns[i].relation, value);
    }
}

static void rebuild_facts(NDMemory *m) {
    if (!m) return;
    memset(m->facts, 0, sizeof(m->facts));
    m->fact_count = 0u;
    for (size_t i = 0; i < m->count; i++) derive_facts_from_entry(m, i);
}

static const char *query_relation(const char *q) {
    if (contains_ci_memory(q, "sensor")) return "sensor";
    if (contains_ci_memory(q, "quem coordena") || contains_ci_memory(q, "coordenador") ||
        contains_ci_memory(q, "coordenadora") || contains_ci_memory(q, "coordenado por quem") ||
        contains_ci_memory(q, "coordenada por quem")) return "coordinator";
    if (contains_ci_memory(q, "bateria")) return "battery";
    if (contains_ci_memory(q, "material") || contains_ci_memory(q, "rodas")) return "material";
    if (contains_ci_memory(q, "responsável") || contains_ci_memory(q, "responsavel") ||
        contains_ci_memory(q, "responsabilidade")) return "responsible";
    if (contains_ci_memory(q, "código") || contains_ci_memory(q, "codigo")) return "code";
    if (contains_ci_memory(q, "versão") || contains_ci_memory(q, "versao")) return "version";
    return NULL;
}

static char *dup_trim(const char *s) {
    s = skip_space(s);
    const char *end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - s);
    if (!n || n >= ND_MEMORY_TEXT_BYTES) return NULL;
    char *p = (char *)malloc(n + 1u);
    if (!p) return NULL;
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

void nd_memory_init(NDMemory *m) {
    if (!m) return;
    memset(m, 0, sizeof(*m));
}

void nd_memory_free(NDMemory *m) {
    if (!m) return;
    for (size_t i = 0; i < m->count; i++) free(m->entries[i].text);
    memset(m, 0, sizeof(*m));
}

int nd_memory_set_path(NDMemory *m, const char *path, char *e, size_t ec) {
    if (!m) {
        seterr(e, ec, "invalid memory object");
        return -1;
    }
    if (!path || !*path) {
        m->path[0] = 0;
        return 0;
    }
    size_t n = strlen(path);
    if (n >= sizeof(m->path)) {
        seterr(e, ec, "memory path too long");
        return -1;
    }
    memcpy(m->path, path, n + 1u);
    return 0;
}

int nd_memory_load(NDMemory *m, const char *path, char *e, size_t ec) {
    if (!m) {
        seterr(e, ec, "invalid memory object");
        return -1;
    }
    nd_memory_free(m);
    nd_memory_init(m);
    if (nd_memory_set_path(m, path, e, ec)) return -1;
    if (!path || !*path) return 0;
    FILE *f = fopen(path, "rb");
    if (!f) return 0; /* first run: empty memory is valid */
    uint32_t h[3];
    if (fread(h, sizeof(uint32_t), 3, f) != 3 || h[0] != ND_MEMORY_MAGIC ||
        h[1] != ND_MEMORY_VERSION || h[2] > ND_MEMORY_MAX_ENTRIES) {
        fclose(f);
        seterr(e, ec, "invalid local memory header");
        return -1;
    }
    for (uint32_t i = 0; i < h[2]; i++) {
        uint32_t n = 0;
        if (fread(&n, sizeof(n), 1, f) != 1 || !n || n >= ND_MEMORY_TEXT_BYTES) {
            fclose(f);
            nd_memory_free(m);
            seterr(e, ec, "invalid local memory entry");
            return -1;
        }
        char *p = (char *)malloc((size_t)n + 1u);
        if (!p || fread(p, 1, n, f) != n) {
            free(p);
            fclose(f);
            nd_memory_free(m);
            seterr(e, ec, "truncated local memory entry");
            return -1;
        }
        p[n] = 0;
        m->entries[m->count++].text = p;
    }
    if (fgetc(f) != EOF) {
        fclose(f);
        nd_memory_free(m);
        seterr(e, ec, "trailing local memory bytes rejected");
        return -1;
    }
    fclose(f);
    rebuild_facts(m);
    return 0;
}

int nd_memory_save(const NDMemory *m, char *e, size_t ec) {
    if (!m) {
        seterr(e, ec, "invalid memory object");
        return -1;
    }
    if (!m->path[0]) return 0;
    char tmp[1100];
    int w = snprintf(tmp, sizeof(tmp), "%s.tmp", m->path);
    if (w < 0 || (size_t)w >= sizeof(tmp)) {
        seterr(e, ec, "memory temporary path too long");
        return -1;
    }
    FILE *f = fopen(tmp, "wb");
    if (!f) {
        seterr(e, ec, "cannot create local memory file");
        return -1;
    }
    uint32_t h[3] = {ND_MEMORY_MAGIC, ND_MEMORY_VERSION, (uint32_t)m->count};
    if (fwrite(h, sizeof(uint32_t), 3, f) != 3) goto io_fail;
    for (size_t i = 0; i < m->count; i++) {
        size_t zn = strlen(m->entries[i].text);
        if (!zn || zn >= ND_MEMORY_TEXT_BYTES || zn > UINT32_MAX) goto io_fail;
        uint32_t n = (uint32_t)zn;
        if (fwrite(&n, sizeof(n), 1, f) != 1 || fwrite(m->entries[i].text, 1, n, f) != n)
            goto io_fail;
    }
    if (fclose(f) != 0) {
        remove(tmp);
        seterr(e, ec, "cannot flush local memory file");
        return -1;
    }
    if (rename(tmp, m->path) != 0) {
        remove(tmp);
        seterr(e, ec, "cannot atomically replace local memory file");
        return -1;
    }
    return 0;
io_fail:
    fclose(f);
    remove(tmp);
    seterr(e, ec, "cannot write local memory file");
    return -1;
}

int nd_memory_clear(NDMemory *m, char *e, size_t ec) {
    if (!m) return -1;
    for (size_t i = 0; i < m->count; i++) free(m->entries[i].text);
    memset(m->entries, 0, sizeof(m->entries));
    memset(m->facts, 0, sizeof(m->facts));
    m->count = 0;
    m->fact_count = 0u;
    return nd_memory_save(m, e, ec);
}

static int isword(unsigned char c) {
    return isalnum(c) || c == (unsigned char)'-' || c >= 128u;
}

static int term_eq(const Term *a, const Term *b) {
    return a->n == b->n && memcmp(a->s, b->s, a->n) == 0;
}

static int stop(const Term *t) {
    static const char *sw[] = {
        "qual", "quais", "quem", "como", "onde", "quando", "porque", "por", "que",
        "uma", "umas", "uns", "para", "com", "sem", "sobre", "diga", "informe", "responda",
        "projeto", "sistema", "registro", "esta", "está", "este", "isso", "aquele", "aquela",
        "do", "da", "dos", "das", "no", "na", "nos", "nas", "de", "em", "ao", "aos"
    };
    for (size_t i = 0; i < sizeof(sw) / sizeof(sw[0]); i++) {
        size_t n = strlen(sw[i]);
        if (t->n == n && memcmp(t->s, sw[i], n) == 0) return 1;
    }
    return 0;
}

static size_t terms(const char *s, Term *out, size_t cap) {
    size_t n = strlen(s), i = 0, k = 0;
    while (i < n && k < cap) {
        while (i < n && !isword((unsigned char)s[i])) i++;
        size_t j = i;
        while (j < n && isword((unsigned char)s[j])) j++;
        if (j > i) {
            Term t;
            size_t z = j - i;
            if (z >= ND_TERM_BYTES) z = ND_TERM_BYTES - 1u;
            for (size_t x = 0; x < z; x++) t.s[x] = (char)lo((unsigned char)s[i + x]);
            t.s[z] = 0;
            t.n = z;
            if (z >= 2u && !stop(&t)) {
                int dup = 0;
                for (size_t x = 0; x < k; x++) if (term_eq(&out[x], &t)) dup = 1;
                if (!dup) out[k++] = t;
            }
        }
        i = j > i ? j : i + 1u;
    }
    return k;
}

static int has(const Term *v, size_t n, const Term *t) {
    for (size_t i = 0; i < n; i++) if (term_eq(&v[i], t)) return 1;
    return 0;
}

int nd_memory_query(const NDMemory *m, const char *q, NDMemoryResult *r, char *e, size_t ec) {
    if (!m || !q || !r) {
        seterr(e, ec, "invalid memory query");
        return -1;
    }
    memset(r, 0, sizeof(*r));
    Term qt[ND_MAX_TERMS];
    size_t qn = terms(q, qt, ND_MAX_TERMS);
    if (!qn) return 0;
    float best = 0.0f;
    size_t best_i = 0;
    for (size_t i = 0; i < m->count; i++) {
        Term mt[ND_MAX_TERMS];
        size_t mn = terms(m->entries[i].text, mt, ND_MAX_TERMS);
        size_t matches = 0;
        float score = 0.0f;
        for (size_t z = 0; z < qn; z++) {
            if (has(mt, mn, &qt[z])) {
                matches++;
                score += qt[z].n >= 6u ? 1.5f : 1.0f;
            }
        }
        if (matches >= 2u) score += 0.25f * (float)(matches - 1u);
        if (score > best) {
            best = score;
            best_i = i;
        }
    }
    if (best >= 2.25f && m->count) {
        r->found = 1;
        r->index = best_i;
        r->score = best;
        r->text = m->entries[best_i].text;
    }
    return 0;
}


static int entry_is_explicit_update(const NDMemory *m, size_t entry_index) {
    return m && entry_index < m->count && m->entries[entry_index].text &&
           starts_ci(skip_space(m->entries[entry_index].text), "ATUALIZAÇÃO:");
}

int nd_memory_query_fact(const NDMemory *m, const char *q, NDMemoryFactResult *r, char *e, size_t ec) {
    if (!m || !q || !r) {
        seterr(e, ec, "invalid memory fact query");
        return -1;
    }
    memset(r, 0, sizeof(*r));
    const char *relation = query_relation(q);
    if (!relation) return 0;
    char subject[ND_MEMORY_SUBJECT_BYTES];
    if (!extract_structured_subject(q, subject, sizeof(subject))) return 0;
    size_t authoritative_from = 0u;
    for (size_t i = 0; i < m->fact_count; i++) {
        const NDMemoryFact *f = &m->facts[i];
        if (!equals_ci(f->subject, subject) || !equals_ci(f->relation, relation)) continue;
        if (entry_is_explicit_update(m, f->entry_index) && f->entry_index >= authoritative_from) {
            authoritative_from = f->entry_index;
        }
    }
    const NDMemoryFact *best = NULL;
    for (size_t i = 0; i < m->fact_count; i++) {
        const NDMemoryFact *f = &m->facts[i];
        if (!equals_ci(f->subject, subject) || !equals_ci(f->relation, relation) ||
            f->entry_index < authoritative_from) continue;
        if (best && !equals_ci(best->value, f->value)) {
            r->conflict = 1;
            r->subject = f->subject;
            r->relation = f->relation;
            return 0;
        } /* conflicting facts after the latest explicit update still fail closed */
        best = f;
    }
    if (!best || best->entry_index >= m->count) return 0;
    r->found = 1;
    r->entry_index = best->entry_index;
    r->score = 1.0f;
    r->subject = best->subject;
    r->relation = best->relation;
    r->value = best->value;
    r->evidence = m->entries[best->entry_index].text;
    return 0;
}

static int append_record(NDMemory *m, const char *text, char *e, size_t ec) {
    char *copy = dup_trim(text);
    if (!copy) {
        seterr(e, ec, "memory statement is empty or too large");
        return -1;
    }
    for (size_t i = 0; i < m->count; i++) {
        if (equals_ci(m->entries[i].text, copy)) {
            free(copy);
            return nd_memory_save(m, e, ec);
        }
    }
    if (m->count == ND_MEMORY_MAX_ENTRIES) {
        free(m->entries[0].text);
        memmove(&m->entries[0], &m->entries[1],
                (ND_MEMORY_MAX_ENTRIES - 1u) * sizeof(m->entries[0]));
        m->count--;
    }
    m->entries[m->count++].text = copy;
    rebuild_facts(m);
    return nd_memory_save(m, e, ec);
}

static const char *canonical_update_phrase(const char *relation) {
    if (!relation) return NULL;
    if (strcmp(relation, "battery") == 0) return " usa bateria ";
    if (strcmp(relation, "coordinator") == 0) return " a coordenadora é ";
    if (strcmp(relation, "responsible") == 0) return " a responsável é ";
    if (strcmp(relation, "code") == 0) return " código é ";
    if (strcmp(relation, "version") == 0) return " versão é ";
    if (strcmp(relation, "material") == 0) return " material é ";
    if (strcmp(relation, "sensor") == 0) return " usa sensor ";
    return NULL;
}

static int handle_update_command(NDMemory *m, const char *statement, char *out, size_t cap,
                                 int *handled, char *e, size_t ec) {
    char subject[ND_MEMORY_SUBJECT_BYTES];
    if (!extract_structured_subject(statement, subject, sizeof(subject))) {
        seterr(e, ec, "memory update requires a structured subject");
        return -1;
    }
    const char *relation = query_relation(statement);
    const char *phrase = canonical_update_phrase(relation);
    if (!phrase) {
        seterr(e, ec, "memory update relation is unsupported");
        return -1;
    }
    static const char *markers[] = {" agora é ", " agora e ", " passa a ser ", " passou a ser "};
    const char *value = NULL;
    for (size_t i = 0; i < sizeof(markers) / sizeof(markers[0]); i++) {
        const char *hit = find_ci_memory(statement, markers[i]);
        if (hit) {
            value = hit + strlen(markers[i]);
            break;
        }
    }
    if (!value || !*skip_space(value)) {
        seterr(e, ec, "memory update requires an explicit new value");
        return -1;
    }
    char trimmed[ND_MEMORY_VALUE_BYTES];
    const char *end = value + strlen(value);
    if (!copy_trimmed_range(value, end, trimmed, sizeof(trimmed))) {
        seterr(e, ec, "memory update value is empty or too large");
        return -1;
    }
    char canonical[ND_MEMORY_TEXT_BYTES];
    int w = snprintf(canonical, sizeof(canonical), "ATUALIZAÇÃO: %s%s%s.", subject, phrase, trimmed);
    if (w < 0 || (size_t)w >= sizeof(canonical)) {
        seterr(e, ec, "memory update record exceeds bounds");
        return -1;
    }
    if (append_record(m, canonical, e, ec)) return -1;
    w = snprintf(out, cap, "Memória local atualizada: %s %s = %s", subject, relation, trimmed);
    if (w < 0 || (size_t)w >= cap) {
        seterr(e, ec, "memory update response buffer too small");
        return -1;
    }
    *handled = 1;
    return 0;
}

int nd_memory_handle_command(NDMemory *m, const char *q, char *out, size_t cap, int *handled,
                             char *e, size_t ec) {
    static const char *remember[] = {"lembre que ", "lembre também que ", "lembre tambem que ", "memorize que ", "guarde que ", "lembre-se de que "};
    static const char *clear[] = {"limpe a memória local", "apague a memória local", "esqueça toda a memória local"};
    if (!m || !q || !out || !cap || !handled) {
        seterr(e, ec, "invalid memory command input");
        return -1;
    }
    *handled = 0;
    const char *p = skip_space(q);
    static const char *update[] = {"atualize:", "atualize que ", "atualize "};
    for (size_t i = 0; i < sizeof(update) / sizeof(update[0]); i++) {
        if (starts_ci(p, update[i])) {
            const char *statement = skip_space(p + strlen(update[i]));
            return handle_update_command(m, statement, out, cap, handled, e, ec);
        }
    }
    for (size_t i = 0; i < sizeof(clear) / sizeof(clear[0]); i++) {
        if (starts_ci(p, clear[i])) {
            if (nd_memory_clear(m, e, ec)) return -1;
            const char *z = "Memória local explícita apagada.";
            if (strlen(z) + 1u > cap) return -1;
            strcpy(out, z);
            *handled = 1;
            return 0;
        }
    }
    for (size_t i = 0; i < sizeof(remember) / sizeof(remember[0]); i++) {
        if (starts_ci(p, remember[i])) {
            const char *statement = p + strlen(remember[i]);
            if (append_record(m, statement, e, ec)) return -1;
            int w = snprintf(out, cap, "Memória local atualizada: %s", skip_space(statement));
            if (w < 0 || (size_t)w >= cap) {
                seterr(e, ec, "memory response buffer too small");
                return -1;
            }
            *handled = 1;
            return 0;
        }
    }
    return 0;
}
