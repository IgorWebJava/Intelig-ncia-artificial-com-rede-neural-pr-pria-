<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.documentation; current: docs/governance/HISTORICAL_BASELINE_POLICY.md -->
# Historical Baseline Policy

Versioned V6/V7/V8 documents and older verification reports are preserved to explain evolution. Their old numbers, profiles and metrics are intentional historical evidence. They must not be edited into the current state.

If a historical document conflicts with current truth, follow `docs/SOURCE_OF_TRUTH.md`.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
