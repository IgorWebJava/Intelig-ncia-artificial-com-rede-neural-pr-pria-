#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,shutil
from pathlib import Path
TOOLS=['aapt2','d8','zipalign','apksigner']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inspect(manifest:Path|None=None):
 observed={n:shutil.which(n) for n in TOOLS}; admitted=False; reason='ARTIFACTS_PENDING'
 if manifest and manifest.is_file():
  m=json.loads(manifest.read_text()); ok=True
  for n in TOOLS:
   spec=m.get(n); path=observed[n]
   if not spec or not path or sha(path)!=spec.get('sha256'):ok=False
  admitted=ok;reason='HASH_PINNED_LOCAL_TOOLCHAIN' if ok else 'PIN_MISMATCH_OR_MISSING'
 return {'tools':observed,'admitted':admitted,'state':reason,'apkGenerated':False,'apkSigned':False,'artDeviceExecuted':False}
if __name__=='__main__':print(json.dumps(inspect(),sort_keys=True))
