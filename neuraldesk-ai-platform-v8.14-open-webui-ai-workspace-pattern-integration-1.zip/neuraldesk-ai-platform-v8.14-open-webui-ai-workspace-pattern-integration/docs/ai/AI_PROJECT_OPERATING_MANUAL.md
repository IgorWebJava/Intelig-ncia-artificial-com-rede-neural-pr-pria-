<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.ai-handoff; current: docs/ai/AI_PROJECT_OPERATING_MANUAL.md -->
# AI Project Operating Manual

## Before work

Resolve current package/documentation version, read memory and source-of-truth, locate the owning module, inspect its preview and specialized mechanic, then inspect contracts/data/tests.

## During work

Prefer the smallest change that satisfies the request. Preserve capability-based boundaries. Update tests and documentation with the implementation. Distinguish interface-only representation from future executable behavior.

## After work

Update module/global docs, memory and skills when relevant. Regenerate previews after visual changes, regenerate documentation inventory, run gates, write verification evidence and create a single complete versioned ZIP.


## Neural Engine Advanced Research Blueprint

See `neural-engine/` for the current V8.11 documentation-only architecture: 94 future modules / 391 capabilities, fully mapped through the Engine↔UI bridge.

## V8.7 frontier readiness

Before planning executable Neural Engine work, read:
- `../frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
- `../frontier-readiness/EXECUTION_ROADMAP.md`
- `../../neural-engine/registry/frontier-readiness.json`

Treat `D0`, `UI0`, parity targets and differentiation targets as documentation states, never as implemented capabilities.



## V8.10 agent-harness research
Before implementing project/session/agent/tool runtime behavior, read `neural-engine/research/deepseek-harness-2026/README.md`, the 12 modules under `neural-engine/modules/11-agent-harness-runtime/`, and the semantic durability/session evolution strategies. Preserve the documentation-only boundary until an executable-engine release is explicitly authorized.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.


## Engine ↔ UI Bridge V8.11
Before changing interface or engine docs, inspect `platform/engine-ui-bridge/registry.json` and run both non-regression/compatibility gates. Do not mark engine states executable while `neural_engine_code_status` is `NOT_IMPLEMENTED`.


## V8.11 cooperative operation

For any structural change, update both the owning UI contract and the corresponding future Neural Engine interface-compatibility documentation. Run non-regression and Engine/UI compatibility gates before release.
