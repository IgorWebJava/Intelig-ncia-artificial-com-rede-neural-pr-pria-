#ifndef ND_MEMORY_H
#define ND_MEMORY_H

#include <stddef.h>

#define ND_MEMORY_MAX_ENTRIES 128u
#define ND_MEMORY_TEXT_BYTES 4096u
#define ND_MEMORY_MAX_FACTS 384u
#define ND_MEMORY_SUBJECT_BYTES 128u
#define ND_MEMORY_RELATION_BYTES 32u
#define ND_MEMORY_VALUE_BYTES 192u

typedef struct {
    char *text;
} NDMemoryEntry;

typedef struct {
    char subject[ND_MEMORY_SUBJECT_BYTES];
    char relation[ND_MEMORY_RELATION_BYTES];
    char value[ND_MEMORY_VALUE_BYTES];
    size_t entry_index;
} NDMemoryFact;

typedef struct {
    NDMemoryEntry entries[ND_MEMORY_MAX_ENTRIES];
    size_t count;
    NDMemoryFact facts[ND_MEMORY_MAX_FACTS];
    size_t fact_count;
    char path[1024];
} NDMemory;

typedef struct {
    int found;
    size_t index;
    float score;
    const char *text;
} NDMemoryResult;

typedef struct {
    int found;
    int conflict;
    size_t entry_index;
    float score;
    const char *subject;
    const char *relation;
    const char *value;
    const char *evidence;
} NDMemoryFactResult;

void nd_memory_init(NDMemory *memory);
void nd_memory_free(NDMemory *memory);
int nd_memory_set_path(NDMemory *memory, const char *path, char *err, size_t errcap);
int nd_memory_load(NDMemory *memory, const char *path, char *err, size_t errcap);
int nd_memory_save(const NDMemory *memory, char *err, size_t errcap);
int nd_memory_clear(NDMemory *memory, char *err, size_t errcap);
int nd_memory_handle_command(NDMemory *memory, const char *question,
                             char *out, size_t outcap, int *handled,
                             char *err, size_t errcap);
int nd_memory_query(const NDMemory *memory, const char *question,
                    NDMemoryResult *result, char *err, size_t errcap);
int nd_memory_query_fact(const NDMemory *memory, const char *question,
                         NDMemoryFactResult *result, char *err, size_t errcap);

#endif
