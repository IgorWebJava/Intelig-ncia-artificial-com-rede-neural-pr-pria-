#!/usr/bin/env python3
"""Reproduce all neural specialists promoted in LocalNet v0.5."""
import argparse
import subprocess
import sys


def run(args):
    print("+", " ".join(args), flush=True)
    subprocess.run(args, check=True)



def require_lessons_precheck() -> None:
    import subprocess as _sp
    import sys as _sys
    from pathlib import Path as _Path
    _root = _Path(__file__).resolve().parents[1]
    _sp.run([_sys.executable, str(_root / "scripts" / "pre_generation_lessons_check.py")], cwd=_root, check=True)

def main():
    require_lessons_precheck()
    ap = argparse.ArgumentParser()
    ap.add_argument("--retriever-steps", type=int, default=1400)
    ap.add_argument("--relation-steps", type=int, default=900)
    ap.add_argument("--pointer-steps", type=int, default=700)
    args = ap.parse_args()
    run([sys.executable, "training/materialize_datasets.py"])
    run([
        sys.executable, "training/train_knowledge_retriever.py",
        "--steps", str(args.retriever_steps),
        "--batch", "64",
    ])
    run([
        sys.executable, "training/train_relation_classifier.py",
        "--steps", str(args.relation_steps),
        "--batch", "96",
    ])
    run([
        sys.executable, "training/train_context_pointer.py",
        "--steps", str(args.pointer_steps),
        "--batch", "32",
    ])


if __name__ == "__main__":
    main()
