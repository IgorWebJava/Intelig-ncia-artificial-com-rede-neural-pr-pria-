<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Multimodal Platform Design

    Skill ID: `neuraldesk.multimodal-platform.v1`

    ## Category

    `ai-media`

    ## Introduced

    `V7.0`

    ## Required development capabilities

    - `multimodal.contract.design.v1`
- `browser.render.v1`

    ## Used by

    - `chat`
- `training`
- `knowledge`
- `tools`
- `operations`
- `audit`
- `system-config`

    ## Related project artifacts

    - `contracts/ai/`
- `contracts/media/`
- `platform/media/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
