#!/usr/bin/env python3
"""Deterministic phase receipts for long verification gates.

Receipts live outside the distributed tree by default and are bound to the
manifest version plus a SHA-256 digest of release inputs. Generated build and
verification outputs are intentionally excluded from the input digest.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "PROJECT_MANIFEST.json"
PRECHECK = ROOT / "scripts/pre_generation_lessons_check.py"

EXCLUDED_DIR_NAMES = {
    "build",
    "build-sanitize",
    "build-werror",
    "__pycache__",
    ".pytest_cache",
}
EXCLUDED_TOP_LEVEL = {"verification"}
EXCLUDED_FILES = {"SHA256SUMS"}
GENERATED_EVALUATION_FILES = {
    "evaluation/KNOWLEDGE_RETRIEVER_REPORT.json",
    "evaluation/CONTEXT_POINTER_REPORT.json",
    "evaluation/RELATION_CLASSIFIER_REPORT.json",
    "evaluation/CONTEXT_COMPOSITION_REPORT.json",
    "evaluation/RELATION_ASSISTED_CONTEXT_REPORT.json",
    "evaluation/LIVE_QA_V05.json",
    "evaluation/REPRODUCIBILITY_V05.json",
    "evaluation/open_knowledge/SHARD_BUILD_REPORT.json",
    "evaluation/open_knowledge/SHARD_EVALUATION_REPORT.json",
}


def manifest_version() -> str:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    version = data.get("version")
    if not isinstance(version, str) or not version:
        raise SystemExit("PROJECT_MANIFEST.json has no valid version")
    return version


def included_file(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    rel_posix = rel.as_posix()
    if rel_posix in EXCLUDED_FILES or rel_posix in GENERATED_EVALUATION_FILES:
        return False
    if rel.parts and rel.parts[0] in EXCLUDED_TOP_LEVEL:
        return False
    if any(part in EXCLUDED_DIR_NAMES for part in rel.parts):
        return False
    return path.is_file()


def iter_input_files() -> list[Path]:
    files: list[Path] = []
    for current, dirnames, filenames in os.walk(ROOT):
        current_path = Path(current)
        rel_current = current_path.relative_to(ROOT)
        if not rel_current.parts:
            dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIR_NAMES and d not in EXCLUDED_TOP_LEVEL]
        else:
            dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIR_NAMES]
        for name in filenames:
            path = current_path / name
            if included_file(path):
                files.append(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def input_digest() -> str:
    h = hashlib.sha256()
    for path in iter_input_files():
        rel = path.relative_to(ROOT).as_posix().encode("utf-8")
        data_hash = hashlib.sha256(path.read_bytes()).digest()
        h.update(len(rel).to_bytes(4, "big"))
        h.update(rel)
        h.update(data_hash)
    return h.hexdigest()


def state_root(version: str, digest: str) -> Path:
    base = Path(os.environ.get("ND_VERIFY_STATE_DIR", "/tmp/neuraldesk-verification-state"))
    return base / version / digest


def receipt_path(suite: str, phase: str, version: str, digest: str) -> Path:
    return state_root(version, digest) / suite / f"{phase}.json"


def run_precheck() -> None:
    subprocess.run([sys.executable, str(PRECHECK)], cwd=ROOT, check=True)


def mark(suite: str, phase: str) -> None:
    run_precheck()
    version = manifest_version()
    digest = input_digest()
    path = receipt_path(suite, phase, version, digest)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "project": "NeuralDesk Mobile Sovereign LocalNet",
        "version": version,
        "inputDigestSha256": digest,
        "suite": suite,
        "phase": phase,
        "completedAtUtc": datetime.now(timezone.utc).isoformat(),
    }
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    print(f"CHECKPOINT MARK PASS suite={suite} phase={phase} version={version} digest={digest}")


def require(suite: str, phases: list[str]) -> None:
    version = manifest_version()
    digest = input_digest()
    for phase in phases:
        path = receipt_path(suite, phase, version, digest)
        if not path.is_file():
            raise SystemExit(f"missing checkpoint: suite={suite} phase={phase} version={version} digest={digest}")
        data = json.loads(path.read_text(encoding="utf-8"))
        expected = {
            "version": version,
            "inputDigestSha256": digest,
            "suite": suite,
            "phase": phase,
        }
        for key, value in expected.items():
            if data.get(key) != value:
                raise SystemExit(f"checkpoint mismatch {path}: {key}={data.get(key)!r} expected {value!r}")
    print(f"CHECKPOINT REQUIRE PASS suite={suite} phases={','.join(phases)} version={version} digest={digest}")


def reset(suite: str) -> None:
    run_precheck()
    version = manifest_version()
    base = Path(os.environ.get("ND_VERIFY_STATE_DIR", "/tmp/neuraldesk-verification-state")) / version
    if not base.exists():
        print(f"CHECKPOINT RESET PASS suite={suite} version={version} removed=0")
        return
    removed = 0
    for digest_dir in list(base.iterdir()):
        target = digest_dir / suite
        if target.exists():
            shutil.rmtree(target)
            removed += 1
        if digest_dir.exists() and not any(digest_dir.iterdir()):
            digest_dir.rmdir()
    if base.exists() and not any(base.iterdir()):
        base.rmdir()
    print(f"CHECKPOINT RESET PASS suite={suite} version={version} removed={removed}")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("digest")
    mark_p = sub.add_parser("mark")
    mark_p.add_argument("suite", choices=["verify", "sanitize"])
    mark_p.add_argument("phase")
    req_p = sub.add_parser("require")
    req_p.add_argument("suite", choices=["verify", "sanitize"])
    req_p.add_argument("phases", nargs="+")
    reset_p = sub.add_parser("reset")
    reset_p.add_argument("suite", choices=["verify", "sanitize"])
    args = parser.parse_args()
    if args.cmd == "digest":
        print(input_digest())
    elif args.cmd == "mark":
        mark(args.suite, args.phase)
    elif args.cmd == "require":
        require(args.suite, args.phases)
    elif args.cmd == "reset":
        reset(args.suite)


if __name__ == "__main__":
    main()
