package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import kotlin.math.exp

/**
 * Módulo 8: Disjuntor Fractal & Amortecimento Exponencial (KODEX ALEPH v12.5).
 */
class FractalBreakerPlugin(
    private val lambdaFactor: Double = 0.35,
    private val maxRecursionDepth: Int = 5
) : IQcnnPlugin {
    override val pluginId: String = "fractal_breaker"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val profundidade = context.chain.size
        if (profundidade > maxRecursionDepth) {
            val fatorDamping = exp(-lambdaFactor * (profundidade - maxRecursionDepth))
            while (context.chain.size > maxRecursionDepth) {
                context.chain.removeAt(context.chain.size - 1)
            }
            context.metadata["fractal_damping"] = (fatorDamping * 10000).toInt() / 10000.0
            context.metadata["circuit_breaker_tripped"] = true
        } else {
            context.metadata["fractal_damping"] = 1.0
            context.metadata["circuit_breaker_tripped"] = false
        }

        return context
    }
}
