<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Current Technical Research & Source Verification

    Skill ID: `neuraldesk.technical-research.v1`

    ## Category

    `research`

    ## Introduced

    `V6.6`

    ## Required development capabilities

    - `web.research.v1`
- `source.verify.v1`
- `documentation.author.v1`

    ## Used by

    - `platform-architecture`

    ## Related project artifacts

    - `official technical sources`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
