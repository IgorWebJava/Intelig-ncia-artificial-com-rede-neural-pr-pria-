#ifndef ND_TOOLS_H
#define ND_TOOLS_H
#include <stddef.h>
typedef struct {int matched;int ok;double value;char operation[16];} NDCalculatorResult;
int nd_calculator_try(const char *question,int rich,char *out,size_t outcap,NDCalculatorResult *result,char *err,size_t errcap);
#endif
