#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,struct
from pathlib import Path
import numpy as np
MAGIC=b'NDTCV001'
HEADER=struct.Struct('<8sIQ')

def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

class TokenCache:
 def __init__(self,path:Path,*,expected_source_sha:str,expected_tokenizer_sha:str,expected_filter:str):
  self.path=Path(path); side=self.path.with_suffix(self.path.suffix+'.json')
  if not self.path.is_file() or not side.is_file():raise ValueError(f'token cache missing: {self.path}')
  meta=json.loads(side.read_text(encoding='utf-8'))
  if meta.get('schema')!='neuraldesk-token-cache-v074-v1':raise ValueError('token cache schema mismatch')
  if meta.get('fileSha256')!=sha(self.path):raise ValueError('token cache file SHA mismatch')
  if meta.get('sourceSha256')!=expected_source_sha or meta.get('tokenizerSha256')!=expected_tokenizer_sha or meta.get('filter')!=expected_filter:raise ValueError('token cache lineage mismatch')
  with self.path.open('rb') as f:
   magic,rows,tokens=HEADER.unpack(f.read(HEADER.size))
  if magic!=MAGIC or rows!=meta.get('rows') or tokens!=meta.get('tokens'):raise ValueError('token cache header mismatch')
  self.rows=int(rows);self.tokens=int(tokens);off0=HEADER.size;tok0=off0+8*(self.rows+1)
  self.offsets=np.memmap(self.path,dtype='<u8',mode='r',offset=off0,shape=(self.rows+1,))
  self.data=np.memmap(self.path,dtype='<u2',mode='r',offset=tok0,shape=(self.tokens,))
  if int(self.offsets[0])!=0 or int(self.offsets[-1])!=self.tokens or np.any(self.offsets[1:]<self.offsets[:-1]):raise ValueError('token cache offsets invalid')
  self.meta=meta
 def row(self,i:int)->np.ndarray:
  if i<0 or i>=self.rows:raise IndexError(i)
  a=int(self.offsets[i]);b=int(self.offsets[i+1]);return self.data[a:b]
