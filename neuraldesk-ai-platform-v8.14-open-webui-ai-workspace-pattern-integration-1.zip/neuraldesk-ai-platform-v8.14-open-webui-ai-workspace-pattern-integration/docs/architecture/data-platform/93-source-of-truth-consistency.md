<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 93 — Source of Truth & Consistency

Rules:

1. One authoritative owner for each mutable aggregate.
2. Writes occur through application services.
3. Validation and authorization occur before persistence.
4. State change and outbox event are stored atomically.
5. Consumers are idempotent.
6. Read models may be eventually consistent.
7. Effective configuration includes version/source metadata.
