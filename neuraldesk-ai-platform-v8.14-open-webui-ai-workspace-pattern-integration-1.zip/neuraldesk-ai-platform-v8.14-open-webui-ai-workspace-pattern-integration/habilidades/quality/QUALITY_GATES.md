<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Quality Gates — Skills & Tooling

V7.4 adds a skills/tooling gate to the existing pipeline:

```text
module tests
→ architecture
→ documentation
→ responsive
→ testing
→ skills/tooling
→ browser visual
```

A skills validation failure blocks structural release.
