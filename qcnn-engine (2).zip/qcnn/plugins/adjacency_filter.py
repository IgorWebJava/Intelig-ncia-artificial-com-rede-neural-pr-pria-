from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS, TRANSICOES_PERMITIDAS

class AdjacencyFilterPlugin(BaseQcnnPlugin):
    """
    Filtro de Adjacência Semântica e Anti-Dissonância.
    Previne loops e anagramas dissonantes.
    """
    @property
    def plugin_id(self) -> str:
        return "adjacency_filter"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        semente = context.target_seed
        dados = MATRIZ_22_LETRAS.get(semente, MATRIZ_22_LETRAS["Alef"])
        camada1 = dados["milui"]

        cadeia = [semente]
        for letra in camada1:
            filhos = MATRIZ_22_LETRAS.get(letra, {}).get("milui", [])
            for sub in filhos:
                ult = cadeia[-1]
                permitidas = TRANSICOES_PERMITIDAS.get(ult, [])
                if sub in permitidas and sub not in cadeia:
                    cadeia.append(sub)

        context.chain = cadeia
        context.final_state = "10 (Ativação Construtiva)"
        return context
