from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS

class NoTernario:
    """Nó Ternário Bitwise com flags [-1, 0, 1]."""
    def __init__(self, letra: str, frequencia_base: float):
        self.letra = letra
        self.frequencia_base = frequencia_base
        self.bit_ativacao: bool = False
        self.bit_inibicao: bool = False
        self.contador_atencao: int = 0

    def definir_estado(self, valor_ternario: int):
        if valor_ternario == 0:
            self.bit_ativacao = False
            self.bit_inibicao = False
        elif valor_ternario == 1:
            self.bit_ativacao = True
            self.bit_inibicao = False
            self.contador_atencao += 1
        elif valor_ternario == -1:
            self.bit_ativacao = False
            self.bit_inibicao = True

    def obter_estado_str(self) -> str:
        if not self.bit_ativacao and not self.bit_inibicao:
            return "00 (Vácuo / Superposição)"
        elif self.bit_ativacao and not self.bit_inibicao:
            return "10 (Ativação Construtiva)"
        elif not self.bit_ativacao and self.bit_inibicao:
            return "01 (Inibição / Ruído)"
        return "00"

class TernaryBitwisePlugin(BaseQcnnPlugin):
    @property
    def plugin_id(self) -> str:
        return "ternary_bitwise"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        nodes = {}
        for letra, info in MATRIZ_22_LETRAS.items():
            nodes[letra] = NoTernario(letra, info["frequencia_hz"])
        context.active_nodes = nodes
        return context
