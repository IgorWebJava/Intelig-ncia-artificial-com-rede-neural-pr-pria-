package com.neuraldesk.localnet

/**
 * Bounded pre-selector for long web pages.
 *
 * It intentionally does not answer the question.  It only retains multiple
 * potentially relevant sentences before the native evidence-coverage engine
 * performs the final grounded selection.
 */
object ContextSelector {
    private val stop = setOf(
        "que", "qual", "quais", "quem", "como", "para", "por", "uma", "uns", "umas",
        "com", "sem", "sobre", "projeto", "sistema", "resposta", "diga", "informe"
    )

    private fun terms(text: String): Set<String> =
        text.lowercase()
            .split(Regex("[^\\p{L}\\p{N}-]+"))
            .filter { it.length >= 3 && it !in stop }
            .toSet()

    fun select(question: String, text: String, maxChars: Int = 12_000): String {
        if (text.length <= maxChars) return text
        val q = terms(question)
        val sentences = text.split(Regex("(?<=[.!?])\\s+" )).filter { it.isNotBlank() }
        val ranked = sentences.mapIndexed { index, sentence ->
            Triple(index, sentence, terms(sentence).count { it in q })
        }.sortedWith(compareByDescending<Triple<Int, String, Int>> { it.third }.thenBy { it.first })

        val chosen = mutableListOf<Pair<Int, String>>()
        var used = 0
        for ((index, sentence, score) in ranked) {
            if (score == 0 && chosen.isNotEmpty()) continue
            val take = sentence.take(2_000)
            if (used + take.length + 1 > maxChars) continue
            chosen += index to take
            used += take.length + 1
            if (chosen.size >= 32 || used >= maxChars - 256) break
        }
        if (chosen.isEmpty()) return text.take(maxChars)
        return chosen.sortedBy { it.first }.joinToString(" ") { it.second }.take(maxChars)
    }
}
