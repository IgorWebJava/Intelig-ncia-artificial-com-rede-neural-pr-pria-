import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json
from qcnn.core.pipeline import QcnnPipeline
from qcnn.plugins.ternary_bitwise import TernaryBitwisePlugin
from qcnn.plugins.milui_expansion import MiluiExpansionPlugin
from qcnn.plugins.adjacency_filter import AdjacencyFilterPlugin
from qcnn.plugins.harmonic_frequency import HarmonicFrequencyPlugin
from qcnn.plugins.hyperdimensional_computing import HyperdimensionalComputingPlugin
from qcnn.plugins.fractal_grammar import FractalGrammarPlugin
from qcnn.plugins.continuous_ingestion import ContinuousIngestionPlugin
from qcnn.plugins.assistant_toolkit import AssistantToolkitPlugin
from qcnn.plugins.multiverse_oracle import MultiverseOraclePlugin
from qcnn.plugins.mycelium_index import MyceliumIndexPlugin
from qcnn.plugins.conceptual_dialogue import ConceptualDialoguePlugin
from qcnn.plugins.organ_multiplexer import OrganMultiplexerPlugin
from qcnn.plugins.octave_regulator import OctaveRegulatorPlugin
from qcnn.plugins.fractal_breaker import FractalBreakerPlugin
from qcnn.plugins.context_crystallizer import ContextCrystallizerPlugin
from qcnn.plugins.metacognitive_auditor import MetaCognitiveAuditorPlugin
from qcnn.plugins.telemetry_meter import TelemetryMeterPlugin

def run_real_interactive_test_session():
    # Instancia pipeline com todos os 16 módulos
    pipeline = QcnnPipeline()
    pipeline.register_plugin(TernaryBitwisePlugin())
    pipeline.register_plugin(MiluiExpansionPlugin())
    pipeline.register_plugin(AdjacencyFilterPlugin())
    pipeline.register_plugin(HarmonicFrequencyPlugin())
    pipeline.register_plugin(HyperdimensionalComputingPlugin(dimension=10000))
    pipeline.register_plugin(FractalGrammarPlugin())
    pipeline.register_plugin(ContinuousIngestionPlugin(knowledge_dir="./conhecimento_local"))
    pipeline.register_plugin(AssistantToolkitPlugin(storage_dir="./storage_android"))
    pipeline.register_plugin(MultiverseOraclePlugin())
    pipeline.register_plugin(MyceliumIndexPlugin())
    pipeline.register_plugin(ConceptualDialoguePlugin(pasta_conhecimento="./conhecimento_local"))
    pipeline.register_plugin(OrganMultiplexerPlugin())
    pipeline.register_plugin(OctaveRegulatorPlugin())
    pipeline.register_plugin(FractalBreakerPlugin())
    pipeline.register_plugin(ContextCrystallizerPlugin(storage_dir="./storage_android"))
    pipeline.register_plugin(MetaCognitiveAuditorPlugin())
    pipeline.register_plugin(TelemetryMeterPlugin())

    perguntas_de_teste = [
        {
            "categoria": "1. FÍSICA E TEORIA QUÂNTICA",
            "prompt": "O que estuda a física quântica e o que é o emaranhamento?",
            "metadata": {}
        },
        {
            "categoria": "2. COSMOLOGIA E GRAVIDADE RELATIVÍSTICA",
            "prompt": "Como a relatividade e a gravidade funcionam no espaço-tempo?",
            "metadata": {}
        },
        {
            "categoria": "3. ASTRONOMIA E BURACOS NEGROS",
            "prompt": "O que a astronomia e a cosmologia explicam sobre galáxias e buracos negros?",
            "metadata": {}
        },
        {
            "categoria": "4. COMPUTAÇÃO HIPERDIMENSIONAL (HDC D=10.000 BITS)",
            "prompt": "Como funcionam as operações de binding e bundling na computação hiperdimensional?",
            "metadata": {}
        },
        {
            "categoria": "5. CÁLCULO MATEMÁTICO SIMBÓLICO EXATO",
            "prompt": "Calcule 125 * 84 + 1500 / 25 - 42",
            "metadata": {}
        },
        {
            "categoria": "6. CONVERSÃO DE UNIDADES FÍSICAS",
            "prompt": "Converta 120 km/h para m/s",
            "metadata": {}
        },
        {
            "categoria": "7. SEGUNDA CONVERSÃO DE UNIDADES (TEMPERATURA)",
            "prompt": "Converta 100 °C para fahrenheit",
            "metadata": {}
        },
        {
            "categoria": "8. ORÁCULO ANALÍTICO MULTI-V (SIMULAÇÃO MULTIVERSO & DECISÃO)",
            "prompt": "Devo expandir a infraestrutura dos nós quânticos agora ou consolidar as operações atuais?",
            "metadata": {"prisma_risco": 0.85, "filosofia": "Alpha Expansionista"}
        },
        {
            "categoria": "9. ROTEIRO E PLANO DE AÇÃO ESTRUTURADO",
            "prompt": "Crie um plano para desenvolver um módulo de telemetria edge em tempo real",
            "metadata": {}
        },
        {
            "categoria": "10. DESCOMPACTAÇÃO GENEALÓGICA MILUI",
            "prompt": "Descompactar semente Alef",
            "metadata": {}
        },
        {
            "categoria": "11. APRENDIZADO CONTÍNUO E ABSORÇÃO DE NOVO CONHECIMENTO",
            "prompt": "Grave esse conhecimento: O motor QCNN opera com latência sub-milissegundo no edge através de 22 nós fundamentais e HDC de 10.000 bits",
            "metadata": {}
        },
        {
            "categoria": "12. RECUPERAÇÃO DO CONHECIMENTO DINÂMICO APRENDIDO",
            "prompt": "O que você aprendeu sobre a latência do motor QCNN no edge?",
            "metadata": {}
        }
    ]

    print("=" * 80)
    print("🔬 SESSÃO DE TESTE REAL INTERATIVO: MOTOR QCNN ENGINE v5.0 / MULTI-V")
    print("=" * 80)

    resultados = []
    for idx, item in enumerate(perguntas_de_teste, 1):
        prompt = item["prompt"]
        meta = item["metadata"]
        res = pipeline.process(prompt, metadata=meta)
        
        resultado_item = {
            "num": idx,
            "categoria": item["categoria"],
            "prompt": prompt,
            "resposta": res.resposta,
            "estado": res.estado,
            "frequencia": res.frequencia,
            "arvore": res.arvore,
            "latencia": res.latencia,
            "metadata": res.metadata
        }
        resultados.append(resultado_item)
        
        print(f"\n[{idx}] CATEGORIA: {item['categoria']}")
        print(f"👉 PERGUNTA: {prompt}")
        print(f"⚡ ESTADO: {res.estado} | FREQUÊNCIA: {res.frequencia} | LATÊNCIA: {res.latencia}")
        print(f"💬 RESPOSTA:")
        print(res.resposta.replace("<br>", "\n").replace("<strong>", "").replace("</strong>", "").replace("<code>", "").replace("</code>", "").replace("<em>", "").replace("</em>", ""))
        print("-" * 80)

    # Grava os resultados estruturados para documentação
    with open("tests/sessao_teste_real_resultados.json", "w", encoding="utf-8") as f:
        json.dump(resultados, f, indent=2, ensure_ascii=False)
    print("\n✅ Sessão de testes finalizada e gravada com sucesso em tests/sessao_teste_real_resultados.json!")

if __name__ == "__main__":
    run_real_interactive_test_session()
