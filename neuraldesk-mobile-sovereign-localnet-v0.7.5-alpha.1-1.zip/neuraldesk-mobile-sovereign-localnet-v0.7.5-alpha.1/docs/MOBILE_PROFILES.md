# v0.7.5 mobile capability routing

Além de MICRO/MOBILE/MOBILE_PLUS, o profile corrente inclui ABI e provider admission. `AUTO` seleciona apenas `CPU_C99` enquanto esse é o único executor real. GPU/NPU detectados sem executor retornam `PROVIDER_UNAVAILABLE`. Nenhum identificador persistente de hardware é necessário. Physical certification continua separada e false neste ambiente.

# Mobile Profiles — v0.7.4-alpha.2

## Enforcement v0.7.3

Os campos de output, threads, deadline e thermal backoff deixam de ser apenas declaração: `nd_resource_effective_*` calcula o orçamento efetivo. Em status térmico elevado o orçamento é reduzido conservadoramente; o mínimo de threads permanece 1 e o output mantém piso bounded. Os números continuam políticas de software, **não** medições físicas de RSS/bateria/temperatura.


`MICRO`, `MOBILE` e `MOBILE_PLUS` são escolhidos por RAM + cores + 64-bit. Os perfis controlam contexto, top-k RAG, output, threads, deadline e thermal backoff. Nenhum perfil promove GPU/NPU inexistente.

## Assets

- retriever: 1.101.376 B;
- KB: 52.143 B;
- pointer: 539.748 B;
- relation classifier: 531.332 B;
- subtotal de assets neurais + KB: **2.224.599 B (~2,12 MiB)**;
- NDOS v1 (31 registros, 0 parâmetros): **68.177 B**;
- total dos cinco assets de runtime: **2.292.776 B (~2,19 MiB)**;
- parâmetros neurais: **543.094 FP32**.

## Perfil de execução

- CPU-first;
- inferência C99;
- FP32 nesta baseline;
- sem Python/PyTorch no aparelho;
- sem GPU/NNAPI obrigatório;
- buffers e objetivos bounded;
- arquitetura de especialistas pequenos + memória factual + ferramentas, em vez de LLM grande não validado no orçamento móvel atual.

## O que este orçamento não mede

Os tamanhos acima são bytes dos assets distribuídos, não RSS/heap/thermal/bateria medidos em aparelho. A árvore não possui evidência física Android desta release; alocações temporárias do runtime, buffers, código nativo e memória do processo não estão incluídos nesse subtotal de assets.

## Impacto v0.6.1

Nenhum peso ou asset foi ampliado. O delta adiciona código e estado bounded de um turno; não há nova alegação de RAM/RSS/latência física até benchmark em dispositivo. Os orçamentos de assets permanecem os mesmos da alpha.2.


## Outbox budgets v0.7.2

- Micro: 20 tarefas, 64 KiB total, 8 KiB/item.
- Mobile: 50 tarefas, 256 KiB total, 16 KiB/item.
- Mobile Plus: 75 tarefas, 512 KiB total, 32 KiB/item.

Todos usam FIFO serial, TTL de sete dias e no máximo oito dependências locais por tarefa.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

