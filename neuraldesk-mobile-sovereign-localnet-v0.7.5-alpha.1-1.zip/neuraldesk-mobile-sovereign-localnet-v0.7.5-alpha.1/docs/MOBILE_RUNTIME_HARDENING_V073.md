# Mobile Runtime Hardening — v0.7.3-alpha.1

Status: **SOURCE CANDIDATE / HOST-VALIDATED DELTA / FINAL RELEASE GATES PENDING**.

A v0.7.3 é rebasada sobre a árvore integral `neuraldesk-mobile-sovereign-localnet-v0.7.2-alpha.1.zip`. A v0.7.1 final continua sendo o rollback externamente atestado. Nenhum peso neural ou dataset promovido foi alterado neste delta.

## 1. Ownership e lifecycle nativo

O `NDAssistant` continua sendo a única política C99 compartilhada por host e Android. O handle JNI agora possui mutex + condition variable, estado `destroying`, contador de operação ativa, cancelamento e deadline monotônico. Apenas uma inferência pode estar ativa por handle; `nativeFree()` sinaliza cancelamento e aguarda a operação sair antes de liberar o assistant.

`NDExecutionControl` adiciona checkpoints cooperativos ao orquestrador. A API síncrona antiga permanece wrapper compatível. O cancelamento é checado antes/depois de etapas bounded relevantes e o deadline é derivado do Resource Governor.

**Limite:** o assistant determinístico ainda calcula a resposta bounded antes de dividir sua string em callbacks. Isso não é token streaming de decoder autoregressivo. True token streaming/chunked prefill pertence a um futuro backbone generativo promovido e continua **NOT IMPLEMENTED / NOT CLAIMED** nesta release.

## 2. Resource Governor efetivo

Os perfis `MICRO`, `MOBILE` e `MOBILE_PLUS` continuam preservados. Além de pergunta/contexto, o runtime agora calcula limites efetivos para:

- bytes máximos de saída;
- threads admitidas pela política;
- deadline por request;
- redução térmica bounded baseada em status recebido do Android.

Android API 29+ fornece `PowerManager.currentThermalStatus`; versões anteriores usam status neutro. A existência dessa ponte não é evidência de comportamento térmico físico certificado.

## 3. Assets sem whole-model ByteArray

`CanonicalAssetStore` recebe `InputStream`, copia em blocos de 64 KiB, calcula SHA-256 incremental, executa `fsync`, valida o staging e faz `ATOMIC_MOVE`/replace apenas quando os bytes persistidos divergem. A rota normal não materializa o modelo inteiro em `ByteArray`.

O probe JVM herdado continua cobrindo `missing -> install`, `same -> preserve` e `stale -> replace`.

## 4. Local RAG bounded e persistente

O mesmo owner `nd_rag` foi estendido; não foi criado um segundo RAG. O índice mantém no máximo 128 chunks e 16 chunks por documento, com:

- hash de documento e deduplicação;
- replace atômico lógico por `doc_id` quando o conteúdo muda;
- eviction LRU de documento inteiro quando o orçamento é atingido;
- token hashes pré-computados para reduzir retokenização BM25;
- Semantic Ranker opcional preservado somente no rerank bounded;
- persistência local `NDRAG001`, versão 1, checksum FNV-1a 64-bit e rejeição de corrupção/trailing bytes.

O gate atual observa `chunks=128`, `documents=16`, persistência, corrupção rejeitada e LRU. Isso mede correção host, não latência/RSS de aparelho.

## 5. Memória de pesquisa Android

`ResearchMemoryStore` passa a ser **opt-in, desabilitada por padrão**. Quando habilitada, usa AES-GCM com chave não exportável no Android Keystore, mantém no máximo 128 registros e persiste pergunta/fonte/contexto bounded — não a resposta gerada. A migração do arquivo plaintext legado só remove o original depois de materializar a cópia criptografada.

Isso reduz exposição local, mas não constitui certificação de segurança universal nem prova contra dispositivo comprometido.

## 6. Android executor

`MainActivity` usa um `newSingleThreadExecutor` para serializar trabalho que toca o mesmo handle. Cancelamento continua disponível fora da fila para sinalizar uma operação em execução. `onDestroy()` cancela, encerra a fila e chama `nativeFree`, cujo boundary nativo aguarda idle.

RAG pode ser salvo/recarregado pelo JNI. Um arquivo persistido inválido é rejeitado e renomeado como evidence local em vez de ser silenciosamente aceito.

## 7. Gates observados antes dos gates finais

- compile C99 `-Werror`: PASS;
- `EXECUTION_CONTROL`: PASS;
- Resource Governor: PASS (`profiles=3`, fail-closed + thermal/output/threads/deadline);
- Local RAG: PASS (bounded + persistence + corruption + LRU);
- JNI host syntax: PASS;
- Kotlin host subset + asset probe: PASS;
- Android wiring structural gate: PASS;
- calculator: 16/16;
- multi-goal: 320/320;
- conversational correctness: 12/12;
- dialogue grounding: 7/7;
- robust intent recovery: 11/11;
- Semantic Core: 11/11;
- Live QA: 35/35;
- legacy fail-closed: 12 corrupções rejeitadas.

Esses resultados não substituem `verify.sh`, `verify_sanitize.sh`, reextração do ZIP e attestação externa final.

## 8. Truth boundary

Continuam não comprovados/não ativados: Generative Micro, Pirá full automático, APK/AAB, ART/aparelho físico, energia/bateria/thermal benchmark real, GPU/NPU e serving público/produção. `speedupClaimed=false` implicitamente: nenhuma otimização desta release recebe alegação de aceleração física sem Device Lab real.
