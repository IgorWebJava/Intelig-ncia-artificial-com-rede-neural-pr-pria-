#include "nd_assistant.h"
#include "nd_model_acquisition.h"
#include "nd_network_policy.h"
#include "nd_outbox.h"
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 5) return 2;
    NDAssistant a;
    char err[256], out[8192];
    NDAnswerMeta meta;
    int fail = nd_assistant_load(&a, argv[1], argv[2], argv[3], argv[4], err, sizeof(err)) != 0;
    if (fail) return 1;
    fail += nd_assistant_set_master_kill(&a, 1, 100) != 0;
    fail += nd_assistant_answer(&a, "Quanto é 2+2?", NULL, 1, out, sizeof(out), &meta, err, sizeof(err)) != 0;
    fail += meta.source != ND_ANSWER_BLOCKED;
    fail += nd_assistant_set_master_kill(&a, 0, 101) != 0;
    fail += nd_assistant_answer(&a, "Quanto é 2+2?", NULL, 1, out, sizeof(out), &meta, err, sizeof(err)) != 0;
    fail += meta.source != ND_ANSWER_CALCULATOR;
    NDNetworkSnapshot s = nd_network_snapshot(1, 1, 5000u);
    fail += nd_network_allows(&s, ND_NETWORK_OP_WEB_CONTEXT, 0) != 0;
    fail += nd_network_allows(&s, ND_NETWORK_OP_WEB_CONTEXT, 1) != 1;
    nd_assistant_free(&a);
    printf("OFFLINE_CONTINUITY %s kill_switch=true network_policy=true\n", fail ? "FAIL" : "PASS");
    return fail ? 1 : 0;
}
