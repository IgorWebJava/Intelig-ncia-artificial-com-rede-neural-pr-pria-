# Market Parity and Differentiation

## Parity priorities
Real model access, projects, memory, RAG/research, tool use, agents, voice/multimodal, artifacts, background work, security and production reliability.

## Differentiation priorities
- multi-model provider independence;
- Universal Context Lens;
- Work Graph;
- Provenance Everywhere;
- Trust Layer;
- project pause/resume/checkpoints;
- unified Agent -> Evaluate -> Deploy -> Observe -> Audit lifecycle;
- same platform for cloud/local/proprietary models;
- user-facing control over cost/risk/versions.

Differentiation must be validated through user outcomes, not feature count.
