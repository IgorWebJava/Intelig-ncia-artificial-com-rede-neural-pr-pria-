<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 98 — Data & Configuration Observability

Correlate:

- HTTP/API trace;
- database spans;
- configuration version;
- event ID;
- outbox lag;
- consumer lag;
- cache hit/miss;
- audit event;
- user/agent identity.

Use shared trace/correlation IDs across layers.
