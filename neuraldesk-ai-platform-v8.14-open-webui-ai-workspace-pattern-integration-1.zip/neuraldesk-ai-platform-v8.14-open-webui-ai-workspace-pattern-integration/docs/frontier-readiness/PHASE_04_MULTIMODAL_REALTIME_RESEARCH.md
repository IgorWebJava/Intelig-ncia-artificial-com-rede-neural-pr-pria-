# Phase 04 — Multimodal, Realtime and Research

Status: DOCUMENTATION-ONLY


Implement media assets, multimodal runtime, voice/realtime, web research and controlled browser/computer-use fallback.

Principles:
- prefer API/tool integration over UI automation;
- computer use is isolated and policy-bound;
- voice requires explicit consent and visible microphone state;
- camera/screen streams have privacy boundaries;
- research results require evidence and citation quality scoring.

Exit result:
- real multimodal project workflows with traceable sources and safe realtime interaction.

## V8.9 omni-modal extension

P04 now includes modality-resource admission, absolute audio/video time alignment, stage-aware async prefill, neural speech codec/rendering and semantic/expression decoupling. Realtime full-duplex/barge-in remains an independent capability and is not assumed from Qwen3-Omni.
