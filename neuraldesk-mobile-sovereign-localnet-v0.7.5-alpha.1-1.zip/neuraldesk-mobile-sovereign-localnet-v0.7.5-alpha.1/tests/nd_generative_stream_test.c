#include "nd_generative.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct CollectCtx {
    uint32_t tokens[32];
    size_t count;
    int pause_once;
    int paused;
} CollectCtx;

typedef struct StopCtx {
    size_t checks;
    size_t stop_at;
} StopCtx;

typedef struct ClockCtx {
    uint64_t now;
    uint64_t step;
} ClockCtx;

static int collect_cb(uint32_t token, size_t output_index, void *user) {
    CollectCtx *ctx = (CollectCtx *)user;
    if (ctx == NULL || output_index != ctx->count || ctx->count >= 32u) return -1;
    ctx->tokens[ctx->count++] = token;
    if (ctx->pause_once && !ctx->paused) {
        ctx->paused = 1;
        return 1;
    }
    return 0;
}

static int stop_cb(void *user) {
    StopCtx *ctx = (StopCtx *)user;
    if (ctx == NULL) return 0;
    ctx->checks += 1u;
    return ctx->checks >= ctx->stop_at ? 1 : 0;
}

static uint64_t now_cb(void *user) {
    ClockCtx *ctx = (ClockCtx *)user;
    uint64_t value;
    if (ctx == NULL) return 0u;
    value = ctx->now;
    ctx->now += ctx->step;
    return value;
}

static int run_to_done(NDGenStreamSession *session,
                       const NDGenStreamControl *control,
                       CollectCtx *collect,
                       size_t *pause_statuses) {
    size_t guard = 0u;
    for (;;) {
        NDGenStreamStatus status = nd_gen_stream_advance(session, control, collect_cb, collect);
        if (status == ND_GEN_STREAM_DONE) return 0;
        if (status == ND_GEN_STREAM_PAUSED) {
            if (pause_statuses != NULL) *pause_statuses += 1u;
        } else if (status != ND_GEN_STREAM_MORE) {
            fprintf(stderr, "unexpected stream status=%d\n", (int)status);
            return -1;
        }
        if (++guard > 128u) return -1;
    }
}

int main(int argc, char **argv) {
    NDGenerativeModel *model = NULL;
    uint32_t prompt[] = {259u, 81u, 117u, 97u, 110u, 116u, 105u, 122u};
    uint32_t greedy[8];
    NDGenStreamSession session;
    NDGenStreamControl control;
    CollectCtx collect;
    const NDGenStreamStats *stats;
    size_t pauses = 0u;
    StopCtx stop;
    ClockCtx clock;
    NDGenStreamStatus status;

    if (argc != 2) {
        fprintf(stderr, "usage: %s FP32_MODEL\n", argv[0]);
        return 2;
    }
    if (nd_gen_load(argv[1], &model) != 0) return 3;
    if (nd_gen_greedy_generate(model, prompt, 8u, greedy, 8u, 8u) != 0) return 4;

    memset(&control, 0, sizeof(control));
    control.prefill_chunk_tokens = 2u;
    control.decode_chunk_tokens = 2u;
    memset(&collect, 0, sizeof(collect));
    nd_gen_stream_session_init(&session);
    if (nd_gen_stream_begin(&session, model, prompt, 8u, 8u) != 0 ||
        run_to_done(&session, &control, &collect, NULL) != 0 ||
        collect.count != 8u || memcmp(collect.tokens, greedy, sizeof(greedy)) != 0) return 5;
    stats = nd_gen_stream_stats(&session);
    if (stats == NULL || stats->prefill_tokens != 8u || stats->prefill_rounds != 4u ||
        stats->emitted_tokens != 8u || stats->decode_rounds < 4u) return 6;
    nd_gen_stream_session_free(&session);

    memset(&collect, 0, sizeof(collect));
    collect.pause_once = 1;
    control.prefill_chunk_tokens = 3u;
    control.decode_chunk_tokens = 4u;
    nd_gen_stream_session_init(&session);
    if (nd_gen_stream_begin(&session, model, prompt, 8u, 8u) != 0 ||
        run_to_done(&session, &control, &collect, &pauses) != 0 ||
        pauses != 1u || collect.count != 8u || memcmp(collect.tokens, greedy, sizeof(greedy)) != 0) return 7;
    stats = nd_gen_stream_stats(&session);
    if (stats == NULL || stats->pause_events != 1u) return 8;
    nd_gen_stream_session_free(&session);

    memset(&control, 0, sizeof(control));
    memset(&collect, 0, sizeof(collect));
    stop.checks = 0u;
    stop.stop_at = 4u;
    control.prefill_chunk_tokens = 8u;
    control.decode_chunk_tokens = 2u;
    control.should_stop = stop_cb;
    control.stop_user = &stop;
    nd_gen_stream_session_init(&session);
    if (nd_gen_stream_begin(&session, model, prompt, 8u, 8u) != 0) return 9;
    status = nd_gen_stream_advance(&session, &control, collect_cb, &collect);
    if (status != ND_GEN_STREAM_CANCELLED || collect.count != 0u || session.prefill_cursor >= 8u) return 10;
    nd_gen_stream_session_free(&session);

    memset(&control, 0, sizeof(control));
    memset(&collect, 0, sizeof(collect));
    stop.checks = 0u;
    stop.stop_at = 15u;
    control.prefill_chunk_tokens = 8u;
    control.decode_chunk_tokens = 8u;
    control.should_stop = stop_cb;
    control.stop_user = &stop;
    nd_gen_stream_session_init(&session);
    if (nd_gen_stream_begin(&session, model, prompt, 8u, 8u) != 0) return 11;
    status = nd_gen_stream_advance(&session, &control, collect_cb, &collect);
    if (status != ND_GEN_STREAM_CANCELLED || collect.count == 0u || collect.count >= 8u) return 12;
    nd_gen_stream_session_free(&session);

    memset(&control, 0, sizeof(control));
    memset(&collect, 0, sizeof(collect));
    clock.now = 100u;
    clock.step = 1u;
    control.prefill_chunk_tokens = 8u;
    control.decode_chunk_tokens = 8u;
    control.deadline_at_ms = 104u;
    control.now_ms = now_cb;
    control.clock_user = &clock;
    nd_gen_stream_session_init(&session);
    if (nd_gen_stream_begin(&session, model, prompt, 8u, 8u) != 0) return 13;
    status = nd_gen_stream_advance(&session, &control, collect_cb, &collect);
    if (status != ND_GEN_STREAM_DEADLINE || collect.count != 0u) return 14;
    nd_gen_stream_session_free(&session);

    nd_gen_free(model);
    puts("GENERATIVE_STREAM PASS canonicalParity=8/8 chunkedPrefill=true backpressurePauseResume=true cancellationPrefill=true cancellationDecode=true deadline=true tokenStreaming=true");
    return 0;
}
