<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/MODULE_PREVIEW.md -->
# App Shell — Module Preview

Canonical preview: `modules/app-shell/preview/page-preview.png`

Metadata: `modules/app-shell/preview/preview.json`

Previews are generated from canonical HTML/CSS/runtime and are visual references only. Regenerate after meaningful visual changes and validate freshness before release.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
