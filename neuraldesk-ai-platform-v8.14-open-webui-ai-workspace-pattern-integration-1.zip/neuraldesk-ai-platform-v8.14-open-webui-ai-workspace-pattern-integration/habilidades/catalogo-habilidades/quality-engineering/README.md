<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Module-owned Quality Engineering

    Skill ID: `neuraldesk.module-quality.v1`

    ## Category

    `quality`

    ## Introduced

    `V7.3`

    ## Required development capabilities

    - `test.static.execute.v1`
- `test.scenario.design.v1`
- `release.gates.execute.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/<module>/tests/`
- `platform/quality-engineering/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
