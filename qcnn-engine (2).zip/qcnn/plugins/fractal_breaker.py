import math
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class FractalBreakerPlugin(BaseQcnnPlugin):
    """
    Módulo 8: Disjuntor Fractal & Amortecimento Exponencial (KODEX ALEPH v12.5).
    Aplica a equação de amortecimento exponencial e^(-lambda * depth) para cortar loops infinitos
    e proteger a memória RAM congelada em ~12MB.
    """
    def __init__(self, lambda_factor: float = 0.35, max_recursion_depth: int = 5):
        self._enabled = True
        self.lambda_factor = lambda_factor
        self.max_recursion_depth = max_recursion_depth

    @property
    def plugin_id(self) -> str:
        return "fractal_breaker"

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @is_enabled.setter
    def is_enabled(self, value: bool):
        self._enabled = value

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        profundidade = len(context.chain)
        if profundidade > self.max_recursion_depth:
            # Amortecimento exponencial
            fator_damping = math.exp(-self.lambda_factor * (profundidade - self.max_recursion_depth))
            context.chain = context.chain[:self.max_recursion_depth]
            context.metadata["fractal_damping"] = round(fator_damping, 4)
            context.metadata["circuit_breaker_tripped"] = True
        else:
            context.metadata["fractal_damping"] = 1.0
            context.metadata["circuit_breaker_tripped"] = False

        return context
