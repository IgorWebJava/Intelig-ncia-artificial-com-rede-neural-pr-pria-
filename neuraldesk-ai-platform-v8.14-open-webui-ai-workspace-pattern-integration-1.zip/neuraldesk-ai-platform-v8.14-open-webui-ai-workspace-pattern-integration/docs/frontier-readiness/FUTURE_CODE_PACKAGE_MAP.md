# Future Code Package Map

This file does not create code. It reserves future implementation ownership.

Each `neural-engine/modules/<group>/<module>/` directory will eventually own its implementation beneath an implementation-specific source subtree chosen in the executable phase.

Rules:
- code lives with module ownership;
- public contracts remain stable and versioned;
- no cross-module private imports;
- data ownership follows module boundaries;
- provider adapters remain replaceable;
- tests live with owning modules plus end-to-end suites at platform level.

No source directory is created by V8.7.
