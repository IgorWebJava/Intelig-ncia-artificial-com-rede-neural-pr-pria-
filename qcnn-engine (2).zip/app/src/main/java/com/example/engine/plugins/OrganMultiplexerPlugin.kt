package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext

data class OrgaoEspecializado(
    val nome: String,
    val bitPos: Int,
    val gatilhos: List<String>,
    val baseConhecimento: String,
    var isAcordado: Boolean = false
)

/**
 * Módulo 10: Modo Expedidor & Bit-Mask Multiplexing de Órgãos (KODEX ALEPH v12.5).
 */
class OrganMultiplexerPlugin : IQcnnPlugin {
    override val pluginId: String = "organ_multiplexer"
    override var isEnabled: Boolean = true

    private val orgaos = listOf(
        OrgaoEspecializado(
            nome = "Direito",
            bitPos = 0,
            gatilhos = listOf("lei", "leis", "crime", "contrato", "constituição", "jurídico", "direito", "norma", "código"),
            baseConhecimento = "Princípios Jurídicos: Todos são iguais perante a lei e a ordem constitucional garante os direitos fundamentais."
        ),
        OrgaoEspecializado(
            nome = "Medicina",
            bitPos = 2,
            gatilhos = listOf("saúde", "sintoma", "dor", "médico", "biologia", "celular", "homeostase", "organismo"),
            baseConhecimento = "Princípios Médicos: A homeostase e a integridade celular protegem os tecidos vivos contra estresse oxidativo e patologias."
        ),
        OrgaoEspecializado(
            nome = "Engenharia",
            bitPos = 4,
            gatilhos = listOf("sistema", "código", "circuito", "algoritmo", "hardware", "software", "estrutura", "edge", "robótica"),
            baseConhecimento = "Princípios de Engenharia: A robustez arquitetural e a tolerância a falhas garantem eficiência máxima com menor consumo energético."
        ),
        OrgaoEspecializado(
            nome = "Filosofia",
            bitPos = 6,
            gatilhos = listOf("mente", "consciência", "verdade", "ética", "existência", "pensamento", "ontologia"),
            baseConhecimento = "Princípios Filosóficos: O observador consciente colapsa o significado e fundamenta a relação entre essência e manifestação."
        ),
        OrgaoEspecializado(
            nome = "Finanças",
            bitPos = 8,
            gatilhos = listOf("economia", "moeda", "mercado", "inflação", "finanças", "dinheiro", "capital", "ativo"),
            baseConhecimento = "Princípios Financeiros: A liquidez, a gestão de risco e o valor temporal do capital regem a estabilidade dos fluxos econômicos."
        ),
        OrgaoEspecializado(
            nome = "Astronomia",
            bitPos = 10,
            gatilhos = listOf("estrela", "galáxia", "buraco negro", "planeta", "cosmo", "astronomia", "órbita", "gravitação"),
            baseConhecimento = "Princípios Astronômicos: A curvatura do espaço-tempo gravitacional organiza galáxias e corpos celestes em harmonia cosmológica."
        )
    )

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val promptLower = context.prompt.lowercase()
        var registradorEstado = 0
        val orgaosAtivados = mutableListOf<OrgaoEspecializado>()

        val ativarTodos = Regex("(?:ativar\\s+todos|ativar\\s+todos\\s+os\\s+orgaos|orgaos\\s+gerais|multiplexar\\s+orgaos)").containsMatchIn(promptLower)

        for (orgao in orgaos) {
            val ativo = ativarTodos || orgao.gatilhos.any { g ->
                Regex("\\b${Regex.escape(g)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(promptLower)
            }
            orgao.isAcordado = ativo
            if (ativo) {
                registradorEstado = registradorEstado or (0b10 shl orgao.bitPos)
                orgaosAtivados.add(orgao)
            }
        }

        context.metadata["organ_bitmask"] = "0b" + Integer.toBinaryString(registradorEstado)
        context.metadata["active_organs"] = orgaosAtivados.map { it.nome }

        if (orgaosAtivados.isNotEmpty() && context.customResponse.isEmpty()) {
            val respostasOrgaos = mutableListOf<String>()
            var hzAdicional = 0.0
            for (o in orgaosAtivados) {
                respostasOrgaos.add("[${o.nome.uppercase()}]: ${o.baseConhecimento}")
                hzAdicional += 33.3
            }

            context.customResponse = respostasOrgaos.joinToString("<br><br>───<br>")
            context.totalFrequencyHz = kotlin.math.max(context.totalFrequencyHz, hzAdicional)
            context.finalState = "10 (Bitmask 0b${Integer.toBinaryString(registradorEstado)})"
            context.chain.clear()
            context.chain.addAll(orgaosAtivados.map { it.nome })
        }

        return context
    }
}
