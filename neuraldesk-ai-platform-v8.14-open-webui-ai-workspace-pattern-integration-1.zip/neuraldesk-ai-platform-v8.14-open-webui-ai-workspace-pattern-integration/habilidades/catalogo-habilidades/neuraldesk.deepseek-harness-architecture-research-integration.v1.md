<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: habilidades -->
# DeepSeek Harness Architecture Research Integration

Use primary sources to extract provider-agnostic agent-harness architecture patterns, map them to NeuralDesk capabilities/modules, document risks and adoption gates, and keep the executable-code boundary unchanged until explicitly authorized.

## Required behaviors
- verify fast-moving upstream state;
- distinguish architecture pattern from implementation detail;
- preserve NeuralDesk contracts;
- document semantic durability, recovery and failure modes;
- add benchmark/ablation gates;
- sync `docs/`, `memória/`, `habilidades/` and engine registries;
- never copy private reasoning or secrets.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
