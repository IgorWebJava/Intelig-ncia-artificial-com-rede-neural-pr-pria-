<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/DEVELOPMENT_SKILLS_AND_TOOLING.md -->
# App Shell — Development Skills & Tooling

Profile: `skills-tools-registry-v1`

## Required skills

- `neuraldesk.project-context-memory.v1`
- `neuraldesk.modular-architecture.v1`
- `neuraldesk.html-css-ui.v1`
- `neuraldesk.adaptive-responsive.v1`
- `neuraldesk.documentation-governance.v1`
- `neuraldesk.module-quality.v1`
- `neuraldesk.release-engineering.v1`
- `neuraldesk.module-preview-management.v1`
- `neuraldesk.experience-runtime-design.v1`
- `neuraldesk.autonomous-assistant-experience-design.v1`
- `neuraldesk.intelligence-experience-design.v1`

## Required development capabilities

- `accessibility.structural.v1`
- `browser.viewport-test.v1`
- `capability.registry.manage.v1`
- `contract.registry.manage.v1`
- `css.author.v1`
- `documentation.author.v1`
- `documentation.sync.v1`
- `filesystem.search.v1`
- `html.author.v1`
- `module.architecture.design.v1`
- `module.manifest.author.v1`
- `project.memory.read.v1`
- `project.memory.update.v1`
- `project.skills.read.v1`
- `project.skills.update.v1`
- `release.gates.execute.v1`
- `release.package.v1`
- `release.versioning.v1`
- `responsive.design.v1`
- `test.scenario.design.v1`
- `test.static.execute.v1`
- `browser.preview.capture.v1`
- `javascript.module-runtime.author.v1`
- `design-system.source.author.v1`
- `progressive-disclosure.design.v1`
- `ui.interaction.test.v1`
- `assistant-experience.surface.design.v1`
- `project-state.visual-model.design.v1`
- `assistant-truthfulness.boundary.design.v1`
- `ui.experience-design.v2`
- `ui.provenance-design.v1`
- `ui.trust-design.v1`

Concrete tools are replaceable providers. Consult `habilidades/REGISTRO_HABILIDADES.json`, `REGISTRO_FERRAMENTAS.json` and the applicable workflow before modification.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
