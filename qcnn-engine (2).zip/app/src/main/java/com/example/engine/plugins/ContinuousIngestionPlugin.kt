package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

data class ConhecimentoDestilado(
    val keyword: String,
    val summary: String,
    val hz: Double,
    val tokens: List<String>
)

/**
 * Pilar 1: Auto-Expansão Ontológica em Background (Continuous Knowledge Distillation).
 * Varre e destila automaticamente arquivos de texto e bases locais na proporção áurea.
 */
class ContinuousIngestionPlugin(
    private val storageDir: File? = null
) : IQcnnPlugin {

    override val pluginId: String = "continuous_ingestion"
    override var isEnabled: Boolean = true

    private val ontologia = ConcurrentHashMap<String, ConhecimentoDestilado>()
    private val arquivosProcessados = ConcurrentHashMap<String, Long>()

    init {
        autoScan()
    }

    private fun calcularFrequenciaAurea(texto: String): Double {
        val phi = 1.61803398875
        val baseHz = 121.35
        val charSum = texto.filter { it.isLetterOrDigit() }.sumOf { it.code }
        val freq = baseHz + (charSum % 1000) * (phi - 1.0)
        return Math.round(freq * 100.0) / 100.0
    }

    private fun extrairEntidades(conteudo: String): List<ConhecimentoDestilado> {
        val lista = mutableListOf<ConhecimentoDestilado>()
        val paragrafos = conteudo.split("\n\n").map { it.trim() }.filter { it.length > 20 }
        for (p in paragrafos) {
            val sentencas = p.split(Regex("[.!?]+")).map { it.trim() }.filter { it.length > 25 }
            for (s in sentencas) {
                val palavras = s.lowercase().split(Regex("[\\s,;:()\"]+")).filter { it.length > 3 }
                if (palavras.isNotEmpty()) {
                    val key = palavras[0]
                    lista.add(
                        ConhecimentoDestilado(
                            keyword = key,
                            summary = s,
                            hz = calcularFrequenciaAurea(s),
                            tokens = palavras.take(8)
                        )
                    )
                }
            }
        }
        return lista
    }

    fun autoScan() {
        if (storageDir == null || !storageDir.exists()) return
        val files = storageDir.listFiles() ?: return
        for (f in files) {
            if (f.name.endsWith(".txt") || f.name.endsWith(".dat") || f.name.endsWith(".org")) {
                val lastMod = f.lastModified()
                val prev = arquivosProcessados[f.name] ?: 0L
                if (lastMod > prev) {
                    try {
                        val text = f.readText(Charsets.UTF_8)
                        val extraidos = extrairEntidades(text)
                        for (item in extraidos) {
                            ontologia[item.keyword] = item
                        }
                        arquivosProcessados[f.name] = lastMod
                    } catch (_: Exception) {}
                }
            }
        }
    }

    fun buscarConhecimento(prompt: String): ConhecimentoDestilado? {
        autoScan()
        val palavras = prompt.lowercase().split(Regex("[\\s,;:.?!]+")).filter { it.length > 3 }
        for (w in palavras) {
            val item = ontologia[w]
            if (item != null) return item
        }
        return null
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context
        val match = buscarConhecimento(context.prompt)
        if (match != null && context.customResponse == null) {
            context.metadata["ingested_source"] = match.keyword
            context.metadata["ingested_hz"] = match.hz
        }
        return context
    }
}
