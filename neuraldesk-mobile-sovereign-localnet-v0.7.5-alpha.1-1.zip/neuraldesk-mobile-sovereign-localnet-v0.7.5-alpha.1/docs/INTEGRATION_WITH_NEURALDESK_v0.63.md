# Integration with NeuralDesk Mobile v0.63

Este pacote Sovereign LocalNet v0.6.1-alpha.1 permanece uma trilha isolada da baseline maior NeuralDesk Mobile v0.63. Ele não finge ser uma mutação integral daquela árvore.

Uma integração futura deve começar pela baseline v0.63 congelada e pelo protocolo canônico de continuidade, comparar funcionalidade existente e importar somente mecanismos superiores e não regressivos.

Itens candidatos desta trilha para comparação:

1. fallback local NDOS auditável e fail-closed;
2. parser/loader binário com trailing-byte rejection;
3. parity Python↔C;
4. planner de preâmbulo tópico;
5. candidate acceptance e rota de incerteza herdadas v0.5.

Os cinco assets desta trilha devem manter provenance/hashes até qualquer migração ser reproduzida e revalidada na árvore maior.

## Estado após auditoria alpha.2

Nenhuma mesclagem com a árvore maior v0.63 foi realizada durante esta auditoria. Os hardenings de asset-sync/evidence/versioning pertencem a esta trilha LocalNet e só podem migrar após auditoria de existência e superioridade na baseline maior.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
