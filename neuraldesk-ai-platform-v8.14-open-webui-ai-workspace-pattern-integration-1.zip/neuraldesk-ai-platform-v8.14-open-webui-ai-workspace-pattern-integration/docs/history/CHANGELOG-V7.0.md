<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# V7.0 — Modular AI Platform Architecture

## Major migration

The project moved from independent root pages to replaceable module packages.

## Added

- `modules/`
- module manifests
- OpenAPI / AsyncAPI / JSON Schema contracts
- data ownership per module
- compatibility matrices
- Module Registry
- Capability Registry
- Contract Registry
- AI Capability Fabric
- provider adapters
- platform-wide event/error/auth/media contracts
- modular database ownership rules
- compatibility route aliases
- architecture validator

## Superseded

Root HTML files are no longer canonical pages; they are compatibility aliases.

The old root `css/` directory was removed. Canonical CSS lives inside each module UI folder.

## Provider isolation

Domain modules no longer conceptually depend on provider-specific AI SDKs.

## Data isolation

Modules may not directly access another module's private tables.
