<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->
# HABILIDADES MESTRE — NeuralDesk V8.12

## Purpose

`habilidades/` records **how to develop, validate, document and release** NeuralDesk. `memória/` records what the project is, why it evolved that way and its current state.

## Current profile

`skills-tools-registry-v1`

## Inventory

- Development skills: **30**
- Tool/provider records: **6**
- Abstract development capabilities: **58**
- Canonical interface modules: **10**
- Future Neural Engine modules: **94**
- Current resolved platform/UI capabilities: **106**
- Future engine capabilities: **391**

## Current essential competencies

Modular architecture; adaptive HTML/CSS/JS UI; multimodal contracts; OpenAPI/AsyncAPI/JSON Schema; PostgreSQL/data ownership; eventing/outbox; AI Capability Fabric; Agent Studio design; security/audit/observability; research integration; engine blueprint governance; documentation/memory synchronization; module-owned testing; browser validation; preview management; release/versioning; cooperative non-regressive Engine/UI evolution.

## Complete change rule

```text
Implementation + Contracts + Data Ownership + Documentation + Memory + Skills + Tests + Preview + Verification + Non-Regression + Engine/UI Bridge = Complete Change
```

## Current special skill

`neuraldesk.cooperative-non-regressive-evolution.v1` formalizes the V8.12 `preserve → extend → bridge` rule.

## AI handoff

Read `AI_HANDOFF.md`. Tool names/providers are replaceable; abstract capabilities and governed contracts are the durable interface.
