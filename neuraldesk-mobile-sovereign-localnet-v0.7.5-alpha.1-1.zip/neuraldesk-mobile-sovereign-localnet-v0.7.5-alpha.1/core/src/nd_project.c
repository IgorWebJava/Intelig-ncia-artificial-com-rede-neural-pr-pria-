#include "nd_project.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

#define NDPR_MAGIC 0x5250444eu
#define NDPR_VERSION 1u

static void set_error(char *err, size_t cap, const char *msg) {
    if (err && cap) snprintf(err, cap, "%s", msg);
}

static int valid_id(const char *id) {
    if (!id || strlen(id) < 3u || strlen(id) >= ND_PROJECT_ID_BYTES) return 0;
    for (const unsigned char *p = (const unsigned char *)id; *p; p++) {
        if (!(isalnum(*p) || *p == '.' || *p == '_' || *p == '-')) return 0;
    }
    return 1;
}

static int normalize_name(const char *name, char out[ND_PROJECT_NAME_BYTES]) {
    if (!name) return -1;
    size_t used = 0u;
    int pending_space = 0;
    for (const unsigned char *p = (const unsigned char *)name; *p; p++) {
        if (*p < 0x20u || *p == 0x7fu) {
            if (isspace(*p)) pending_space = used > 0u;
            continue;
        }
        if (isspace(*p)) {
            pending_space = used > 0u;
            continue;
        }
        if (pending_space && used + 1u < ND_PROJECT_NAME_BYTES) out[used++] = ' ';
        pending_space = 0;
        if (used + 1u >= ND_PROJECT_NAME_BYTES) break;
        out[used++] = (char)*p;
    }
    while (used && out[used - 1u] == ' ') used--;
    out[used] = 0;
    return used ? 0 : -1;
}

static size_t find_index(const NDProjectStore *s, const char *id) {
    if (!s || !id) return (size_t)-1;
    for (size_t i = 0u; i < s->count; i++) if (strcmp(s->projects[i].id, id) == 0) return i;
    return (size_t)-1;
}

static int persist(const NDProjectStore *s, char *err, size_t ec) {
    if (!s->path[0]) return 0;
    char tmp[1100];
    if (snprintf(tmp, sizeof(tmp), "%s.tmp", s->path) >= (int)sizeof(tmp)) {
        set_error(err, ec, "project path too long");
        return -1;
    }
    FILE *f = fopen(tmp, "wb");
    if (!f) { set_error(err, ec, "cannot open project temp"); return -1; }
    uint32_t magic = NDPR_MAGIC, version = NDPR_VERSION, count = (uint32_t)s->count, current = (uint32_t)s->current_index;
    int failed = fwrite(&magic, sizeof(magic), 1u, f) != 1u || fwrite(&version, sizeof(version), 1u, f) != 1u ||
                 fwrite(&count, sizeof(count), 1u, f) != 1u || fwrite(&current, sizeof(current), 1u, f) != 1u;
    if (!failed && s->count) failed = fwrite(s->projects, sizeof(s->projects[0]), s->count, f) != s->count;
    if (fflush(f) != 0 || fclose(f) != 0) failed = 1;
    if (failed) { remove(tmp); set_error(err, ec, "cannot persist projects"); return -1; }
    if (rename(tmp, s->path) != 0) { remove(tmp); set_error(err, ec, "cannot commit projects"); return -1; }
    return 0;
}

void nd_project_store_init(NDProjectStore *s) {
    if (!s) return;
    memset(s, 0, sizeof(*s));
    snprintf(s->projects[0].id, sizeof(s->projects[0].id), "default");
    snprintf(s->projects[0].name, sizeof(s->projects[0].name), "Projeto principal");
    s->count = 1u;
    s->current_index = 0u;
}

int nd_project_store_set_path(NDProjectStore *s, const char *path, char *err, size_t ec) {
    if (!s || !path || strlen(path) >= sizeof(s->path)) { set_error(err, ec, "invalid project path"); return -1; }
    snprintf(s->path, sizeof(s->path), "%s", path);
    return 0;
}

int nd_project_store_restore(NDProjectStore *s, char *err, size_t ec) {
    if (!s || !s->path[0]) return 0;
    FILE *f = fopen(s->path, "rb");
    if (!f) return persist(s, err, ec);
    uint32_t magic = 0u, version = 0u, count = 0u, current = 0u;
    if (fread(&magic, sizeof(magic), 1u, f) != 1u || fread(&version, sizeof(version), 1u, f) != 1u ||
        fread(&count, sizeof(count), 1u, f) != 1u || fread(&current, sizeof(current), 1u, f) != 1u ||
        magic != NDPR_MAGIC || version != NDPR_VERSION || count == 0u || count > ND_PROJECT_MAX || current >= count ||
        fread(s->projects, sizeof(s->projects[0]), count, f) != count || fgetc(f) != EOF) {
        fclose(f); set_error(err, ec, "project store corrupt"); return -1;
    }
    fclose(f);
    s->count = count;
    s->current_index = current;
    if (strcmp(s->projects[0].id, "default") != 0) { set_error(err, ec, "default project missing"); return -1; }
    for (size_t i = 0u; i < s->count; i++) {
        if (!valid_id(s->projects[i].id) || !s->projects[i].name[0]) { set_error(err, ec, "project record invalid"); return -1; }
    }
    return 0;
}

int nd_project_create(NDProjectStore *s, const char *id, const char *name, uint64_t now, char *err, size_t ec) {
    if (!s || !valid_id(id) || find_index(s, id) != (size_t)-1 || s->count >= ND_PROJECT_MAX) {
        set_error(err, ec, "invalid or duplicate project"); return -1;
    }
    NDProject p;
    memset(&p, 0, sizeof(p));
    if (normalize_name(name, p.name)) { set_error(err, ec, "invalid project name"); return -1; }
    snprintf(p.id, sizeof(p.id), "%s", id);
    p.created_at_ms = now;
    p.updated_at_ms = now;
    s->projects[s->count++] = p;
    return persist(s, err, ec);
}

int nd_project_rename(NDProjectStore *s, const char *id, const char *name, uint64_t now, char *err, size_t ec) {
    size_t idx = find_index(s, id);
    if (idx == (size_t)-1) { set_error(err, ec, "project not found"); return -1; }
    char normalized[ND_PROJECT_NAME_BYTES];
    if (normalize_name(name, normalized)) { set_error(err, ec, "invalid project name"); return -1; }
    snprintf(s->projects[idx].name, sizeof(s->projects[idx].name), "%s", normalized);
    s->projects[idx].updated_at_ms = now;
    return persist(s, err, ec);
}

int nd_project_select(NDProjectStore *s, const char *id, char *err, size_t ec) {
    size_t idx = find_index(s, id);
    if (idx == (size_t)-1) { set_error(err, ec, "project not found"); return -1; }
    s->current_index = idx;
    return persist(s, err, ec);
}

int nd_project_remove(NDProjectStore *s, const char *id, char *err, size_t ec) {
    if (!s || !id || strcmp(id, "default") == 0) { set_error(err, ec, "default project cannot be removed"); return -1; }
    size_t idx = find_index(s, id);
    if (idx == (size_t)-1) return 0;
    if (s->current_index == idx) s->current_index = 0u;
    else if (s->current_index > idx) s->current_index--;
    if (idx + 1u < s->count) memmove(&s->projects[idx], &s->projects[idx + 1u], (s->count - idx - 1u) * sizeof(s->projects[0]));
    s->count--;
    memset(&s->projects[s->count], 0, sizeof(s->projects[0]));
    return persist(s, err, ec);
}

const NDProject *nd_project_current(const NDProjectStore *s) {
    if (!s || !s->count || s->current_index >= s->count) return NULL;
    return &s->projects[s->current_index];
}

int nd_project_storage_path(const char *base, const char *project, const char *leaf, char *out, size_t cap) {
    if (!base || !*base || !valid_id(project) || !leaf || !*leaf || strchr(leaf, '/') || strchr(leaf, '\\') || !out || !cap) return -1;
    int w = snprintf(out, cap, "%s/%s/%s", base, project, leaf);
    return (w < 0 || (size_t)w >= cap) ? -1 : 0;
}
