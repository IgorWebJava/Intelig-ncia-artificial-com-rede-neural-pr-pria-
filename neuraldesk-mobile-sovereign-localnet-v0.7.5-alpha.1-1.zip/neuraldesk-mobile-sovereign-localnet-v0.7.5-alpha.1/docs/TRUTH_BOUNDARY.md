# v0.7.5 truth-boundary addendum

Implementado e comprovável: computational token streaming/UTF-8 adapter como mecânica; CPU_C99 hardware route; GPU/NPU fail-closed; sanitized progress/drain journal; current corpus governance; gradient accumulation resume-equivalence. Não comprovado/autorizado: modelo generativo útil/promovido, generative assistant activation, multi-request inference batching, GPU/NPU execution, multimodal neural inference, autonomous agents, APK/AAB/ART/device físico ou physical speedup.

# Truth Boundary — v0.7.4-alpha.2

Verdadeiro nesta candidata: lifecycle JNI host-validado com single-flight/cancel/deadline, Resource Governor efetivo, asset install streaming, Local RAG bounded/persistente/LRU, memória de pesquisa Android opt-in AES-GCM/Keystore e não-regressão targeted do comportamento existente.

Continua falso/não comprovado: **Generative Micro promovido, token streaming autoregressivo, Pirá full ativado, APK/AAB, ART/device físico, M1/M2/M3, GPU/NPU, speedup, energia/bateria/thermal benchmark físico, public/production serving ou segurança universal**.


Verdadeiro: C99 local, Android/JNI/Kotlin host-validated, Semantic Ranker, Local RAG, Safety bounded, Resource Governor, Journal, checkpoint/resume, Device Lab software, cross-target ABI e toolchain admission. Falso/não comprovado: Generative Micro promovido, Pirá full ativado, APK/AAB, Android ART/device físico, M1/M2/M3, GPU/NPU, public/production serving ou segurança universal.

## Podemos afirmar

- três redes neurais próprias da v0.5 continuam executando localmente sem mudança de pesos;
- existe uma KB first-party de 201 registros;
- existe um shard local NDOS de 31 registros humanos Pirá 2.0/CC BY 4.0;
- o NDOS usa 0 parâmetros neurais e recuperação TF-IDF local;
- Python e C reproduzem decisão de retrieval em 53/53 consultas de validação/calibração;
- 25/25 matches aceitos na validação humana estavam corretos e 0/25 negativos foram aceitos;
- o holdout pós-implementação teve 2/2 respostas aceitas corretas e uma recusa conservadora;
- quatro corrupções do formato foram rejeitadas;
- o asset foi reproduzido duas vezes byte-idêntico;
- o fallback NDOS só é consultado depois que fontes mais autoritativas não cobrem o objetivo.

## Não podemos afirmar

- que o NDOS seja treinamento neural, embedding model ou modelo de linguagem;
- que 31 registros constituam conhecimento aberto geral;
- que similaridade TF-IDF prove verdade do mundo;
- que a v0.6 alpha.2 seja byte-idêntica à alpha.1 perdida;
- que o pacote histórico `.ndsh` de 1.281 registros seja o runtime promovido nesta release;
- consciência, AGI, factualidade universal ou equivalência a modelos de fronteira;
- certificação física Android, APK/AAB verificado em dispositivo real ou desempenho térmico nesta evidência.

## Fronteira da resposta

O texto NDOS retornado é o answer humano armazenado localmente. Não existe chamada de IA externa para gerar ou reescrever a resposta.

## Android e rede

Podemos afirmar que JNI usa o mesmo núcleo C e que a política de asset-sync possui probe JVM host. Não podemos afirmar que `CanonicalAssetStore`, JNI, ART, filesystem, TLS ou rede foram certificados em aparelho Android físico. O cliente genérico possui controles HTTPS/endereço/bounds, mas esta release não reivindica eliminação completa de DNS-rebinding/TOCTOU ou segurança contra conteúdo remoto adversarial.

## Truth boundary adicional da v0.6.1

É verdadeiro afirmar que a candidata possui parser matemático composto, planner canônico único, fallback sparse fail-closed posterior à recusa neural, binding de atributo de memória, grounding morfológico conservador e continuidade bounded de um turno, todos exercitados pelo gate conversacional 12/12.

Continua **falso** afirmar que isso é um LLM generativo moderno, que os pesos aprendem durante o diálogo, que existe atenção longa/Transformer/MoE treinado nesta trilha, que o sistema possui compreensão universal, ou que está pronto para produção física Android. Os 543.094 parâmetros neurais e cinco assets permanecem inalterados nesta candidata.


## Limite v0.6.2

Histórico de 8 turnos e fatos estruturados não significam aprendizagem online dos pesos. O resumo é extração determinística das perguntas recentes, não geração autoregressiva. A v0.6.2 ainda não deve ser descrita como LLM generativo moderno nem como produção física Android certificada.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

