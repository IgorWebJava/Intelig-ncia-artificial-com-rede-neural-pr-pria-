<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Master Prompt — NeuralDesk Frontier Evolution Program

You are responsible for evolving the NeuralDesk documentation into an implementation-ready specification for a future AI platform capable of reaching parity with, and where evidence supports it exceeding, the strongest AI products available at implementation time.

## Non-negotiable scope for the current documentation phase

Create and improve **documentation only**.

Do not implement:
- backend services;
- model inference;
- neural network training;
- agent execution;
- tool execution;
- web browsing;
- computer use;
- persistent memory;
- real-time voice;
- background jobs;
- production infrastructure;
- executable source code.

The documentation must make future implementation possible without redesigning the architecture.

## Mission

Document a future NeuralDesk that can:
- use frontier external models immediately through replaceable adapters;
- route each request to the best model/capability for the task;
- support local, private and self-hosted models;
- progressively introduce NeuralDesk-owned specialized models;
- eventually support frontier-scale model research where resources justify it;
- execute persistent projects and conversations;
- pause/resume projects through durable checkpoints;
- compile relevant context instead of sending unlimited raw history;
- maintain scoped user/project/conversation/session/agent memory;
- perform real RAG and research with evidence, citations and provenance;
- orchestrate agents, tools, skills and workflows;
- execute work in controlled sandboxes;
- create and verify artifacts and complete projects;
- support voice, image, audio, video, document and screen/camera workflows;
- expose human approvals for risky operations;
- operate background and long-running tasks;
- provide cost, latency, quality, safety and traceability controls;
- evaluate every model/agent/workflow change before promotion;
- provide full operations, audit, versioning, canary and rollback;
- scale from one user/local deployment to distributed enterprise workloads.

## Architecture principles

1. Capability-first, provider-second.
2. Contracts before implementations.
3. Project state is durable; conversation history alone is not state.
4. Memory scopes are explicit and controllable.
5. All side effects pass through policy/approval.
6. Every artifact and action has provenance.
7. Evaluation is part of delivery, not an afterthought.
8. Every optimization requires a correct reference baseline.
9. Cloud, self-hosted and NeuralDesk-owned models remain interchangeable behind stable capabilities.
10. No superiority claim without reproducible evidence.
11. Security, privacy, cost and rollback are design inputs.
12. The UI must never pretend a future capability is executable before its runtime exists.

## Required planning method

For every capability:
1. identify current UI surface;
2. identify future engine owner;
3. define contract;
4. define state/data ownership;
5. define dependencies;
6. define security boundaries;
7. define observability;
8. define tests;
9. define benchmarks;
10. define implementation wave;
11. define rollback/fallback;
12. define exit criteria.

## Program sequence

Do not implement all engine modules simultaneously.

Follow:
- Phase 00 — measurement and baseline;
- Phase 01 — executable platform core;
- Phase 02 — model access, project continuity, memory and context;
- Phase 03 — knowledge, tools and agents;
- Phase 04 — multimodal, voice, web research and controlled computer use;
- Phase 05 — artifacts, long-running work and automation;
- Phase 06 — production control plane and enterprise hardening;
- Phase 07 — NeuralDesk-owned model program;
- Phase 08 — frontier research and continuous optimization.

At each phase, stop promotion if quality, safety, reliability, latency or cost gates fail.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
