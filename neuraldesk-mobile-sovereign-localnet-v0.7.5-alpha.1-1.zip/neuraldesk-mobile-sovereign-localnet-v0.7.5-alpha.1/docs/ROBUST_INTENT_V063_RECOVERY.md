# Robust Intent v0.6.3 Recovery — v0.7.1-alpha.1

A árvore v0.6.3 original foi perdida durante uma truncagem de workspace. A v0.7.1 não afirma byte-identidade com esse código perdido; reconstrói as propriedades documentadas e as prende a `nd_robust_intent_v063_recovery_test`.

Gate atual: **11/11 PASS**, simultaneamente com v0.6.1 **12/12**, v0.6.2 **7/7** e Live QA **35/35**. Propriedades: papel/capacidades, inferência, peso fixo na inferência, owner contextual por discourse bridge, conflito de memória fail-closed, RAG por sigla, quantização vs KV cache, quantificador universal, non-entailment, eventos atuais fail-closed e histórico bounded.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
