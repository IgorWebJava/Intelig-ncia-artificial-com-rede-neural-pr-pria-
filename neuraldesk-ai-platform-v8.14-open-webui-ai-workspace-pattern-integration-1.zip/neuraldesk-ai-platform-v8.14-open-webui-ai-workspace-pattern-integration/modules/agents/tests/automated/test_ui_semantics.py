import sys, unittest, re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class UISemanticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.ctx = TestContext(__file__)
    def test_viewport_meta_exists(self): self.assertRegex(self.ctx.html, r'<meta[^>]+name=["\']viewport["\']')
    def test_single_module_owned_css(self):
        links=re.findall(r'<link\b[^>]*href=["\']([^"\']+\.css)["\'][^>]*>',self.ctx.html,re.I); self.assertEqual(len(links),1); self.assertNotIn('/',links[0])
    def test_single_module_owned_runtime(self):
        scripts=re.findall(r'<script\b[^>]*src=["\']([^"\']+)["\'][^>]*>',self.ctx.html,re.I); self.assertEqual(scripts,['runtime/module-runtime.js'])
        self.assertIn('defer', self.ctx.html.lower())
    def test_no_external_runtime_urls(self): self.assertNotRegex(self.ctx.html,r'<script\b[^>]*src=["\']https?://')
    def test_required_ids_exist(self):
        for item in self.ctx.test_manifest['ui_assertions']['required_ids']:
            with self.subTest(id=item): self.assertRegex(self.ctx.html,rf'\bid=["\']{re.escape(item)}["\']')
    def test_required_text_exists(self):
        for text in self.ctx.test_manifest['ui_assertions']['required_text']:
            with self.subTest(text=text): self.assertIn(text.lower(),self.ctx.normalized_html.lower())
    def test_ui_profile_marker_exists(self): self.assertIn('data-ui-profile="intelligence-experience-v2"',self.ctx.html)
    def test_accessibility_landmarks_exist(self):
        for token in ['skip-link','aria-label','main-content']:
            with self.subTest(token=token): self.assertIn(token,self.ctx.html)
if __name__=='__main__': unittest.main()
