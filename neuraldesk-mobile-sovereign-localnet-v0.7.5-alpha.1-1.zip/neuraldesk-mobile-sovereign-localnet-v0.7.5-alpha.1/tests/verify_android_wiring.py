#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'android/app/src/main/java/com/neuraldesk/localnet/MainActivity.kt').read_text()
native=(ROOT/'android/app/src/main/java/com/neuraldesk/localnet/NativeEngine.kt').read_text()
store=(ROOT/'android/app/src/main/java/com/neuraldesk/localnet/CanonicalAssetStore.kt').read_text()
memory=(ROOT/'android/app/src/main/java/com/neuraldesk/localnet/ResearchMemoryStore.kt').read_text()
jni=(ROOT/'android/app/src/main/cpp/neuraldesk_jni.c').read_text()
gradle=(ROOT/'android/app/build.gradle.kts').read_text()
assert 'neuraldesk-semantic-ranker-v0.7.1.ndsr' in main
assert 'neuraldesk-open-knowledge-pira-full-v0.7.1' not in main and 'candidate.ndos' not in gradle
assert 'selectProfile()' in main and 'NativeEngine.setProfile(handle, profile)' in main
assert 'NativeEngine.answerStream' in main and 'NativeEngine.cancel(handle)' in main
assert 'NativeEngine.ragAddDocument' in main
assert 'NativeEngine.ragSave' in main and 'NativeEngine.ragLoad' in main
assert 'Executors.newSingleThreadExecutor()' in main
assert 'currentThermalStatus' in main and 'NativeEngine.setThermalStatus' in main
assert '.readBytes()' not in main and '.readBytes()' not in store
assert 'InputStream' in store and 'MessageDigest.getInstance("SHA-256")' in store and '64 * 1024' in store
assert 'semanticRankerPath' in native and 'nativeAnswerStream' in native and 'nativeCancel' in native
assert 'nativeSetThermalStatus' in native and 'nativeRagSave' in native and 'nativeRagLoad' in native
assert 'pthread_mutex_t' in jni and 'pthread_cond_t' in jni and 'active_operations' in jni
assert 'nd_assistant_answer_controlled' in jni and 'nd_assistant_answer_stream_controlled' in jni
assert 'calloc(65536u' not in jni and 'calloc(65536' not in jni
assert 'AndroidKeyStore' in memory and 'AES/GCM/NoPadding' in memory
assert 'prefs.getBoolean("enabled", false)' in memory
assert 'if (!isEnabled()) return' in memory
assert '.put("question"' in memory and '.put("source"' in memory and '.put("context"' in memory
assert '.put("answer"' not in memory
print('ANDROID_WIRING PASS profile=true semantic_ranker=true rag_persistence=true single_flight=true thermal=true bounded_assets=true encrypted_opt_in_memory=true native_lifecycle=true')
