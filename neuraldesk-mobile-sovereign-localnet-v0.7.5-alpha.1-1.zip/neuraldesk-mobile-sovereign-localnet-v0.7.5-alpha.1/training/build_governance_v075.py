#!/usr/bin/env python3
"""Build current-corpus governance for NeuralDesk v0.7.5.

This ports the stronger v0.63 governance mechanics without fabricating the
historical 490-record corpus or 250-item Golden bytes, which are not present in
the recoverable current library. Historical hashes are evidence-only.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os, subprocess, sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'training/data/generative_v074_v2'
OUT=ROOT/'training/data/governance_v075'
PRE=ROOT/'scripts/pre_generation_lessons_check.py'
HIST={
 'curatedRecordsSha256':'2ab3eec2efb6528ce71bf61f098285bc7822e9caca26cbf9e08debfbbe2dbc63',
 'trainingTextSha256':'4f00999b7eadc561c08240bdb78de5e126284c52c08e8473742996b745dec663',
 'golden250Sha256':'5b7382967349fd2bc884d0fd6d63829895a6d0a35febe3fa880fc707f4e59b4d',
}

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def norm(s:str)->str:
 return ' '.join(s.casefold().split())

def read_jsonl(p:Path):
 with p.open(encoding='utf-8') as f:
  for line in f:
   if line.strip(): yield json.loads(line)

def source_counts(p:Path)->Counter:
 return Counter(str(o.get('source','UNKNOWN')) for o in read_jsonl(p))

def write_atomic(path:Path,text:str):
 path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix(path.suffix+'.tmp')
 with tmp.open('w',encoding='utf-8',newline='') as f:
  f.write(text);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)

def build()->dict:
 rich=DATA/'rich_sft.jsonl'; ctx=DATA/'context_sft.jsonl'; replay=DATA/'causal_replay.jsonl'; val=DATA/'pira_validation.jsonl'
 for p in (rich,ctx,replay,val):
  if not p.is_file(): raise SystemExit(f'missing current corpus owner: {p}')
 rich_rows=list(read_jsonl(rich));ctx_rows=list(read_jsonl(ctx));replay_rows=list(read_jsonl(replay));val_rows=list(read_jsonl(val))
 train_q={norm(str(o.get('question',''))) for o in rich_rows+ctx_rows if o.get('question')}
 val_q={norm(str(o.get('question',''))) for o in val_rows if o.get('question')}
 overlap=sorted(train_q & val_q)
 if overlap: raise SystemExit(f'global question leakage={len(overlap)}')
 if any(o.get('trainingEligible') is not True for o in rich_rows+ctx_rows): raise SystemExit('train rows must declare trainingEligible=true')
 if any(o.get('usage')!='EVALUATION_ONLY' for o in val_rows): raise SystemExit('validation must be EVALUATION_ONLY')
 sources=[
  {'id':'PIRA_2_0_CC_BY_4_0','publisher':'C4AI / Pirá 2.0','rights':'CC BY 4.0','derivativesAllowed':True,'trainingEligibility':'TRAINING_ELIGIBLE_FROZEN_CURRENT_BYTES','piiPolicy':'NO_NEW_INGESTION_WITHOUT_EXPLICIT_REVIEW','provenance':'training/data/open_knowledge/historical_full/PIRA_PROVENANCE_v06.json'},
  {'id':'NEURALDESK_FIRST_PARTY_KB','publisher':'NeuralDesk','rights':'NEURALDESK_FIRST_PARTY','derivativesAllowed':True,'trainingEligibility':'TRAINING_ELIGIBLE','piiPolicy':'FIRST_PARTY_CURATED_NO_RAW_USER_CREDENTIALS','provenance':'training/knowledge_base.py'},
  {'id':'NEURALDESK_FIRST_PARTY_RETRIEVER_TRAIN','publisher':'NeuralDesk','rights':'NEURALDESK_FIRST_PARTY','derivativesAllowed':True,'trainingEligibility':'TRAINING_ELIGIBLE','piiPolicy':'FIRST_PARTY_CURATED_NO_RAW_USER_CREDENTIALS','provenance':'training/data/knowledge_retriever_train.tsv'},
  {'id':'NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN','publisher':'NeuralDesk','rights':'NEURALDESK_FIRST_PARTY','derivativesAllowed':True,'trainingEligibility':'TRAINING_ELIGIBLE','piiPolicy':'SYNTHETIC_FIRST_PARTY_NO_USER_DATA','provenance':'training/data/context_pointer_train.jsonl'},
  {'id':'PIRA_VALIDATION_140','publisher':'C4AI / Pirá 2.0','rights':'CC BY 4.0','derivativesAllowed':True,'trainingEligibility':'REFERENCE_ONLY_EVALUATION','piiPolicy':'NO_TRAINING_USE','provenance':'training/data/generative_v074_v2/pira_validation.jsonl'},
  {'id':'DIALOGUE_AND_POST_CORRECTION_HOLDOUTS','publisher':'NeuralDesk','rights':'NEURALDESK_FIRST_PARTY','derivativesAllowed':False,'trainingEligibility':'REFERENCE_ONLY_EVALUATION','piiPolicy':'NO_TRAINING_USE','provenance':'evaluation/'},
 ]
 observed=set(source_counts(rich))|set(source_counts(ctx))
 catalog_train={s['id'] for s in sources if s['trainingEligibility'].startswith('TRAINING_ELIGIBLE')}
 if not observed <= catalog_train: raise SystemExit(f'uncatalogued training sources={sorted(observed-catalog_train)}')
 return {
  'schema':'neuraldesk-current-corpus-governance-v075-v1',
  'status':'CURRENT_BYTES_VERIFIED_HISTORICAL_V063_GOVERNANCE_PORTED_NO_GOLDEN_FABRICATION',
  'policy':{
   'newSourcesRequireExplicitRights':True,'newSourcesRequireDerivativesAllowed':True,
   'newSourcesRequirePiiReview':True,'referenceOnlyCannotEnterTraining':True,
   'globalQuestionCrossSplitLeakageMustEqual':0,'goldenOrHoldoutTrainingReuseProhibited':True,
  },
  'current':{
   'richSft':{'rows':len(rich_rows),'sha256':sha(rich),'sourceCounts':dict(sorted(source_counts(rich).items()))},
   'contextSft':{'rows':len(ctx_rows),'sha256':sha(ctx),'sourceCounts':dict(sorted(source_counts(ctx).items()))},
   'causalReplay':{'rows':len(replay_rows),'sha256':sha(replay),'sourceCounts':dict(sorted(source_counts(replay).items()))},
   'piraValidation':{'rows':len(val_rows),'sha256':sha(val),'usage':'EVALUATION_ONLY'},
   'globalQuestionCrossSplitLeakage':0,
  },
  'sources':sources,
  'historicalV063':{
   'evidenceStatus':'CONFLICTING_RELEASE_STATUS_CAPABILITY_EVIDENCE_ONLY',
   'rawCurated490Recovered':False,'historicalGolden250Imported':False,
   'reason':'Canonical hashes and governance contract are recoverable, but raw curated-record and Golden-suite bytes were not found in the current Library. Do not fabricate.',
   'attestedCounts':{'curatedTotal':490,'train':397,'validation':35,'test':58,'golden':250},
   'attestedHashes':HIST,
  },
  'multimodal':{'metadataContractsHistoricalEvidence':True,'trainedMultimodalModel':False,'runtimeActivated':False},
  'promotionAuthorized':False,
 }

def main()->int:
 subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(OUT/'CURRENT_CORPUS_GOVERNANCE.json'));ap.add_argument('--catalog-csv',default=str(OUT/'SOURCE_CATALOG.csv'));a=ap.parse_args()
 m=build();out=Path(a.output);write_atomic(out,json.dumps(m,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 csvp=Path(a.catalog_csv);csvp.parent.mkdir(parents=True,exist_ok=True);tmp=csvp.with_suffix('.csv.tmp')
 fields=['id','publisher','rights','derivativesAllowed','trainingEligibility','piiPolicy','provenance']
 with tmp.open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(m['sources']);f.flush();os.fsync(f.fileno())
 os.replace(tmp,csvp)
 print(f"CURRENT_CORPUS_GOVERNANCE PASS rich={m['current']['richSft']['rows']} context={m['current']['contextSft']['rows']} replay={m['current']['causalReplay']['rows']} validation={m['current']['piraValidation']['rows']} leakage=0 historicalGolden250Imported=false")
 return 0
if __name__=='__main__': raise SystemExit(main())
