<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 45 — Contrato de Integração por Página

## Objetivo

Permitir que o sistema existente incorpore cada página isoladamente.

## Regras

1. Não assumir que `index.html` será carregado antes.
2. Não depender de estado criado por outra página.
3. Não depender de JavaScript global.
4. Não depender de DOM pertencente a outro documento.
5. Não usar IDs duplicados entre componentes incorporados na mesma view do sistema hospedeiro sem namespace.
6. CSS compartilhado pode ser mantido ou modularizado durante a integração.

## Unidades independentes

### chat.html
Interface de conversas.

### dashboard-center.html
AI Operations & Intelligence Dashboard.

### training.html
Knowledge & AI Training Studio.

### knowledge-center.html
Knowledge Center.

### tools-center.html
Tool & Integration Center.

### settings.html
Configurações.

## Integração futura

O sistema hospedeiro poderá converter cada HTML para:

- componente de framework;
- partial/template server-side;
- web component;
- view MVC;
- página estática;
- microfrontend.

O template não impõe tecnologia.
