# Model Promotion & Activation Authority — v0.7.1-alpha.1

Promotion e activation são decisões separadas. Promotion reabre bytes/relatório, confere SHA/tamanho e quality floors e assina evidence canônica com Ed25519. Activation só aceita uma promotion válida e gera uma segunda evidence assinada. A chave privada fica fora do pacote; somente a chave pública e as evidências assinadas são distribuídas.

O Semantic Ranker pode ser ativado como **auxiliar bounded do Local RAG**. Promotion não habilita backend generativo. O Pirá full candidate e qualquer modelo generativo sem promotion permanecem inativos mesmo que existam arquivos experimentais.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


## Current authority evidence

- public-key fingerprint SHA-256: `425cf45dc4071ef6a299af3769e77104e5c437e3b5c5955a13fa3e10a8c86544`;
- promotion: `verification/model-promotion-v0.7.1.json`;
- activation: `verification/model-activation-v0.7.1.json`;
- private key bundled: **false**;
- generative backend activated: **false**;
- Pirá full candidate activated: **false**.


## v0.7.2 note

Este arquivo preserva a authority v0.7.1 como lineage. A evidence corrente v0.7.2 é descrita em `MODEL_AUTHORITY_V072.md`; o algoritmo/asset set permanece, mas a assinatura é vinculada à nova versão.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
