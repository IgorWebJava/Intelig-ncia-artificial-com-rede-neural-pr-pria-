<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 96 — Neural Runtime Data Flow

```text
User
→ Chat API
→ Context Orchestrator
→ Configuration Service
→ Knowledge / Models / Tools
→ Neural Runtime
→ Result
→ Conversation Store
→ Audit / Telemetry
```

The neural runtime reads effective configuration through services/cache populated from the authoritative data platform.
