#!/usr/bin/env python3
"""Materialize first-party multidomain language/code curriculum for v0.7.6.

Training-only inputs are derived from current project documentation and source code.
Evaluation/tests/verification/memory/release evidence are excluded. File-level hashing
keeps each source file wholly in train or holdout so neighboring chunks cannot leak.
"""
from __future__ import annotations
import hashlib, json, re, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PRE=ROOT/'scripts/pre_generation_lessons_check.py'
OUT=ROOT/'training/data/generative_v076'
ALLOWED={'.c','.h','.py','.kt','.kts','.md','.txt'}
ROOTS=['core/src','core/include','training','android/app/src/main/java','docs','cli']
EXCLUDE_PARTS={'tests','evaluation','verification','build','build-sanitize','__pycache__','memória','models','training-state'}
EXCLUDE_FILES={'docs/EVALUATION.md'}

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def sha_file(p:Path)->str:return sha_bytes(p.read_bytes())
def split_for(rel:str)->str:
    v=int.from_bytes(hashlib.sha256(rel.encode()).digest()[:4],'big')%100
    return 'train' if v<82 else ('dev' if v<91 else 'holdout')
def lang(p:Path)->str:
    return {'.c':'C','.h':'C header','.py':'Python','.kt':'Kotlin','.kts':'Kotlin Gradle','.md':'Markdown','.txt':'text'}.get(p.suffix,'text')
def chunks(text:str, size:int=640, overlap:int=96):
    text=text.replace('\r\n','\n').replace('\r','\n')
    out=[]; pos=0
    while pos<len(text):
        end=min(len(text),pos+size)
        piece=text[pos:end].strip()
        if len(piece)>=80:out.append(piece)
        if end>=len(text):break
        pos=max(pos+1,end-overlap)
    return out

def function_units(p:Path,text:str):
    ls=text.splitlines(); out=[]
    if p.suffix=='.py': pat=re.compile(r'^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\((.*?)\)')
    elif p.suffix in {'.kt','.kts'}: pat=re.compile(r'^\s*(?:private\s+|public\s+|internal\s+|protected\s+|suspend\s+|inline\s+|override\s+)*fun\s+([A-Za-z_]\w*)\s*\((.*?)\)')
    else: pat=re.compile(r'^\s*(?:static\s+)?(?:[A-Za-z_]\w*[\s\*]+)+([A-Za-z_]\w*)\s*\(([^;]*)\)\s*\{?\s*$')
    for i,line in enumerate(ls):
        m=pat.match(line)
        if not m:continue
        block='\n'.join(ls[i:min(len(ls),i+14)]).strip()
        if len(block)<40:continue
        out.append((m.group(1),m.group(2).strip(),line.strip(),block))
    return out

def doc_sections(text:str):
    ls=text.splitlines(); out=[]
    for i,line in enumerate(ls):
        if not re.match(r'^#{1,4}\s+\S',line):continue
        title=re.sub(r'^#{1,4}\s+','',line).strip()
        body=[]
        for x in ls[i+1:i+18]:
            if re.match(r'^#{1,4}\s+\S',x):break
            if x.strip():body.append(x.strip())
        ans=' '.join(body)[:320].strip()
        if len(ans)>=60:out.append((title,ans))
    return out

def write_jsonl(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8') as f:
        for r in rows:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')

def main():
    subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
    files=[]
    for base in ROOTS:
        q=ROOT/base
        if not q.exists():continue
        cand=[q] if q.is_file() else list(q.rglob('*'))
        for p in cand:
            if not p.is_file() or p.suffix.lower() not in ALLOWED:continue
            rel=p.relative_to(ROOT).as_posix()
            if rel in EXCLUDE_FILES or any(part in EXCLUDE_PARTS for part in p.relative_to(ROOT).parts):continue
            try:text=p.read_text(encoding='utf-8')
            except UnicodeDecodeError:continue
            files.append((rel,p,text,split_for(rel)))
    causal={'train':[],'dev':[],'holdout':[]}; sft={'train':[],'dev':[],'holdout':[]}; manifests=[]
    for rel,p,text,sp in sorted(files):
        manifests.append({'path':rel,'split':sp,'sha256':sha_file(p),'bytes':p.stat().st_size,'language':lang(p)})
        for j,piece in enumerate(chunks(text)):
            causal[sp].append({'id':f'project:{rel}:chunk:{j:04d}','source':'NEURALDESK_FIRST_PARTY_PROJECT_SOURCE','path':rel,'language':lang(p),'text':piece,'trainingEligible':sp=='train'})
        if p.suffix in {'.c','.h','.py','.kt','.kts'}:
            for j,(name,args,sig,block) in enumerate(function_units(p,text)):
                # Symbol/parameter reading tasks.
                sft[sp].append({'id':f'code:{rel}:symbol:{j:04d}','source':'NEURALDESK_FIRST_PARTY_CODE_TASK','question':f'Neste trecho {lang(p)}, qual é o nome do símbolo de função declarado?\n{sig}','response':name,'trainingEligible':sp=='train','path':rel,'task':'symbol_reading'})
                sft[sp].append({'id':f'code:{rel}:params:{j:04d}','source':'NEURALDESK_FIRST_PARTY_CODE_TASK','question':f'Leia esta assinatura {lang(p)} e transcreva os parâmetros declarados entre parênteses.\n{sig}','response':args or '(sem parâmetros)','trainingEligible':sp=='train','path':rel,'task':'signature_reading'})
                # Completion from real code; target is never generated by an external model.
                if len(block)>90:
                    for k,frac in enumerate((0.34,0.62)):
                        cut=max(40,min(len(block)-24,int(len(block)*frac)))
                        target=block[cut:cut+150]
                        if len(target)>=24:
                            prefix=block[max(0,cut-260):cut]
                            sft[sp].append({'id':f'code:{rel}:completion:{j:04d}:{k}','source':'NEURALDESK_FIRST_PARTY_CODE_TASK','question':f'Complete a próxima parte deste trecho {lang(p)} do NeuralDesk a partir do prefixo:\n{prefix}','response':target,'trainingEligible':sp=='train','path':rel,'task':'code_completion'})
                sft[sp].append({'id':f'code:{rel}:language:{j:04d}','source':'NEURALDESK_FIRST_PARTY_CODE_TASK','question':f'Qual é a linguagem deste trecho?\n{block[:360]}','response':lang(p),'trainingEligible':sp=='train','path':rel,'task':'language_identification'})
        if p.suffix=='.md':
            for j,(title,ans) in enumerate(doc_sections(text)):
                sft[sp].append({'id':f'doc:{rel}:{j:04d}','source':'NEURALDESK_FIRST_PARTY_DOC_TASK','question':f'Explique, com base na documentação do NeuralDesk, o tópico: {title}','response':ans,'trainingEligible':sp=='train','path':rel,'task':'documentation_explanation'})
    OUT.mkdir(parents=True,exist_ok=True)
    for sp in causal:write_jsonl(OUT/f'project_causal_{sp}.jsonl',causal[sp]);write_jsonl(OUT/f'project_sft_{sp}.jsonl',sft[sp])
    (OUT/'SOURCE_FILES.json').write_text(json.dumps(manifests,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    prov={'schema':'neuraldesk-generative-v076-project-corpus-v1','fileSplit':'SHA256_PATH_82_9_9','sourceFiles':len(manifests),'causalCounts':{k:len(v) for k,v in causal.items()},'sftCounts':{k:len(v) for k,v in sft.items()},'trainingSources':['NEURALDESK_FIRST_PARTY_PROJECT_SOURCE','NEURALDESK_FIRST_PARTY_CODE_TASK','NEURALDESK_FIRST_PARTY_DOC_TASK'],'excluded':['tests/','evaluation/','verification/','memória/','models/','docs/EVALUATION.md'],'holdoutPolicy':'FILE_LEVEL_NO_TRAIN_CHUNK_FROM_HOLDOUT_FILE','externalAiTargets':False}
    for n in [*['project_causal_'+s+'.jsonl' for s in causal],*['project_sft_'+s+'.jsonl' for s in sft],'SOURCE_FILES.json']:
        prov.setdefault('sha256',{})[n]=sha_file(OUT/n)
    (OUT/'PROVENANCE.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(prov,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
