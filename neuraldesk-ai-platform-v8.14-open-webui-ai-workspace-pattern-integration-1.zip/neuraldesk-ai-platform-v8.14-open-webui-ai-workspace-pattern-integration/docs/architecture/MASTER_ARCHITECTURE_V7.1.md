<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Master Architecture — NeuralDesk V7.1

## Platform

```text
App Shell
   ↓
Module Registry
   ↓
Capability Registry
   ↓
Versioned Contracts
   ↓
Replaceable Modules
```

## Data path

```text
UI / Client
→ API Gateway / BFF
→ Application / Domain Service
→ Module-owned Data
→ PostgreSQL SSOT
```

## Distributed change path

```text
State Change
+
Transactional Outbox
→ Commit
→ Event Stream
→ Idempotent Consumers
```

## AI path

```text
Domain Module
→ AI Capability Fabric
→ Model Router
→ Capability Negotiation
→ Provider Adapter
→ External / Local Model
```

## Media path

```text
Upload
→ Media Platform
→ Safety / Validation
→ Object Storage
→ Asset Reference
→ AI / Knowledge / Training
```

## Platform invariants

1. Everything functional is a module.
2. Modules depend on contracts/capabilities, not private implementations.
3. Modules own their private mutable data.
4. UI does not access PostgreSQL directly.
5. Provider SDKs are isolated behind adapters.
6. Multimodal assets use stable references.
7. Important changes are audited.
8. Public contracts are independently versioned.


## V7.5 Agent Platform Extension

```text
Project Registry
      ↓
Agent Projects & Multi-Agent Studio
      │
      ├── Runtime Agent Skill Registry
      ├── Tool Catalog / Gateway
      ├── Knowledge Retrieval
      ├── AI Capability Fabric
      ├── Training / Evaluation
      ├── Audit
      └── Operations
```

The canonical module set now contains 10 modules, including `neuraldesk.agents`. Runtime agent skills are separate from development `habilidades/`.
