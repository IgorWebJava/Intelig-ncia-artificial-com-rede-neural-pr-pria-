# v0.7.5 architecture addendum

O runtime continua com **uma única autoridade C99**. Novos primitives: `NDGenStreamSession`, `NDGenTextStreamSession`, `NDHardwareCapabilities/NDHardwareRoute` e Run Journal progress/drain. Eles estendem owners existentes; não criam segundo decoder, segundo resource governor ou segundo telemetry backend.

# Architecture — v0.7.4-alpha.2

## Mobile execution delta v0.7.3

O owner continua sendo o mesmo `NDAssistant` C99. `NDExecutionControl` injeta cancel/deadline cooperativos sem criar segunda engine. JNI serializa uma operação por handle e espera idle no destroy. `nd_resource` governa limites efetivos por profile/thermal. `nd_rag` permanece owner único e agora adiciona lifecycle bounded/persistência `NDRAG001`. Android apenas adapta lifecycle, assets e Keystore; nenhuma política de resposta é duplicada em Kotlin.

True generative streaming, paged KV e speculative decoding continuam fora desta release porque não há backbone generativo promovido. Esses mecanismos não podem ser simulados no assistant determinístico.


Ordem canônica:

`semantic_intent_frame_and_safety_precheck -> memory_command_or_conversation_policy -> bounded_recent_history_topic_shift_and_non_entailment_guard -> plan_goals -> supplied_context_or_local_rag_bm25_semantic_rerank_grounding -> exact_tool_or_text_utility -> structured_explicit_memory_then_text_memory -> internal_neural_knowledge_with_acronym_preservation_then_sparse_kb_if_neural_refuses -> active_local_open_knowledge_ndos_if_internal_refuses -> uncertainty -> safety_output_postcheck -> compose`

O Local RAG usa BM25 para recall bounded e o Semantic Ranker somente para reordenar top-N. Promotion e activation são authorities separadas. Resource Governor define limites por perfil; Safety é pre/post e não reivindica segurança universal.

## Objetivo

Maximizar utilidade móvel e factualidade sem esconder um backend externo de IA e sem obrigar uma rede pequena a resolver tarefas que mecanismos determinísticos fazem melhor.

## Pipeline canônico

A ordem abaixo foi conferida diretamente em `core/src/nd_assistant.c` e deve coincidir com `PROJECT_MANIFEST.json`:

```text
question
  -> explicit memory command or bounded deterministic conversation policy
  -> optional one-turn follow-up augmentation
  -> planner / subgoals
  -> para cada objetivo:
       1. supplied context + grounding
          -> sentence segmentation
          -> entity / temporal grounding
          -> neural relation classification
          -> per-goal evidence coverage
          -> relation-conditioned neural pointer
          -> candidate acceptance / grounded fallback
       2. exact local calculator, quando aplicável
       3. explicit local memory
       4. internal neural knowledge retriever + versioned .ndkb
          -> if neural refuses: conservative sparse match on the SAME .ndkb
          -> score + margin + entity precision guard
       5. local NDOS v1 somente se toda a rota interna recusar
       6. explicit uncertainty
  -> compose goals covered by their authoritative routes
```

Contrato machine-readable correspondente:

`memory_command_or_conversation_policy -> bounded_followup_context -> plan_goals -> supplied_context_grounding -> exact_tool -> explicit_memory -> internal_neural_knowledge_then_sparse_kb_if_neural_refuses -> local_open_knowledge_ndos_if_internal_refuses -> uncertainty -> compose`.

Uma exceção deliberada é o fail-closed para contexto estruturado: quando há contexto fornecido sobre uma entidade estruturada mas a relação pedida não é sustentada, o runtime pode encerrar aquele objetivo como incerto em vez de procurar um fato genérico em fontes posteriores. Isso evita que uma entidade correta seja usada como licença para responder um atributo ausente.

## Knowledge path

O retriever neural não armazena a resposta em um token secreto. Ele escolhe um registro da `.ndkb`; confiança e margem determinam aceitação. O conteúdo factual permanece inspecionável e versionável fora dos pesos.

## Relation path

O classificador recebe features hash + cues auditáveis e produz 25 relações + `unknown`. O preprocessamento Python/C faz parte do contrato do modelo. A linha neural preservada da v0.5 usa threshold conservador e possui uma exceção auditável: top-1 conhecido com confiança mínima pode ser aceito quando existe uma cue explícita **única** da própria relação, sem cue concorrente. Isso evita reduzir globalmente o gate de margem.

## Pointer path

O pointer v2 usa bytes UTF-8, janela local e embedding de relação. Ele propõe `start/end`; não decide sozinho se o texto deve ser exibido.

### Candidate acceptance

O runtime valida que o candidato:

- existe literalmente na evidência;
- não começa/termina no meio de token;
- não é vazio ou trivial;
- não é apenas uma repetição da frase que nomeia a própria relação;
- preserva extensões estruturadas já presentes na evidência.

Se a proposta falha, a evidência selecionada permanece a resposta grounded. O sistema troca precisão de span por segurança, não por invenção.

## Multiobjetivo

Até 8 objetivos são tratados individualmente. O sistema não usa top-k global como cobertura. Cada objetivo precisa de suporte próprio; respostas compostas podem misturar contexto, memória, calculadora e KB.

## Internet

A internet não participa do raciocínio remoto. Android adquire texto HTTPS autorizado, filtra/seleciona candidatos e entrega texto ao mesmo runtime C. Sem evidência suficiente, a política é recusar.

## Delta v0.6.0-alpha.2 — Open Knowledge NDOS

Após a rota interna v0.5 recusar um objetivo, `NDAssistant` pode consultar opcionalmente um `NDOS v1`. O shard não participa da seleção contextual anterior, não substitui calculadora/memória/KB e não é consultado quando o retriever interno já aceitou uma resposta.

```text
internal knowledge rejected
  -> normalize UTF-8 -> ASCII
  -> hashed word/char features
  -> TF-IDF cosine over 31 local human records
  -> best + second-best
  -> require score AND margin
  -> accepted human answer OR explicit uncertainty
```

O planner também reconhece preâmbulos tópicos/de propósito antes de uma oração interrogativa, impedindo que `Para estimar X, qual ...?` gere um falso objetivo `Para estimar X`.

## Conversational correctness v0.6.1

O runtime continua não-generativo no sentido de um decoder LLM geral. A v0.6.1 acrescenta um estado bounded de **um turno anterior** (`last_question`/`last_answer`) para resolver follow-ups curtos como `E por que isso importa?`. Não existe atualização online de pesos.

O planner é uma única fonte de verdade (`nd_planner`) tanto no `NDAssistant` quanto no grounding contextual. Planos distributivos gerados para `cada técnica` são autossuficientes e não recebem herança genérica de entidade.

A KB interna continua neural-first. Um matcher sparse pode recuperar uma pergunta canônica somente quando o retriever neural recusa; o fallback exige cobertura lexical/margem conservadoras e deve recusar entidades estruturadas inéditas em vez de substituí-las por entidades conhecidas.

A calculadora agora analisa expressões simbólicas bounded por recursive descent antes do parser verbal legado, preservando a separação entre operações exatas e conhecimento aprendido.


## Dialogue Grounding v0.6.2

A rota de memória consulta primeiro fatos estruturados derivados quando pergunta e evidência identificam sujeito+relação. Se não houver fato inequívoco, a rota textual herdada continua disponível. O histórico da instância guarda no máximo 8 pares pergunta/resposta e é usado somente para continuidade bounded e resumo determinístico. Nova sigla/entidade explícita bloqueia herança de tópico. Retrieval de KB neural permanece first; para consultas com acrônimo, um candidato aceito que perde a sigla é rejeitado antes do fallback sparse.


## Orchestrator canônico v0.6.2

`memory_command_or_conversation_policy -> bounded_recent_history_topic_shift_and_non_entailment_guard -> plan_goals -> supplied_context_grounding -> exact_tool -> structured_explicit_memory_then_text_memory -> internal_neural_knowledge_with_acronym_preservation_then_sparse_kb_if_neural_refuses -> local_open_knowledge_ndos_if_internal_refuses -> uncertainty -> compose`


## Offline continuity v0.7.2

A camada de continuidade não altera a precedência do orchestrator. `nd_network_policy`, `nd_outbox`, `nd_project`, `nd_pilot`, `nd_model_acquisition` e `nd_benchmark` são owners auxiliares locais. O outbox não é uma rota de inferência e nunca envia tarefas para IA externa. Pilot master kill é checado antes de `NDAssistant` executar a cadeia canônica. Projects só administra metadados e paths; memória/RAG/outbox preservam ownership próprio.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

