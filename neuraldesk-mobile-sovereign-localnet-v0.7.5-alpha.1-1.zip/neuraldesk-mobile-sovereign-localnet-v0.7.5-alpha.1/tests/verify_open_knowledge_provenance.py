#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
R=Path(__file__).resolve().parents[1]; P=R/'training/data/open_knowledge'
expected={
 'PIRA_RECONSTRUCTION_PROVENANCE.json':'7e69a4ff81be666f1c7194d23a205e5310e0278404628fa01163fb44e83153e5',
 'pira_reconstruction_records_v1.jsonl':'bdc7843402ec8ce6ccbb18fdb5a89f8c83f42168c5f9c586b494bfea222dd771',
 'pira_reconstruction_validation_v1.jsonl':'2f629a979afd4cc90a3360ba0e8bddef6670598ef3d9495ac683a48a8173fc0b',
 'open_knowledge_negatives_v1.jsonl':'34ebf1befe0bd6597f703c1d228d2a09f8fd7f65e53306cce8bf959b9619ba59',
 'open_knowledge_holdout_v1.jsonl':'7cc225f6eadc3034d7a5ec52755bfdd663bf64a5a5851cfec2dfe9c5c006bc08'}
for name,sha in expected.items():
    got=hashlib.sha256((P/name).read_bytes()).hexdigest(); assert got==sha,(name,got,sha)
prov=json.loads((P/'PIRA_RECONSTRUCTION_PROVENANCE.json').read_text(encoding='utf-8'))
assert prov['source']=='Pirá 2.0' and prov['licenseApplied']=='CC BY 4.0'
assert prov['lineage']['automaticParaphrasesUsedForShard'] is False and prov['lineage']['testSplitUsed'] is False
assert len(prov['selectedSourceIds'])==31 and len(set(prov['selectedSourceIds']))==31 and 'A160' in prov['selectedSourceIds']
records=[json.loads(x) for x in (P/'pira_reconstruction_records_v1.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
assert len(records)==31 and all(r['license']=='CC BY 4.0' for r in records)
text=(P/'pira_reconstruction_records_v1.jsonl').read_text(encoding='utf-8').lower()
for forbidden in ['question_aut_','answer_aut_','context_pt','text_pt']: assert forbidden not in text
print('open-knowledge-provenance PASS 5 artifacts; 31 human records; test split unused; automatic fields excluded')
