<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.skills; current: docs/architecture/CURRENT_SKILLS_TOOLING.md -->
# Current Skills & Tooling

Development skills profile: `skills-tools-registry-v1`. Current registry tracks **23 skills** and **58 abstract development capabilities**.

Important V8 skills include experience runtime design, autonomous-assistant experience template design, Intelligence Experience Design and module preview/documentation governance. Concrete tools remain replaceable providers of abstract capabilities.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
