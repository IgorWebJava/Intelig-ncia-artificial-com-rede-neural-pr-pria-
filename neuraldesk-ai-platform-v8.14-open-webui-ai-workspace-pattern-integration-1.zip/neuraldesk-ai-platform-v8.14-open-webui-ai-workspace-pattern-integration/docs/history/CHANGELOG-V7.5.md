<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# V7.5 — Agent Projects & Multi-Agent Studio

## Added
- `modules/agents/` complete modular package
- `agents.html` compatibility alias
- Project Registry capability provider
- Runtime Agent Skill Registry
- Agent schemas/contracts and `mod_agents` migration
- Agent catalog/builder/teams/workflows/playground/evals/versions/runs/deployments/trash UI
- Agent module tests/docs/skills requirements
- runtime agent skill templates and system agent templates

## Integrated
- App Shell
- System Configuration
- AI Operations
- Audit
- Training/Evaluation
- Tool Center
- Knowledge
- Chat/Settings navigation
- Module/Capability/Contract registries

## Version model
Package/Architecture/Documentation/Memory/Skills: V7.5 · Visual platform profile remains adaptive-multimodal-v1.
