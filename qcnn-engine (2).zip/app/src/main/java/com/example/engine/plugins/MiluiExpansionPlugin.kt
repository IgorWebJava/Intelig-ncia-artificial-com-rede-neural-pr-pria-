package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.QcnnExecutionContext

/**
 * Plugin de Descompactação Quântico-Cabalística (Milui).
 * Expande a semente em camadas fractais genealógicas.
 */
class MiluiExpansionPlugin : IQcnnPlugin {
    override val pluginId: String = "milui_expansion"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        val prompt = context.prompt.lowercase()
        var semente = "Alef"

        for (letra in MatrizLetras.MATRIZ_22.keys) {
            if (prompt.contains(letra.lowercase())) {
                semente = letra
                break
            }
        }

        context.targetSeed = semente
        val dadosSemente = MatrizLetras.MATRIZ_22[semente] ?: MatrizLetras.MATRIZ_22["Alef"]!!
        context.metadata["camada_1"] = dadosSemente.milui

        return context
    }
}
