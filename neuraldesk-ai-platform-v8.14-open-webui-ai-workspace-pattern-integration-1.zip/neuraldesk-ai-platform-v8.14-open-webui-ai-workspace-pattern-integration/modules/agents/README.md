<!-- neuraldesk-documentation-sync: V8.8 -->

# Agent Projects & Multi-Agent Studio — Modular Package

Canonical module ID: `neuraldesk.agents`

This module owns project-scoped agent definitions, versions, bindings, teams, workflows, deployments and run metadata. It **does not** own Projects, Tools, Knowledge contents, AI provider implementations or global development skills.

```text
modules/agents/
├── module.manifest.json
├── ui/
├── contracts/
├── data/
├── docs/
├── tests/
└── compatibility/
```
