import os
import re
import math
from typing import Dict, List, Any, Optional
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class ContinuousIngestionPlugin(BaseQcnnPlugin):
    """
    Pilar 1: Auto-Expansão Ontológica em Background (Continuous Knowledge Distillation).
    Monitora e destila automaticamente arquivos de texto, manuais e bases locais
    em grafos de conhecimento estruturados, frequências áureas (phi=1.618)
    e nós conceituais instantâneos.
    """
    def __init__(self, knowledge_dir: str = "./conhecimento_local"):
        super().__init__()
        self.knowledge_dir = knowledge_dir
        self.ingested_files: Dict[str, float] = {}
        self.distilled_ontology: Dict[str, Dict[str, Any]] = {}
        self._auto_scan()

    @property
    def plugin_id(self) -> str:
        return "continuous_ingestion"

    def _calculate_golden_frequency(self, text: str) -> float:
        phi = 1.61803398875
        base_hz = 121.35
        char_sum = sum(ord(c) for c in text if c.isalnum())
        freq = base_hz + (char_sum % 1000) * (phi - 1.0)
        return round(freq, 2)

    def _extract_entities_and_relations(self, text: str) -> List[Dict[str, Any]]:
        """
        Extrai entidades, conceitos-chave, sinônimos e orações centrais sem dependências externas.
        Indexa tanto substantivos principais quanto bigramas conceituais.
        """
        paragraphs = [p.strip() for p in text.split("\n\n") if len(p.strip()) > 15]
        entities = []
        stop_words = {"para", "como", "sobre", "entre", "quando", "onde", "pelo", "pela", "este", "esta", "isso", "esse", "essa", "mais", "muito", "todo", "toda", "com", "sem", "sob", "dos", "das"}
        
        for p in paragraphs:
            sentences = re.split(r'[.!?\n]+', p)
            for s in sentences:
                s_clean = s.strip()
                if len(s_clean) > 20:
                    words = [w for w in re.split(r'[\s,;:()"\#\-\_\/\[\]]+', s_clean.lower()) if len(w) > 3 and w not in stop_words]
                    if words:
                        for w in words[:4]:
                            entities.append({
                                "keyword": w,
                                "summary": s_clean,
                                "hz": self._calculate_golden_frequency(s_clean),
                                "tokens": words[:8]
                            })
                        if len(words) >= 2:
                            bigram = f"{words[0]} {words[1]}"
                            entities.append({
                                "keyword": bigram,
                                "summary": s_clean,
                                "hz": self._calculate_golden_frequency(s_clean),
                                "tokens": words[:8]
                            })
        return entities

    def _auto_scan(self):
        """Varre o diretório e constrói a ontologia local em microssegundos."""
        if not os.path.exists(self.knowledge_dir):
            try:
                os.makedirs(self.knowledge_dir, exist_ok=True)
            except Exception:
                return

        for fname in os.listdir(self.knowledge_dir):
            if fname.endswith(".txt") or fname.endswith(".dat") or fname.endswith(".org"):
                fpath = os.path.join(self.knowledge_dir, fname)
                try:
                    mtime = os.path.getmtime(fpath)
                    if fname not in self.ingested_files or self.ingested_files[fname] < mtime:
                        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                        extracted = self._extract_entities_and_relations(content)
                        for item in extracted:
                            self.distilled_ontology[item["keyword"]] = item
                        self.ingested_files[fname] = mtime
                except Exception:
                    pass

    def ingest_raw_text(self, title: str, text: str) -> int:
        """Permite ingestão manual programática de um novo bloco de texto."""
        extracted = self._extract_entities_and_relations(text)
        for item in extracted:
            self.distilled_ontology[item["keyword"]] = item
        return len(extracted)

    def search_distilled_knowledge(self, prompt: str) -> Optional[Dict[str, Any]]:
        self._auto_scan()
        words = [w.lower() for w in re.split(r'[\s,;:.?!]+', prompt) if len(w) > 3]
        for w in words:
            if w in self.distilled_ontology:
                return self.distilled_ontology[w]
        return None

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        matched = self.search_distilled_knowledge(context.prompt)
        if matched and not context.custom_response:
            context.metadata["ingested_source"] = matched["keyword"]
            context.metadata["ingested_hz"] = matched["hz"]
        return context
