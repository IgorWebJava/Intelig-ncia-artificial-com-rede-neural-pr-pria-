from typing import Dict, List
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS

class MiluiExpansionPlugin(BaseQcnnPlugin):
    """
    Plugin de Expansão Fractal (Milui Cabalístico das 22 Letras Fundamentais).
    Identifica a semente alvo e expande a primeira camada genealógica.
    """

    DICIONARIO_MILUI: Dict[str, List[str]] = {
        letra: dados["milui"] for letra, dados in MATRIZ_22_LETRAS.items()
    }

    @property
    def plugin_id(self) -> str:
        return "milui_expansion"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        prompt_lower = context.prompt.lower()
        target_seed = "Alef"

        for key in self.DICIONARIO_MILUI.keys():
            if key.lower() in prompt_lower:
                target_seed = key
                break

        context.target_seed = target_seed
        context.metadata["camada_1"] = self.DICIONARIO_MILUI.get(target_seed, ["Alef", "Lamed", "Pei"])
        return context
