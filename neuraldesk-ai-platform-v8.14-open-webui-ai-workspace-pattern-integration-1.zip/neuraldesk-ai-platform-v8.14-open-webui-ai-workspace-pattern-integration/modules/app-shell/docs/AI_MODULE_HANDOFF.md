<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/AI_MODULE_HANDOFF.md -->
# AI Module Handoff — App Shell

## Read before modifying

1. `CURRENT_STATE.md`
2. `MECHANICS_AND_FUNCTIONALITY.md`
3. `module.manifest.json`
4. `contracts/`
5. `data/ownership.md`
6. `tests/test.manifest.json`
7. `preview/preview.json`
8. `../../../neural-engine/registry/ui-mechanic-traceability.json`

## Invariants

- Preserve `intelligence-experience-v2`, `workspace-runtime-v2` and `neuraldesk-intelligence-design-v2` unless a versioned migration is explicitly approved.
- JavaScript remains module-owned; no global monolithic runtime dependency.
- UI never talks directly to private tables or provider SDKs.
- Keep template-only mechanics truthful; future Neural Engine behavior is `NOT-IMPLEMENTED` until real code exists.
- Any new UI mechanic must receive future engine ownership and traceability before release.
- Meaningful visual changes require preview regeneration.
- Documentation, memory and skills must be synchronized in the same version package.

## Future engine owners for this module

- `neural-engine.project-runtime`
- `neural-engine.task-runtime`
- `neural-engine.checkpoint-resume-runtime`
- `neural-engine.notification-runtime`
- `neural-engine.capability-resolution`
- `neural-engine.approval-policy-guardrails`


## Release expectation

Run the full release gate suite and the Neural Engine documentation validator before packaging.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.

## V8.14 handoff
Preserve the `open-webui-ai-workspace-patterns-v1` surface and truth boundary. Re-verify Open WebUI research/license before implementation; never copy upstream code blindly.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
