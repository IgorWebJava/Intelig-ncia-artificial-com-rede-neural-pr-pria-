import os
import json
import time
import re
from typing import Dict, List, Any
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class ContextCrystallizerPlugin(BaseQcnnPlugin):
    """
    Módulo 12 & 9: Gerenciador de Contexto, Cristalização de Memória e Eco Harmônico (KODEX ALEPH v12.5).
    - Retém o Eco de Frequência Residual das últimas 3 interações.
    - Cristaliza fatos do usuário e entidades chave no arquivo inconsciente.dat.
    """
    def __init__(self, storage_dir: str = "./storage_android"):
        self._enabled = True
        self.storage_dir = storage_dir
        self.caminho_arquivo = os.path.join(storage_dir, "inconsciente.dat")
        self.eco_frequencias: List[float] = []
        if not os.path.exists(storage_dir):
            try:
                os.makedirs(storage_dir, exist_ok=True)
            except Exception:
                pass
        self.memoria_cristalizada: Dict[str, Any] = self._carregar_memoria()

    @property
    def plugin_id(self) -> str:
        return "context_crystallizer"

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @is_enabled.setter
    def is_enabled(self, value: bool):
        self._enabled = value

    def _carregar_memoria(self) -> Dict[str, Any]:
        if os.path.exists(self.caminho_arquivo):
            try:
                with open(self.caminho_arquivo, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def cristalizar(self, chave: str, valor: Any):
        self.memoria_cristalizada[chave.lower()] = {
            "valor": valor,
            "timestamp": time.time()
        }
        try:
            with open(self.caminho_arquivo, "w", encoding="utf-8") as f:
                json.dump(self.memoria_cristalizada, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def atualizar_eco(self, hz: float):
        if hz > 0:
            self.eco_frequencias.append(hz)
            if len(self.eco_frequencias) > 3:
                self.eco_frequencias.pop(0)

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt_lower = context.prompt.lower()

        # 1. Detecção e Cristalização automática de dados pessoais
        match_nome = re.search(r"meu nome é\s+([a-zA-ZÀ-ÿ]+)", prompt_lower)
        if match_nome:
            nome_extraido = match_nome.group(1).capitalize()
            self.cristalizar("nome_usuario", nome_extraido)
            context.metadata["cristalizacao"] = f"Identidade registrada: {nome_extraido}"

        # 2. Injeção de Memória de Longo Prazo
        memoria_injetada = []
        for chave, dados in self.memoria_cristalizada.items():
            if ("lembra" in prompt_lower or "quem sou" in prompt_lower or "meu nome" in prompt_lower or chave in prompt_lower):
                memoria_injetada.append(f"[MEMÓRIA CRISTALIZADA: {chave.upper()}] = {dados.get('valor')}")

        # 3. Cálculo do Eco Residual Harmônico
        eco_medio = 0.0
        if self.eco_frequencias:
            eco_medio = sum(self.eco_frequencias) / len(self.eco_frequencias)
            context.metadata["eco_frequencia_residual"] = round(eco_medio, 2)

        if memoria_injetada:
            prefixo_memoria = "<br>".join(memoria_injetada)
            if context.custom_response:
                context.custom_response = f"{prefixo_memoria}<br><br>{context.custom_response}"
            else:
                context.custom_response = prefixo_memoria

        # Atualiza o eco com a frequência desta rodada
        if context.total_frequency_hz > 0:
            self.atualizar_eco(context.total_frequency_hz)

        return context
