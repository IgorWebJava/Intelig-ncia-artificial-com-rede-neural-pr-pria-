# v0.7.5 evaluation addendum

Novos gates de mecânica não são benchmarks de inteligência: streaming verifica canonical parity/backpressure/cancel/deadline/UTF-8; hardware routing verifica provider fail-closed; governance verifica direitos/splits/leakage; accumulation verifica determinismo. Os modelos Micro v3 anteriormente rejeitados continuam rejeitados. O Golden 250 histórico v0.63 não é recriado: seus hashes são lineage evidence only.

# Evaluation Contract — v0.7.4-alpha.2

## Novos gates v0.7.3

- `nd_execution_control_test`: cancelamento por checkpoint, execução normal controlada e callback wrapper;
- `nd_resource_test`: três perfis, fail-closed e redução thermal/output/threads/deadline;
- `nd_rag_test`: dedup/replace, LRU bounded, persistência/reload e corruption rejection;
- `verify_android_wiring.py`: single-thread executor, lifecycle JNI, thermal bridge, asset streaming e memória opt-in criptografada;
- `verify_kotlin_host.sh`: missing/same/stale preservado com `InputStream`.

Todos os gates herdados de inteligência/grounding permanecem obrigatórios; os novos gates não substituem Live QA/Golden/sanitizer.


Gates herdados permanecem autoridades de não-regressão. Gates novos: Semantic Core **11/11**; Semantic Ranker **746/749**; Robust Intent recovery **11/11**; Historical Convergence **9/9**; Safety **7 adversarial/3 benign/2 output**; checkpoint/resume PASS; Device Lab software PASS; Local RAG semantic rerank PASS. O Pirá full candidate não é promovido por existir; precisão/answerability ainda bloqueiam activation.

## Regra de promoção

A v0.6.1 precisa preservar todos os gates v0.5/v0.6 e demonstrar que as correções conversacionais aumentam cobertura sem reduzir o fail-closed. Loss não é usada como prova porque o NDOS não é uma rede neural.

## Gates herdados

Os verificadores de retriever, relation classifier, pointer, candidate acceptance, contexto, multiobjetivo, Live QA, calculadora, memória e fail-closed continuam intactos em `scripts/verify.sh`.

## Gates NDOS

### Paridade
`tests/verify_open_knowledge.py` compara ranking/score/margin/decision Python↔C em 53 consultas: **53/53**.

### Positivos humanos
28 paráfrases humanas não armazenadas no shard: **28/28 raw top-1**; gate de aceitação mantém **25/25 corretas e 0 erradas**.

### Negativos
25 perguntas fora do conhecimento do shard: **0/25 aceitas**.

### Holdout pós-implementação
3 paráfrases humanas reservadas: **3/3 raw top-1**, **2/2 aceitas corretas**, 1 recusada conservadoramente.

### Corrupção
Quatro classes independentes — magic, truncamento, bytes extras e bucket count inválido — são **4/4 rejeitadas**.

### Reprodutibilidade
`tests/verify_open_knowledge_reproducibility.py` reconstrói o `.ndos` duas vezes e exige igualdade byte a byte com o asset distribuído.

## Planner e calculadora

`tests/nd_planner_test.c` cobre a regressão científica original e também preâmbulo `fases 1 e 2`, distribuição `quantização + KV cache` e herança tardia `Atlas-77`.

`tests/nd_calculator_test.c` possui **16/16** casos, incluindo precedência, parênteses, operadores UTF-8, potência e divisão por zero fail-closed.

## Conversational Correctness pós-implementação

`tests/nd_conversational_correctness_test.c` executa 12 cenários na mesma instância do `NDAssistant`: expressão composta, memória com atributos concorrentes, preâmbulo científico, planejamento distributivo, entidade fictícia `Noveria-999`, RAG em paráfrase, loss/generalização, contexto Atlas parcial, comparação absoluta, saudação transparente e follow-up de um turno. Resultado targeted atual: **12/12**.

Esse conjunto foi criado depois das falhas observadas e não substitui Live QA. O gate Live QA continua **35/35** após o hardening sparse.

## Interpretação

Os números medem um shard finito e conjuntos finitos. A recusa de uma paráfrase no holdout é considerada preferível a reduzir thresholds e aceitar negativos.

## Camadas de prova

- **unitário/especialista:** formatos, Retriever 856, Relation 4.008, Pointer 2.000;
- **integração:** candidate acceptance, 1.006 contexto, 320 multiobjetivo, assistant, NDOS assistant e Live QA 35;
- **negativo/fail-closed:** 12 corrupções dos quatro assets herdados + 4 corrupções NDOS, além de 25 negativos NDOS;
- **sanitizer host:** subset C executável sob ASan/UBSan; não equivale a fuzzing nem Android device;
- **release evidence:** logs finais versionados, metadata regenerada e ZIP reextraído/reverificado.

Os marcadores finais são `VERIFY PASS version=0.6.1-alpha.1` e `SANITIZER PASS version=0.6.1-alpha.1`. Um log com PASS de outra versão é rejeitado pelo gerador de metadata.

## Gate retomável vinculado aos inputs

A v0.6.1 mantém os mesmos testes, mas permite executar o fechamento em fases determinísticas quando a janela externa não comporta o agregador monolítico. Cada fase concluída gera um receipt externo à release por `scripts/verification_checkpoint.py`, contendo versão, fase e SHA-256 canônico dos inputs. A fase final exige todos os receipts da mesma versão/digest. Mudança em código, documentação, manifest, modelos ou datasets invalida automaticamente a retomada. Esse mecanismo não transforma timeout em PASS e não autoriza pular cobertura.

## Evidence de fechamento da v0.6.1
`generate_release_metadata.py` não usa mais números herdados de release anterior para calculadora/conversação. Ele exige receipts externos atuais, marcador versionado e o mesmo SHA-256 dos inputs em `FINAL_VERIFY.log`/`FINAL_SANITIZER.log`. O contrato atual é calculadora **16/16** e conversational correctness **12/12**.


## Gate v0.6.2 — Dialogue Grounding

`nd_dialogue_grounding_v062_test` contém 7 cenários novos, criados a partir de falhas observadas no diálogo final v0.6.1: `Aurora-3 -> LiDAR`, `Aurora-3 -> Renata`, RAG sem internet, mudança RAG -> Transformer/RNN, não-entailment, conhecimento aberto seguido de implicação e resumo bounded. Promoção exige **7/7**, mais os **12/12** herdados, Live QA **35/35** e todos os demais gates.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

