<!-- neuraldesk-documentation-sync: V8.8 -->

# Module Preview — Agent Projects & Multi-Agent Studio

Canonical preview:

```text
modules/agents/preview/page-preview.png
```

Source UI:

```text
modules/agents/ui/agents.html
```

Standard capture profile:

```text
module-preview-v1
1600x1000
viewport capture
```

Regenerate after any meaningful visual UI change.

Command:

```text
python tools/generate_module_previews.py --module agents
```
