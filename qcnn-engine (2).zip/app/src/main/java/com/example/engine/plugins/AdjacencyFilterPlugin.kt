package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.QcnnExecutionContext

/**
 * Plugin Filtro de Adjacência Semântica e Anti-Dissonância.
 * Previne loops e anagramas dissonantes estabilizando a árvore de manifestação.
 */
class AdjacencyFilterPlugin : IQcnnPlugin {
    override val pluginId: String = "adjacency_filter"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        val semente = context.targetSeed
        val dadosSemente = MatrizLetras.MATRIZ_22[semente] ?: MatrizLetras.MATRIZ_22["Alef"]!!
        val camada1 = dadosSemente.milui

        val cadeia = mutableListOf(semente)

        for (letra in camada1) {
            val filhos = MatrizLetras.MATRIZ_22[letra]?.milui ?: emptyList()
            for (sub in filhos) {
                val ult = cadeia.last()
                val permitidas = MatrizLetras.TRANSICOES_PERMITIDAS[ult] ?: emptyList()
                if (sub in permitidas && sub !in cadeia) {
                    cadeia.add(sub)
                }
            }
        }

        context.chain.clear()
        context.chain.addAll(cadeia)
        context.finalState = "10 (Ativação Construtiva)"

        return context
    }
}
