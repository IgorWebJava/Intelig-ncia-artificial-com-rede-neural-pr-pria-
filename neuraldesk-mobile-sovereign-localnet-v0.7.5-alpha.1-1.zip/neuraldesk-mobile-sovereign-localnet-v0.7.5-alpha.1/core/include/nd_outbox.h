#ifndef ND_OUTBOX_H
#define ND_OUTBOX_H

#include <stddef.h>
#include <stdint.h>
#include "nd_network_policy.h"
#include "nd_resource.h"

#define ND_OUTBOX_MAX_DEPENDENCIES 8u
#define ND_OUTBOX_PROJECT_ID_BYTES 64u
#define ND_OUTBOX_IDEMPOTENCY_BYTES 40u

typedef enum {
    ND_OUTBOX_QUEUED = 0,
    ND_OUTBOX_RETRY_WAIT = 1,
    ND_OUTBOX_SENDING = 2,
    ND_OUTBOX_PAUSED = 3,
    ND_OUTBOX_BLOCKED_DEPENDENCY = 4,
    ND_OUTBOX_EXPIRED = 5
} NDOutboxState;

typedef enum {
    ND_OUTBOX_ERR_NONE = 0,
    ND_OUTBOX_ERR_NETWORK = 1,
    ND_OUTBOX_ERR_PROVIDER_HTTP = 2,
    ND_OUTBOX_ERR_RESOURCE = 3,
    ND_OUTBOX_ERR_ABORTED = 4,
    ND_OUTBOX_ERR_UNKNOWN = 5
} NDOutboxErrorCategory;

typedef struct {
    uint64_t id;
    uint64_t created_at_ms;
    uint64_t expires_at_ms;
    uint64_t next_attempt_at_ms;
    uint32_t attempts;
    NDOutboxState state;
    NDOutboxErrorCategory last_error;
    int requires_network;
    char project_id[ND_OUTBOX_PROJECT_ID_BYTES];
    char idempotency_key[ND_OUTBOX_IDEMPOTENCY_BYTES];
    uint64_t dependencies[ND_OUTBOX_MAX_DEPENDENCIES];
    size_t dependency_count;
    uint64_t missing_dependencies[ND_OUTBOX_MAX_DEPENDENCIES];
    size_t missing_dependency_count;
    char *content;
    size_t content_bytes;
} NDOutboxItem;

typedef struct {
    char path[1024];
    NDMobileProfile profile;
    NDOutboxItem *items;
    size_t count;
    size_t capacity;
    uint64_t next_id;
    size_t max_items;
    size_t max_bytes;
    size_t max_item_bytes;
    uint64_t ttl_ms;
} NDOutbox;

typedef struct {
    size_t items;
    size_t bytes;
    size_t queued;
    size_t paused;
    size_t blocked;
    size_t expired;
} NDOutboxSummary;

void nd_outbox_init(NDOutbox *outbox);
void nd_outbox_free(NDOutbox *outbox);
int nd_outbox_configure(NDOutbox *outbox, NDMobileProfile profile, const char *path, char *err, size_t errcap);
int nd_outbox_restore(NDOutbox *outbox, uint64_t now_ms, char *err, size_t errcap);
int nd_outbox_enqueue(NDOutbox *outbox, const char *project_id, const char *content,
                      const uint64_t *dependencies, size_t dependency_count, int requires_network,
                      uint64_t now_ms, uint64_t *out_id, char *err, size_t errcap);
int nd_outbox_remove(NDOutbox *outbox, uint64_t id, char *err, size_t errcap);
int nd_outbox_relink(NDOutbox *outbox, uint64_t id, const uint64_t *dependencies, size_t dependency_count,
                     uint64_t now_ms, char *err, size_t errcap);
int nd_outbox_mark_sending(NDOutbox *outbox, uint64_t id, char *err, size_t errcap);
int nd_outbox_mark_success(NDOutbox *outbox, uint64_t id, char *err, size_t errcap);
int nd_outbox_mark_failure(NDOutbox *outbox, uint64_t id, NDOutboxErrorCategory category,
                           uint64_t now_ms, char *err, size_t errcap);
const NDOutboxItem *nd_outbox_next_eligible(NDOutbox *outbox, const NDNetworkSnapshot *network,
                                            int manual, uint64_t now_ms);
NDOutboxSummary nd_outbox_summary(const NDOutbox *outbox);
const char *nd_outbox_state_name(NDOutboxState state);

#endif
