# Internet Access — v0.7.2-alpha.1

A internet é uma **fonte opcional de evidência textual**. Nenhuma API de IA externa é chamada para produzir a resposta.

## Fluxo Android

1. usuário fornece URL/pesquisa;
2. `WebContextClient` aplica política HTTPS e valida destino;
3. texto remoto é bounded;
4. `ContextSelector` seleciona candidatos sem responder;
5. o C planner divide subobjetivos;
6. relation classifier identifica o atributo pedido e atributos das sentenças;
7. grounding exige entidade/relação/temporalidade coerentes;
8. pointer condicionado propõe valor;
9. candidate acceptance valida o span ou faz fallback para a evidência;
10. resposta é composta localmente;
11. `ResearchMemoryStore` pode manter evidência para reutilização offline.

## Política de incerteza

Se o contexto menciona a entidade mas não contém a relação solicitada, o sistema não completa com conhecimento genérico e não inventa. O objetivo permanece explicitamente não coberto.

## Controles executados pelo cliente genérico

`WebContextClient` exige HTTPS, proíbe userinfo e portas diferentes de 443, resolve o host e rejeita endereços any/loopback/link-local/site-local/multicast e IPv6 ULA, revalida cada redirect, limita o corpo a 384 KiB por padrão e aceita somente texto/JSON. HTML é reduzido a texto; JavaScript não é executado pelo runtime.

A pesquisa automática usa endpoint fixo `pt.wikipedia.org`, limita resposta e extrai texto público. Isso é aquisição de evidência, não provider de IA.

## Limite de rede honesto

A validação de endereço é feita antes de `HttpURLConnection` abrir a conexão; o código não fixa o socket ao IP previamente validado. Portanto a árvore **não afirma proteção completa contra DNS rebinding/TOCTOU**, proxy hostil, comprometimento de CA, conteúdo malicioso semanticamente convincente ou segurança de navegador. Esses riscos exigem hardening adicional e testes de rede fora desta evidência host.

## v0.6.1

Planner, sparse fallback e contexto de follow-up são totalmente locais. Nenhuma das correções conversacionais adiciona fetch, provider, API de modelo ou execução remota. A fronteira de rede permanece inalterada.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
