<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Target Capability Model

The future system is organized into seven capability planes.

## 1. Experience plane
Home, Projects, Chat, Agents, Knowledge, Tools, Training, Operations, Audit, Settings and System Config.

## 2. Work plane
Projects, tasks, checkpoints, artifacts, notifications, approvals, background work and collaboration.

## 3. Intelligence plane
Goal interpretation, planning, context compilation, memory, model routing, tool use, agent orchestration and verification.

## 4. Knowledge plane
Ingestion, parsing, chunking, embeddings, metadata, retrieval, reranking, graph relationships, citations and source provenance.

## 5. Multimodal plane
Text, images, audio, speech, video, documents, screen/camera streams and media asset lifecycle.

## 6. Model plane
External APIs, self-hosted models, local portable models, adapters, fine-tunes and NeuralDesk-owned models.

## 7. Control plane
Identity, authorization, configuration, policies, deployment, observability, cost, evaluation, audit, safety and rollback.

A capability is considered implementation-ready only after owner, contract, state, security, observability, tests, benchmark and rollback have been documented.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
