# LIÇÕES APRENDIDAS E ANTI-REGRESSÃO — NeuralDesk Mobile Sovereign LocalNet

**Status:** CANÔNICO / LEITURA OBRIGATÓRIA ANTES DE QUALQUER GERAÇÃO OU MODIFICAÇÃO  
**Aplica-se a:** código, modelos, datasets, treinamento, documentação, Android/JNI, manifests, verificadores, relatórios e releases.  
**Regra zero:** este arquivo deve ser lido e analisado integralmente antes de criar, alterar, treinar, regenerar, migrar ou empacotar qualquer artefato do projeto.

## 1. Protocolo obrigatório antes de gerar qualquer coisa

1. Ler este arquivo do início ao fim.
2. Identificar quais lições se aplicam à mudança pretendida.
3. Verificar se a funcionalidade/arquivo/modelo já existe antes de criar outro.
4. Definir o baseline que não pode regredir e os gates que provarão superioridade.
5. Não promover nenhuma implementação com resultado parcial, execução interrompida, hash não reproduzido ou teste adaptado apenas para fazê-la passar.
6. Implementar na menor superfície canônica possível, evitando caminhos paralelos.
7. Executar testes negativos além dos Golden conhecidos.
8. Remover fisicamente código, modelos, dados, caches e documentos superseded antes da release.
9. Atualizar documentação e manifests para descrever o que realmente existe, não o que se pretendia construir.
10. Gerar o ZIP somente depois de verificar a árvore limpa e repetir os gates a partir do ZIP reextraído.

Nenhuma exceção silenciosa é permitida. Se um gate não puder ser executado, a release deve declarar explicitamente esse limite e permanecer não promovida.

---

## 2. O que fizemos certo — preservar

### 2.1 Separar prova de runtime de prova de inteligência
**Acerto:** o primeiro modelo minúsculo foi tratado como prova de engenharia, não como “IA pronta”.  
**Por que funcionou:** compilação, formato de pesos, inferência C e paridade puderam ser validados sem confundir isso com qualidade de respostas.  
**Regra:** sempre manter gates de infraestrutura separados de gates de capacidade/qualidade.

### 2.2 Mostrar respostas brutas e rejeitar métricas enganosas
**Acerto:** perguntas reais foram feitas ao runtime e respostas ruins foram mostradas sem correção manual.  
**Regra:** uma queda de loss nunca substitui avaliação de comportamento. Toda promoção de inteligência precisa incluir respostas brutas, Golden independente e holdout criado depois da implementação.

### 2.3 Rejeitar modelos que “aprendem o formato” mas erram o fato
**Acerto:** modelos generativos com loss baixa foram rejeitados quando confundiram Brasil/Austrália, repetiram texto ou memorizaram templates.  
**Regra:** factualidade e generalização têm prioridade sobre loss e fluência.

### 2.4 Separar responsabilidades em arquitetura móvel
**Acerto:** cálculo virou ferramenta exata; fatos auditáveis foram para memória factual; recuperação e pointer neural ficaram especializados; contexto passou a usar cobertura de evidências.  
**Por que funcionou:** reduziu parâmetros ociosos, alucinação e interferência entre tarefas.  
**Regra:** não obrigar uma rede pequena a memorizar o que pode ser resolvido com ferramenta determinística ou memória versionada.

### 2.5 Fail-closed e incerteza explícita
**Acerto:** quando contexto não sustenta um subobjetivo, o sistema recusa em vez de completar com conhecimento genérico não relacionado.  
**Regra:** entidade correta sozinha não é evidência suficiente. Cada subobjetivo precisa de suporte semântico para a relação pedida.

### 2.6 Decomposição de perguntas multipartes
**Acerto:** substituir ranking global por cobertura por subobjetivo corrigiu perguntas de dois e três objetivos.  
**Regra:** perguntas multipartes exigem decomposição, evidência por objetivo e cobertura completa antes da síntese.

### 2.7 Reprodutibilidade estrita
**Acerto:** foi identificado não determinismo CPU e os treinadores foram alterados para uma thread, algoritmos determinísticos e MKLDNN desativado quando necessário.  
**Regra:** modelo canônico só pode ser promovido depois de duas reproduções independentes byte-idênticas usando o código presente na própria release.

### 2.8 Testar o ZIP que será entregue
**Acerto:** releases anteriores foram reextraídas em diretório vazio, recompiladas e reverificadas.  
**Regra:** testar a pasta de trabalho não é suficiente. O artefato final precisa passar os gates após extração limpa.

### 2.9 Uma única fonte de verdade para assets Android
**Acerto:** assets duplicados foram removidos e Android passou a apontar para `models/`.  
**Regra:** nunca manter segunda cópia manual de modelos no app; build deve consumir os assets canônicos.

### 2.10 Warnings e sanitizers como gates
**Acerto:** erros `-Werror` foram corrigidos no código, não mascarados; ASan/UBSan foram usados antes de release.  
**Regra:** não reduzir rigor do compilador para fazer uma implementação passar.

---

## 3. O que fizemos errado — não repetir

### 3.1 Erro: usar loss baixa como sinal de inteligência
**Sintoma:** loss chegou a valores baixos enquanto respostas continuavam incorretas, repetitivas ou trocavam entidades.  
**Causa:** objetivo de treinamento mede previsão no conjunto visto, não compreensão/generalização.  
**Correção:** Live QA, Golden independente, holdout pós-implementação e testes adversariais.  
**Prevenção:** nenhuma release pode alegar ganho de inteligência com base apenas em loss/perplexidade.

### 3.2 Erro: Golden inflado por normalização/template
**Sintoma:** 290/290 incluía normalização determinística de frases de introdução; o número parecia mais forte do que a generalização real.  
**Causa:** avaliação media pipeline completo com atalhos estruturais, não apenas compreensão semântica.  
**Correção:** documentar exatamente o que cada gate mede e criar paráfrases/holdouts independentes.  
**Prevenção:** relatórios devem declarar preprocessamento, normalizações e regras determinísticas que participam da métrica.

### 3.3 Erro: respostas completas escondidas como tokens especiais
**Sintoma:** tokenizer anterior transformava respostas completas conhecidas em tokens únicos.  
**Causa:** otimização de memorização prejudicava composição de respostas novas.  
**Correção:** remover a mecânica da linha canônica.  
**Prevenção:** nenhum tokenizer pode codificar respostas Golden inteiras como atalhos sem justificativa explícita e teste de generalização.

### 3.4 Erro: coexistência de modelos antigos e novos
**Sintoma:** v0.3 e v0.4 permaneceram simultaneamente em `models/`; builds e docs ainda apontavam para versões antigas.  
**Causa:** evolução incremental sem limpeza final obrigatória.  
**Correção:** auditoria de referências + remoção física dos superseded.  
**Prevenção:** verificador de higiene deve falhar se assets de baseline anterior sobreviverem sem função de rollback explicitamente declarada.

### 3.5 Erro: Android/JNI conectado à arquitetura antiga
**Sintoma:** CLI/orquestrador novo existia, mas JNI ainda carregava componentes da v0.2/v0.3.  
**Causa:** integração não foi tratada como parte do mesmo gate de arquitetura.  
**Correção:** host e Android devem chamar a mesma política C canônica.  
**Prevenção:** toda alteração de orquestração deve incluir teste de correspondência host↔JNI e inspeção dos paths de assets.

### 3.6 Erro: dependência de trainers/scripts superseded
**Sintoma:** trainer novo importava funções de scripts experimentais antigos.  
**Causa:** reutilização rápida criou dependência oculta.  
**Correção:** extrair utilidades canônicas e eliminar scripts superseded.  
**Prevenção:** nenhum arquivo canônico pode importar módulo marcado como legacy, rejected, experiment ou versão anterior.

### 3.7 Erro: checkpoint aprovado sem reprodução byte-idêntica
**Sintoma:** um `.ndqa` passava testes, mas o script atual produzia hash diferente.  
**Causa:** artefato havia sido gerado sob estado de código/numérico diferente.  
**Correção:** reproduzir com código final, duas vezes, e promover apenas o novo hash determinístico.  
**Prevenção:** hash canônico deve ser derivado somente após a dupla reprodução final.

### 3.8 Erro: não determinismo numérico no treinamento CPU
**Sintoma:** mesma seed e script geravam hashes diferentes com múltiplas threads.  
**Causa:** ordem de reduções/rotinas CPU não determinísticas.  
**Correção:** `torch.set_num_threads(1)`, algoritmos determinísticos e backend controlado.  
**Prevenção:** o teste de reprodução deve comparar bytes, não apenas métricas.

### 3.9 Erro: pointer treinado em poucas relações
**Sintoma:** bom desempenho em código/cor/temperatura/responsável, mas baixa generalização para capital/material/idioma/etc.  
**Causa:** currículo estreito demais.  
**Correção:** ampliar famílias de relações e criar holdouts estruturais.  
**Prevenção:** declarar cobertura de relações do dataset e testar famílias não vistas/variações de posição.

### 3.10 Erro: média de bytes destruindo semântica da pergunta
**Sintoma:** arquiteturas byte-level acertavam sentença mas falhavam relação/valor em formulações novas.  
**Causa:** representação pequena demais para preservar palavras/relacionamentos.  
**Correção:** separar retrieval e extração; usar features lexicais/hashing quando mais adequadas.  
**Prevenção:** não aumentar passos cegamente quando a limitação é representacional.

### 3.11 Erro: ranking global sem cobertura por objetivo
**Sintoma:** duas evidências parecidas com “atual” eram escolhidas para pergunta `código + responsável`.  
**Causa:** top-k global não garante diversidade de objetivos.  
**Correção:** decomposição e seleção por subobjetivo.  
**Prevenção:** benchmark obrigatório com 2 e 3 objetivos em ordens variadas.

### 3.12 Erro: entity-match usado como evidência suficiente
**Sintoma:** frase com `Atlas-900` cobria indevidamente “quando será lançado” mesmo sem data.  
**Causa:** peso excessivo para entidade compartilhada.  
**Correção:** exigir correspondência da relação pedida e bloquear fallback genérico quando contexto específico é insuficiente.  
**Prevenção:** testes negativos onde entidade existe mas atributo solicitado está ausente.

### 3.13 Erro: separador textual quebrava valores estruturados
**Sintoma:** `v4.0.0`, IPs e decimais eram truncados em pontos internos.  
**Causa:** qualquer `.` era interpretado como fim de sentença.  
**Correção:** distinguir pontuação terminal de ponto interno em token estruturado e completar span apenas dentro do token presente na evidência.  
**Prevenção:** regressão fixa com versões, IPs, números decimais, datas e códigos.

### 3.14 Erro: pointer só aprendia valor após a relação
**Sintoma:** `Marina é responsável...` falhava quando o treino privilegiava `responsável ... Marina`.  
**Causa:** viés posicional do currículo.  
**Correção:** gerar variações com valor antes/depois da relação.  
**Prevenção:** datasets devem balancear posição do valor e ordem sintática.

### 3.15 Erro: síntese explicativa selecionava efeito sem causa
**Sintoma:** respondia “reduz trabalho repetido” mas omitía “evita recomputação”.  
**Causa:** relevância local não garantia cobertura causal.  
**Correção:** combinar mecanismo + consequência em perguntas explicativas.  
**Prevenção:** Golden explicativo deve avaliar cobertura de conceitos, não só presença de uma frase relevante.

### 3.16 Erro: builds, caches e relatórios experimentais dentro da árvore de release
**Sintoma:** `build/`, `__pycache__`, experimentos e relatórios antigos reapareceram durante desenvolvimento.  
**Causa:** validar antes da limpeza e não repetir limpeza após os próprios gates.  
**Correção:** `clean -> verify -> build/test -> clean final -> inventory/checksums -> zip -> reextract -> verify`.  
**Prevenção:** limpeza final é obrigatória depois de qualquer gate que gere artefatos temporários.

### 3.17 Erro: verificador estrutural com falso positivo
**Sintoma:** auditor encontrou texto `neuraldesk-demo.ndm` dentro do próprio teste e tratou como arquivo existente.  
**Causa:** busca textual usada para verificar existência física.  
**Correção:** verificar filesystem/paths, não ocorrência de strings.  
**Prevenção:** cada verificador deve testar o fenômeno real que pretende bloquear.

### 3.18 Erro: condição de corrida no wrapper Android
**Sintoma:** inferências simultâneas podiam compartilhar KV/cache e `onDestroy()` podia liberar handle em uso.  
**Causa:** lifecycle e concorrência não estavam serializados.  
**Correção:** sincronizar load/generate/free.  
**Prevenção:** toda API nativa stateful precisa de política explícita de ownership/thread-safety.

### 3.19 Erro: treinamento longo sem checkpoint/resume adequado
**Sintoma:** execuções interrompidas antes da exportação não produziam artefato verificável.  
**Causa:** treinamento monolítico e limite operacional do host.  
**Correção:** quando aplicável, checkpoint resumível com estado do otimizador e RNG; nunca contar passos interrompidos como concluídos.  
**Prevenção:** processos longos devem ser retomáveis ou divididos em gates determinísticos.

### 3.20 Erro: dados mortos consumindo capacidade
**Sintoma:** centenas de fatos aritméticos estavam na base neural mesmo após cálculo virar ferramenta.  
**Causa:** dataset não foi podado junto com a mudança de arquitetura.  
**Correção:** remover dados não consumidos pelo runtime canônico.  
**Prevenção:** toda mudança de responsabilidade deve incluir auditoria de dados órfãos.

---

## 4. Regras de decisão arquitetural

- **Preservar antes de estender.** Nunca substituir algo que passa gates por algo apenas “mais novo”.
- **Superioridade precisa ser medida.** Mudança só é promovida se melhora capacidade, robustez, custo ou clareza sem regredir gates existentes.
- **Uma única rota canônica.** Evitar implementações paralelas ativas para a mesma função.
- **Sem código morto em release.** Experimentos rejeitados ficam fora do pacote distribuído.
- **Sem dependência de IA externa para inferência.** Internet pode fornecer contexto; a decisão/resposta é processada localmente.
- **Sem defaults silenciosos críticos.** Formato, dimensão, versão, paths de modelo e limites devem ser explícitos e validados.
- **Sem afirmações acima da evidência.** Não chamar de AGI, consciência, produção física ou certificação o que os testes não provaram.
- **Fail-closed > resposta inventada.** Incerteza correta é melhor que cobertura falsa.
- **Ferramentas para operações exatas.** Matemática, parsing e transformações determinísticas não devem ser memorizadas pela rede sem necessidade.
- **Modelos para decisões que exigem aprendizado.** Recuperação, ranking, extração e linguagem podem ser neurais quando superam alternativas simples nos gates.

---

## 5. Gates mínimos antes de qualquer promoção

### Código/runtime
- compilação C/C++ com warnings como erro;
- testes unitários e de integração;
- ASan/UBSan no host quando compatível;
- fail-closed de formatos e corrupção;
- correspondência host/JNI para a política canônica.

### Modelos
- dataset materializado e hashado;
- treino determinístico;
- duas reproduções byte-idênticas do checkpoint final;
- Golden independente;
- holdout criado após a implementação;
- testes negativos e perguntas livres;
- relatório contendo também falhas, não apenas média agregada.

### Contexto/internet
- múltiplas evidências;
- múltiplas entidades concorrentes;
- informação antiga vs. atual;
- 2 e 3 subobjetivos;
- atributo ausente com entidade presente;
- valores estruturados (versão, IP, decimal, data, código);
- recusa quando cobertura é insuficiente.

### Release
- nenhuma referência a asset superseded;
- nenhum build/cache/checkpoint parcial;
- documentação sincronizada com código real;
- inventário e SHA-256 finais;
- ZIP reextraído em diretório vazio e verificado novamente.

---

## 6. Checklist mental obrigatório para a próxima IA/execução

Antes de escrever uma linha de código, responder internamente:

- O que já existe que resolve isto?
- Qual erro desta lista pode reaparecer nesta mudança?
- Qual baseline não pode regredir?
- Como a nova capacidade será medida fora do treino?
- Existe um caminho determinístico/exato melhor que usar uma rede neural?
- O runtime Android e o host continuarão usando a mesma política?
- Estou criando uma segunda fonte de verdade?
- O artefato final poderá ser reproduzido apenas com os arquivos que serão entregues?
- Se a implementação falhar, ela será removida fisicamente da release?
- O relatório final distinguirá fato comprovado de objetivo futuro?

Se qualquer resposta estiver indefinida, a implementação ainda não está pronta para promoção.

---

## 7. Histórico de promoção/rejeição resumido

- **v0.1:** prova real de runtime/treinamento; inteligência insuficiente. Preservar a lição, não o modelo.
- **v0.2:** especialistas separados; ganhos reais, mas avaliações iniciais superestimavam generalização de contexto.
- **v0.2.1:** limpeza estrutural, assets únicos, concorrência Android corrigida.
- **v0.3:** arquitetura híbrida promovida após rejeição do gerador factual; retrieval + memória factual + pointer + ferramentas + incerteza.
- **v0.4:** expansão de conhecimento/relações, planner multi-fonte, memória reutilizável, parsing estruturado e grounding mais rigoroso. Sua promoção é válida somente quando reproduções, gates finais e revalidação do ZIP estiverem documentados em `verification/REPORT.json` e nos logs finais.

---

## 8. Regra de manutenção deste próprio arquivo

Este documento é vivo e append-only em conteúdo histórico: uma lição antiga pode ser refinada, mas não apagada apenas porque a arquitetura mudou. Toda falha nova relevante descoberta durante desenvolvimento deve ser registrada aqui **antes da próxima geração/modificação subsequente**. Toda correção deve indicar qual teste permanente impede a recorrência.

**Este arquivo é a primeira leitura obrigatória do projeto.**

## 9. Lições adicionadas durante o fechamento da v0.4

### 9.1 Acerto: transformar a leitura deste arquivo em gate executável
**Acerto:** materialização, treinamento, build, sanitizers, JNI e verificação passaram a carregar `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md` antes da geração.  
**Limite honesto:** um script prova que o arquivo foi carregado e validado, mas compreensão semântica continua sendo obrigação do operador/IA.  
**Regra:** manter o precheck como primeiro gate e nunca descrevê-lo falsamente como prova automática de compreensão humana/IA.

### 9.2 Erro: patch automático assumiu indentação uniforme
**Sintoma:** ao inserir o precheck em `train_context_pointer.py`, o primeiro patch gerou `IndentationError` porque o arquivo legado usava indentação compacta de um espaço.  
**Causa:** transformação textual assumiu estilo de quatro espaços sem analisar a estrutura real do arquivo.  
**Correção:** corrigir a indentação e executar `py_compile` imediatamente.  
**Prevenção:** antes de patches automáticos, inspecionar a estrutura/estilo do arquivo; após qualquer transformação de código, executar gate sintático antes de continuar. Para código canônico, preferir formatação estruturada e legível em vez de estilo excessivamente compacto.

### 9.3 Acerto: reprodução final do pointer v0.4
**Resultado:** duas execuções independentes do trainer final produziram o mesmo SHA-256 `a0e8e47cdf8f296898e84aeefb62734a868d853c376fa806662192c4cd2d2872`, com 100% do Golden e 4/4 casos inéditos do trainer.  
**Regra preservada:** esse hash só pode ser promovido depois de os demais gates da release confirmarem que o artefato reproduzido é exatamente o consumido pelo runtime final.

### 9.4 Erro: adicionar um binário ao gate sem respeitar seu contrato de CLI
**Sintoma:** a primeira execução do `scripts/verify.sh` v0.4 chamou `nd_context_synth_test` sem os argumentos obrigatórios e a cadeia parou com `usage: ... QA QUESTION CONTEXT`.  
**Causa:** o verificador foi ampliado assumindo que todos os testes C eram executáveis sem argumentos.  
**Correção:** inspecionar a assinatura real do teste e fornecer modelo, pergunta e contexto canônicos, ou deixar a cobertura equivalente no gate que já executa o binário corretamente.  
**Prevenção:** antes de adicionar qualquer ferramenta/teste ao gate agregado, executar individualmente com sua interface documentada e verificar exit code/saída. Nunca confundir falha de harness com falha do componente testado.

### 9.5 Erro: agrupar reproduções longas demais em um único comando operacional
**Sintoma:** retriever 2× + pointer 2× foram encadeados numa única execução; o comando atingiu o limite depois de concluir o primeiro pointer e iniciar o segundo.  
**Causa:** o trabalho era determinístico, mas o agrupamento excedeu a janela operacional do executor.  
**Correção:** considerar somente artefatos efetivamente exportados; reexecutar a reprodução faltante isoladamente; comparar bytes/hash depois.  
**Prevenção:** gates longos devem ser divididos por especialista/etapa, com resultados persistentes e verificáveis. Nunca interpretar timeout do harness como treinamento concluído.

### 9.6 Acerto: refatoração de legibilidade sem alterar os artefatos neurais
**Resultado:** após reformatar os dois trainers canônicos, o retriever e a base factual foram reproduzidos duas vezes byte-idênticos e iguais aos assets distribuídos; o pointer também foi reproduzido duas vezes byte-idêntico e igual ao asset distribuído.  
**Regra:** refatorações de código de treinamento são aceitas somente quando datasets, métricas e hashes finais permanecem comprovadamente equivalentes ou quando uma mudança de hash é explicitamente justificada como nova promoção.

### 9.7 Acerto: concluir reproduções longas em execuções isoladas
**Resultado:** após a execução agregada anterior ter sido interrompida, o pointer v0.4 foi treinado em duas execuções isoladas completas. Ambas produziram `a0e8e47cdf8f296898e84aeefb62734a868d853c376fa806662192c4cd2d2872`, foram byte-idênticas entre si e coincidiram com o asset canônico distribuído; ambas mantiveram 100% do Golden e 4/4 probes inéditos.
**Regra:** quando uma reprodução longa for interrompida pelo executor, repetir apenas a unidade incompleta de forma isolada, persistir o resultado e comparar bytes com o asset canônico. Nunca inferir conclusão a partir de progresso parcial.

### 9.8 Erro: assumir que `zipfile.extractall()` restaura permissões Unix
**Sintoma:** o primeiro ZIP determinístico foi criado com CRC válido e armazenava `rwxr-xr-x` nos metadados, mas a reextração feita pela biblioteca padrão `zipfile` não aplicou os bits de execução; a validação falhou com `PermissionError` ao chamar `./scripts/verify.sh`.
**Causa:** metadados Unix presentes no ZIP não garantem que todo extrator os aplique ao filesystem de destino.
**Correção:** a verificação do pacote deve invocar scripts shell explicitamente via `bash`, sem depender do bit executável restaurado pelo extrator; o ZIP continua preservando os modos para extratores que os suportam.
**Prevenção:** testar o pacote com o mesmo mecanismo de extração usado pelo verificador e nunca assumir equivalência entre metadados armazenados e permissões efetivamente materializadas. Uma falha de reextração bloqueia a release mesmo quando CRC e hashes internos estão corretos.

### 9.9 Erro: corrigir apenas o script de entrada e esquecer chamadas shell aninhadas
**Sintoma:** após passar a chamar `verify.sh` via `bash`, a revalidação ainda falhou porque `verify.sh` executa `./scripts/clean.sh` e outros scripts, que continuavam sem bit executável no filesystem extraído por `zipfile`.
**Causa:** a primeira correção tratou o sintoma no processo pai, mas não restaurou a propriedade do artefato que todos os processos filhos dependem.
**Correção:** após `extractall()`, o empacotador restaura explicitamente os modos Unix armazenados em `ZipInfo.external_attr` para cada arquivo e verifica `os.X_OK` nos scripts críticos antes dos gates.
**Prevenção:** ao corrigir problemas de empacotamento, validar a árvore materializada completa e suas invariantes, não apenas o primeiro comando que falhou. Preferir restaurar metadados do artefato a criar exceções em cada chamador.


## 10. Lições adicionadas durante a evolução v0.5

### 10.1 Erro: classificador de estratégia memorizou formulações apesar de loss quase zero
**Sintoma:** o primeiro `response-policy` atingiu 100% no treino e loss ~0,00108, mas somente 40,1% (77/192) no Golden com templates e sujeitos reservados.
**Causa:** features hash de palavras/n-grams + currículo pequeno deixaram o modelo associar padrões superficiais das formulações de treino às classes, sem aprender generalização suficiente para sinônimos/estruturas novas.
**Correção obrigatória:** rejeitar o checkpoint; ampliar diversidade lexical/estrutural e incorporar features de intenção mais invariantes (raízes/prefixos funcionais, interrogativos e construções), mantendo Golden separado. Não aumentar passos cegamente.
**Prevenção permanente:** qualquer novo especialista de linguagem deve ter Golden com formulações não vistas e só pode ser promovido se o ganho vier junto de generalização; loss/treino perfeito não contam como prova de capacidade.

### 10.2 Erro: ampliar templates elevou Golden, mas não eliminou fragilidade lexical
**Sintoma:** após expandir o currículo de 860 para 1.780 exemplos, o `response-policy` subiu de 40,1% para 93,2% no Golden, mantendo 100% no treino, mas ainda confundiu sinônimos/estruturas de explicação, mecanismo, síntese, lista, comparação e procedimento.
**Causa:** hashes de palavras/n-grams capturam forma superficial, mas um classificador minúsculo não induziu de forma confiável equivalências como `contraste/paralelo`, `síntese/resumo`, `mecanismo/como` e `etapas/procedimento` a partir desse volume de dados.
**Correção obrigatória:** adicionar features semânticas de intenção explícitas e auditáveis (famílias lexicais/stems), mantendo as features neurais gerais e o Golden independente. Documentar que o preprocessamento participa da métrica.
**Prevenção permanente:** se uma capacidade linguística pequena puder ser representada por features interpretáveis sem esconder a resposta, preferir esse viés indutivo a aumentar parâmetros/passos cegamente; manter avaliação pós-implementação para detectar atalhos.

### 10.3 Erro: features semânticas + MLP ainda perderam estrutura de intenção
**Sintoma:** o `response-policy` com famílias lexicais auditáveis + hashes atingiu 93,75% no Golden, praticamente sem melhorar sobre a versão anterior.
**Causa:** a representação continua essencialmente bag-of-features; ela não preserva adequadamente ordem/composição de construções como `como funciona` vs. `como executar ... por etapas`, nem relações entre cues distantes.
**Correção obrigatória:** rejeitar o checkpoint e trocar o classificador por uma representação sequencial pequena (token/cue embeddings + convolução ou pooling posicional), mantendo o mesmo Golden independente.
**Prevenção permanente:** quando o erro depender da ordem da linguagem, não tentar resolver apenas com mais exemplos ou mais pesos em uma representação que descarta ordem.

### 10.4 Erro: arquitetura sequencial mais complexa piorou o classificador de estratégia
**Sintoma:** embeddings hash + Conv1D 3/5 + max-pooling + cues atingiram apenas 66,1% no Golden, abaixo do MLP anterior (93,75%), embora a loss de treino também caísse fortemente.
**Causa:** o problema de estratégia de resposta possui poucas classes e cues linguísticos explicitamente auditáveis; a rede sequencial adicionou graus de liberdade e colisões de hashing sem volume/diversidade de dados suficiente para aprender invariâncias melhores.
**Correção:** rejeitar completamente esse especialista da release v0.5. Usar um seletor determinístico e documentado para estilo/formato, e concentrar treinamento neural em tarefas onde ele demonstra ganho mensurável: seleção/reranqueamento de evidências, extração de spans e recuperação de conhecimento.
**Prevenção permanente:** complexidade arquitetural só é promovida se superar uma baseline mais simples no holdout. "Mais neural" não é sinônimo de "mais inteligente".

### 10.5 Erro: reranqueador binário pergunta↔sentença não aprendeu alinhamento relacional
**Sintoma:** MLP binária com 18.000 pares, incluindo negativos de mesma entidade/relação errada e mesma relação/entidade errada, atingiu somente 28,7% top-1 em 2.000 grupos Golden adversariais.
**Causa:** misturar sinais de pergunta e evidência em um único bag hash e pedir uma decisão binária deixou o modelo sem uma representação explícita da variável latente central: a relação semântica (`porta`, `licença`, `status`, etc.).
**Correção:** rejeitar o `.nder` e decompor: treinar um classificador neural de relação comum a perguntas e sentenças; usar concordância de relação como sinal adicional de ranking, enquanto entidade, temporalidade e cobertura continuam verificadas separadamente.
**Prevenção permanente:** quando negativos difíceis diferem por fatores independentes (entidade vs. relação), modelar esses fatores separadamente em vez de esperar que uma pequena rede os desemaranhe implicitamente.

### 10.6 Erro: materialização densa excessiva impediu o treino do classificador de relações
**Sintoma:** o primeiro pipeline tentou pré-calcular ~70.300 vetores de 4.096 floats e atingiu o limite operacional antes do primeiro passo de treinamento.
**Causa:** o dataset mantinha todas as entidades/valores específicos, embora a tarefa fosse classificar apenas a relação semântica; isso multiplicou exemplos redundantes e memória sem adicionar sinal útil.
**Correção:** mascarar/ignorar entidades estruturadas e tokens predominantemente numéricos nas features de relação, reduzir `feature_dim` e usar amostragem estratificada por relação/variante, preservando Golden completo e entidades holdout.
**Prevenção permanente:** antes de escalar exemplos, separar variação relevante de variação nuisance. Pipeline de treino móvel deve medir custo de materialização e não usar matrizes densas gigantes quando o sinal pode ser comprimido sem perder o objetivo.

### 10.7 Erro: normalizador novo referenciou módulo não importado
**Sintoma:** o treino estratificado do classificador de relações parou antes do primeiro passo com `NameError: name 're' is not defined`.
**Causa:** o patch adicionou regex ao preprocessamento sem atualizar a lista de imports; `py_compile` não detecta nomes ausentes que só falham em runtime.
**Correção:** importar explicitamente `re` e executar um smoke test funcional de `features()`/`build_sets()` antes de iniciar o treino longo.
**Prevenção permanente:** após refatoração de preprocessamento, além de `py_compile`, executar pelo menos uma chamada real de cada função nova antes do gate pesado.

### 10.8 Limite: classificador de relações não pode mapear sinônimos nunca vistos sem sinal lexical
**Sintoma:** o classificador neural de 25 relações atingiu 100% nas sentenças Golden e 100% na classe unknown, mas 88% nas perguntas Golden (94,0% total). Os erros concentram-se em sinônimos reservados que nunca apareceram no treino.
**Causa:** o modelo é treinado do zero, sem embeddings semânticos externos; palavras totalmente novas como equivalentes de uma relação não possuem um mecanismo mágico para herdar significado.
**Correção:** ampliar o currículo lexical com sinônimos das relações em frases de treino diferentes das frases Golden, mantendo entidades, estruturas completas e combinações Golden reservadas. Avaliar separadamente `question` e `sentence`.
**Prevenção permanente:** distinguir holdout estrutural de vocabulário OOV absoluto. Para um modelo sem pretraining externo, exigir generalização semântica de termos nunca supervisionados é um teste de capacidade inexistente, não um teste justo da implementação.

### 10.9 Limite residual: cues relacionais elevaram o Golden a 98,98%, mas negativos ambíguos ainda vazaram
**Sintoma:** com features relacionais auditáveis, o classificador chegou a 98,98% total; sentenças 100%, perguntas 98% e unknown 80%.
**Causa:** algumas perguntas/sentenças genéricas contêm palavras que também são cues válidos de relações catalogadas, e algumas formulações Golden ainda ficam semanticamente ambíguas sem contexto suficiente.
**Correção:** inspecionar os erros restantes, adicionar negativos difíceis que contenham cues sem expressar um atributo cadastral e, se necessário, ajustar aceitação por confiança/margem em vez de forçar toda entrada a uma relação.
**Prevenção permanente:** classificadores auxiliares devem possuir classe unknown forte e ser usados como bônus, não como autoridade única de grounding.

### 10.10 Erro de dataset: a mesma formulação `quem produziu` recebeu rótulos incompatíveis
**Sintoma:** 40/40 erros de pergunta restantes classificavam `Diga quem produziu Registro-X` como `manufacturer`, enquanto o Golden esperava `author`.
**Causa:** o currículo de fabricante já treinava `Informe quem produziu {e}`, enquanto o Golden de autoria usava `Diga quem produziu {e}`. Sem tipar a entidade como obra/produto, a frase é semanticamente ambígua; exigir rótulos diferentes mede inconsistência do dataset, não generalização.
**Correção:** tornar as duas relações semanticamente distinguíveis: autoria pergunta explicitamente `autor/autoria/escreveu`; fabricante usa `fabricante/fabrica/empresa produziu`. Regenerar train/Golden e hashes.
**Prevenção permanente:** antes de interpretar erro de modelo, procurar colisões de rótulo/semântica no próprio dataset. Um Golden contraditório deve ser corrigido e documentado, nunca usado para forçar memorizações artificiais.

### 10.11 Erro: código C novo usou compactação que falhou em `-Werror`
**Sintoma:** o primeiro build de `nd_relation.c` falhou em `-Wmisleading-indentation` em duas linhas com múltiplas instruções/loops na mesma linha.
**Causa:** estilo excessivamente compacto tornou o fluxo visual ambíguo para o compilador e para revisão humana.
**Correção:** reformatar blocos de controle com uma instrução por linha, remover cálculo auxiliar não utilizado e recompilar com o mesmo conjunto de warnings.
**Prevenção permanente:** novos módulos C canônicos devem privilegiar legibilidade estrutural; `-Werror` permanece obrigatório e nunca é relaxado para aceitar código novo.

### 10.12 Erro: primeira implementação C do classificador de relações divergiu do Python em 40/4.008 casos
**Sintoma:** o modelo treinado atingia o gate Python, mas `nd_relation_batch` passou apenas 3.968/4.008 no runtime C.
**Causa inicial:** existe diferença entre o preprocessamento/features Python e C; enquanto não houver diagnóstico exato, o componente não pode ser integrado ao ranking contextual.
**Correção obrigatória:** listar os casos divergentes, comparar normalização/cues/hashing passo a passo e corrigir a implementação C para paridade operacional. Não ajustar o Golden nem baixar threshold para esconder a divergência.
**Prevenção permanente:** todo novo especialista treinado precisa de gate Python↔runtime nativo sobre o Golden completo antes de ser consumido pelo orquestrador.

### 10.13 Erro: placeholders e espaços do preprocessamento nativo não reproduziam o Python
**Sintoma:** as 40 divergências Python↔C restantes concentraram-se em perguntas de `length`, como `Diga quanto Registro-XXXX mede.`; o Python aceitava `length`, enquanto o C devolvia `unknown`.
**Causa:** o Python substitui entidade/número por `ENTIDADE`/`NUMERO` e depois executa `normalize()`, que converte ASCII para minúsculas e colapsa whitespace. O C inseria placeholders maiúsculos depois da etapa de lowercase e não colapsava os espaços adicionais. Isso alterava palavras, byte n-grams e bigrams usados pela mesma rede.
**Correção obrigatória:** fazer o preprocessamento C gerar exatamente a representação normalizada do Python — placeholders minúsculos, whitespace único e trim — e repetir o Golden completo 4.008/4.008.
**Prevenção permanente:** qualquer feature aprendida que exista em Python e runtime nativo deve possuir paridade explícita de preprocessamento, não apenas paridade de pesos. Normalização, placeholders, token boundaries e hashing fazem parte do contrato do modelo.

### 10.14 Regressão: pointer 25-relações passou Golden, mas perdeu limite de span em caso livre antigo
**Sintoma:** após expandir o currículo contextual para 25 relações, o pointer atingiu 2.000/2.000 no Golden, porém no probe independente `Marina é responsável pelo projeto Atlas-77.` retornou `ina`, resultando em 3/4 probes inéditos.
**Causa:** o Golden de uma frase por entidade/relação não exercita suficientemente todas as posições do valor. A expansão de relações diluiu exemplos em que a resposta aparece no início da sentença e o modelo voltou a errar o boundary inicial por poucos bytes.
**Correção obrigatória:** rejeitar esse checkpoint; ampliar sistematicamente o currículo para valores no início, meio e fim da sentença em várias relações, mantendo probes antigos como regressão permanente e adicionando probes das oito novas relações.
**Prevenção permanente:** Golden por relação não substitui diversidade posicional de span. Todo extrator deve ser avaliado em matriz `relação × posição do valor × valor estruturado/natural`, além de exemplos livres pós-implementação.

### 10.15 Erro: novos templates posicionais existiam no código, mas o gerador continuava limitado a `% 3`
**Sintoma:** após adicionar cinco variantes de sentença para treinar spans no início/meio/fim, a nova execução reproduziu praticamente a mesma curva e manteve o mesmo erro `Marina -> ina`.
**Causa:** `sentence_for()` passou a ter cinco variantes, porém `build_context()` ainda fornecia `(n + ki) % 3`; as variantes 3 e 4 nunca eram materializadas. A mudança existia como código morto e não alterava os dados de treinamento.
**Correção obrigatória:** usar o número real de variantes (cinco) na seleção, materializar o corpus e medir a distribuição de posições da resposta antes do treino.
**Prevenção permanente:** toda expansão de dataset precisa de um gate de materialização/coverage que prove que os novos exemplos realmente aparecem nos dados; presença de template no fonte não é evidência de uso.

### 10.16 Regressão residual: currículo posicional ativo expôs truncamento de respostas longas
**Sintoma:** com as cinco posições realmente materializadas, o pointer corrigiu o caso leading `Marina`, mas atingiu 1.994/2.000 Golden e 3/4 probes livres. Erros truncaram spans válidos: `Clara Souza -> Clara`, `22 de agosto de 2028 -> 22`, `policarbonato -> polica` e checksum parcial.
**Causa provável:** a tarefa ficou mais diversa sem aumentar parâmetros; em 500 passos os heads de início/fim ainda não consolidaram boundaries para respostas longas e valores estruturados em todas as posições, embora a loss continue baixa.
**Correção controlada:** testar primeiro maior consolidação da mesma arquitetura mantendo dataset/Gates fixos. Só aceitar mais passos se Golden + probes melhorarem; caso contrário, alterar explicitamente o objetivo/sampler de span e registrar nova causa.
**Prevenção permanente:** avaliar separadamente início e fim do span, comprimento e tipo de valor; 99.x% não substitui 100% nos gates pequenos de exatidão quando a saída é factual/copied evidence.

### 10.17 Limite: ajustar penalização de comprimento não resolve a extração composicional do pointer
**Sintoma:** ao reavaliar o checkpoint de 900 passos com penalidades de span entre 0,00 e 0,05, o Golden variou apenas entre 1.994 e 1.998/2.000 e os probes livres permaneceram 4–5/8; nomes, licença, porta e latência ainda tinham boundaries incorretos.
**Causa:** o problema não é apenas preferência por spans curtos. O pointer byte-level recebe uma média da pergunta e precisa inferir simultaneamente a relação semântica e os limites do valor; ao ampliar para 25 relações essa representação tornou-se gargalo.
**Correção arquitetural:** condicionar o pointer v0.5 pelo `relation_id` produzido pelo classificador neural já validado, adicionando um embedding pequeno de relação ao estado de cada posição. A relação continua auxiliar e grounding/entidade permanecem separados.
**Prevenção permanente:** antes de ajustar hiperparâmetros de decoding, testar se o erro vem da representação. Quando outro especialista já resolveu uma variável latente com paridade nativa, reutilizar esse sinal explicitamente em vez de obrigar outro modelo pequeno a reaprendê-la implicitamente.

### 10.18 Limite: pointer condicionado por relação passou Golden, mas não 12 probes livres
**Sintoma:** o pointer v2 condicionado por `relation_id` atingiu 2.000/2.000 Golden e 9/12 probes livres. Nos erros, retornou parte da frase que descreve a relação (`responsável...`, `porta...`) ou um fragmento curto (`O`) em vez do valor.
**Causa:** o embedding de relação melhora desambiguação no currículo conhecido, mas ainda não garante boundaries corretos em estruturas sintáticas novas. Golden perfeito não transforma o pointer em autoridade de resposta.
**Correção arquitetural:** tratar o pointer como proponente de span. Antes de mostrar `Resposta direta`, validar o candidato: spans vazios/curtos ou classificados pelo próprio especialista como a relação pedida são rejeitados; o sistema então retorna a sentença de evidência selecionada, que permanece grounded. Quando a relação estiver disponível, também condicionar o pointer por ela.
**Prevenção permanente:** separar `candidate generation` de `candidate acceptance`. Um componente neural que propõe uma resposta pode permanecer útil se uma camada independente detecta candidatos claramente não-valores e faz fallback seguro, mas seu raw accuracy deve continuar documentado.

### 10.19 Erro: seleção compacta de top-2 no classificador nativo voltou a falhar sob `-Werror`
**Sintoma:** após integrar o classificador de relações à rota canônica, a recompilação completa em GCC 14 sinalizou `log[0]/log[1] may be used uninitialized` na expressão compacta que inicializava `top` e `second` em uma única linha.
**Causa:** embora o header do modelo valide 26 classes em runtime, o fluxo C excessivamente compacto não torna essa invariável evidente para a análise estática do compilador; a mesma forma já havia causado problemas de legibilidade/diagnóstico em mudanças anteriores.
**Correção obrigatória:** validar explicitamente `classes >= 2`, calcular todos os logits antes da seleção e reescrever top-1/top-2 em blocos legíveis que não dependam de inferência implícita do compilador. Manter `-Werror`.
**Prevenção permanente:** funções numéricas nativas críticas devem evitar expressões condensadas para inicialização/ranking. Invariantes de dimensão relevantes precisam ser checadas no ponto de uso quando isso melhora segurança e analisabilidade estática.

### 10.20 Erro: datasets materializados ficaram atrás do gerador canônico v0.5
**Sintoma:** `training/context_data.py` já materializa 25 relações, 52.500 exemplos de treino e 2.000 Golden, mas `training/data/context_pointer_*.jsonl` ainda continha 35.700/1.360 exemplos da v0.4.
**Causa:** o trainer consumia `build_context()` diretamente e por isso podia produzir um modelo novo, enquanto a etapa de materialização não foi executada novamente após a expansão do currículo. A árvore passou a carregar código/modelo v0.5 com snapshots de dataset antigos.
**Correção obrigatória:** executar `training/materialize_datasets.py` após toda mudança do gerador, atualizar contagens e SHA-256 e fazer os gates compararem os arquivos materializados com a saída atual de `build_context()`/`build_sets()`.
**Prevenção permanente:** nenhum modelo pode ser promovido se os datasets distribuídos não forem uma materialização byte-exata do gerador consumido pelo trainer final. Freshness de dados passa a ser gate explícito da release.

### 10.21 Regressão de prova: expansão do corpus invalidou o Golden nativo anterior do classificador de relações
**Sintoma:** depois de ativar/materializar as cinco posições de sentença do pointer, o novo gate nativo sobre o Golden corrente passou apenas 3.953/4.008. As falhas concentram-se em formas novas como `Para Registro-X, o valor Y consta no campo de versão/cor/checksum` e em algumas formulações de fabricante.
**Causa:** o resultado 4.008/4.008 havia sido obtido contra um estado anterior do corpus. `context_data.py` foi ampliado depois, mas o classificador distribuído e sua prova Python↔C não foram regenerados como consequência dessa dependência.
**Correção obrigatória:** tratar mudanças de `context_data.py` como invalidação automática do classificador de relações; retreinar com o corpus final, repetir Golden Python completo e depois Python↔C/nativo completo. Se restar divergência, corrigir preprocessamento/features e não thresholds/G Golden.
**Prevenção permanente:** registrar dependências entre datasets e especialistas. Toda mudança em um gerador compartilhado precisa disparar revalidação/reprodução de todos os modelos que consomem suas perguntas ou sentenças, mesmo quando o arquivo de pesos de outro especialista não foi editado diretamente.

### 10.22 Rejeição: retreinar o classificador no corpus final não restaurou sozinho a generalização exigida
**Sintoma:** com o `context_data.py` final, 900 passos e o mesmo modelo, o classificador obteve sentenças 100%, perguntas 98% e `unknown` 75% (98,95% total), ficando abaixo do gate por visão.
**Causa:** a expansão de sentenças alterou a distribuição consumida pelo treino, mas o conjunto estratificado e os negativos continuaram pequenos para algumas formulações de pergunta/unknown. Reexecutar o mesmo treino não resolve automaticamente a cobertura lexical e a calibração.
**Correção obrigatória:** inspecionar os erros individuais, reforçar apenas as lacunas semânticas reais do currículo e os negativos difíceis, mantendo as perguntas Golden intactas. Não baixar threshold para converter erro de generalização em PASS.
**Prevenção permanente:** depois de qualquer retreino provocado por dependência de dados, exigir métricas separadas por `question`, `sentence` e `unknown`; média global não pode esconder regressão numa visão específica.

### 10.23 Divergência nativa: Python 100% e C 3.998/4.008 em checksums hexadecimais
**Sintoma:** após corrigir o currículo final, o classificador de relações atingiu 100% nas visões `question`, `sentence` e `unknown` no Python, mas o runtime C reproduziu apenas 3.998/4.008; as 10 divergências restantes concentram-se em sentenças de `checksum`, frequentemente classificadas como `date` ou não aceitas.
**Causa provável:** o contrato de preprocessamento divergiu para valores alfanuméricos que começam por dígito. O Python mascara apenas tokens que correspondem integralmente a um número estruturado (`dígitos` com separadores numéricos), enquanto o C inicia mascaramento assim que encontra um dígito e pode transformar apenas o prefixo numérico de um checksum hexadecimal, deixando o sufixo alfabético. Isso altera features/hash mesmo com pesos idênticos.
**Correção obrigatória:** comparar as normalizações Python e C dos casos divergentes e fazer o C reproduzir exatamente a semântica do preprocessamento usado no treino. Um token alfanumérico como checksum não pode ser parcialmente convertido em `numero`; somente tokens integralmente numéricos/estruturados devem ser mascarados como número. Reexecutar os 4.008 casos no C antes de promover o checkpoint.
**Prevenção permanente:** paridade de modelo inclui tokenização e normalização de valores estruturados. Os gates precisam conter explicitamente checksum hexadecimal, versão, IP, decimal, código alfanumérico e outros tokens que misturam dígitos/letras para impedir divergências silenciosas entre Python e C.

### 10.24 Regressão de integração: classificador 4.008/4.008 e pointer 2.000/2.000 não garantiram holdout contextual 400/400
**Sintoma:** após promover o classificador revalidado, os gates unitários de relação e pointer passaram integralmente, porém o holdout adversarial de contexto caiu de 400/400 para 350/400. Os 50 casos falhos são perguntas de `port` formuladas como `endpoint numérico`, e o runtime faz fallback fail-closed (`evidência insuficiente`) em vez de recuperar a porta correta.
**Causa a determinar:** um especialista pode estar correto isoladamente e ainda falhar quando seus sinais passam por thresholds/combinação do sintetizador. A classificação da pergunta, a classificação da sentença ou o gate de concordância relação+entidade podem estar descartando a evidência apesar dos Goldens independentes.
**Correção obrigatória:** localizar a etapa exata da perda de cobertura usando os mesmos exemplos adversariais; corrigir o contrato de integração, não o Golden, e preservar o fail-closed. Reexecutar 4.008 relação, 2.000 pointer, 400 adversarial e 1.006 regressão após a mudança.
**Prevenção permanente:** gates unitários não substituem gates end-to-end. Toda promoção de pesos/preprocessamento de um especialista deve reexecutar benchmarks de composição onde os componentes interagem sob thresholds reais.

### 10.25 Causa da regressão 350/400: relação correta no top-1 foi descartada pelo gate de margem apesar de cue explícito único
**Sintoma:** nos 50 casos adversariais de `port`, o classificador escolhe `port` como top-1 para a pergunta `endpoint numérico ... utiliza`, com confiança ~0,47, mas a margem para a segunda classe fica ~0,018 e `accepted=0`. A sentença da porta, por outro lado, é classificada corretamente com alta confiança.
**Causa:** a palavra de superfície `utiliza` aparece fortemente em perguntas de protocolo, comprimindo a margem, enquanto a expressão explícita `endpoint numérico` identifica porta de forma inequívoca. O gate operacional considerava somente confiança+margem e ignorava a evidência lexical explícita já auditada nas cues.
**Correção obrigatória:** preservar o gate conservador padrão, mas permitir aceitação do top-1 conhecido quando existe cue explícito da própria relação e nenhuma outra relação possui cue explícito concorrente no mesmo texto. Não baixar globalmente o threshold de margem. Revalidar desconhecidos, relações, holdout adversarial e perguntas multipartes.
**Prevenção permanente:** calibração deve distinguir `baixa margem por competição de superfície` de `ausência de evidência semântica`. Exceções de aceitação só podem usar sinais auditáveis e exclusivos, nunca apenas reduzir thresholds globais.

### 10.26 Erro de gate: o treinador media `unknown`, mas não o exigia para aprovação
**Sintoma:** `train_relation_classifier.py` calcula `gold_by_view` para `question`, `sentence` e `unknown`, porém a condição final de falha exigia >=99% apenas para `question` e `sentence`. Um futuro checkpoint poderia portanto ser exportado como aprovado mesmo degradando a recusa de entradas fora das relações catalogadas.
**Causa:** a métrica foi ampliada durante a correção 10.22, mas a condição executável de promoção não foi sincronizada com a regra documentada.
**Correção obrigatória:** exigir >=99% também em `unknown` e alinhar o número padrão de steps do trainer ao caminho canônico de `train_release.py`, para que execução direta e execução de release tenham o mesmo contrato.
**Prevenção permanente:** toda métrica declarada como gate na documentação deve existir como condição executável de falha; relatórios informativos não substituem enforcement no trainer/verificador.

### 10.27 Lacuna de enforcement: o trainer de relações executava o precheck, mas não era fiscalizado pelo gate de protocolo
**Sintoma:** `training/train_relation_classifier.py` já chama `pre_generation_lessons_check.py`, porém `tests/verify_lessons_protocol.py` não o listava entre os caminhos cuja fiação é obrigatoriamente verificada.
**Causa:** o especialista de relações foi adicionado depois do gate original e a lista de caminhos críticos não foi sincronizada.
**Correção obrigatória:** incluir o trainer de relações em `wired` e manter o teste falhando se qualquer caminho canônico de geração/build perder o precheck.
**Prevenção permanente:** ao adicionar um novo trainer, gerador, empacotador ou build canônico, atualizar na mesma mudança o gate que comprova a leitura obrigatória das lições.

### 10.28 Regressão de processo: primeira implementação NDOS repetiu estilo C compacto já proibido
**Sintoma:** o primeiro build da reconstrução NDOS v1 foi bloqueado por `-Wmisleading-indentation` em leituras do header/records escritas com múltiplas instruções na mesma linha.
**Causa:** apesar da lição 10.11 já proibir esse padrão, a implementação inicial reutilizou compactação visual durante a reconstrução do loader binário.
**Correção:** manter `-Werror`, reformatar cada leitura/atribuição/checagem em instruções estruturadas separadas e recompilar sem reduzir warnings.
**Prevenção permanente:** antes do primeiro build de qualquer novo módulo C, executar inspeção sintática/estilística específica para controle de fluxo compacto; recorrência de uma lição antiga deve ser registrada como regressão de processo, não ocultada por já existir uma regra semelhante.

### 10.29 Acerto: árvore perdida não autoriza reutilizar hashes ou resultados históricos como evidência nova
**Situação:** a árvore de desenvolvimento da reconstrução v0.6 alpha.1 não estava persistida, enquanto havia um ZIP histórico v0.6 de arquitetura `.ndsh` diferente e um README posterior descrevendo `NDOS v1`.
**Decisão correta:** partir do ZIP íntegro v0.5, usar o pacote histórico apenas como fonte de lineage/regressão, materializar novamente o delta NDOS e atribuir uma nova identidade `v0.6.0-alpha.2` com hashes próprios.
**Prevenção permanente:** quando código/asset que originou um hash não puder ser recuperado e reproduzido, nunca fabricar equivalência. A continuação deve receber nova identidade de artefato e declarar explicitamente que não é byte-idêntica ao estado perdido.

### 10.30 Regressão de integração: inserir `OPEN_SHARD` antes de `QUESTION` quebrou consumidores CLI herdados
**Sintoma:** os gates NDOS, planner, multiobjetivo e assistant passaram, mas `tests/verify_live_qa.py` falhou porque continuava chamando a interface v0.5 `RETRIEVER KB CONTEXT_QA RELATION QUESTION ...`; a primeira integração v0.6 havia deslocado `QUESTION` ao tornar `OPEN_SHARD` um argumento obrigatório anterior.
**Causa:** a mudança preservou a API C interna, mas não preservou o contrato público/operacional da CLI. Testes isolados do novo componente não detectaram imediatamente a quebra dos consumidores herdados.
**Correção:** restaurar integralmente a ordem v0.5 e tornar o open-shard um último argumento opcional: `... QUESTION [CONTEXT] [RICH] [MEMORY_PATH] [OPEN_SHARD]`. A ausência do novo argumento mantém exatamente a rota antiga.
**Prevenção permanente:** extensões aditivas de interfaces canônicas devem preferir argumentos opcionais finais ou opções nomeadas; qualquer mudança de posição/assinatura pública exige teste explícito de compatibilidade com todos os consumidores existentes antes do gate completo.

### 10.31 Erro de reconstrução: reescrita manual da CLI usou enum inexistente
**Sintoma:** ao restaurar compatibilidade posicional da CLI, o primeiro rebuild falhou porque `source_name()` referenciava `ND_ANSWER_TOOL`, enquanto o contrato canônico define `ND_ANSWER_CALCULATOR`.
**Causa:** a reescrita manual usou um nome conceitual genérico em vez de reutilizar literalmente os símbolos do header e da CLI v0.5.
**Correção:** substituir pelo enum canônico e recompilar imediatamente com `-Werror` antes de executar testes funcionais.
**Prevenção permanente:** ao alterar apenas a assinatura/ordem de argumentos de uma interface existente, preservar o restante do arquivo por diff mínimo; nomes de enums, ABI e constantes devem ser copiados da fonte canônica, nunca reconstruídos de memória.

### 10.32 Dupla falha de validação: label CLI mudou e shell ad-hoc não interrompeu após teste falhar
**Sintoma:** após corrigir o enum, `verify_live_qa.py` ainda rejeitou a calculadora porque a CLI imprimia `source=tool` em vez do contrato herdado `source=calculator`. O comando ad-hoc continuou e imprimiu uma linha local de `PASS` porque aquele shell não havia sido iniciado com `set -e`.
**Causa:** a correção trocou o símbolo do enum, mas não restaurou literalmente a string pública v0.5; além disso, um agrupamento de probes fora dos scripts canônicos não estava fail-fast.
**Correção:** restaurar `return "calculator"` e executar toda sequência de validação ad-hoc com `set -euo pipefail`; somente o `VERIFY PASS` do script canônico pode ser usado como aprovação agregada.
**Prevenção permanente:** compatibilidade inclui valores textuais observáveis usados por consumidores/testes. Comandos manuais de validação devem ser fail-fast e nunca emitir marcador de sucesso depois de uma etapa que falhou.

### 10.33 Regressão Android: copiar asset somente quando ausente pode preservar bytes superseded após atualização
**Sintoma:** `MainActivity.asset()` copiava cada modelo de `assets/` para `filesDir` somente quando o arquivo ainda não existia. Como a reconstrução alpha.2 reutiliza o nome `neuraldesk-open-knowledge-pira-v0.6.ndos` com bytes/hash diferentes da tentativa histórica alpha.1, uma instalação atualizada poderia continuar carregando o arquivo antigo já persistido.
**Causa:** a política de “uma única fonte de verdade em `models/`” era verdadeira no empacotamento, mas não estava garantida no lifecycle de instalação/upgrade do app. Existência de path foi confundida com identidade de conteúdo.
**Correção obrigatória:** comparar os bytes empacotados com os bytes persistidos e substituir atomicamente qualquer cópia ausente ou divergente antes de carregar JNI; a mesma regra deve valer para todos os assets canônicos, não apenas NDOS.
**Prevenção permanente:** qualquer cache/cópia de asset versionado deve validar conteúdo, hash ou identidade equivalente antes de reutilização. Adicionar teste JVM determinístico de `missing -> install`, `same -> preserve` e `stale -> replace`; existência de arquivo nunca basta como prova de atualidade.

### 10.34 Regressão de evidência: logs e REPORT marcados como finais sobreviveram de uma versão anterior
**Sintoma:** a árvore `v0.6.0-alpha.2` continha `FINAL_VERIFY.log` atual com `VERIFY PASS`, mas `FINAL_SANITIZER.log` e `verification/REPORT.json` ainda pertenciam à v0.5. `SHA256SUMS.txt` era internamente consistente com esses arquivos obsoletos, portanto checksum por si só não detectava a mentira semântica.
**Causa:** `generate_release_metadata.py` verificava apenas a presença textual de `VERIFY PASS`/`SANITIZER PASS`, sem exigir que os logs declarassem e correspondessem à versão corrente do `PROJECT_MANIFEST.json`.
**Correção obrigatória:** os gates agregados devem emitir marcador versionado e o gerador de metadata deve rejeitar logs cujo marcador de versão não corresponda exatamente ao manifest corrente. `REPORT.json` deve derivar a versão do manifest, não de literal hard-coded.
**Prevenção permanente:** evidência de release precisa ser ligada a identidade de versão/artefato, não apenas a nome do arquivo ou marcador genérico. Toda promoção deve regenerar logs, REPORT e checksums depois da última mudança de código/documentação.

### 10.35 Drift observável: documentação atualizada não compensa strings de versão antigas no código/UI
**Sintoma:** a documentação e o manifest declaravam alpha.2, enquanto a UI Android ainda mostrava `NeuralDesk LocalNet v0.5` e os User-Agent de aquisição web declaravam `0.4.0`.
**Causa:** versionamento foi atualizado nos manifests/builds, mas valores públicos distribuídos em layout e clientes de rede ficaram fora de um gate de consistência.
**Correção obrigatória:** alinhar strings observáveis à versão canônica atual e adicionar auditoria de consistência que compare manifest, Android `versionName`, UI e identificadores públicos relevantes, permitindo apenas referências históricas explicitamente classificadas como lineage/rollback/model asset.
**Prevenção permanente:** toda mudança de versão deve ter um gate machine-readable de drift. Não usar busca cega para proibir toda menção histórica: o verificador deve distinguir referências canônicas atuais de nomes legítimos de assets herdados e documentação de lineage.

### 10.36 Lacuna de enforcement: Retriever e Pointer mediam Golden obrigatório, mas exportavam antes de exigir aprovação
**Sintoma:** `train_knowledge_retriever.py` e `train_context_pointer.py` calculavam Golden e escreviam o asset/report, porém não encerravam com falha quando o Golden ficava abaixo do contrato de promoção. O Relation Classifier já possuía enforcement explícito.
**Causa:** a validação forte existia nos verificadores da release, mas não no próprio caminho de geração do checkpoint. Assim, uma execução direta do trainer poderia sobrescrever um path canônico com candidato inferior antes de o gate agregado rejeitá-lo.
**Correção obrigatória:** avaliar o Golden antes de exportar para o path solicitado e abortar se o Retriever não atingir 100% do Golden ou se o Pointer não atingir 100% do Golden condicionado. Os probes livres do Pointer permanecem diagnósticos, porque a política final usa candidate acceptance/fallback e não exige que o proponente acerte 12/12 isoladamente.
**Prevenção permanente:** toda métrica denominada Golden obrigatório deve bloquear o próprio gerador antes de escrever o artefato promovível; o gate de release continua obrigatório e não é substituído pelo gate do trainer.

### 10.37 Inconsistência de índice: documento canônico registrado no manifest não se listava no índice de documentação
**Sintoma:** o novo gate de consistência encontrou `docs/DOCUMENTATION_INDEX.md` entre os documentos canônicos registrados, mas o próprio índice não continha uma entrada explícita para `DOCUMENTATION_INDEX.md`.
**Causa:** historicamente o índice era tratado como recipiente, não como artefato indexado; ao tornar o manifest exaustivo sobre todos os documentos, essa exceção implícita passou a criar duas visões diferentes da documentação canônica.
**Correção:** adicionar o próprio índice à lista e manter o gate exigindo que todo `.md` top-level de `docs/` apareça tanto no manifest quanto no índice.
**Prevenção permanente:** inventários canônicos devem ser fechados sobre o próprio conjunto quando o objetivo é exaustividade; não criar exceções silenciosas apenas para satisfazer um verificador novo.

### 10.38 Recorrência operacional: build canônico fixo em `-j2` fez gates completos excederem a janela do executor
**Sintoma:** duas execuções limpas de `verify.sh` e uma de `verify_sanitize.sh` foram encerradas externamente sem marcador final, apesar de não apresentarem erro funcional; a compilação C consumiu a maior parte da janela com paralelismo fixo de dois jobs em host com cinco CPUs disponíveis.
**Causa:** o número de jobs estava hard-coded nos scripts, misturando uma escolha conservadora de recurso com o contrato semântico do gate. A cobertura não dependia de `-j2`, mas o tempo operacional sim.
**Correção:** tornar o paralelismo configurável por `ND_BUILD_JOBS`, preservando `2` como default e validando que o valor seja inteiro positivo. O mesmo source/test set continua sendo compilado; apenas a concorrência de build muda.
**Prevenção permanente:** parâmetros de recurso que não alteram semântica devem ser configuráveis e validados. Nunca reduzir testes, samples ou rigor de warnings para caber numa janela; otimizar somente scheduling/build quando isso não muda os bytes/contratos avaliados.

### 10.39 Auditoria JNI: aquisição de strings podia deixar recurso sem release em falha parcial
**Sintoma:** `nativeAnswer` adquiria `question` e depois `context`; somente em seguida verificava `q == NULL`. Se a aquisição da pergunta falhasse e a do contexto tivesse sucesso, a função retornaria sem liberar `c`. Argumentos `jstring` nulos também dependiam implicitamente do contrato Kotlin em vez de falharem explicitamente no boundary nativo.
**Causa:** o caminho feliz foi priorizado e o gate JNI existente comprova compilação/símbolos no host, não injeta falhas de alocação do JNI nem executa ART real.
**Correção:** rejeitar argumentos obrigatórios nulos antes da aquisição; adquirir/verificar `question` antes de tentar `context`; se `context` for fornecido e sua aquisição falhar, liberar `question` antes de retornar. Aplicar guardas equivalentes ao `nativeLoad`.
**Prevenção permanente:** boundaries JNI devem ter ownership linear auditável: cada aquisição bem-sucedida precisa ter release em todo caminho de saída. Gates de sintaxe não devem ser descritos como prova de lifecycle sob OOM/ART; revisão de caminhos de erro continua obrigatória.

### 10.40 Falha de cálculo composto: detectar um operador não equivale a avaliar a expressão inteira
**Sintoma:** a pergunta `Quanto é (37 × 19) + 15?` foi tratada pela calculadora, mas o runtime selecionou apenas um operador e respondeu `37 + 19 = 56`, ignorando precedência, parênteses, o terceiro operando e o símbolo Unicode de multiplicação.
**Causa:** `nd_calculator_try()` extraía até quatro números e escolhia uma única operação por presença textual; a implementação servia para operações binárias, não para expressões matemáticas.
**Correção obrigatória:** adicionar parser bounded de expressão com precedência, parênteses, operadores `+ - * / ^` e equivalentes Unicode suportados, mantendo as formas verbais existentes como rota compatível.
**Prevenção permanente:** o gate da calculadora deve incluir expressões com três ou mais operandos, precedência, parênteses, operadores Unicode, divisão por zero dentro da expressão e entradas não matemáticas. Nunca alegar suporte a “expressões” se apenas uma operação binária for executada.

### 10.41 Falha de planner: preâmbulo contextual foi promovido a objetivo e contaminou a composição
**Sintoma:** `Nas fases 1 e 2 do Parque das Conchas, quais campos de petróleo aparecem?` gerou dois objetivos; o primeiro recuperou corretamente Pirá A1045 e o segundo respondeu indevidamente `A capital de Alemanha é Berlim`.
**Causa:** a regra que protege preâmbulos antes de vírgula reconhecia somente alguns inícios (`Para`, `Sobre` etc.) e não distinguia genericamente uma oração circunstancial inicial de uma pergunta autônoma.
**Correção obrigatória:** classificar como preâmbulo qualquer segmento inicial antes de `, qual/quais/quem/...` que não contenha intenção interrogativa própria, preservando-o no mesmo objetivo.
**Prevenção permanente:** regressões devem cobrir preâmbulos de condição, tempo, local, fase, finalidade e contexto; nenhuma parte não interrogativa pode virar objetivo independente apenas por preceder uma vírgula.

### 10.42 Falha de cobertura por entidade: coordenação `cada X` precisa de objetivos distintos
**Sintoma:** `Se eu usar quantização e KV cache na inferência, o que cada técnica tende a economizar?` retornou duas vezes a explicação de KV cache e não cobriu quantização.
**Causa:** a decomposição textual separou a estrutura sintática, não as duas entidades coordenadas às quais `cada técnica` se referia; em seguida o retriever global selecionou o mesmo conhecimento para ambos os fragmentos.
**Correção obrigatória:** quando houver dois tópicos coordenados e referência distributiva (`cada técnica`, `cada abordagem`, `cada método`, `cada um`), expandir deterministicamente em um objetivo por tópico, preservando a mesma pergunta predicativa.
**Prevenção permanente:** o gate multipartes deve exigir diversidade de objetivos e rejeitar composições onde dois objetivos semanticamente distintos recebem a mesma evidência sem justificativa.

### 10.43 Falha de memória relacional: recuperar a frase certa não prova que o atributo certo foi extraído
**Sintoma:** depois de memorizar `Solis-9 usa bateria de sódio e a responsável é Helena`, a pergunta `Que tipo de bateria o projeto Solis-9 usa?` encontrou a entrada correta, mas o pointer devolveu `Helena`.
**Causa:** a recuperação de memória foi lexicalmente correta, porém a relação `tipo de bateria` não pertence às 25 relações treinadas; o pointer propôs um span plausível de outra relação e a política aceitou a resposta sem um binding lexical específico do atributo pedido.
**Correção obrigatória:** para perguntas `tipo de <atributo>` ou equivalentes não cobertas pelo classificador, usar extração lexical grounded no mesmo atributo da evidência antes de aceitar um span neural de relação desconhecida.
**Prevenção permanente:** testes de memória devem conter uma única entrada com dois ou mais atributos concorrentes e perguntar cada atributo separadamente. Acertar a entrada e errar o valor conta como falha.

### 10.44 Falha de herança de entidade: o anchor pode aparecer em um objetivo posterior
**Sintoma:** em `Com base apenas neste contexto, qual é a versão e o responsável do Atlas-77?`, o primeiro subobjetivo perdeu `Atlas-77`, falhou no contexto e caiu para conhecimento genérico sobre internet, enquanto o segundo carregava a entidade.
**Causa:** `inherit_anchor()` procurava entidade apenas no primeiro objetivo após o split.
**Correção obrigatória:** descobrir o anchor em todos os objetivos e propagá-lo aos fragmentos interrogativos que perderam a entidade, sem sobrescrever uma entidade já explícita.
**Prevenção permanente:** testar coordenações onde a entidade aparece no primeiro, no último e no meio dos objetivos; supplied-context com entidade estruturada nunca pode cair para conhecimento genérico quando o atributo solicitado estiver ausente.

### 10.45 Limite de recuperação neural: recusa correta pode ainda esconder uma correspondência lexical inequívoca
**Sintoma:** `O que é RAG?` e a paráfrase sobre loss/inteligência recusaram embora existam registros internos canônicos muito próximos (`O que significa RAG?`, `Uma loss menor garante inteligência geral?`).
**Causa:** o retriever neural fail-closed é deliberadamente conservador e não possui uma segunda etapa lexical auditável para casos de correspondência forte.
**Correção permitida:** adicionar fallback sparse first-party somente depois da recusa neural, com score e margem fail-closed, sem substituir um resultado neural aceito.
**Prevenção permanente:** medir o fallback em positivos pós-implementação e negativos adversariais; uma melhoria de recall só pode ser promovida se não introduzir respostas aceitas incorretas.

### 10.46 Falha de implementação do fallback sparse: dependência de ctype e linha compacta foram bloqueadas por `-Werror`
**Sintoma:** o primeiro build v0.6.1 parou em `nd_knowledge.c`: `isalnum` foi usado sem `<ctype.h>` e uma sequência `if(...);rr->...` em linha única disparou `-Wmisleading-indentation`.
**Causa:** a implementação nova foi inserida em arquivo historicamente compacto sem revalidar imediatamente includes e legibilidade estrutural sob o conjunto completo de warnings canônicos.
**Correção:** incluir explicitamente `<ctype.h>`, expandir o fluxo de aceitação em linhas/blocos inequívocos e recompilar com o mesmo `-Werror`.
**Prevenção permanente:** toda adição de helpers C deve declarar seus headers diretos e evitar múltiplas decisões/efeitos na mesma linha; o primeiro gate após alteração C é sempre a compilação com warnings como erro.

### 10.47 Divergência de planners: o assistant e o grounding contextual decompunham a mesma pergunta de formas diferentes
**Sintoma:** o planner top-level tratou `Com base apenas neste contexto, qual é a versão e o responsável do Atlas-77?` como um objetivo, enquanto `nd_context_synth.c` possuía um segundo `split_goals()` independente e produziu três objetivos, bloqueando inclusive a evidência correta de `Caio`.
**Causa:** havia duas fontes de verdade ativas para decomposição multipartes: `nd_planner.c` e uma implementação paralela em `nd_context_synth.c`.
**Correção obrigatória:** tornar `nd_planner` a única autoridade de decomposição e fazer o grounding contextual consumir o plano canônico; ampliar o planner canônico para coordenações interrogativas `e o/e a/e os/e as` quando representam atributos adicionais.
**Prevenção permanente:** não manter dois parsers/planners ativos para a mesma semântica. Testes devem comparar a decomposição usada pelo assistant e pelo grounding em perguntas idênticas.

### 10.48 Herança indevida em plano distributivo: sigla de tópico foi confundida com anchor de entidade
**Sintoma:** a expansão de `quantização e KV cache ... cada técnica` criou corretamente dois objetivos, mas o pós-processamento herdou `KV cache tende a economizar?` para o objetivo de quantização, fazendo ambos recuperarem KV cache.
**Causa:** a expansão distributiva foi submetida à mesma herança de entidade usada para fragmentos que perderam um identificador; `KV` em maiúsculas foi interpretado como entidade pelo heurístico existente.
**Correção:** planos distributivos já possuem tópico explícito em cada objetivo e não devem passar por herança de anchor. A herança continua apenas para splits em que um fragmento interrogativo realmente perdeu a entidade compartilhada.
**Prevenção permanente:** cada transformação do planner deve declarar se produz objetivos autossuficientes ou dependentes de herança; não aplicar pós-processamentos semanticamente incompatíveis de forma global.

### 10.49 Falha do teste adversarial: comparação case-sensitive marcou resposta semanticamente correta como falha
**Sintoma:** a política de comparação absoluta respondeu `Não existe ... depende ...`, mas o teste procurava literalmente `não existe` com `strstr`, classificando diferença de caixa como regressão.
**Causa:** o teste pretendia verificar conteúdo semântico mínimo, mas usou comparação textual sensível a maiúsculas sem necessidade.
**Correção:** alinhar o literal à saída canônica ou usar helper case-insensitive quando a caixa não faz parte do contrato.
**Prevenção permanente:** testes devem ser estritos apenas nas propriedades que realmente pertencem ao contrato; não introduzir fragilidade de caixa/pontuação quando o objetivo é validar comportamento semântico.

### 10.50 Unificação de planner deixou helper órfão e `-Werror` bloqueou código morto
**Sintoma:** depois de substituir o `split_goals()` paralelo de `nd_context_synth.c` pelo planner canônico, `find_ci()` deixou de ter consumidores e a compilação falhou com `-Wunused-function`.
**Causa:** a remoção da segunda fonte de verdade eliminou corretamente uma dependência, mas o helper privado legado não foi removido na mesma transformação.
**Correção:** remover o helper órfão e recompilar sem desabilitar `-Wunused-function` ou `-Werror`.
**Prevenção permanente:** refatorações de consolidação devem incluir auditoria de símbolos privados que perdem consumidores; código morto não permanece na árvore distribuída.

### 10.51 Falha de grounding morfológico: `responsável` e `responsabilidade` foram tratados como relações diferentes
**Sintoma:** a pergunta `o responsável do Atlas-77?` foi classificada corretamente como `owner`, mas a evidência `O Atlas-77 está sob responsabilidade de Caio.` foi classificada pelo relation classifier como `date` e recebeu penalidade, ficando abaixo do threshold de cobertura.
**Causa:** o classificador de 25 relações foi treinado com formas lexicais específicas; a variante nominal `responsabilidade` não fazia parte dos cues canônicos. O grounding dependia demais da classe neural mesmo quando pergunta e evidência compartilhavam um radical lexical forte.
**Correção:** manter o classificador inalterado e acrescentar correspondência morfológica conservadora no scorer de evidência: termos longos podem dar suporte quando compartilham prefixo lexical suficientemente longo, enquanto anchors estruturados continuam exigindo igualdade exata.
**Prevenção permanente:** o benchmark contextual deve incluir variações morfológicas de relação (`responsável/responsabilidade`, formas nominais/adjetivais equivalentes) e confirmar que o ganho de recall não aumenta falsos positivos nos holdouts existentes.

### 10.52 Regressão do fallback sparse: similaridade lexical trocou uma entidade fictícia por uma capital conhecida
**Sintoma:** `Qual é a capital do país fictício Noveria-999?` deixou de recusar e respondeu `Países Baixos é Amsterdã` após a introdução do fallback sparse.
**Causa:** o fallback aceitou duas correspondências lexicais genéricas (`capital` + raiz próxima de `país/países`) com margem suficiente, mas não possuía proteção contra substituição de entidade estruturada inédita.
**Correção obrigatória:** aumentar o mínimo de cobertura lexical para casos não-acrônimo e impedir que uma correspondência relacional genérica substitua uma entidade específica. O fallback continua posterior à recusa neural e deve privilegiar precisão sobre recall.
**Prevenção permanente:** toda evolução de retrieval precisa reexecutar unknown/entidade-fictícia do Live QA. Adicionar regressão explícita para `Noveria-999` e casos equivalentes; ganho em paráfrase nunca pode reduzir o fail-closed factual.

### 10.53 Recorrência operacional: mesmo com paralelismo correto, o agregador monolítico excedeu a janela externa
**Sintoma:** `verify.sh` com `ND_BUILD_JOBS=5` concluiu 100% da compilação `-Werror`, limpeza, protocolo e consistência documental, mas a execução externa foi encerrada após o primeiro gate de formato antes do marcador `VERIFY PASS`. Nenhum erro funcional foi emitido, porém o resultado continuou não promovível.
**Causa:** o gate agregado reúne build limpa, verificações neurais extensas, comportamento, JNI e Kotlin em um único processo cuja duração pode exceder a janela operacional, mesmo quando o paralelismo da compilação já foi otimizado.
**Correção obrigatória:** suportar execução retomável por fases determinísticas. Cada fase concluída deve produzir um receipt fora da árvore distribuída, vinculado à versão e a um SHA-256 canônico dos inputs da release. Fases posteriores só podem reutilizar receipts cujo digest ainda corresponda exatamente aos mesmos código, documentação, manifest, modelos e datasets; qualquer alteração invalida a continuidade. O marcador final só pode ser emitido depois de validar todos os receipts exigidos da mesma versão/digest.
**Prevenção permanente:** gates longos devem poder ser executados como uma sequência verificável sem reduzir cobertura, amostras, sanitizers ou rigor de compilação. Timeout nunca vira PASS; retomada só é válida quando criptograficamente vinculada aos mesmos inputs e quando artefatos intermediários necessários permanecem íntegros.

### 10.54 Pipeline de release ficou semanticamente atrás dos gates v0.6.1
**Sintoma:** depois de `VERIFY PASS version=0.6.1-alpha.1` e `SANITIZER PASS version=0.6.1-alpha.1`, a auditoria pré-empacotamento encontrou `generate_release_metadata.py` ainda publicando `calculator: 10/10`, sem registrar o gate `conversational correctness 12/12`, enquanto `package_release.py` reexecutava `verify.sh`/`verify_sanitize.sh` apenas no modo monolítico, incompatível com o mecanismo retomável criado para a mesma release. `verification/AUDIT_STATUS.json` também ainda dizia que os marcadores finais não tinham sido observados.
**Causa:** os gates executáveis evoluíram mais rápido que a camada de evidence/empacotamento. Os scripts de release foram herdados de versões anteriores e não estavam cobertos por uma comparação semântica contra o manifest e os resultados atuais.
**Correção obrigatória:** derivar métricas atuais de fontes machine-readable sempre que possível; registrar explicitamente calculadora 16/16 e conversational correctness 12/12; vincular evidence ao digest canônico e às fases/receipts exigidos; atualizar `AUDIT_STATUS.json` a partir dos fatos verificados, nunca de literais antigos; e fazer a verificação do ZIP reextraído suportar exatamente as mesmas fases retomáveis usadas na árvore fonte, sem reduzir cobertura.
**Prevenção permanente:** antes de freeze de qualquer release, auditar também os scripts que geram evidence e pacote. Um motor que passou seus testes ainda não é release se metadata ou empacotador descrevem outro contrato. Qualquer mudança nesses scripts altera os inputs canônicos, invalida receipts anteriores e exige nova execução dos gates antes do pacote final.

### 10.55 Falso positivo em gate de pipeline: proibir uma string não prova ausência de execução monolítica
**Sintoma:** `verify_release_pipeline.py` rejeitou o novo `package_release.py` porque encontrou literalmente `['bash', 'scripts/verify.sh']`, embora a chamada estivesse dentro de `run_phase()` com `ND_VERIFY_PHASE` definido para cada fase canônica.
**Causa:** o teste inspecionava uma representação textual da chamada, não a propriedade semântica que queria garantir. A mesma linha é correta tanto no modo fase-a-fase quanto poderia ser incorreta num modo monolítico dependendo do ambiente.
**Correção obrigatória:** validar a presença das listas completas de fases, definição explícita de `ND_VERIFY_PHASE`/`ND_SANITIZE_PHASE`, estado externo `ND_VERIFY_STATE_DIR`, iteração por fase e digest da árvore reextraída. Não proibir a chamada shell necessária em si.
**Prevenção permanente:** gates estáticos devem testar contratos observáveis/estruturais, não substrings que podem aparecer legitimamente. Falso positivo de teste deve ser registrado e corrigido; nunca alterar o código correto apenas para satisfazer uma asserção textual mal formulada.

### 10.56 Gate de consistência acoplado à implementação textual antiga do gerador
**Sintoma:** após generalizar `generate_release_metadata.py` para validar VERIFY e SANITIZER pela mesma função, `verify_documentation_consistency.py` falhou porque procurava literalmente `f'VERIFY PASS version={version}'` no source do gerador.
**Causa:** o gate verificava a sintaxe interna de uma implementação anterior, não o contrato funcional de exigir marcador versionado e digest/receipts correntes.
**Correção obrigatória:** o gate deve validar que o manifest declara os marcadores canônicos e que o gerador possui validação genérica de `PASS version`, receipt marker e digest atual. A forma de construir a string não é parte do contrato.
**Prevenção permanente:** quando uma função é refatorada sem alterar o comportamento exigido, testes estruturais devem permanecer semânticos. Não congelar snippets de implementação como se fossem API.

### 10.57 Digest canônico excluía builds semanticamente, mas ainda os percorria fisicamente
**Sintoma:** a fase `checkpoint` concluiu `verify_verification_checkpoint.py`, porém não conseguiu emitir o receipt dentro da janela porque `input_digest()` usava `ROOT.rglob('*')`; `included_file()` rejeitava `build/` e `build-sanitize/`, mas somente depois que toda a árvore já havia sido percorrida.
**Causa:** exclusão semântica foi implementada como filtro posterior, não como poda de travessia. Diretórios de build volumosos continuaram custando I/O e tempo mesmo sem contribuir um byte para o SHA-256.
**Correção obrigatória:** enumerar inputs com travessia que remova diretórios excluídos antes de descer neles, preservando exatamente o mesmo conjunto lógico de arquivos incluídos. Adicionar teste que compare o digest antes/depois de criar conteúdo arbitrário dentro de diretório excluído.
**Prevenção permanente:** caminhos excluídos de hash, inventário ou pacote devem ser podados na enumeração quando podem crescer muito. Um filtro correto em conteúdo pode ainda ser operacionalmente incorreto se percorre artefatos que deveriam ser invisíveis.

### 10.58 Metadata assumiu schema inexistente do relatório Pointer
**Sintoma:** `generate_release_metadata.py` falhou com `KeyError: unseen_total` depois que todos os gates haviam passado. O relatório real `CONTEXT_POINTER_REPORT.json` contém `unseen_exact` como proporção e a lista `unseen_rows`, não a chave `unseen_total`.
**Causa:** a implementação do gerador usou uma lembrança/assunção de schema em vez de validar o JSON real produzido pelo trainer atual.
**Correção obrigatória:** derivar total e acertos diretamente de `unseen_rows` (`len(rows)` e soma de `exact`) e cruzar a razão calculada com `unseen_exact` quando presente. Se houver inconsistência, abortar metadata em vez de adivinhar.
**Prevenção permanente:** consumidores de evidence devem validar o schema efetivamente materializado e preferir contagens derivadas de registros concretos a chaves presumidas. Antes de freeze, todo campo novo do REPORT deve ser exercitado pelo gerador real, não apenas por teste textual do source.

### 10.59 Empacotador confundiu o nome da suíte `sanitize` com o marcador público `SANITIZER`
- **Falha observada:** a revalidação do ZIP executou o sanitizer, mas `package_release.py` construiu genericamente `SANITIZE PASS version=...`; o contrato canônico emitido por `verify_sanitize.sh` é `SANITIZER PASS version=...`. O pacote foi corretamente bloqueado apesar de o problema estar apenas na verificação do marcador.
- **Causa:** derivar o marcador público diretamente do nome interno da suíte (`sanitize`) em vez de usar um contrato explícito por suíte.
- **Correção obrigatória:** mapear explicitamente `verify -> VERIFY PASS` e `sanitize -> SANITIZER PASS` e cobrir esse contrato em teste estrutural/funcional do pipeline.
- **Regra anti-regressão:** nomes internos de fases/suítes nunca podem ser usados para inferir silenciosamente strings de evidência pública; markers versionados são contratos explícitos.

### 10.60 Snapshot de pacote preservou estado mais novo do que a árvore de trabalho posteriormente sobrescrita
- **Falha observada:** após a tentativa de empacotamento, a árvore de trabalho voltou parcialmente para uma revisão mais antiga em exatamente sete arquivos (README, manifest, CURRENT_STATE, EVALUATION, lições e logs finais), enquanto o ZIP criado antes da falha preservou a revisão mais nova com as lições 10.53–10.58 e digest/evidence correspondentes.
- **Causa:** escrita posterior parcial sobre a árvore de trabalho, sem validação de equivalência contra o snapshot recém-criado.
- **Correção obrigatória:** recuperar somente arquivos cuja versão mais nova seja comprovada byte a byte pelo snapshot, registrar a divergência e invalidar todos os receipts após qualquer recuperação/modificação.
- **Regra anti-regressão:** depois que um snapshot é criado, qualquer etapa posterior deve tratar a árvore fonte como imutável ou verificar seu digest antes e depois; divergência fonte↔snapshot bloqueia promoção e nunca é resolvida por escolher arbitrariamente um dos lados.

### 10.61 Memória multiatributo: recuperar a evidência correta ainda pode ligar a relação ao span errado
- **Falha observada:** após memorizar `o robô Aurora-3 usa sensor LiDAR e é coordenado por Renata`, tanto `Qual sensor o robô Aurora-3 usa?` quanto `Quem coordena o robô Aurora-3?` recuperaram a frase certa, mas devolveram `Aurora-3 usa` em vez de `LiDAR`/`Renata`.
- **Causa:** a memória persistia somente texto livre e delegava a seleção do valor ao pointer/context synth; não existia um índice explícito `sujeito -> relação -> valor` para relações concorrentes na mesma sentença.
- **Correção obrigatória:** derivar fatos estruturados first-party a partir das entradas persistidas, com sujeito, relação canônica e valor grounded; consultas que identificam relação+entidade devem resolver o fato estruturado antes do pointer textual. O texto original permanece como evidência e fonte persistente.
- **Regra anti-regressão:** cada entrada de memória com dois ou mais atributos deve ser consultada por atributo individualmente; recuperar a frase certa e o valor errado é falha. O índice estruturado deve ser reconstruível deterministicamente a partir do arquivo persistido e não criar fatos ausentes no texto.

### 10.62 Falso follow-up: pronome anafórico não autoriza herdar tópico quando a pergunta introduz âncoras novas
- **Falha observada:** depois de discutir RAG, `Se alguém disser que Transformer é sempre superior a RNN em qualquer tarefa, essa afirmação está correta?` herdou a pergunta anterior apenas porque continha `essa`, devolvendo conteúdo de RAG.
- **Causa:** `is_followup()` tratava `isso/essa/esse` como sinal suficiente e concatenava o último turno sem verificar mudança explícita de tópico.
- **Correção obrigatória:** separar `tem marcador anafórico` de `deve herdar contexto`. Acrônimos, entidades estruturadas ou tópicos explícitos novos que não aparecem no turno anterior bloqueiam herança; follow-ups vagos sem nova âncora continuam elegíveis.
- **Regra anti-regressão:** testes sequenciais devem cobrir anáfora legítima (`E por que isso importa?`) e troca de tópico com pronome (`... Transformer ... RNN ..., essa afirmação ...`). Herança incorreta de tópico conta como erro mesmo que a resposta isolada seja factual.

### 10.63 Retrieval perdeu âncora acrônima: pergunta RAG foi aceita como política de internet
- **Falha observada:** `Como funciona a ideia de RAG...?` recebeu como primeiro objetivo a resposta `O NeuralDesk usa a internet...`, apesar de existir um registro canônico específico `O que significa RAG?`.
- **Causa:** o retriever neural aceitou uma classe topicamente próxima sem validação de preservação da âncora acrônima explícita; como o resultado neural já estava aceito, o fallback sparse correto nunca era consultado.
- **Correção obrigatória:** resultados neurais aceitos para consultas com acrônimos explícitos devem preservar esses acrônimos na pergunta/resposta do registro candidato; se perderem a âncora, são rejeitados e o pipeline pode tentar o fallback sparse fail-closed.
- **Regra anti-regressão:** acrônimos explícitos não podem ser substituídos por conceitos apenas relacionados. A proteção precisa manter os Golden atuais e continuar recusando entidades/acrônimos inexistentes quando não houver registro correspondente.

### 10.64 Follow-up lógico: recuperar a evidência anterior não equivale a responder uma pergunta de implicação
- **Falha observada:** depois de responder que covariância turbulenta é um método possível, `isso significa que qualquer método alternativo está necessariamente errado?` repetiu a mesma evidência em vez de avaliar a implicação.
- **Causa:** follow-up era implementado por concatenação textual do turno anterior; não havia política explícita para distinguir `evidência afirma X` de `X implica exclusividade/necessidade`.
- **Correção obrigatória:** para perguntas bounded de implicação absoluta (`isso significa que qualquer ... necessariamente ...?`), responder de forma epistemicamente conservadora: a evidência positiva de um método não prova exclusividade sem evidência comparativa.
- **Regra anti-regressão:** nunca converter existência/suficiência de uma evidência em universalidade, exclusividade ou necessidade sem suporte explícito.

### 10.65 Estado de diálogo limitado: um único último turno não permite resumo auditável de conversa multi-turn
- **Falha observada:** após vários turnos, `Resuma nossa conversa até aqui em duas frases.` recusou porque o assistant preservava somente `last_question/last_answer`.
- **Causa:** o estado conversacional v0.6.1 foi desenhado apenas para follow-up bounded de um turno, não para histórico recente estruturado.
- **Correção obrigatória:** manter um buffer bounded de turnos recentes dentro da instância do assistant, sem persistir pesos nem alegar aprendizagem online; disponibilizar resumo determinístico baseado nos tópicos/perguntas realmente registrados.
- **Regra anti-regressão:** resumo nunca pode inventar turnos ou conteúdo que não existiram. O tamanho do histórico deve ser bounded, documentado e liberado com a instância.

### 10.66 Recorrência de estilo C compacto: novo guard de acrônimos voltou a disparar `-Wmisleading-indentation`
- **Falha observada:** a primeira compilação da v0.6.2 parou em `nd_knowledge.c` porque declarações foram colocadas na mesma linha após `if (...) return`, produzindo `-Wmisleading-indentation` sob `-Werror`.
- **Causa:** reapareceu o padrão de compactação já proibido pela lição 10.46 ao inserir helpers em um arquivo historicamente condensado.
- **Correção obrigatória:** expandir condições, declarações e efeitos em blocos/linhas inequívocos e recompilar mantendo exatamente o mesmo conjunto de warnings como erro.
- **Regra anti-regressão:** código novo não deve imitar o estilo compacto legado quando isso reduz auditabilidade; lições antigas continuam normativas mesmo em funções novas.

### 10.67 Acrônimo por substring criou falsa ambiguidade lexical
- **Falha observada:** depois de rejeitar corretamente a classe de internet para uma consulta com `RAG`, o fallback de acrônimo ainda recusou porque a busca case-insensitive por substring considerava ocorrências internas em palavras maiores como se fossem o token `RAG`.
- **Causa:** preservação de acrônimo foi implementada com `contains_ascii_ci`, adequada para frases comuns, mas incorreta para identidade de token.
- **Correção obrigatória:** acrônimos devem ser comparados em fronteiras de token alfanumérico, com igualdade integral case-insensitive; substring interna nunca conta como preservação de entidade/sigla.
- **Regra anti-regressão:** validadores de identidade (siglas, códigos, entidades estruturadas) exigem igualdade de token ou estrutura, não mera ocorrência de substring.

### 10.68 Herança de âncora topical contaminou objetivo já autossuficiente
- **Falha observada:** na pergunta `Como funciona a ideia de RAG e por que separar recuperação de geração pode ser útil?`, o primeiro objetivo passou a recuperar corretamente RAG, mas o segundo também devolveu RAG em vez da resposta específica sobre separar recuperação e geração.
- **Causa:** o planner propagou a sigla `RAG` para um segundo objetivo que já continha predicado e objetos suficientes; depois o novo guard de preservação de acrônimo fez corretamente o retrieval respeitar essa âncora indevida.
- **Correção obrigatória:** herança de entidade/âncora só deve ocorrer em fragmentos interrogativos semanticamente dependentes, como atributos que perderam a entidade compartilhada; objetivos que já possuem conteúdo temático suficiente não recebem acrônimo/tópico do vizinho.
- **Regra anti-regressão:** não confundir consistência de âncora com propagação global de tópico. Em perguntas multipartes, cada objetivo autossuficiente preserva sua própria intenção.

### 10.69 Heurístico de objetivo autossuficiente contou preâmbulo como tópico e regrediu herança Atlas-77
- **Falha observada:** ao impedir herança indevida de `RAG`, o caso herdado `Com base apenas neste contexto, qual é a versão e o responsável do Atlas-77?` deixou de propagar `Atlas-77` ao objetivo `versão`; palavras do preâmbulo fizeram o fragmento parecer autossuficiente.
- **Causa:** a contagem de conteúdo temático percorreu o objetivo inteiro, incluindo instruções/preâmbulos anteriores ao núcleo interrogativo.
- **Correção obrigatória:** determinar autossuficiência somente a partir do núcleo iniciado pelo primeiro marcador interrogativo (`qual`, `quem`, `por que`, etc.); preâmbulos de fonte, condição ou escopo não contam como objeto temático.
- **Regra anti-regressão:** toda correção de planner precisa passar simultaneamente casos de tópico independente e herança tardia de entidade; não otimizar um padrão quebrando o outro.

### 10.70 Erro de extensão de teste: resultado de fato foi usado antes da declaração
- **Falha observada:** ao ampliar `nd_memory_test.c` para validar fatos estruturados antes/depois de reload, `NDMemoryFactResult fr` foi inserido depois do primeiro uso e a compilação `-Werror` bloqueou o teste.
- **Causa:** patch textual em duas regiões do teste alterou a ordem de statements sem revisar o escopo completo da função.
- **Correção obrigatória:** declarar todos os objetos de resultado no bloco inicial da função antes dos primeiros usos e recompilar o teste sob os mesmos warnings.
- **Regra anti-regressão:** patches de teste também passam por compilação canônica; falha no teste não deve ser confundida com falha do runtime, mas deve ser corrigida antes de qualquer conclusão funcional.

### 10.71 Teste de persistência consultou fato antes de criá-lo
- **Falha observada:** `nd_memory_test` reportou duas falhas embora o probe externo mostrasse `LiDAR` e `Renata` corretamente antes/depois do reload. A inspeção revelou que as duas consultas estruturadas haviam sido inseridas antes do comando que memoriza Aurora-3.
- **Causa:** substituição textual atingiu o primeiro bloco compatível em vez do bloco pós-reload pretendido.
- **Correção obrigatória:** manter asserções de fatos imediatamente após a criação e repetir as mesmas asserções explicitamente após `nd_memory_load`.
- **Regra anti-regressão:** ao estender testes stateful, revisar a linha do tempo completa `setup -> ação -> assert -> persist -> reload -> assert`; correspondência textual de patch não substitui revisão de estado.

### 10.72 Predicado sem entidade foi confundido com tópico autossuficiente e regrediu Atlas-900
- **Falha observada:** `Qual é o identificador atual de Atlas-900 e quando será lançado?` cobriu o identificador, mas o objetivo `quando será lançado?` perdeu `Atlas-900` e caiu para conhecimento genérico sobre incerteza.
- **Causa:** o heurístico de autossuficiência aceitou dois termos (`será`, `lançado`) como densidade temática suficiente, embora o fragmento continue semanticamente dependente da entidade do objetivo anterior.
- **Correção obrigatória:** exigir densidade temática maior para bloquear herança; fragmentos curtos de atributo/predicado (`quando será lançado`, `qual versão`, `quem responde`) continuam recebendo a entidade compartilhada.
- **Regra anti-regressão:** Live QA de entidades estruturadas multipartes é gate obrigatório de qualquer mudança no planner; predicado sem sujeito explícito não deve ser tratado como novo tópico por contagem rasa.

### 10.73 Validação manual adivinhou nome de verificador inexistente
- **Falha observada:** após os testes v0.6.2 e Live QA passarem, uma sequência manual tentou executar `tests/verify_knowledge_runtime.py`, arquivo que não existe na árvore canônica, encerrando o shell com código 2.
- **Causa:** o nome do gate foi reconstruído por memória em vez de ser enumerado a partir dos scripts/testes reais.
- **Correção obrigatória:** listar os verificadores existentes ou consumir `scripts/verify.sh` como fonte de verdade antes de montar sequências ad-hoc.
- **Regra anti-regressão:** nomes de testes, scripts, enums e caminhos nunca são adivinhados; devem ser lidos da árvore atual.

### 10.74 Manifest e arquitetura divergiram na string canônica do orchestrator v0.6.2
- **Falha observada:** `verify_documentation_consistency.py` rejeitou a candidata porque `PROJECT_MANIFEST.json` já continha a nova ordem com histórico bounded, memória estruturada e preservação de acrônimos, mas `docs/ARCHITECTURE.md` apenas descrevia as mudanças em prosa e não continha a mesma cadeia canônica.
- **Causa:** atualização semântica foi feita nos dois lugares, porém o gate exige também uma representação literal única para evitar duas ordens concorrentes.
- **Correção obrigatória:** publicar em `ARCHITECTURE.md` a string exata do campo `architecture.orchestrator` do manifest e manter o gate de igualdade.
- **Regra anti-regressão:** descrições explicativas podem variar, mas a ordem canônica machine-readable/legível deve existir literalmente em todas as autoridades exigidas pelo gate.

### 10.75 Intenção conversacional por papel não generalizou além das saudações testadas
- **Falha observada:** `Olá! Qual é o seu papel neste dispositivo?` caiu em `uncertain`, apesar de a release conhecer o papel e os limites do NeuralDesk.
- **Causa:** a rota conversacional reconhecia padrões muito literais e não possuía intenção explícita `capabilities/role` separada da saudação.
- **Regra anti-regressão:** capacidades conversacionais determinísticas devem ser reconhecidas por intenção e anchors semânticos auditáveis, não por uma única frase Golden. Uma formulação nova de `o que você faz / qual seu papel / o que consegue fazer` deve manter a mesma fronteira de verdade.

### 10.76 Cobertura de goals não garantiu resposta à intenção: inferência duplicou conteúdo de rede neural
- **Falha observada:** `Quando eu digo inferência de uma rede neural, o que isso significa?` produziu duas cópias da definição de rede neural; o turno seguinte marcou `2/2` goals mas não respondeu diretamente se os pesos continuam sendo treinados.
- **Causa:** o planner superdecompôs a pergunta e a composição considerou cada fragmento coberto mesmo quando as respostas não satisfaziam o tipo semântico solicitado; não havia deduplicação final.
- **Regra anti-regressão:** decomposição não pode duplicar respostas idênticas, e `covered_goals` só deve ser interpretado como cobertura estrutural, nunca como prova de satisfação semântica. Perguntas definicionais de um único conceito devem permanecer um goal quando possível.

### 10.77 Grounding de responsabilidade falhou com modificador nominal
- **Falha observada:** no contexto `A engenheira responsável é Bianca`, a pergunta por responsável do Delta-8 foi recusada embora a evidência estivesse explícita.
- **Causa:** a extração/normalização de owner estava ligada a formas mais estreitas de `responsável`, sem cobrir modificadores nominais antes da relação.
- **Regra anti-regressão:** relações estruturadas devem reconhecer variantes conservadoras como `o responsável é`, `a responsável é`, `a engenheira responsável é`, `o técnico responsável é`, sem relaxar anchors de entidade.

### 10.78 Conflito de memória não foi fail-closed no caminho end-to-end
- **Falha observada:** após memorizar `Nimbus-4 ... coordenado por Paulo` e depois `Nimbus-4 é coordenado por Carla`, `Quem coordena ... agora?` respondeu Paulo.
- **Causa:** o índice estruturado detectava/representava fatos, mas a rota de fallback por evidência textual ainda podia selecionar uma nota antiga e contornar a política de conflito.
- **Regra anti-regressão:** se a mesma entidade/relação tiver valores conflitantes e não existir uma operação explícita de substituição/versionamento, nenhuma rota textual pode escolher um dos valores. O assistant deve declarar conflito/insuficiência. Atualização deve ser um comando explícito diferente de simples `Lembre que`.

### 10.79 Preservação de acrônimo RAG ainda não cobriu intenção `sigla ... quer dizer`
- **Falha observada:** `Em sistemas de IA, o que a sigla RAG quer dizer?` retornou `uncertain`, enquanto formulações já testadas de RAG passavam.
- **Causa:** o guard de acrônimo preservava token, mas a recuperação fallback e o planner ainda dependiam de formas de pergunta próximas aos templates existentes.
- **Regra anti-regressão:** presença de acrônimo explícito deve preservar o token e permitir recuperar sua definição canônica em formas `o que é`, `o que significa`, `sigla X`, `X quer dizer`, sem aceitar classes que não preservem o mesmo acrônimo.

### 10.80 Comparação técnica e quantificador universal foram tratados por regras genéricas erradas
- **Falha observada:** `quantização é a mesma coisa que KV cache?` respondeu apenas KV cache; `quantização mais agressiva sempre melhora a qualidade?` caiu numa resposta genérica sobre nenhuma arquitetura ser sempre melhor.
- **Causa:** não havia intenção de contraste `X é o mesmo que Y`, e o guard de afirmações universais usava uma resposta canned de arquitetura sem exigir que o tópico fosse arquitetura.
- **Regra anti-regressão:** comparações devem preservar os dois anchors e cobrir ambos; quantificadores como `sempre/nunca` só podem ativar uma regra cuja resposta permaneça no mesmo tópico. Guards epistemológicos devem ser topic-preserving.

### 10.81 Não-entailment de follow-up ficou estreito demais ao tipo `método alternativo`
- **Falha observada:** após `otimização de rotas de helicóptero -> maior segurança e redução de custo`, `Isso prova que toda rota não otimizada é necessariamente insegura?` apenas repetiu a evidência anterior.
- **Causa:** a regra de não-entailment foi implementada para padrões específicos do caso científico anterior, não para quantificadores universais e negações em geral.
- **Regra anti-regressão:** follow-ups com `isso prova/implica/significa` + quantificadores absolutos (`todo`, `qualquer`, `sempre`, `necessariamente`, `nenhum`) devem exigir evidência que sustente a implicação. Ausência dessa evidência deve gerar uma resposta conservadora de não-entailment.

### 10.82 Pergunta temporal/evento atual foi aceita por candidato do tipo errado
- **Falha observada:** `Quem ganhou a Copa do Brasil de 2026?` respondeu `A capital de Brasil é Brasília` com confidence 0.809855.
- **Causa:** overlap lexical `Brasil` permitiu que um candidato de `capital` fosse aceito para uma intenção `winner/event`, sem validação de answer type nem validade temporal.
- **Regra anti-regressão:** candidatos factuais devem ser compatíveis com o tipo de pergunta (`quem/onde/quando/capital/vencedor/...`). Consultas contemporâneas/eventos datados sem evidência local temporalmente válida devem falhar fechado em vez de usar um fato estático lexicalmente próximo.

### 10.83 Intenção de resumo multi-turn ficou acoplada à frase Golden
- **Falha observada:** `Resuma os principais assuntos dos nossos oito turnos mais recentes.` caiu em `uncertain`, apesar de `Resuma nossa conversa até aqui em duas frases.` passar.
- **Causa:** o detector de resumo era literal demais e não tratava variantes de `resumir/sintetizar`, `últimos/recentes N turnos`, `principais assuntos`.
- **Regra anti-regressão:** resumo bounded deve ser reconhecido por intenção estruturada e respeitar o limite máximo do histórico; diferentes formulações não podem depender de uma única frase canônica.

### 10.84 Confidence do assistant saiu do domínio probabilístico documentado
- **Falha observada:** respostas compostas/contextuais emitiram `confidence=8.750000` e `confidence=2.750000`.
- **Causa:** scores internos não normalizados foram propagados para `NDAnswerMeta.confidence`, misturando score de ranking com confiança pública.
- **Regra anti-regressão:** `NDAnswerMeta.confidence` e `margin` públicos devem permanecer finitos em `[0,1]`. Scores internos podem ter outra escala, mas precisam de campos internos distintos ou normalização/clamp explicitamente testado.

### 10.85 Limite generativo continua válido e não deve ser mascarado por respostas canned
- **Observação:** `Escreva quatro versos originais...` falhou fechado, como esperado para a arquitetura atual sem decoder autoregressivo.
- **Regra anti-regressão:** não transformar ausência de geração livre em um conjunto de templates que finja capacidade generativa. Essa limitação só será removida quando existir um backbone generativo real, treinado e avaliado.

### 10.86 Patch de build assumiu adjacência textual inexistente no CMake
- **Falha observada:** ao integrar `nd_robust_intent_v063_test`, o patch procurou `add_executable(...)` imediatamente seguido de `target_link_libraries(...)`, mas o CMake canônico possui `target_compile_options(...)` entre essas linhas.
- **Causa:** a alteração foi ancorada numa forma textual reconstruída, não no bloco real lido integralmente.
- **Regra anti-regressão:** mudanças em build manifests devem localizar e revisar o bloco canônico completo antes de editar. Não remover nem contornar `target_compile_options`; novos testes precisam herdar os mesmos warnings e sanitizers dos testes existentes.

### 10.87 Ponte discursiva por adjacência não bastou para owner contextual com modificador
- **Falha observada:** após a primeira implementação da ponte discursiva, o holdout v0.6.3 ainda recusou `Bianca` em `A engenheira responsável é Bianca`, embora todos os demais casos novos tenham passado.
- **Causa ainda a verificar:** a falha pode estar antes da seleção de evidência (decomposição/herança de entidade), na classificação relacional da frase ou na extração do valor; a simples adjacência não autoriza adivinhar qual etapa falhou.
- **Regra anti-regressão:** quando uma correção parcial não resolve o caso, instrumentar planner, relation e context synthesis separadamente antes do próximo patch. Não ampliar heurísticas sem localizar o estágio exato da recusa.

### 10.88 Conflict barrier confundiu fatos compatíveis por extração de valor ampla
- **Falha observada:** o gate herdado `memory-attribute` passou a declarar conflito para Solis-9 e deixou de responder `sódio`.
- **Causa ainda a verificar:** o novo barrier agora expõe qualquer divergência entre valores derivados para a mesma relação; se a extração de uma das entradas inclui palavras adicionais ou uma forma semanticamente equivalente, a política de conflito pode disparar por diferença textual que não representa conflito factual real.
- **Regra anti-regressão:** conflito deve comparar valores canônicos da relação, não spans textualizados incompatíveis por erro de parsing. Antes de relaxar o barrier, inspecionar os fatos derivados e corrigir a normalização/extrator.

### 10.89 Ponte discursiva single-goal ampliou evidência, mas pointer aceitou span da entidade como valor de owner
- **Falha observada:** no caso herdado Atlas-77, o segundo objetivo deixou de falhar fechado e respondeu `O Atlas-77` como responsável, elevando cobertura incorretamente para 2/2.
- **Causa:** a ponte discursiva permitiu uma sentença adjacente/relacionada, mas a validação final do pointer não confirmou que o span extraído é compatível com o tipo de relação solicitado.
- **Regra anti-regressão:** discourse bridging só decide qual sentença pode fornecer evidência; ele não autoriza qualquer span neural. O valor direto ainda deve passar por answer-type/relation-value validation. Para owner, um span que é a própria entidade estruturada não pode ser aceito como pessoa/responsável.

### 10.90 Helper novo em `nd_context_synth.c` foi inserido antes da declaração da dependência
- **Falha observada:** após endurecer a ponte discursiva, a build `-Werror` falhou porque `sentence_is_absence_statement()` chamou `contains_ci_n()` antes de qualquer declaração visível; depois, a definição `static` de `contains_ci_n` entrou em conflito com a declaração implícita criada pelo compilador.
- **Causa:** a edição preservou a lógica pretendida, mas não respeitou a ordem/dependências reais das funções C no arquivo canônico.
- **Regra anti-regressão:** antes de inserir um helper que chama funções internas, verificar a ordem de declaração no arquivo completo. Corrigir com forward declaration tipada ou mover o helper para depois da dependência; nunca desligar `-Werror` nem aceitar declaração implícita.

### 10.91 Verificador Live QA foi chamado contra um diretório de build não canônico
- **Falha observada:** os testes C v0.6.3/v0.6.2/v0.6.1, memória e planner passaram em `build-v063`, mas `tests/verify_live_qa.py` abortou com `FileNotFoundError: ./build/ndassistant` antes de executar qualquer pergunta.
- **Causa:** o verificador tem contrato explícito com a build canônica `build/`; a validação ad hoc havia compilado a mesma árvore em `build-v063`.
- **Regra anti-regressão:** distinguir falha de harness de falha funcional. Verificadores que declaram um caminho de build canônico devem ser executados após produzir exatamente esse caminho; não adaptar o teste para apontar a um diretório conveniente apenas para fazê-lo passar.

### 10.92 Perda de workspace: árvore truncada não é fonte de verdade recuperável
- **Falha observada:** durante a evolução para v0.7, a candidata desapareceu e a cópia de trabalho v0.6.3 ficou reduzida a documentação/evidence, sem `core/`, `training/`, `scripts/`, Android e modelos.
- **Risco:** reconstruir centenas de arquivos pela memória da conversa poderia fabricar um estado que nunca existiu byte a byte e invalidar hashes, gates e lineage.
- **Regra permanente:** quando uma árvore perde partes estruturais, ela deve ser classificada como `TRUNCATED / NOT_A_RELEASE_SOURCE`; a recuperação parte do último ZIP integral verificável e reaplica somente mudanças cujo comportamento possa ser reprovado por testes atuais.
- **Aplicação nesta recuperação:** v0.6.2-alpha.1 reproduzível é a base física; as lições/auditorias v0.6.3 sobreviventes são apenas especificação de anti-regressão, nunca prova de código ausente.

### 10.93 Treino interrompido por perda de workspace não produz modelo promovível
- **Falha observada:** o treino do primeiro generative Micro iniciou, mas o diretório candidato desapareceu antes de um status terminal e antes de os assets finais serem congelados.
- **Regra permanente:** PID, log parcial, loss parcial ou existência temporária de arquivo não equivalem a treinamento concluído. Somente `status=0`, avaliação pós-treino, hashes canônicos e reprodução autorizam promoção.

### 10.94 Recuperação deve preservar baseline e ocorrer em nova árvore
- **Acerto obrigatório:** nunca modificar o ZIP/base íntegra durante recuperação. Criar uma candidata nova, registrar o rollback exato, executar precheck e só então reaplicar mudanças.
- **Gate recomendado:** o projeto recuperado deve conseguir reconstruir e verificar os assets herdados antes de aceitar novos modelos.

### 10.95 Recorrência recuperada: integração Semantic Core voltou a compactar controle de fluxo em C
- **Falha observada:** duas rotas novas do assistant foram escritas como `if (meta) ...; record_turn(...); return`, disparando `-Wmisleading-indentation` sob `-Werror`.
- **Regra permanente:** qualquer rota nova deve usar uma instrução por linha e blocos explícitos quando a leitura puder sugerir guarda inexistente. Nunca reduzir o rigor do compilador para aceitar a implementação.

### 10.96 Conflict barrier expôs sobreposição de padrões compatíveis da mesma relação
- **Falha observada:** `usa bateria de sódio` gerava dois fatos: `battery=sódio` pelo padrão específico e `battery=de sódio` pelo padrão amplo `usa bateria `; o novo barrier interpretou isso como conflito real.
- **Regra permanente:** antes de comparar fatos como conflitantes, padrões sobrepostos da mesma relação devem produzir valores canônicos equivalentes. Normalizar preposições estruturais (`de/da/do`) quando pertencem ao template, não ao valor.

### 10.97 Loss de validação menor não autoriza promoção de backbone generativo com texto incoerente
- **Falha observada:** o primeiro Micro decoder reduziu validation loss de ~90,57 para ~2,98 e exportou assets válidos, mas os probes greedy ainda produziram fragmentos linguisticamente ruins.
- **Regra permanente:** promoção generativa exige simultaneamente: treino terminal, validação finita/melhor, formato reproduzível, runtime parity e probes comportamentais que demonstrem texto decodificável/coerente. Loss sozinha nunca é suficiente.
- **Ação:** os assets do primeiro run são experimentais e serão sobrescritos somente por um treino que passe o gate comportamental.

### 10.98 Runtime generativo repetiu compactação C incompatível com o contrato `-Werror`
- **Falha observada:** o primeiro loader `NDGM` colocou `if/goto/return` na mesma linha e foi bloqueado por `-Wmisleading-indentation`.
- **Regra permanente:** arquivos novos de runtime neural devem ser escritos para legibilidade auditável desde a primeira versão; não usar múltiplos controles de fluxo na mesma linha, mesmo quando semanticamente válidos em C.

### 10.99 Refatoração de candidatos removeu acidentalmente o texto fail-closed
- **Falha observada:** após integrar o reranker relativo, `Noveria-999` manteve `ND_ANSWER_UNCERTAIN`, mas o buffer de resposta ficou vazio porque o bloco que emitia a mensagem padrão foi removido junto com o fluxo antigo.
- **Regra permanente:** toda saída `ND_ANSWER_UNCERTAIN` deve ter texto explícito não vazio; gates negativos devem validar source **e** conteúdo. Refatorar seleção de candidatos não pode apagar o contrato de UX/safety.

### 10.100 Answer-type validation precisa bloquear fallback para valor de outra relação
- **Falha observada:** em contexto Arara-9, perguntas de `massa` e `data` não tiveram extração semântica direta; o pointer reutilizou o código `AR9-X`, produzindo valor do tipo errado.
- **Regra permanente:** quando a pergunta declara um tipo de resposta (pessoa/código/massa/data/material), um fallback só pode ser aceito se o valor tiver forma/relação compatível. Ausência explícita do tipo solicitado encerra a rota como incerteza.

### 10.101 Scores internos não podem vazar como `confidence` pública fora de [0,1]
- **Falha observada:** `cr.best_score` do grounding chegou a 5,25/5,50 e foi copiado diretamente para `NDAnswerMeta.confidence`.
- **Regra permanente:** scores de ranking permanecem internos; toda confidence/margin pública deve ser finita e normalizada/clampada em [0,1].

### 10.102 Condição de ausência sem parênteses explícitos foi bloqueada por `-Wparentheses`
- **Falha observada:** a regra `não informa` combinou `||` e `&&` confiando na precedência da linguagem C.
- **Regra permanente:** regras semânticas/safety com múltiplos operadores lógicos devem usar agrupamento explícito, mesmo quando a precedência padrão produziria o mesmo resultado.

### 10.103 Upweight de SFT foi neutralizado por deduplicação posterior
- **Falha observada:** `authored * 12` pretendia aumentar a frequência das instruções de alta qualidade, mas a deduplicação global no final de `generative_data.py` removeu todas as repetições.
- **Regra permanente:** distinguir deduplicação de conteúdo de **peso de amostragem**. Exemplos únicos devem ser deduplicados antes; pesos/cópias intencionais para currículo entram depois ou por sampler explícito.

### 10.104 Inicialização padrão de embedding tied produziu logits iniciais excessivos no Micro decoder
- **Falha observada:** `nn.Embedding` padrão iniciou com escala muito maior que projeções lineares; como o embedding também é a matriz de saída, validation loss inicial ficou ~90.
- **Regra permanente:** backbones causais com embedding/output tied devem usar inicialização explícita, determinística e compatível entre embedding/projeções (nesta linha, normal std=0,02), mantendo RMSNorm em 1.

### 10.105 — Repetir SFT antes de split por hash pode mandar todas as cópias para validation
- **Falha observada:** no terceiro treino generativo, o exemplo `Crie uma analogia curta para quantização.` foi repetido 32 vezes, mas as 32 cópias tinham o mesmo hash e foram todas para validation (`hash % 10 == 0`). O treino recebeu zero cópias dessa instrução, enquanto KV cache caiu no train e foi aprendido.
- **Causa:** currículo/oversampling foi aplicado antes do split determinístico por conteúdo.
- **Correção obrigatória:** splitar o corpus-base único primeiro; somente depois anexar/oversamplear as amostras SFT autoradas ao **train**. Validation deve permanecer independente e sem duplicatas de currículo.
- **Regra permanente:** oversampling nunca participa da decisão train/validation; a unidade de split é o exemplo único antes de qualquer peso/cópia.

### 10.106 — Probe generativo idêntico ao SFT mede memorização, não generalização mínima
- **Falha de desenho:** os primeiros coherence probes reutilizavam literalmente prompts presentes no SFT autorado.
- **Risco:** um modelo pode passar copiando a continuação de um prompt conhecido sem responder a uma paráfrase.
- **Correção obrigatória:** a promoção do backbone exige probes de **paráfrase holdout**, ausentes do treino, além de queda de validation loss e integridade dos formatos FP32/Q8/Q4.
- **Regra permanente:** prompts de promoção generativa não podem ser strings idênticas a prompts SFT do treino.

### 10.107 — Trainer que lê documentação mutável não é reproduzível após doc-sync
- **Risco encontrado:** o corpus generativo incluía parágrafos de `docs/*.md` diretamente a cada execução. Atualizar documentação depois do treino alteraria os tokens e impediria reconstruir byte-idêntico o modelo promovido.
- **Correção obrigatória:** materializar o corpus-base e o SFT autorado como JSONL canônicos, registrar SHA-256/proveniência e fazer o trainer consumir apenas esses bytes congelados.
- **Regra permanente:** documentação pode originar materialização, mas pesos promovidos nunca dependem de documentos mutáveis lidos dinamicamente durante rebuild/release.

### 10.108 — Treino rejeitado não pode sobrescrever assets canônicos antes do gate
- **Falha encontrada:** `train_generative_micro.py` exportava FP32/Q8/Q4 para `models/` antes de avaliar os coherence probes. Uma execução rejeitada podia deixar pesos novos em disco enquanto `TRAINING_REPORT.json` ainda descrevia uma execução anterior.
- **Impacto:** árvore internamente incoerente (`asset bytes != report`) mesmo quando o trainer terminava com status de rejeição.
- **Correção obrigatória:** exportar para staging no mesmo filesystem, avaliar todos os gates usando os bytes staged e somente então promover com replace atômico; o relatório é escrito por último. Em rejeição, staging é removido e os assets canônicos permanecem inalterados.
- **Regra permanente:** nenhum trainer pode modificar um asset promovido antes de completar todos os gates de qualidade, integridade e proveniência.

### 10.109 — Asset generativo e relatório divergentes invalidam ambos como promovidos
- **Falha observada:** após múltiplas tentativas de treino/recovery, `evaluation/generative_micro/TRAINING_REPORT.json` descrevia o Micro antigo de 430.944 parâmetros enquanto `models/neuraldesk-generative-micro-v0.7-*.ndgm` continham bytes de uma tentativa posterior rejeitada de 1.197.696 parâmetros.
- **Impacto:** nenhum dos dois conjuntos pode servir como fonte de verdade; arquivo existente não equivale a asset promovido.
- **Regra permanente:** antes de cada treino, verificar `report ↔ asset size ↔ SHA ↔ architecture`. Divergência marca o backbone como `UNPROMOTED_STALE` e impede uso pelo runtime/release até um novo treino terminal escrever assets e relatório atomicamente na mesma promoção.

### 10.110 — Pré-treino causal misturado não basta para instruction following em Micro decoder
- **Falha observada:** 1,197,696 parâmetros, 1.400 steps e validation loss 6,269→1,575 ainda produziram texto incoerente em 3/4 probes de paráfrase.
- **Causa arquitetural:** o treino causal sobre fluxo misto ensina distribuição de texto, mas não concentra gradiente suficiente na continuação da resposta de instruções, especialmente em um modelo Micro.
- **Correção obrigatória:** separar `pretraining` causal base de uma fase `SFT` onde a loss é mascarada para os tokens da resposta/EOS, usar exemplos autorados únicos e diversos, manter holdouts de paráfrase fora do SFT e continuar exigindo comportamento + loss + integridade antes da promoção.
- **Regra permanente:** nunca reduzir coherence gates para salvar um modelo pequeno; melhorar objetivo/dados/arquitetura.

### 10.111 — Recovery gate v0.6.3 separou falso positivo de teste de três lacunas reais
- **Resultado observado:** o gate reconstruído de 11 propriedades encontrou quatro falhas: (1) o teste de owner rejeitou `Delta-8 usa` mesmo quando isso aparecia somente na evidência e a resposta direta correta era Bianca; (2) `O que RAG quer dizer em sistemas de IA?` caiu em incerteza; (3) `Quantização e KV cache economizam a mesma coisa?` cobriu apenas KV cache; (4) `Isso prova que qualquer outra técnica...` não acionou non-entailment.
- **Classificação:** (1) é bug do teste, pois misturou valor direto com evidence; (2)-(4) são propriedades v0.6.3 não totalmente recuperadas na árvore reconstruída.
- **Regra permanente:** testes de answer-type devem inspecionar a resposta direta separadamente da evidence; recovery gates devem preservar variações linguísticas documentadas (`quer dizer`, `mesma coisa`, `isso prova`) sem codificar entidades específicas.

### 10.112 — Response-only SFT puro causou catastrophic forgetting no Micro decoder
- **Falha observada:** após pré-treino com validation loss 1,643, 1.600 steps de SFT response-only reduziram a SFT loss praticamente a zero, mas elevaram a validation loss base para 8,577 e apenas 2/6 probes passaram de forma coerente.
- **Conclusão:** memorizar 48 instruções não equivale a melhorar linguagem; o modelo pequeno esqueceu distribuição base enquanto superajustava o currículo.
- **Correção obrigatória:** durante SFT manter replay causal/base com peso explícito e LR menor; ampliar o corpus humano permitido com dados já auditados pelo projeto, preservando validation independente.
- **Regra permanente:** promoção exige simultaneamente retenção de linguagem base, SFT generalizável e probes holdout. `SFT loss≈0` isoladamente é sinal de overfit, não de inteligência.

### 10.113 — Corpus histórico verificável pode ser reutilizado como fonte, não como código canônico
- **Fonte recuperada:** o ZIP histórico v0.6 contém `pira_human_records.jsonl` SHA-256 `430fb2765864f5042978acfb74e455872352158901b61782edea9e7c6bf1d0f7`, com 1.281 Q/A humanas Pirá 2.0 CC BY 4.0: 1.141 train e 140 validation; test split não usado.
- **Regra permanente:** é permitido reutilizar esses bytes como corpus/proveniência porque a origem/licença/hash são verificáveis, mas o código/runtime histórico daquele ZIP continua não-canônico para a linha recuperada.
- **Treino generativo:** train e validation devem respeitar o split original; validation nunca entra no treino/SFT/BPE de promoção.

### 10.114 — Gate do runtime generativo deve acompanhar a arquitetura promovida e validar limites de decodificação
- **Falha encontrada durante a recuperação:** `tests/nd_generative_test.c` ainda exigia a arquitetura experimental rejeitada `dim=128 / q_heads=8 / ffn=384`, enquanto o trainer atual de promoção usa `dim=160 / q_heads=10 / ffn=448`.
- **Risco adicional:** a validação UTF-8 antiga avançava os bytes de continuação sem primeiro rejeitar `NUL`, podendo inspecionar além do final lógico da string em uma sequência truncada.
- **Correção:** o gate C agora exige a arquitetura v2 atual, parâmetros >=1,7M e rejeita sequência UTF-8 truncada antes de avançar; um teste separado do assistant exige que apenas intenção criativa alcance `ND_ANSWER_GENERATIVE`, enquanto factual desconhecido/temporal permanece fail-closed.
- **Regra permanente:** toda mudança arquitetural promovível deve atualizar conjuntamente trainer, formato, loader e teste de header; segurança de parsing/decoding não pode depender de o modelo sempre produzir bytes válidos.

### 10.115 — Replay preservou linguagem, mas SFT com apenas 48 instruções não ensinou instruction-following suficiente
- **Treino observado:** Micro v2 com 1.742.880 parâmetros, 1.400 steps causais + 900 mixed-SFT (675 supervisionados / 225 replay). Validation passou de `6,2723` para `2,2556` no pré-treino e terminou em `2,3517`, portanto o catastrophic forgetting da tentativa anterior foi controlado. A SFT loss caiu de `6,2690` para `0,00285`.
- **Falha de promoção:** apenas 1/6 probes holdout foi coerente; quantização, KV cache, pesos em inferência, comparação quantização/KV e evento atual continuaram linguisticamente incoerentes. O trainer terminou `status=1` e os assets staged não foram promovidos.
- **Causa:** as 1.141 Q/A humanas Pirá de treino participavam apenas como fluxo causal. A fase response-only supervisionava somente 48 instruções autoradas, quantidade insuficiente para ensinar a transformação geral `Pergunta -> Resposta` ao decoder Micro.
- **Correção obrigatória:** converter também o split Pirá **train** em exemplos SFT response-only e misturá-los com as 48 instruções autoradas, mantendo replay causal; o split Pirá validation (140) continua estritamente fora de BPE/SFT/treino. Não reduzir os 6 probes de promoção.
- **Regra permanente:** dados em formato Q/A só ensinam instruction-following de forma direta quando o objetivo de treino supervisiona a resposta; presença causal do texto, mesmo em grande quantidade relativa ao modelo, não substitui SFT.

### 10.118 — Auditoria histórica deve comparar capacidades por evidência, não por número de versão
**Ocorrência (2026-08-24):** a linha Sovereign LocalNet v0.7 é superior em Semantic Core/reranking/memória/grounding/backbone generativo, mas releases Mobile Runtime v0.46–v0.63 preservam mecânicas executáveis mais avançadas de serving/inferência móvel (paged KV/COW, prefix reuse, speculative verification, compiler/quantization quality floors, weight streaming/LRU, observability/recovery, hardware routing, native/JNI/DEX toolchain gates e curated corpus/Golden) que não estavam integralmente reintegradas.
**Regra:** nunca escolher uma versão inteira por ser numericamente maior. Construir uma matriz `capacidade -> melhor implementação comprovada -> truth boundary -> owner atual`, portar somente mecanismos superiores para o owner canônico atual e exigir não-regressão de todas as capacidades já superiores na linha destino. Implementação histórica em JS não deve criar um segundo runtime paralelo quando o owner corrente é C99/Android; reexpressar o mecanismo first-party no runtime atual.

### 10.119 — Assets generativos rejeitados não podem virar base de otimização ou evidence de qualidade
**Ocorrência (2026-08-24):** os três `.ndgm` presentes na árvore recuperada carregavam e executavam, mas o gate `nd_generative_quality_test` falhou 18/18 probes (6 probes x 3 formatos). Não existe `TRAINING_REPORT.json` promovido para esses bytes.
**Regra:** tratar os `.ndgm` atuais como candidatos rejeitados/stale até novo treino passar simultaneamente corpus/provenance, validation, probes, FP32/Q8/Q4 runtime quality, corruption e release gates. Otimizações de runtime podem ser desenvolvidas estruturalmente contra o formato, mas nenhuma metadata/release pode declarar o backbone aprovado antes dos gates de qualidade.

### 10.120 — Gate de arquitetura promovida não pode ser confundido com gate de mecânica do runtime
**Falha observada:** após portar mmap + paged KV + prefix reuse + speculative verification para `nd_generative.c`, o teste `nd_generative_test` foi executado contra os assets `.ndgm` stale/rejeitados existentes. O teste recusou corretamente os headers `dim=128/q=8/ffn=384`, pois o contrato da próxima arquitetura promovível exige `dim=160/q=10/ffn=448`.

**Causa:** o verificador de modelo promovido e a validação das novas mecânicas de execução têm responsabilidades diferentes. Reutilizar o primeiro para provar o segundo transforma uma rejeição esperada de pesos stale em falso diagnóstico de regressão do runtime.

**Correção/regra permanente:** manter o gate de arquitetura/qualidade fail-closed e criar testes separados de mecânica que aceitem qualquer NDGM estruturalmente válido apenas como fixture não-promovível. Paged KV, COW, prefix reuse, mmap e speculative target-parity só recebem PASS por propriedades de execução; isso nunca promove os pesos usados como fixture. Os assets stale continuam proibidos para release/quality evidence.

### 10.121 — Overload Kotlin legado deve acompanhar a expansão da assinatura JNI
**Falha observada:** ao ampliar o gate host Kotlin para validar hardware/profile routing, a compilação encontrou que o overload legado `NativeEngine.load(...)` ainda encaminhava somente seis caminhos para `nativeLoad`, enquanto a assinatura v0.7 exige também `semanticRankerPath`, `generativePath` e `profile`.

**Causa:** a assinatura JNI principal evoluiu, mas o adapter de compatibilidade Kotlin não foi atualizado conjuntamente. O erro permaneceu oculto enquanto determinadas compilações não percorriam a superfície completa.

**Correção/regra permanente:** toda expansão de assinatura JNI deve atualizar no mesmo delta: declaração `external`, todos os overloads/adapters Kotlin, MainActivity/callers, host compile gate e JNI syntax gate. Compatibilidade legada deve fornecer valores fail-closed explícitos (`""`/perfil canônico) em vez de depender de argumentos ausentes.

### 10.122 — Batches SFT de fontes diferentes precisam de shape comum antes de concatenação
**Falha observada:** a tentativa balanceada `v07_gen7` concluiu os 1.400 steps de pré-treino (`loss 6,280409 -> 1,431509`) e falhou ao iniciar mixed-SFT com `RuntimeError: Sizes of tensors must match ... Expected size 126 but got size 94`. Os batches authored e Pirá foram tokenizados/padded independentemente e depois concatenados em `dim=0`.

**Causa:** cada helper produziu largura dinâmica baseada no maior exemplo daquele sub-batch; concatenar duas fontes sem repadding para a largura máxima comum viola o contrato tensorial.

**Correção/regra permanente:** mixed-source SFT deve construir/repaddar ambos os sub-batches para um comprimento comum bounded pelo contexto antes de `cat`, ou montar o batch conjunto antes do padding. O erro não autoriza reduzir contexto, remover Pirá, alterar os 6 probes ou promover os pesos anteriores. A próxima tentativa deve repetir do zero (ou de checkpoint explicitamente versionado, se houver) e somente promover por todos os gates atuais.

### 10.123 — Separação por arquivo não basta: fontes derivadas podem reintroduzir perguntas do validation no treino
**Falha observada:** ao recuperar a governança v0.63 em um Golden v0.7, o verificador por pergunta canônica encontrou duas perguntas Pirá-human-validation presentes também em fontes treináveis do corpus generativo. A origem é a composição aditiva: o corpus-base inclui registros NDOS/Pirá selecionados independentemente, enquanto `pira_validation` era considerado separado apenas do arquivo `pira_train`.

**Causa:** o gate anterior comprovava separação entre arquivos materializados principais, mas não construía um índice global de identidade de pergunta através de **todas** as fontes derivadas. Um registro de avaliação pode reaparecer por outra rota/proveniência e contaminar o treino mesmo sem duplicata byte-idêntica de linha JSONL.

**Correção/regra permanente:** construir primeiro o conjunto canônico de perguntas/IDs reservados a validation/Golden e excluí-lo de todas as fontes `TRAINING_ELIGIBLE`, inclusive corpus-base, NDOS-derived, SFT e futuras misturas. A governança deve medir `globalQuestionCrossSplitLeakage=0`, não apenas exact-file overlap. Qualquer vazamento invalida o treino anterior para claims de generalização nesses itens e exige rematerialização/retraining antes de promoção.

### 10.124 — Builders derivados não devem duplicar contagens canônicas de corpus
**Falha observada:** após remover corretamente 4 linhas contaminadas do corpus-base (746 -> 742), `build_curated_governance_v07.py` falhou porque repetia a antiga asserção literal `len(base)==746`.

**Causa:** a contagem de uma fonte materializada foi duplicada em dois owners de build. O segundo script ficou stale assim que o owner canônico do corpus mudou por uma correção legítima de leakage.

**Correção/regra permanente:** builders/evaluators derivados devem ler `GENERATIVE_MICRO_V07_PROVENANCE.json` (ou authority equivalente) e verificar hashes/contagens contra ele, em vez de copiar números literais. Testes podem exigir invariantes de segurança (`leakage=0`, validation=140, SFT=48), mas counts derivados devem possuir uma única autoridade machine-readable.

### 10.125 — Perfil Q4 exige paridade comportamental própria; tamanho menor não autoriza promoção
**Achado:** o novo gate de paridade de primeiro token, executado apenas como diagnóstico contra os assets generativos stale/rejeitados, mediu FP32↔Q8 = `20/20 (100%)` e FP32↔Q4 = `11/20 (55%)`. O Q4 ficou abaixo do piso v0.7 de 75% e continua proibido como perfil Micro promovido.

**Regra permanente:** cada formato quantizado deve passar seus próprios gates de integridade, qualidade comportamental e paridade relativa ao FP32. Q8 exige top-1/first-token parity >=90%; Q4 >=75% nesta arquitetura Micro, além dos 6 probes comportamentais em cada formato. Footprint reduzido, load bem-sucedido ou velocidade nunca compensam uma regressão de qualidade abaixo do piso.

### 10.126 — Novo source do núcleo compartilhado precisa entrar no CMake host e Android no mesmo delta
**Falha encontrada por auditoria pré-build:** `nd_runtime_control.c` foi incorporado ao `neuraldesk_core` host e passou testes, enquanto o `android/app/src/main/cpp/CMakeLists.txt` ainda enumerava manualmente a lista antiga. Como o JNI passou a chamar o managed path que depende desse módulo, um link Android real falharia apesar do `verify_jni_host.sh` sintático passar.

**Correção/regra permanente:** toda adição/remoção de `core/src/*.c` compartilhado deve atualizar simultaneamente host CMake e Android CMake. Adicionar gate de consistência que compara a lista canônica de sources e falha antes de release quando um owner C compartilhado está ausente da build Android. Syntax-only JNI nunca substitui link coverage.

### 10.127 — Artefato histórico integral recuperado supera reconstrução parcial de conhecimento aberto
**Achado (auditoria profunda 2026-08-24):** a Library preserva o ZIP integral `neuraldesk-mobile-sovereign-localnet-v0.6.0-alpha.1.zip`. Seus bytes contêm `pira_human_records.jsonl` SHA-256 `430fb2765864f5042978acfb74e455872352158901b61782edea9e7c6bf1d0f7` com 1.281 Q/A humanas Pirá 2.0 CC BY 4.0 (1.141 train + 140 validation) e o shard histórico `.ndsh` de 2.799.672 bytes. A reconstrução posterior de 31 registros foi correta enquanto os bytes integrais estavam perdidos, mas deixou de ser a fonte mais completa depois da recuperação do artefato original.
**Regra permanente:** quando um artefato histórico integral, hashável e licenciado reaparece, ele pode substituir uma reconstrução parcial como **fonte de dados/proveniência**, nunca como código/runtime canônico automático. Reintegrar o conhecimento no formato/runtime atual e preservar separadamente holdouts de treino/model promotion; não declarar os registros validation como treino neural.

### 10.128 — Promotion/signing é um owner separado do trainer e está ausente na linha v0.7
**Achado:** Mobile Runtime v0.40 possuía quality-regression independente, revalidação de lineage/rights/runtime ABI e assinatura Ed25519 antes de promoção. A v0.7 possui gates no trainer e packaging hashado, mas não uma autoridade separada que reabra os assets e só então assine um manifesto de modelo promovido.
**Regra permanente:** trainer `PASS` não autoriza modelo. Implementar `model promotion gate` separado, que reabre bytes, executa avaliações independentes atuais (incluindo quantização/Golden), valida provenance e só então emite manifesto assinado Ed25519 com chave privada fora da árvore distribuída. Assinatura não ativa serving nem hardware.

### 10.129 — Safety de geração deve existir antes e depois do decoder, não apenas como fail-closed factual
**Achado:** v0.42 possuía suite first-party de prompt precheck e output postcheck com thresholds 100% BLOCK/ALLOW em suite bounded e zero output secreto. A v0.7 protege factualidade e current events, mas a rota criativa generativa ainda não possui owner safety pre/post equivalente.
**Regra permanente:** integrar safety bounded antes da geração criativa e inspeção da saída antes de retornar texto. A suite é evidence limitada (`universalSafetyClaim=false`), não prova universal. Prompt/output bloqueados devem ser auditáveis sem persistir conteúdo bruto.

### 10.130 — Runtime móvel síncrono perdeu streaming/cancellation/deadline do serving v0.46
**Achado:** v0.46 implementava token streaming real, chunked prefill, backpressure, cancellation/deadline e auditoria incremental; a v0.7 gera a resposta completa antes de retornar ao Kotlin.
**Regra permanente:** o decoder atual deve oferecer API streaming first-party com callback de delta UTF-8, checks de cancelamento durante prefill/decode, deadline bounded e chunked prefill cooperativo. A API antiga síncrona permanece como wrapper de compatibilidade. Streaming não pode alterar o texto final canônico.

### 10.131 — KV incremental precisa de oracle full-forward explícito
**Achado:** v0.41/v0.45 exigiam parity incremental↔full causal (<=1e-10 no modelo FP64 histórico). A v0.7 possui KV paginado e testes de speculative parity, mas não um oracle independente que recompute o prefixo inteiro e compare o próximo-token/logits ao caminho incremental.
**Regra permanente:** adicionar full-forward reference oracle para fixtures/promoted assets e exigir parity por formato dentro da tolerância definida. Otimização KV/prefix/speculative só é promovível se o oracle permanecer estável.

### 10.132 — Treino longo precisa checkpoint/resume versionado e integrity-bound
**Achado:** Mobile Runtime antigo possuía checkpoint de parâmetros + AdamW + step + hashes. O trainer PyTorch v0.7 reinicia do zero após falha/process loss e as tentativas 1.400+900 steps já demonstraram custo operacional relevante.
**Regra permanente:** salvar checkpoint externo/transitório por fase/step com model state, optimizer state, config, corpus/tokenizer hashes e SHA-256; resume só aceita checkpoint cuja arquitetura/dados/config correspondam exatamente. Checkpoint nunca é modelo promovido e não entra no ZIP final.

### 10.133 — Padrões V8 documentais só entram após prova no runtime atual
**Achado:** V8.20 documentou EMA/SWA/checkpoint averaging; V8.22 documentou RLVR, context funnel, cost-quality routing, kernel fusion e microagentes. Esses itens eram `DOCUMENTATION_ONLY / NOT_IMPLEMENTED`.
**Regra permanente:** não chamar esses padrões de funcionalidade histórica recuperada. Eles podem originar experimento first-party atual. SWA/EMA, por exemplo, só será adotado se um A/B determinístico contra a mesma trajetória melhorar validation/probes sem regressão; RLVR só onde a recompensa é verificável e possui anti-reward-hacking gate.

### 10.134 — Ranker amplo dual-encoder não pode ser promovido por loss de treino
- **Falha observada:** o experimento `dual_encoder_contrastive_full_pira_v2` convergiu para loss muito baixa no conjunto de treino, mas no holdout humano Pirá-validation atingiu apenas **49/129 top-1 (37,98%)** e **90/129 top-5 (69,77%)**; um caso crítico de KV-cache teve margem semântica de apenas ~0,0248.
- **Causa:** o dual encoder hashed separa query/candidate e funciona bem como árbitro pequeno, mas não modela interações finas suficientes para uma base heterogênea de 1.281 registros quando usado como ranker global.
- **Regra permanente:** nunca promover ranker por training loss; exigir holdout humano intocado e casos críticos. Para o Pirá completo, preferir **sparse top-N + cross-encoder/reranker de interação + answerability gate**, mantendo o shard completo desativado para resposta automática até o holdout provar ganho sem falsos positivos.
- **Estado:** experimento rejeitado; nenhum asset `full ranker` foi promovido para `models/`.

### 10.135 — Testes novos também obedecem ao padrão estrutural de `-Werror`
- **Falha observada:** a primeira versão de `nd_assistant_streaming_test.c` colocou `if (argc != 10) return 2;` e várias declarações na mesma linha; `-Wmisleading-indentation -Werror` bloqueou a compilação antes da execução funcional.
- **Regra permanente:** nenhum teste novo pode usar compactação multi-instrução que torne ownership/controle de fluxo ambíguo. Corrigir a estrutura do teste; nunca relaxar `-Werror` para validar uma funcionalidade nova.

### 10.136 — Gate de streaming não pode exigir promoção de pesos generativos rejeitados
- **Falha observada:** o teste inicial de integração do assistant exigia `ND_ANSWER_GENERATIVE` usando os `.ndgm` stale/rejeitados; esses pesos geraram menos que o mínimo útil e o assistant corretamente caiu para `ND_ANSWER_UNCERTAIN`, embora o decoder streaming direto já demonstrasse chunks reais/paridade/cancelamento.
- **Regra permanente:** separar **mecânica do runtime** de **qualidade/promoção dos pesos**. O gate de streaming do decoder deve provar emissão incremental, paridade e cancel/deadline com qualquer fixture estruturalmente válida; o gate do assistant só deve exigir rota criativa generativa depois que um modelo for independentemente promovido. Enquanto isso, provar que o wrapper de assistant transmite respostas não-generativas exatamente uma vez e preserva fail-closed.

### 10.137 — Workspace truncado nunca é continuidade válida; release nova deve rebasar do último ZIP integral verificável
**Falha observada:** durante a auditoria histórica profunda a árvore de trabalho v0.7 voltou a aparecer truncada, contendo apenas documentos/evidence reanexados, enquanto o código-fonte, Android, modelos, scripts e testes não estavam mais presentes naquele diretório.
**Causa operacional:** persistência transitória de workspace não é equivalente a artefato de release. Arquivos reanexados pelo chat podem recriar somente uma fração da árvore e preservar o nome do diretório, criando uma aparência falsa de continuidade.
**Correção/regra permanente:** antes de continuar uma candidata, exigir presença e consistência de `PROJECT_MANIFEST.json`, `core/`, `models/`, `training/`, `scripts/`, `tests/`, `android/` e gates. Se a árvore estiver truncada, nunca preencher arquivos ausentes por memória. Rebasear do último ZIP integral/reproduzível comprovável, reaplicar deltas a partir de evidence histórica e executar novamente todos os gates. A árvore truncada permanece apenas como fonte documental/evidence, nunca como baseline executável.

### 10.138 — Ports históricos também precisam obedecer à legibilidade estrutural exigida por `-Werror`
**Falha observada:** a primeira compilação dos novos owners `nd_text_utils.c` e `nd_rag.c` foi bloqueada por `-Wmisleading-indentation -Werror`, porque algumas instruções/loops haviam sido compactados na mesma linha. Nenhum teste funcional chegou a ser executado.
**Correção/regra permanente:** ports históricos e módulos novos devem manter uma instrução/decisão por bloco legível, com chaves e quebras explícitas onde o fluxo possa parecer ambíguo. Nunca afrouxar `-Werror`; o algoritmo pode ser preservado, mas a forma do código deve tornar ownership e controle de fluxo inequívocos.

### 10.139 — Melhorias semânticas não podem criar conflitos artificiais nem reduzir cobertura multipartes
**Falhas observadas:** após integrar o Semantic Core, o contrato v0.6.1 detectou (1) `Solis-9` como conflito porque dois patterns sobrepostos derivavam `battery=sódio` e `battery=de sódio` da mesma frase; (2) respostas diretas mais claras para RAG e quantização/KV passaram a reportar `goal_count=1`, regredindo contratos que exigem cobertura explícita de duas partes.
**Correção/regra permanente:** derivação estruturada deve evitar patterns genéricos que duplicam um pattern mais específico com preposição residual; fatos semanticamente equivalentes nunca viram conflito. Respostas semânticas diretas podem substituir decomposição interna, mas devem preservar a cardinalidade/coverage observável de perguntas multipartes e mencionar explicitamente cada eixo solicitado.

### 10.140 — Resposta semanticamente equivalente ainda pode perder uma garantia auditável do contrato
**Falha observada:** o novo texto geral de non-entailment dizia que uma conclusão universal exigia evidência adicional, mas deixou de conter a afirmação explícita `não prova` exigida pelo gate v0.6.2.
**Correção/regra permanente:** quando um contrato histórico usa uma formulação curta como garantia auditável de epistemic safety, uma resposta nova pode ser mais rica, mas deve preservar a afirmação explícita central (`a evidência observada não prova a conclusão universal`) para manter comportamento e auditabilidade.

### 10.141 — JNI streaming/RAG também deve manter ownership explícito sob `-Werror`
**Falha observada:** o primeiro gate JNI da v0.7.1 foi bloqueado em `nativeAnswer` e `nativeAnswerStream` porque a liberação condicional de `context` e a liberação obrigatória de `question` estavam compactadas na mesma linha, produzindo `-Wmisleading-indentation`.
**Correção/regra permanente:** em JNI, cada aquisição/liberação de recurso deve ter bloco visual inequívoco. Liberação condicional e obrigatória nunca ficam na mesma linha; `-Werror` permanece obrigatório. O gate host precisa passar antes de qualquer claim Android/JNI.

### 10.142 — Recovery v0.6.3 precisa testar famílias linguísticas, não uma única formulação
- **Falha observada:** o novo gate de recuperação 11-case revelou que “o que acontece durante a inferência”, “INT4 sempre preserva...” e “isso prova que todas as alternativas...” ainda podiam escapar dos intents bounded, embora formulações vizinhas já passassem.
- **Causa:** os detectores semânticos estavam excessivamente presos a combinações lexicais específicas (`inferência` + verbos limitados; universal quantifier incompleto; non-entailment sem `todas/alternativas`).
- **Correção obrigatória:** intents de inferência, universalidade e entailment devem reconhecer famílias bounded de formulações e continuar fail-closed; o gate 11/11 permanece independente dos gates 12/12 e 7/7.

### 10.143 — Gates devem validar propriedade sem exigir sinônimo literal não contratual
- **Falha observada:** o caso de evento atual já respondia corretamente que faltava “informação temporal atual”, mas o teste exigia literalmente “temporalmente”.
- **Causa:** assert textual mais estreito que o contrato real de fail-closed temporal.
- **Correção obrigatória:** testes devem aceitar a formulação canônica observável do contrato (`temporal` + ausência de evidência) e continuar rejeitando qualquer resposta factual inventada.

### 10.144 — Trainer/evaluator deve ler o schema materializado real, não nomes presumidos
- **Falha observada:** o primeiro recovery train do Semantic Ranker concluiu 700 steps, mas a avaliação Pirá-validation abortou com `KeyError: source_id`; o arquivo canônico usa `expected_source_id` e `query`.
- **Causa:** o evaluator novo presumiu o schema do corpus de treino ao ler um fixture de validação com contrato diferente.
- **Correção obrigatória:** ler os nomes do schema materializado real, manter treino/seed/threshold idênticos e nunca promover um asset quando a avaliação terminal não conclui.

### 10.145 — Recuperar arquitetura pelo tamanho não recupera a qualidade aprendida
- **Falha observada:** o ranker reconstruído com exatamente 131.200 parâmetros e 524.832 bytes atingiu apenas 644/741 comparações conhecidas + 7/8 críticas.
- **Causa:** a evidência histórica preservava arquitetura/resultados, não os pesos; treinar apenas contra um hard-negative lexical não reproduziu a geometria semântica anterior.
- **Correção obrigatória:** melhorar o objetivo de aprendizagem mantendo arquitetura/gates; se o holdout continuar abaixo do floor, deixar o ranker fora da release em vez de baixar o threshold ou reutilizar SHA antigo sem bytes.

### 10.146 — Runtime C99 não pode depender silenciosamente de tokenizer POSIX
- **Falha observada:** o loader/inferencer do Semantic Ranker compilou em fonte, mas `-Werror` rejeitou `strtok_r` como declaração implícita no modo C99 atual.
- **Causa:** `strtok_r` é POSIX e não faz parte do C99 puro; o runtime móvel precisa permanecer portátil entre host/Android cross-targets.
- **Correção obrigatória:** usar tokenização bounded própria em C99, sem feature macros artificiais, e manter os pesos/asset treinados intactos; a paridade só conta após recompilação limpa.

### 10.137 — JNI/Kotlin asset-signature drift after Semantic Ranker integration
- **Falha observada:** após adicionar `semanticRankerPath` ao `nativeLoad`, o wrapper Kotlin público continuou chamando a assinatura anterior e o gate host falhou com `no value passed for parameter memoryPath`.
- **Causa:** alteração da boundary JNI aplicada à declaração nativa e ao C, mas uma chamada adapter permaneceu stale.
- **Correção obrigatória:** toda mudança de assinatura JNI deve atualizar declaração Kotlin, wrappers públicos, call sites, MainActivity e gate host na mesma transação lógica.
- **Anti-regressão:** `verify_kotlin_host.sh` e `verify_jni_host.sh` são gates obrigatórios antes de sincronizar identidade/release; host verde isolado não prova boundary Android válida.

### 10.138 — Intent precedence: WEIGHT_UPDATE must precede broad DEFINE_INFERENCE
- **Falha observada:** `nd_semantic_test` classificou “Os pesos aprendem automaticamente durante a inferência?” como `DEFINE_INFERENCE` em vez de `WEIGHT_UPDATE`.
- **Causa:** a regra ampla de definição/inferência era avaliada antes da intenção mais específica `pesos + inferência + aprendem/atualizam/mudam`.
- **Correção obrigatória:** intenções semanticamente específicas devem ter precedência sobre padrões amplos que compartilham tokens; não corrigir o teste nem inserir exceção por frase completa.
- **Anti-regressão:** `nd_semantic_test` permanece gate obrigatório e deve cobrir colisões de precedência entre intenções.

### 10.139 — Multi-step sync scripts must import dependencies before mutating canonical state
- **Falha observada:** a sincronização v0.7.1 atualizou manifest/Android e criou docs, mas o bloco de regeneração de `canonicalDocs` terminou com `NameError: json is not defined`.
- **Causa:** script ad hoc multi-etapas começou a mutar arquivos antes de validar todas as dependências/imports do bloco posterior.
- **Correção obrigatória:** após falha parcial, inspecionar o estado efetivamente escrito e retomar somente passos ausentes; não reaplicar cegamente o script inteiro.
- **Anti-regressão:** scripts de sincronização/release devem validar imports/config primeiro ou operar por staging/commit atômico quando possível.

### 10.140 — Não criar authority paralela quando um owner histórico já existe
- **Falha observada:** a convergência passou a conter `scripts/model_authority.py` (owner histórico recuperado) e um novo `tools/model_authority.py`, ambos capazes de assinar promotion/activation.
- **Causa:** a nova implementação foi criada antes de concluir a auditoria de duplicidade no namespace de scripts/tools.
- **Correção obrigatória:** preservar e estender o owner `scripts/model_authority.py`, remover a authority paralela, regenerar uma única cadeia de chave pública/promotion/activation e fazer os testes apontarem apenas para esse owner.
- **Anti-regressão:** nenhuma nova release/model/serving authority pode ser criada sem busca integral por owner existente; `verify_project.py`/auditoria devem tratar authorities paralelas como regressão arquitetural.

### 10.141 — Promotion authority must provision its own required runtime build
- **Falha observada:** após `clean.sh`, `scripts/model_authority.py promote` chamou `verify_semantic_ranker.py`, que exige `build/nd_semantic_ranker_test`, e falhou porque o build não existia.
- **Causa:** a authority passou a depender implicitamente de uma ordem externa (`build` antes de promotion), sem declarar/provisionar essa dependência.
- **Correção obrigatória:** a promotion authority deve construir/revalidar explicitamente o runtime necessário ou receber um artefato de build autenticado; nesta linha ela chama `scripts/build_host.sh` antes dos runtime verifiers.
- **Anti-regressão:** promotion executada após `clean.sh` deve funcionar de forma independente e nunca reutilizar um binário stale silenciosamente.

### 10.142 — Candidate não ativado não deve inflar o asset set Android
- **Falha de arquitetura detectada:** o Pirá full de 1.281 registros estava em `models/`, e o Gradle empacota todo `../../models` como assets. Mesmo `CANDIDATE_NOT_ACTIVATED`, esses 1,5 MB entrariam no app móvel.
- **Correção:** mover candidates/evidence não ativados para `candidates/`; `models/` fica reservado aos assets realmente promovidos/ativados pelo runtime Android.
- **Anti-regressão:** `verify_cleanliness.py` e documentação devem diferenciar runtime assets de candidate artifacts; existir no ZIP completo não implica ocupar footprint do app.

### 10.143 Pré-auditoria Python pode invalidar cleanliness se o cache não for limpo novamente
- **Falha observada:** a pré-auditoria executou `python3 -m py_compile ...` e, imediatamente depois, `tests/verify_cleanliness.py`; o próprio `py_compile` criou `scripts/__pycache__`, portanto o gate de higiene falhou antes de `verify_project.py`.
- **Causa:** ordem operacional incorreta do harness de pré-auditoria. O gate oficial `verify.sh` já chama `clean.sh` no início de `static`, mas a checagem manual fora do wrapper não repetiu a limpeza depois de gerar bytecode transitório.
- **Regra:** nenhum cache gerado por uma ferramenta de validação pode ser confundido com conteúdo distribuível. Sempre executar `scripts/clean.sh` depois de `py_compile`/testes que gerem cache e antes de `verify_cleanliness.py`, metadata ou packaging. Não enfraquecer a lista de diretórios proibidos para acomodar cache transitório.

### 10.144 Novo assert de authority deve respeitar a ordem de inicialização do próprio gate
- **Falha observada:** `tests/verify_project.py` abortou com `NameError: ROOT is not defined` antes de validar o projeto.
- **Causa:** a nova asserção de unicidade de `scripts/model_authority.py` foi inserida por busca textual antes da linha que inicializa `ROOT`.
- **Regra:** alterações em gates devem ser executadas imediatamente contra o próprio arquivo e nunca podem presumir ordem de símbolos por busca textual. Asserções dependentes de `ROOT` entram somente depois de sua definição; falha do test harness não deve ser atribuída ao runtime.

## 10.145 — Auditoria histórica profunda encontrou owners executáveis de continuidade offline ainda ausentes na LocalNet atual

**Falha encontrada antes da implementação v0.7.2:** a comparação de código real entre a release final v0.7.1 e a árvore cumulativa Mobile Runtime v0.63 mostrou que `durable outbox`, `adaptive network policy` e `project-scoped offline command dependencies` existiram como mecanismos executáveis nas versões iniciais, mas não possuem owner equivalente no núcleo C99 atual. Resource Governor, Local RAG e Run Journal já haviam sido recuperados, portanto a lacuna é específica de continuidade offline e política de rede.

**Regra anti-regressão:** não criar um backend remoto ou authority paralela. Recuperar somente os invariantes superiores: fila durável local, idempotency key, FIFO serial, dependências locais acíclicas, quotas por perfil, TTL/paused/blocked states, categorias de erro sanitizadas e política de rede `offline/constrained/normal`. Nenhuma entrega para IA externa é permitida pela política `NEURALDESK_FIRST_PARTY_ONLY`.

## 10.146 — Caminho do precheck obrigatório mudou e não deve ser inferido por memória

**Falha operacional:** ao reabrir o ZIP final v0.7.1, a primeira tentativa procurou `scripts/prechange_lessons_check.py`, que não existe nessa release. A autoridade real é `scripts/pre_generation_lessons_check.py`, confirmada pelos bytes do ZIP e pelo `tests/verify_lessons_protocol.py`.

**Regra anti-regressão:** em toda recuperação/release, localizar o precheck a partir da árvore real antes de executá-lo; nunca assumir path histórico apenas porque existiu em outra versão.

## 10.147 — Local Projects era um owner executável independente e não deve ser confundido com duplicação de memória/RAG

**Descoberta:** a auditoria dos bytes Mobile Runtime cumulativos confirmou que `project-service.js` administrava apenas identidade/metadados de workspace (`default`, create/select/rename/remove), enquanto conversação, fontes e outbox eram delimitadas pelo `projectId` em seus próprios stores. Portanto recuperar Local Projects não exige criar uma segunda implementação de memória ou RAG.

**Regra anti-regressão:** o owner de projetos deve permanecer metadata-only, com ID opaco validado, nome bounded, projeto `default` não removível e helper de paths project-scoped. Estado de memória/RAG/outbox continua pertencendo aos seus owners; isolamento é obtido por paths/IDs separados, não por duplicação de engines.

## 10.148 — Outbox durável precisa de negative controls de persistência e dependências

**Descoberta:** o happy-path inicial v0.7.2 provou enqueue/FIFO/backoff/reload, mas ainda não cobria arquivo truncado/adulterado, remoção manual de pai bloqueando filho, relink e quotas.

**Regra anti-regressão:** Durable Outbox só entra no release quando corruption/trailing/truncation falham fechado, dependência removida não é tratada como sucesso, relink válido recupera o filho, ciclos são rejeitados e quotas Micro/Mobile/Mobile Plus são exercitadas.

## 10.149 — Weight Averaging/SWA de V8.20 era documentação-only e só pode ser adotado atrás da authority atual

**Descoberta:** V8.20/V8.22 documentava `training → immutable checkpoints → compatibility gate → averaging candidate → evaluation → promotion decision → signed artifact`, mas não existia implementação executável nessa linha de blueprint.

**Regra anti-regressão:** qualquer implementação v0.7.2 de checkpoint averaging deve exigir os mesmos bindings, chaves, shapes e dtypes; usar checkpoints imutáveis verificados; produzir apenas `AVERAGING_CANDIDATE_NOT_PROMOTED`; preservar source checkpoints; e nunca contornar `scripts/model_authority.py` ou os quality-regression gates.

## 10.150 — Image preprocessing histórico não é superior enquanto não existe modelo visual promovido

**Decisão de auditoria:** o `image-preprocessor.js` histórico fazia resize/reencode/metadata stripping, mas sua utilidade era subordinada a uma rota multimodal que a LocalNet atual ainda não possui como modelo executável promovido. Portá-lo isoladamente agora criaria código móvel sem consumidor e poderia ser interpretado incorretamente como multimodalidade.

**Regra anti-regressão:** preservar o padrão documental e os requisitos (JPEG/PNG/WebP, size/pixel caps, metadata stripped, Resource Governor), mas só implementar o preprocessor nativo quando existir um owner visual executável capaz de consumi-lo e um gate multimodal correspondente.

## 10.151 — Harness manual passou argumento de memória a gates que usam memória temporária internamente

**Falha operacional:** ao revalidar v0.6.1/v0.6.2/v0.6.3 após o port v0.7.2, foram passados seis argumentos de asset, incluindo um path de memória explícita. Os três executáveis aceitam somente `RETRIEVER KB CONTEXT_QA RELATION OPEN_SHARD`; retornaram usage/code 2 antes de executar qualquer caso.

**Regra anti-regressão:** antes de invocar testes manuais fora de `verify.sh`, ler a usage/assinatura do executável ou reutilizar exatamente o comando canônico do gate. Retorno 2 por usage nunca é regressão funcional nem PASS.

## 10.152 — Benchmark histórico é útil se preservar `MEASURED_NOT_CERTIFIED`

**Descoberta:** o core histórico possuía `benchmark-evaluation.js` com p50/p95/p99, success rate e scorecard, explicitamente marcado `MEASURED_NOT_CERTIFIED`. A v0.7.1 possui Device Lab/Run Journal, mas não um agregador C reutilizável para métricas locais do runtime.

**Regra anti-regressão:** portar somente agregação de métricas sanitizadas e scorecard; nenhum resultado host pode ser chamado de benchmark físico Android, SLO ou certificação M1/M2/M3. Prompts/respostas/endpoints/secrets continuam proibidos na evidência.

## 10.153 — Sincronização de identidade v0.7.2 não pode deixar gates/metadata/document registry presos à v0.7.1

**Falha encontrada antes do freeze:** `PROJECT_MANIFEST.json`, Gradle e RuntimeIdentity já declaravam `0.7.2-alpha.1`, mas `tests/verify_release_pipeline.py` e `tests/verify_project.py` ainda exigiam literalmente `0.7.1-alpha.1`; `scripts/generate_release_metadata.py` ainda emitia chaves/flags `v071*` e afirmava que pesos/datasets v0.7.1 haviam mudado; e `canonicalDocs` não incluía `OFFLINE_CONTINUITY_V072.md`, `HISTORICAL_DEEP_AUDIT_V072.md` e `MODEL_AUTHORITY_V072.md`.

**Distinção obrigatória:** nomes de assets como `neuraldesk-semantic-ranker-v0.7.1.ndsr` e o Pirá full candidate v0.7.1 são lineage/bytes realmente herdados e **não** devem ser renomeados apenas para acompanhar a versão do pacote. Já versão corrente, gates, metadata e registry documental devem sempre refletir a release atual.

**Correção obrigatória:** derivar a identidade corrente do manifest nos gates/metadata sempre que possível; regenerar `canonicalDocs` a partir da árvore canônica; declarar `v072NeuralWeightsChanged=false` e `v072DatasetsChanged=false`; preservar rollback v0.7.1 e assets herdados byte-idênticos.

**Anti-regressão:** uma release é bloqueada se manifest/Android/docs/gates/metadata discordarem sobre a versão corrente ou se um documento canônico top-level ficar fora do registry. Referências v0.7.1 só são aceitas quando explicitamente lineage, rollback ou nome de asset herdado.

## 10.154 — Gate estrutural não pode imprimir PASS antes das últimas asserções

**Falha encontrada por inspeção antes da execução:** ao adicionar os novos contratos v0.7.2 a `tests/verify_release_pipeline.py`, as asserções de Weight Averaging e Offline Continuity foram anexadas depois do `print('release-pipeline-contract PASS ...')` herdado.

**Risco:** um log poderia conter um marcador visual de PASS e ainda terminar com exception/código diferente de zero. Mesmo que o wrapper oficial use return code, esse padrão degrada a evidence humana e pode induzir leitura incorreta de logs parciais.

**Correção obrigatória:** o marcador público PASS deve ser a última ação do gate, executada somente depois de todas as asserções; nenhum teste novo pode ser adicionado depois dele.

**Anti-regressão:** timeout, log parcial ou marcador impresso antes do fim nunca substitui return code 0 e receipt terminal.

## 10.155 — Gates que usam `Path('.')` devem ser invocados com cwd na raiz do projeto

**Falha operacional:** a pré-auditoria chamou `tests/verify_release_pipeline.py` por path absoluto enquanto o shell permanecia fora da raiz. O gate usa `root = Path('.')` e falhou com `PROJECT_MANIFEST.json` ausente antes de executar qualquer asserção funcional.

**Correção:** executar gates cwd-sensitive com `cwd=ROOT`/`cd "$ROOT"` ou tornar o gate future-proof com raiz derivada de `__file__` em uma mudança separada.

**Anti-regressão:** code 1 por diretório de trabalho incorreto nunca é interpretado como regressão do runtime nem como PASS; harnesses manuais devem reproduzir o cwd do wrapper oficial.

## 10.156 — Gate novo repetiu acoplamento textual ao verificar opt-in da memória Android

**Falha observada:** `tests/verify_android_wiring.py` exigiu literalmente `getBoolean(PREF_ENABLED, false)`, enquanto `ResearchMemoryStore.isEnabled()` implementava corretamente o mesmo contrato com `prefs.getBoolean("enabled", false)`. O gate abortou apesar de a propriedade funcional — memória desabilitada por padrão e escrita condicionada a `isEnabled()` — estar presente.

**Causa:** o teste congelou um nome interno de constante inexistente em vez de validar o comportamento/estrutura relevante. É uma recorrência das lições 10.55/10.56: snippet de implementação não é API nem prova semântica.

**Correção obrigatória:** validar que `isEnabled()` lê a preferência `enabled` com default `false`, que `append()` retorna sem persistir quando `isEnabled()==false`, e que a memória usa armazenamento criptografado/Keystore. Não exigir o nome de uma constante privada.

**Anti-regressão:** gates estáticos novos devem buscar invariantes observáveis e podem aceitar formas equivalentes de implementação. Uma falha do próprio harness deve ser registrada e corrigida; o código correto não deve ser deformado apenas para satisfazer uma substring.

## 10.157 — Avaliador individual pode depender do diretório de build canônico

**Falha operacional:** a revalidação manual executou os binários C a partir de `build-dev/`, mas `tests/verify_live_qa.py` chama deliberadamente `./build/ndassistant`. O evaluator encerrou com `FileNotFoundError` antes de avaliar qualquer pergunta, embora todos os testes C executados imediatamente antes tivessem passado.

**Causa:** o harness manual divergiu do layout usado pelo gate oficial; não houve falha de inferência ou regressão comportamental.

**Correção/regra permanente:** avaliações que fazem referência explícita a `./build/...` devem ser executadas depois do prebuild canônico em `build/`, ou receber uma futura abstração de path em mudança independente e testada. Não alterar o Golden/evaluator apenas para acomodar um diretório ad-hoc e nunca contar `FileNotFoundError` pré-inferência como falha ou PASS do modelo.

## 10.158 — Recorrência de identidade: gates v0.7.2 ainda hard-coded bloquearam a candidata v0.7.3

**Falha observada:** após criar a candidata `0.7.3-alpha.1`, `tests/verify_project.py` e `tests/verify_release_pipeline.py` abortaram porque ainda exigiam literalmente `manifest['version'] == '0.7.2-alpha.1'`; `verify_documentation_consistency.py` também bloqueou corretamente porque README/docs ainda descreviam v0.7.2.

**Causa:** a correção histórica 10.153 sincronizou a v0.7.2, mas manteve assertions de versão como literais, fazendo a mesma classe de drift reaparecer na release seguinte.

**Correção obrigatória:** gates de estrutura/pipeline devem validar o formato e a coerência da versão corrente derivada do `PROJECT_MANIFEST.json`, e comparar Android/RuntimeIdentity/docs com essa autoridade. Uma versão anterior só pode aparecer como lineage/rollback/asset herdado explicitamente classificado.

**Anti-regressão:** nenhuma release futura deve exigir edição manual de uma igualdade hard-coded apenas para avançar o número de versão. O gate deve falhar por inconsistência entre autoridades, não por possuir internamente a versão da release anterior.

## 10.159 — Perda da candidata v0.7.4-alpha.1 invalida checkpoints e exige nova identidade de reconstrução

**Falha operacional observada:** a árvore transitória `v0.7.4-alpha.1` e seus checkpoints de treino deixaram de existir no workspace antes de serem persistidos como artefato integral verificável. A Biblioteca preservou a release final `v0.7.3-alpha.1` e evidências históricas, mas não preservou os bytes executáveis nem os checkpoints da candidata v0.7.4.

**Risco:** continuar a partir de descrições da conversa ou reutilizar hashes de checkpoints desaparecidos fabricaria uma continuidade que não pode ser reproduzida byte a byte. Um checkpoint citado em log, mas cujos bytes não existem, não pode ser retomado nem contado como treino concluído.

**Correção aplicada:** preservar `v0.7.3-alpha.1` como rollback final; criar uma nova árvore `v0.7.4-alpha.2` diretamente a partir do ZIP final atestado; reaplicar apenas mecanismos que possam ser novamente implementados e reprovados; gerar novos hashes/evidence; declarar explicitamente que alpha.2 não é byte-idêntica à candidata perdida.

**Regra permanente:** nenhuma candidata transitória ou checkpoint importante pode ser considerado continuidade até possuir snapshot/persistência verificável fora do workspace efêmero. Ao fechar uma unidade longa de trabalho, persistir pelo menos um snapshot de desenvolvimento claramente `NOT_PROMOTED` e, para treino, checkpoints integrity-bound externos. Perda dos bytes invalida seus hashes como evidence executável e exige nova identidade de reconstrução.

## 10.160 — Blacklist de cleanliness por nome genérico não pode bloquear um owner novo comprovadamente diferente do artefato legado

**Falha observada:** após introduzir o tokenizer first-party `NDTK v1` da v0.7.4, `tests/verify_cleanliness.py` rejeitou `core/include/nd_tokenizer.h` apenas porque esse path constava numa lista histórica de artefatos superseded. O novo header/source não é restauração do tokenizer rejeitado: possui formato `NDTKV001`, vocab 512, fitting train-only, checksum, roundtrip e corruption gate próprios.

**Causa:** a blacklist antiga codificou um nome de arquivo genérico como identidade do mecanismo superseded. Quando um owner legítimo reutilizou o nome conceitual correto, o teste passou a bloquear a propriedade errada.

**Correção/regra permanente:** cleanliness deve bloquear artefatos legados por identidade verificável — formatos/magics antigos, assets rejeitados, imports/paths de runtime superseded ou coexistência de duas authorities — e não proibir para sempre um nome conceitual genérico. Ao reusar um namespace legítimo, exigir gate que prove que o novo owner é único e que os formatos/assets antigos continuam ausentes. Nunca renomear implementação correta apenas para contornar uma substring/path blacklist stale.

## 10.161 — Gate de paridade de primeiro token não deve executar geração completa desnecessária

**Falha operacional:** o primeiro `evaluate_generative_quality_v074.py` usou a mesma função de geração de 64 tokens tanto para os 18 probes comportamentais quanto para as 60 execuções auxiliares de paridade de primeiro token. O runtime C99 de referência estava correto, mas o gate excedeu a janela externa antes de produzir relatório terminal.

**Causa:** o harness confundiu a propriedade medida. Paridade de primeiro token exige somente o próximo token do mesmo prefixo; gerar os 63 tokens seguintes não adiciona cobertura a essa métrica.

**Correção/regra permanente:** manter 64 tokens para os seis probes comportamentais de cada formato, mas usar `max_tokens=1` exclusivamente no subgate de first-token parity. Otimização de harness é permitida quando preserva exatamente a propriedade medida; nunca reduzir número de prompts, formatos ou critérios semânticos para caber na janela.

## 10.162 — Variável `ROOT` não substitui `cd`: gate CMake precisa de working-directory canônico explícito

**Falha operacional observada:** ao iniciar o primeiro build do Micro v2, o comando definiu `ROOT=/mnt/data/.../v0.7.4-alpha.2`, mas chamou `cmake -S .` sem executar `cd "$ROOT"`. O CMake recebeu `/` como diretório de source e abortou antes de compilar qualquer arquivo.

**Classificação:** falha de harness/working-directory; não é falha do runtime generativo nem autorização para alterar CMake, warnings ou testes.

**Correção/regra permanente:** comandos agregados que dependem de caminhos relativos devem executar `cd "$ROOT"` explicitamente antes do primeiro passo ou usar caminhos absolutos em `-S/-B`. A presença de uma variável `ROOT` não prova que o processo está nesse diretório. Repetir o mesmo gate no diretório canônico; nunca adaptar source tree ou esconder o erro para produzir PASS.

## 10.163 — Logging de loss não deve converter Tensor com gradiente diretamente para escalar

**Falha observada:** o primeiro speed probe do trainer Micro v2 executou corretamente, mas PyTorch emitiu `UserWarning` porque o log usava `float(loss)` enquanto o tensor ainda mantinha `requires_grad=True`.

**Risco:** a conversão não alterou o backward já concluído neste caso, porém warnings no caminho canônico escondem problemas reais e tornam a evidência ruidosa.

**Correção/regra permanente:** valores destinados apenas a logging devem usar `loss.detach().item()` depois da etapa de otimização. Warnings novos no trainer devem ser eliminados pela causa correta antes de uma campanha canônica; nunca suprimi-los globalmente.

## 10.164 — Corpus maior pode piorar a voz do decoder se uma fonte sintética dominar a amostragem

**Falha observada:** o primeiro screening Micro v2 combinou 2.563 SFT ricos com 52.500 exemplos context-pointer first-party. A governança de leakage estava correta e a loss caiu rapidamente, mas o replay causal era uma lista única com 55.063 registros, dos quais ~95% vinham do context-pointer. Após 800 pretrain + 400 SFT, os seis probes históricos falharam e as respostas brutas colapsaram para padrões sintéticos como `Registro-...`, `capital...` e `Resposta:`.

**Causa:** volume bruto foi confundido com mistura adequada. Uma fonte sintética de extração é útil para grounding e estrutura, mas dominou a distribuição linguística e passou a definir a voz do decoder.

**Correção obrigatória:** materializar ou amostrar fontes por classe. Replay causal deve possuir pesos explícitos por fonte, e SFT deve privilegiar respostas humanas/rich first-party. Context-pointer pode permanecer como regularização bounded, nunca dominar a mistura apenas porque contém mais linhas. A configuração de mistura entra no hash do checkpoint.

**Regra permanente:** aumentar corpus só é melhoria quando provenance, leakage **e mixture weighting** são governados. Loss menor com mudança indesejada de estilo é regressão comportamental e bloqueia continuação daquele checkpoint; reiniciar a campanha quando a política de amostragem muda.

## 10.165 — Export Q8/Q4 não pode transformar loop Python por peso em gargalo do checkpoint terminal

**Falha operacional observada:** após um gate curto de resume do Micro v2 balanceado concluir os mesmos steps, a chamada externa expirou já na etapa terminal de exportação. O exporter quantizava 4,48 milhões de parâmetros percorrendo blocos e estendendo listas Python elemento a elemento.

**Classificação:** gargalo de harness/export, não falha de treinamento nem justificativa para pular Q8/Q4.

**Correção/regra permanente:** quantização blockwise deve usar operações vetorizadas bounded (NumPy/C) mantendo exatamente tamanho de bloco, cálculo de escala, arredondamento, clipping, packing e formato serializado. Antes de substituir o exporter canônico, comparar bytes/hashes contra uma saída do algoritmo anterior no mesmo checkpoint; otimização só é aceita se preservar a semântica definida ou receber nova versão de formato explicitamente validada.

## 10.166 — Vetorização de quantização precisa preservar também a promoção de dtype, não só a fórmula

**Falha detectada pelo negative gate:** a primeira versão vetorizada do exporter produziu FP32 byte-idêntico, mas Q8 com SHA diferente do exporter predecessor no mesmo checkpoint. O cálculo por bloco parecia matematicamente igual, porém a matriz `float32` foi dividida por um array de escalas `float64`, promovendo o quociente antes do `rint`.

**Causa:** o loop predecessor dividia um array NumPy `float32` por um escalar Python derivado do máximo do bloco; nessa operação o ufunc mantinha `float32`. A vetorização alterou silenciosamente a regra de arredondamento perto de fronteiras de quantização.

**Correção/regra permanente:** gates de reproducibilidade de quantização devem cobrir bytes completos, não apenas top-1/paridade de saída. Ao vetorizar, reproduzir explicitamente dtype de cada etapa (`float32` para divisão/arredondamento quando esse for o contrato). Qualquer mudança de SHA exige ou correção para byte-parity ou uma versão de formato/algoritmo nova e deliberada.

### 10.167 — Loss menor e currículo balanceado ainda podem falhar por objetivo/batching ineficiente
**Ocorrência (2026-08-25):** o Micro v2 (`4.476.640` parâmetros, `dim=224`, 8 camadas, GQA 7:1) foi retreinado do zero com tokenizer source-balanced, pretraining `70% rich / 30% contextual` e SFT `80% rich / 10% contextual / 10% rich replay`. A campanha terminal `800 pretrain + 1200 SFT` reduziu Pirá validation de `6,276065` para `3,843947`, mas o runtime C99 FP32 falhou os 6/6 holdouts históricos e produziu repetição linguística (`compona/comentos/para...`). A contaminação anterior de estilo `Registro/capital` desapareceu, portanto balancear a fonte corrigiu a voz dominante, mas não produziu instruction-following coerente.
**Diagnóstico:** depois de remover dominância de fonte, continuar apenas aumentando steps de um treino `batch=1` não é evidência de progresso. Em 1.200 steps SFT, apenas uma fração do corpus rico único recebe supervisão e o gradiente tem alta variância; validation loss pode cair enquanto geração greedy continua colapsada.
**Regra permanente:** um candidato terminal com `0/6` comportamento não recebe mais steps cegamente. A próxima tentativa deve alterar uma propriedade de aprendizagem mensurável (por exemplo batching real, cobertura por época do corpus rico, scheduler/objetivo, ou capacidade) e criar evidence que separe eficiência do treino de capacidade do runtime. Os seis holdouts históricos permanecem somente regressão de desenvolvimento; promoção futura exige holdout novo pós-congelamento.

### 10.168 — Minibatching/época melhora eficiência e cobertura, mas 0/6 terminal ainda bloqueia a mesma arquitetura
**Ocorrência (2026-08-25):** mantendo o Micro v2 de `4.476.640` parâmetros, NDGM v4, NDTK v2 e o corpus source-balanced, foi implementado treino real por minibatches/épocas. Uma época de pretraining usou batches `7 rich replay + 3 context`, e uma época de SFT usou `8 rich response-only + 1 context + 1 rich replay`, cobrindo todos os `2.563` exemplos ricos em cada fase (com apenas tail-fill explícito no último batch). `pause -> resume` atravessando pretrain->SFT produziu model-state, AdamW e FP32/Q8/Q4 idênticos ao caminho ininterrupto. A campanha completa executou `688` optimizer updates, reduziu Pirá validation de `6,276065` para `3,452152` e apresentou `2.568` exemplos ricos em SFT, mas o runtime C99 FP32 ainda falhou `0/6` holdouts históricos com pseudo-palavras/repetição.
**Diagnóstico:** batch=1 era ineficiente, mas não era a única causa do colapso. O ganho de loss/cobertura sem ganho comportamental refuta a hipótese de que somente minibatching resolveria instruction-following nessa capacidade.
**Regra permanente:** preservar o trainer minibatch/epoch e sua evidence de resume, mas não adicionar épocas cegamente ao mesmo Micro v2 após `0/6`. A próxima tentativa deve mudar outra propriedade isolável, preferencialmente capacidade linguística ou representação/objetivo, mantendo corpus, evaluation boundary e runtime gates constantes quando possível. Promoção continua proibida até comportamento FP32 útil e holdout novo pós-congelamento.

### 10.169 — Checkpoint grande precisa de commit atômico; interrupção não pode deixar path final truncado
**Falha observada (2026-08-25):** no gate `pause -> resume` do Micro v3 (~11,23 M parâmetros), uma chamada externa foi interrompida enquanto `torch.save()` escrevia diretamente o checkpoint `v3batch-phase-sft-...-u4.pt`. O path final ficou presente com ~94,8 MB, menor que os ~134,9 MB esperados, e sem sidecar; o checkpoint anterior `u2` permaneceu íntegro. Um consumidor que verificasse somente a existência/nome poderia tentar retomar bytes truncados.
**Causa:** o writer publicava o nome final antes de concluir serialização e durabilidade. O sidecar com SHA era escrito apenas depois, então ausência de sidecar bloqueava o loader atual, mas o filesystem ainda continha um artefato final-looking inválido.
**Correção/regra permanente:** checkpoints treináveis devem usar two-phase local commit: serializar para arquivo temporário no mesmo diretório, `flush/fsync`, calcular/verificar hash, `os.replace()` atômico para o path final, `fsync` do diretório e só então publicar sidecar por temp+replace+fsync. Loader exige arquivo + sidecar + SHA + config binding. Temporário órfão nunca conta como checkpoint. Interrupção deve preservar o último checkpoint final válido e jamais substituir seu path por bytes parciais.

### 10.170 — Cadência de checkpoint por número de batches pode ser insuficiente quando a capacidade cresce
**Falha operacional (2026-08-25):** o primeiro screening Micro v3 (`11.229.760` parâmetros, batch 10, seq 64) atingiu a janela externa depois de imprimir apenas os primeiros ~25 batches e antes do checkpoint configurado para batch 50. Como nenhum checkpoint final válido existia, todo progresso após o início da chamada foi corretamente descartado.
**Diagnóstico:** uma cadência adequada ao Micro v2 não é automaticamente adequada ao Micro v3. O custo por batch aumentou com a capacidade e o intervalo de persistência passou a exceder a janela operacional disponível.
**Regra permanente:** campanhas maiores devem escolher checkpoint cadence a partir do custo medido da unidade de treino, com intervalo suficientemente curto para preservar progresso bounded. Nenhum batch sem checkpoint integrity-bound é contabilizado após interrupção. Otimizações CPU (threads/MKLDNN ou equivalente) só podem ser adotadas depois de provar novamente determinismo/resume na mesma configuração; velocidade nunca autoriza remover `torch.use_deterministic_algorithms`, validation isolation ou hashes de checkpoint.

### 10.171 — Validation serial pode dominar a janela e mascarar throughput real do treino
**Falha operacional (2026-08-25):** no primeiro screening Micro v3, a chamada externa atingiu timeout depois de apenas ~25 batches, sugerindo inicialmente que cada optimizer update era muito caro. Um speed probe isolado mostrou ~0,40 s por batch de 10 exemplos com 4 threads; o custo dominante estava em `evalv()`, que executava 140 forwards individuais antes do primeiro batch/checkpoint.
**Causa:** o evaluator preservado do Micro menor fazia um forward por exemplo. Ao crescer para 11,23 M parâmetros, a avaliação serial tornou-se muito mais cara que dezenas/centenas de updates batched.
**Correção/regra permanente:** evaluation continua usando todos os itens reservados e sem gradiente, mas pode empilhar sequências já padded em minibatches e calcular a mesma média de cross-entropy por exemplo. O gate deve comparar serial vs batched no mesmo estado e exigir diferença numérica bounded antes de substituir o caminho canônico. Otimizar evaluator nunca autoriza reduzir `validationItems`, contaminar treino ou trocar a métrica.

### 10.172 — Harness de diálogo deve consumir nomes/schemas canônicos, nunca enums presumidos
**Falha observada (2026-08-25):** o primeiro build do novo `nd_independent_dialogue_v074` foi bloqueado por `-Werror` porque o harness tentou usar `ND_MOBILE_PROFILE_MOBILE`, enquanto a autoridade real `nd_resource.h` expõe `ND_PROFILE_MOBILE`.
**Causa:** o código de avaliação foi escrito a partir do significado conceitual do perfil em vez de consultar o símbolo público exato já existente.
**Correção/regra permanente:** qualquer harness novo deve ler os headers/contratos atuais e usar os nomes públicos canônicos. Falha de nome/schema em ferramenta de avaliação nunca autoriza alias ad hoc no runtime nem relaxamento de warnings; registrar a ocorrência, corrigir apenas o harness e recompilar sob o mesmo `-Werror`.

### 10.173 — Diálogo independente deve ser preservado como evidence antes de virar currículo
**Campanha observada (2026-08-25):** uma sessão contínua de 30 turnos entre ChatGPT (interrogador externo) e o `NDAssistant` canônico v0.7.4-alpha.2 foi executada com Retriever, KB, Pointer, Relation, Open Knowledge, Semantic Ranker, RAG local e memória. O run UTF-8 natural obteve 16 PASS, 4 PARTIAL e 10 FAIL no rubric independente; o run ASCII stress mostrou sensibilidade adicional de normalização. Falhas novas/recorrentes incluíram relation binding `código`, memória multiatributo/update, non-entailment sem a afirmação explícita `não prova`, resposta simples de quantização desviada para treino/validação/inferência, open-knowledge contaminado por RAG irrelevante, keywords, resumo de oito turnos e porcentagem em linguagem natural.
**Risco:** transformar imediatamente os próprios 30 prompts avaliados em treino e depois reutilizá-los como prova faria o sistema memorizar a prova e destruiria seu valor de holdout independente.
**Correção/regra permanente:** preservar transcript bruto + metadata + rubric antes de qualquer correção. Itens FAIL/PARTIAL podem gerar `REFERENCE_ONLY`/training-candidate properties, mas deixam de ser elegíveis como holdout de promoção depois que influenciarem implementação/currículo. Toda futura promoção que use essas falhas para desenvolvimento deve criar um novo diálogo holdout pós-correção, com formulações e entidades diferentes. Resultados de diálogo não autorizam backend generativo, model promotion ou alteração de thresholds por si só.

### 10.174 — Gate de modelos corrente não pode continuar provando arquitetura/corpus predecessor
**Falha observada (2026-08-25):** após o diálogo, a fase `models` ainda chamava `verify_python_c_generative_parity_v074.py`, que exporta a antiga Micro v1/NDGM v3 e é corretamente rejeitada pelo runtime corrente NDGM v5. A mesma fase executava apenas `verify_generative_corpus_v074.py`, provando o corpus inicial 1.342/1.342 em vez da mistura corrente Micro v3 baseada em 2.563 rich SFT + 52.500 context SFT + 55.063 replay.
**Causa:** a arquitetura e o currículo evoluíram, mas o agregador de release não trocou sua prova corrente; testes predecessores permaneceram válidos historicamente, porém deixaram de representar o candidato atual.
**Correção/regra permanente:** gates de release devem apontar explicitamente para a autoridade corrente indicada no manifest. Parity do predecessor pode permanecer como regressão histórica, mas não substitui parity da arquitetura atual. Corpus corrente precisa validar seus próprios hashes, counts, validation isolation e holdout leakage. Sempre registrar a troca no agregador; nunca adaptar o runtime para carregar um formato superseded só para fazer um gate stale passar.

### 10.175 — Verificador de identidade não pode fixar o ordinal `alpha.1`
**Falha observada (2026-08-25):** depois de toda a bateria behavior passar, `verify_project.py` rejeitou a identidade válida `0.7.4-alpha.2` porque usava regex literal `0\.7\.[0-9]+-alpha\.1`.
**Causa:** o gate confundiu a convenção de uma release anterior com o schema de versão do projeto.
**Correção/regra permanente:** validar a gramática da versão candidata (`0.7.<patch>-alpha.<ordinal>` com inteiros positivos) e coerência com manifest/docs, nunca um ordinal hard-coded. Corrigir apenas o gate; não renomear a candidata para satisfazer uma asserção stale. Qualquer mudança no verificador invalida receipts anteriores do digest e não autoriza promoção retroativa.

### 10.176 — Harness de continuidade não deve adivinhar nome de artefato de avaliação
**Falha operacional (2026-08-25):** ao retomar a campanha pós-diálogo, o primeiro probe tentou abrir `evaluation/dialogue_v074/DIALOGUE_RUBRIC.json`, mas a árvore canônica realmente contém `DIALOGUE_EVALUATION.json`. O relatório Markdown foi lido corretamente; a tentativa JSON falhou antes de qualquer alteração funcional.
**Causa:** o nome do arquivo foi reconstruído por significado conceitual em vez de ser enumerado da árvore atual, recorrendo à mesma classe das lições 10.73/10.146.
**Correção/regra permanente:** antes de consumir evidence, listar os artefatos reais do diretório ou ler o manifest da campanha; nomes de rubric/evaluation/checkpoint/teste nunca são inferidos por memória. Uma falha de path do harness não é falha do runtime e deve ser corrigida sem renomear o artefato canônico apenas para acomodar o chamador.

### 10.177 — Novo intent semântico não pode roubar uma pergunta multipartes nem apagar garantia histórica
**Falha observada:** após adicionar `QUANTIZATION_SAVINGS` e uma resposta mais concreta para Transformer↔RNN, o gate histórico de conversational correctness falhou: uma pergunta que continha simultaneamente quantização e KV cache foi capturada pelo intent simples de quantização e perdeu o eixo KV; a resposta Transformer↔RNN preservou o sentido, mas removeu as garantias auditáveis históricas `Não existe` e `depende`.
**Causa:** a precedência de intents específicos não respeitou cardinalidade semântica, e o enriquecimento textual substituiu em vez de estender a afirmação normativa já coberta por regressão.
**Correção/regra permanente:** intents de comparação/multipartes devem ter precedência sobre intents de um único tópico. Ao enriquecer uma resposta histórica, preservar literalmente ou de forma auditavelmente equivalente as garantias centrais exigidas pelos gates (`Não existe superioridade universal...`, `depende...`) e acrescentar detalhes sem reduzir a cobertura observável.

### 10.178 — Piso RAG por dois termos ainda pode aceitar evidência falsa quando os termos são genéricos ou a entidade não coincide
**Falha observada:** após exigir dois termos distintos no RAG, `Que bateria o Jacarandá-4 usa?` ainda foi sombreado por um documento de outro projeto que compartilhava apenas `usa` + `bateria`, impedindo a memória estruturada de responder. A pergunta científica sobre fluxos oceano-atmosfera ainda admitiu o documento de model authority porque auxiliares como `pode`/`ser` completaram artificialmente o piso de dois termos.
**Causa:** contagem de overlaps semânticos não distinguia entidade estruturada obrigatória de termos genéricos/auxiliares.
**Correção/regra permanente:** quando a consulta contém entidade estruturada (token com dígito e `-`/`_`), ao menos uma entidade estruturada da consulta deve ocorrer no chunk antes de qualquer score positivo. A lista de stopwords do RAG deve excluir auxiliares e verbos genéricos que não fornecem topicalidade (`ser`, `pode/podem`, formas genéricas de `usar` etc.). Piso numérico de termos só é válido depois desses filtros.

### 10.179 — Remover falso RAG pode expor falso positivo do retriever interno; extrator lexical deve respeitar qualificadores de relação
**Falhas observadas:** após endurecer o RAG, a consulta científica oceano-atmosfera deixou de ser contaminada pelo documento RAG, porém o retriever interno aceitou com baixa confiança uma resposta de Shakespeare, impedindo a consulta ao Open Knowledge. Em paralelo, a extração determinística de `código` em `Seu código interno é IP27-X` devolveu `interno`, pois tratou a palavra qualificadora entre a relação e o verbo como se fosse o valor.
**Causa:** (1) candidate acceptance interno ainda permite topicalidade lexical fraca sem cobertura mínima de termos de conteúdo em algumas perguntas fora do domínio Golden; (2) o parser lexical de código reconhecia `código ` genericamente antes de resolver formas `código <qualificador> é <valor>`.
**Correção/regra permanente:** a rota de conhecimento interno deve rejeitar candidatos semanticamente desconectados por um guard de cobertura lexical/conceitual antes de bloquear fallback Open Knowledge, sem baixar ou mascarar Golden existentes. Extratores determinísticos de relação devem reconhecer qualificadores (`código interno é`, `identificador externo é` etc.) e extrair somente depois do delimitador relacional, nunca a primeira palavra após o nome da relação.

### 10.180 — Relação explícita em frase adjacente e entidade estruturada precisam de binding antes de qualquer fallback semântico
**Falhas observadas no novo holdout pós-correção:** `Buriti-12` estava na primeira frase e `O código interno é BT12-Q` na segunda; o scorer escolheu a primeira frase antes que o extrator de código fosse consultado. Em outra pergunta, `Quando o Buriti-12 foi lançado?` não encontrou a relação no RAG, porém o retriever interno aceitou conhecimento genérico de incerteza sem conter `Buriti-12`.
**Causa:** (1) extração determinística da relação ocorria somente sobre a sentença top-1; (2) o knowledge retriever não exigia preservação de entidade estruturada desconhecida, apenas de acrônimos.
**Correção/regra permanente:** para perguntas relacionais explícitas, uma sentença de valor pode herdar a entidade estruturada da sentença imediatamente anterior sob o mesmo discourse bridge conservador, e esse caminho deve ser avaliado antes do pointer top-1. Qualquer candidato de conhecimento interno para consulta com entidade estruturada deve conter exatamente a mesma entidade; topicalidade genérica ou formato interrogativo semelhante nunca substituem entity binding.

### 10.181 — Holdout de answer-type deve validar a seção direta sem penalizar valores legítimos citados na evidence
**Falha observada:** o novo holdout marcou como FAIL `Resposta direta: BT12-Q` porque a seção posterior `Evidência no contexto:` também continha o nome da coordenadora `Tainá Freitas`. O runtime havia extraído corretamente o código; a asserção procurava a ausência do nome concorrente no output inteiro.
**Causa:** o harness misturou a propriedade do valor direto com o conteúdo auditável da evidence, repetindo a classe já documentada em 10.111.
**Correção/regra permanente:** testes de tipo/valor devem recortar e validar `Resposta direta:` separadamente. A evidence pode legitimamente conter outros atributos da mesma sentença e não deve ser apagada para fazer o gate passar.

### 10.182 — Fixture RAG de replace não pode remover a própria topicalidade exigida pelo hardening
**Falha observada (2026-08-25):** depois do hardening entity-aware/stopword-aware, `nd_rag_test` passava sem Semantic Ranker, mas falhava no ramo ranked. O teste substituía `kv-doc` por `KV cache atualizado reutiliza chaves e valores e reduz recomputação causal por token.` e, logo depois, consultava `Como reduzir recomputação da atenção durante inferência autoregressiva?`. Com o novo piso seguro de dois termos de conteúdo, o documento substituído preservava somente `recomputação` como overlap lexical exato; portanto ele era corretamente excluído antes do reranker.
**Causa:** o fixture de replace foi criado quando um overlap esparso menor ainda era aceito e ficou semanticamente stale após o hardening. Relaxar o runtime para satisfazê-lo reabriria a classe de contaminação eliminada em 10.178.
**Correção/regra permanente:** fixtures que pretendem testar reranking precisam preservar a topicalidade mínima exigida pela política corrente. Corrigir o texto do documento de teste para manter pelo menos dois termos de conteúdo da consulta ampla; não reduzir `required_matches`, não reintroduzir auxiliares como evidência e não usar semantic rerank para ressuscitar candidato lexicalmente não admitido.

### 10.183 — Novo executável ligado ao core sanitizado precisa herdar também as flags de link ASan/UBSan
**Falha observada (2026-08-25):** o build normal v0.7.4-alpha.2 passou integralmente, porém `verify_sanitize.sh` falhou ao linkar `nd_independent_dialogue_v074`. O target novo linkava `neuraldesk_core`, cujos objetos estavam instrumentados com ASan/UBSan, mas havia sido omitido da lista CMake que aplica `-fsanitize=address,undefined` aos executáveis. O linker então reportou símbolos `__asan_*`/`__ubsan_*` não resolvidos.
**Causa:** a adição do novo harness atualizou `add_executable`/link normal, mas não a segunda autoridade manual de targets sanitizados.
**Correção/regra permanente:** todo novo executável C/C++ que linka o core compartilhado deve entrar, no mesmo delta, na lista/gate de sanitizer quando `ND_SANITIZE=ON`. Não remover o teste, não desligar instrumentação e não tratar sucesso do build normal como cobertura sanitizer. O gate de build deve falhar fechado se qualquer target distribuído/testável ficar fora das flags de compile/link sanitizadas.

### 10.184 — Holdout que possui recursos dinâmicos precisa de cleanup único também nos caminhos de erro
**Falha observada (2026-08-25):** após corrigir o link sanitizer, o runtime ASan chegou ao `nd_post_dialogue_holdout_v074_test` e reportou 524.800 bytes vazados do Semantic Ranker. O ranker estava corretamente owned pelo `NDAssistant`; o problema era o harness: depois do setup, cada `if (ask(...)) return 1;` encerrava o processo sem `nd_assistant_free()`, `unlink(memory)` e `unlink(run journal)`.
**Causa:** o teste implementou teardown apenas no setup-fail e no caminho terminal normal; erros durante os 18 probes pulavam o owner cleanup.
**Correção/regra permanente:** harnesses que carregam assistant/modelos/mmap/memória devem convergir sucesso e falha para um único bloco de cleanup. ASan leak em teste é gate real de ownership e não pode ser descartado como irrelevante. Resposta funcional falha deve continuar retornando erro, mas somente depois de liberar todos os recursos adquiridos.

### 10.185 — Owner carregado pelo NDAssistant precisa existir também no teardown canônico
**Falha observada (2026-08-25):** mesmo depois de convergir todos os caminhos do novo holdout para `nd_assistant_free()`, LeakSanitizer continuou reportando exatamente 524.800 bytes alocados em `nd_semantic_ranker_load()`. A inspeção mostrou que `nd_assistant_load_semantic_ranker()` assume ownership e libera o ranker anterior em reload, mas `nd_assistant_free()` não chamava `nd_semantic_ranker_free()` antes de zerar a struct.
**Causa:** a superfície de lifecycle evoluiu quando o Semantic Ranker foi incorporado ao assistant, porém o destructor canônico não foi sincronizado com o novo owner.
**Correção/regra permanente:** toda adição de recurso owned ao `NDAssistant` (heap, mmap, file handle, mutex, model/ranker) deve atualizar no mesmo delta load/reload/free e possuir sanitizer gate que exercite teardown após uso real. `memset()` nunca substitui destructor de sub-owner dinâmico. Reload seguro não prova free final seguro.

### 10.186 — Sanitizer de kernel denso deve ser particionado sem reduzir a cobertura total
**Falha operacional (2026-08-25):** `nd_generative_mechanics_test` completo passa em ~3,5 s no build normal, mas a combinação ASan+UBSan sobre Micro v3/NDGM v5 (11.229.760 parâmetros) excedeu repetidamente janelas de 180–270 s. O custo vem sobretudo dos 20 probes Q8/Q4, cada um executando três full-forwards densos instrumentados. Nenhum erro foi emitido antes dos timeouts, mas timeout não pode virar PASS.
**Risco:** reduzir de 20 probes para poucos casos apenas no sanitizer tornaria a coverage quantitativamente menor e esconderia paths/índices específicos.
**Correção/regra permanente:** manter o modo padrão integral do teste inalterado para VERIFY e permitir particionamento fail-fast do mesmo conjunto no sanitizer: um bloco core (oracle incremental/full, KV/COW/prefix/speculative) e slices disjuntos cuja união cobre exatamente os 20 probes quantizados. Cada slice precisa provar todos os casos que recebeu; receipt sanitizer só pode ser emitido depois da cobertura 0..19 completa. Particionamento operacional não autoriza reduzir thresholds, formatos ou número total de probes.

### 10.187 — SFT não pode supervisionar apenas o prefixo curto da maioria das respostas sem declarar a perda de cobertura
**Falha observada (2026-08-25):** após concluir o pretraining Micro v3 em 367/367 batches e executar 50 minibatches SFT, os seis probes históricos continuaram 0/6 e a geração permaneceu repetitiva. A auditoria do objetivo mostrou que `sftrow()` em `seqLen=64` reservava no máximo 24 tokens para a resposta. No corpus rico v0.7.4, a resposta mediana possui 63 tokens, p90 116 e máximo 332; 2.249/2.563 respostas (87,75%) excedem 24 tokens. Somando todos os exemplos, apenas 32,75% dos tokens de resposta recebiam supervisão possível sob esse packing.
**Causa:** o packing priorizou espaço fixo para prompt e truncou sistematicamente a cauda das respostas, enquanto a métrica de corpus contava exemplos completos. Mais parâmetros ou mais steps não corrigem um alvo que nunca apresenta a maior parte do texto esperado.
**Correção/regra permanente:** cobertura de SFT deve ser medida em tokens de resposta efetivamente supervisionados, não apenas em quantidade de exemplos apresentados. Mudança de packing/sequence length é mudança semântica do objetivo e precisa de nova identidade/config hash; checkpoint antigo não pode ser “resumido” silenciosamente sob o objetivo novo. Quando um pretraining já concluído é reutilizado, tratá-lo como predecessor imutável e iniciar uma fase SFT nova explicitamente lineage-bound ao SHA do checkpoint/weights, com optimizer/state próprios. Gates devem registrar distribuição de comprimentos, cobertura de tokens, truncamento e respostas brutas.

### 10.188 — SFT v2 terminal com alta cobertura mas 0/6 bloqueia segunda época; separar qualidade do backbone de quantização
**Falha/achado observado:** o Micro v3/NDGM v5, após pretraining completo 367/367 e uma época SFT v2 completa 321/321 com `seqLen=128`, `promptCap=48` e 93,39% dos tokens de resposta supervisionados, reduziu a validation loss de `3.724779` para `3.143320` e elevou teacher-forced top-1 para ~65,53% numa amostra treinável, mas permaneceu `0/6` nos seis holdouts em geração autoregressiva FP32. Q8 e Q4 também ficaram `0/6`. A paridade de primeiro token terminal foi Q8=`18/20` e Q4=`19/20`, acima dos pisos históricos, demonstrando que quantização não é a causa primária da falha comportamental.

**Correção/regra permanente:** uma época SFT de alta cobertura que termina `0/6` não recebe segunda época automática apenas porque loss/teacher-forcing melhoraram. O checkpoint deve ser `REJECTED_NOT_PROMOTABLE` e a próxima experiência precisa alterar uma propriedade causal mensurável (escala/diversidade de pretraining, objetivo, dados ou arquitetura), mantendo os seis holdouts como regression-only e criando holdout novo se surgir candidato. Qualidade FP32 deve ser decidida antes de quantização; Q8/Q4 parity boa não resgata backbone FP32 incoerente.

### 10.189 — Corpus disponível não equivale a corpus efetivamente visto; medir cobertura por fonte no pretraining
**Falha/achado observado:** o Micro v3 possui 11.229.760 parâmetros e a mistura first-party v2 contém 52.500 registros contextuais (~4,05 milhões de tokens tokenizados), porém a política de época `ONE_FULL_RICH_REPLAY_COVERAGE` encerrou o pretraining após 367 minibatches de 7 rich + 3 context. Isso apresentou todo o replay rico, mas somente 1.101/52.500 registros contextuais (~2,10%), deixando ~97,90% dessa fonte sem nunca contribuir para gradiente. Aumentar capacidade e SFT sobre esse backbone data-starved terminou 0/6 mesmo após melhorar packing e coverage de respostas.

**Correção/regra permanente:** relatórios de treino precisam distinguir `availableRows/tokens` de `optimizerSeenRows/tokens` por fonte. Uma fonte grande não pode ser usada como argumento de escala se a definição de época encerra antes de cobri-la. Quando uma fonte sintética/contextual precisa de cobertura ampla sem dominar estilo, usar uma fase de pretraining com identidade própria, epoch definido pela cobertura da fonte grande e ponderação explícita de loss por fonte; a ponderação/configuração deve entrar no config hash e em checkpoint/resume. Não reutilizar checkpoint SFT rejeitado como predecessor; usar somente um checkpoint pré-SFT íntegro e SHA-bound.

### 10.190 — Retokenização Python dentro do hot loop pode dominar treino resumível; cache derivado deve ser integrity-bound
**Achado observado:** no Data-Scale Pretraining v2, um microbenchmark com os tensores já preparados mediu ~2.282 tokens/s em batch 64, mas a campanha real avançou muito mais lentamente porque cada minibatch chamava o tokenizer Python novamente para dezenas de registros. Como a campanha é dividida em processos retomáveis, repetir parsing/tokenização no hot path aumenta custo sem acrescentar aprendizagem.

**Correção/regra permanente:** corpus de treino congelado pode gerar um cache tokenizado derivado, desde que seja first-party, contenha somente splits `TRAINING_ELIGIBLE`, fique ligado por SHA ao tokenizer e ao corpus-fonte, tenha formato/versionamento e integrity verification explícitos, e nunca inclua validation/Golden/holdout. O trainer deve revalidar esses bindings antes de usar o cache. Cache muda desempenho/I/O, não objetivo; paridade de sequência tokenizada cache↔tokenizer precisa ser provada antes da campanha.

### 10.191 — Batch pequeno evita pressão de memória, mas AdamW por microbatch desperdiça throughput; acumulação deve ter identidade própria
**Achado observado:** no Data-Scale Pretraining v2, batch 64 nativo sofreu degradação operacional severa nesta CPU, enquanto batch 8 permaneceu estável e alcançou checkpoint 350/7500. Porém batch 8 executa AdamW oito vezes para processar a mesma quantidade de sequências que um batch efetivo 64, aumentando custo de optimizer sem ampliar cobertura de dados.

**Correção/regra permanente:** quando batch efetivo grande causa pressão de memória, preferir gradient accumulation bounded: microbatches pequenos, mesma composição total por fonte, loss escalada explicitamente e um único clip/AdamW por batch efetivo. `microbatchSize`, `accumulationSteps`, composição efetiva e ordem de acumulação entram no config hash/checkpoint. A trajetória de um checkpoint batch-pequeno não pode ser retomada sob acumulação; preservar o checkpoint anterior como linha supersedida/diagnóstica e reiniciar do predecessor comum. Antes da campanha, exigir `uninterrupted == pause→resume` no novo modo.

### 10.192 — Nome de versão histórica não é autoridade quando attestations entram em conflito
**Achado (auditoria profunda v0.7.5):** a Biblioteca preserva evidência de uma linha `v0.63` com corpus/Golden e também uma attestation normativa `V0_63_NOT_CREATED_NEXT_ANDROID_BOUNDARY_UNAVAILABLE`. Tratar apenas o número `0.63` como uma única verdade faria o merge herdar uma alegação de release contraditória.
**Correção/regra permanente:** auditar por capability + bytes/hashes/contrato. Uma mecânica historicamente atestada pode ser reexpressa no owner atual sem herdar automaticamente o status da release que a descrevia. Conflitos de lineage devem permanecer documentados e nunca ser resolvidos inventando uma cronologia.

### 10.193 — Hash histórico de Golden não autoriza recriar seus itens
**Achado:** a governança v0.63 registra hashes canônicos e contagens para corpus 490 / Golden 250, porém os bytes brutos `curated-corpus-records-v1.jsonl` e `golden-evaluation-suite-v1.json` não foram recuperados na Biblioteca disponível nesta auditoria.
**Correção/regra permanente:** portar o mecanismo de rights/provenance/split/PII/epistemic separation e registrar os hashes como `EVIDENCE_ONLY_BYTES_NOT_RECOVERED`; `historicalGolden250Imported=false` deve permanecer obrigatório. Nunca gerar 250 itens novos e chamá-los de Golden histórico.

### 10.194 — Token streaming computacional só fecha o contrato quando existe delta UTF-8 seguro
**Achado:** uma API incremental que emite apenas token IDs recupera chunked prefill/cancel/deadline/backpressure, mas ainda não satisfaz a regra 10.130 de callback de texto. Em tokenizer byte-level, um token pode carregar parte de um code point UTF-8.
**Correção/regra permanente:** manter token streaming como primitive e oferecer adaptador no mesmo owner tokenizer/generative que acumula bytes até um prefixo UTF-8 válido antes do callback. Teste obrigatório deve usar code point multibyte real e provar que pausa/resume não altera o texto final.

### 10.195 — Gradient accumulation muda a trajetória e exige checkpoint somente em fronteira do optimizer
**Achado:** batch 8 evita pressão de memória, mas um AdamW por microbatch não equivale ao batch efetivo 64 planejado. Retomar um checkpoint batch8 dentro de uma política acumulada misturaria duas trajetórias diferentes.
**Correção/regra permanente:** `accumulationSteps`, microbatch e effective batch entram no config hash; cada grupo escala a loss pelo número real de microbatches, faz um único clip/AdamW e checkpoints só podem ocorrer em fronteiras do optimizer. A adoção exige `uninterrupted == pause→resume` em model-state, AdamW e FP32/Q8/Q4.

### 10.196 — Gerador crítico não pode depender indiretamente do caminho do precheck por import de outro trainer
**Falha observada (2026-08-25):** o `static` v0.7.5 bloqueou `training/build_token_cache_v074_v2.py` em `verify_lessons_protocol.py`. O builder de fato executava `PRE`, porém obtinha essa constante por `from train_generative_micro_v074_v3 import ... PRE ...`; o arquivo não declarava explicitamente `pre_generation_lessons_check.py` como sua própria autoridade.
**Risco:** uma refatoração do trainer importado pode alterar/remover a constante e desligar silenciosamente a lei de leitura no builder derivado. Um caminho de geração crítico não deve depender de wiring transitivo para cumprir a Regra Zero.
**Correção/regra permanente:** cada gerador/treinador/build crítico deve declarar e executar diretamente o caminho canônico `scripts/pre_generation_lessons_check.py` na própria fonte. Compartilhar helpers é permitido, mas a ligação da Regra Zero não é transitiva e deve ser verificável por arquivo.

### 10.197 — Manifest v0.7.5 perdeu a prioridade literal da primeira documentação
**Falha observada (2026-08-25):** `verify_documentation_consistency.py` rejeitou a candidata porque `PROJECT_MANIFEST.json.canonicalDocs` enumerava os `docs/*.md`, mas não mantinha `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md` como a primeira entrada, contrariando a própria Regra Zero.
**Causa:** a sincronização da lista de documentação histórica v0.7.5 regenerou o catálogo a partir de `docs/` e perdeu o item especial que não pertence àquela pasta.
**Correção/regra permanente:** `canonicalDocs[0]` deve ser sempre e literalmente `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md`; somente as entradas seguintes são a enumeração ordenada de `docs/*.md`. Geradores de manifest/documentação não podem reconstruir essa lista apenas por glob de `docs/`.

### 10.198 — Freeze não pode herdar rollback/sourceBaseline hard-coded de releases anteriores
**Falha observada (2026-08-25):** após VERIFY+SANITIZER v0.7.5 passarem, a auditoria pré-freeze encontrou `PROJECT_MANIFEST.json.rollback.externalRelease` ainda apontando para v0.7.1, embora `sourceBaseline` e os documentos correntes reconhecessem v0.7.3 como última release externamente atestada. `scripts/generate_release_metadata.py` também publicava literais `sourceBaseline=0.7.2-alpha.1` e `externallyAttestedRollback=0.7.1-alpha.1`.
**Risco:** um ZIP tecnicamente correto poderia publicar lineage/rollback incoerente e tornar recuperação futura ambígua. Evidence gerada por literais antigos não é autoridade da release corrente.
**Correção/regra permanente:** rollback externo e source/development predecessor devem vir das autoridades correntes do manifest, com SHA quando disponível. Geradores de evidence não podem hard-code versões correntes. Auditoria pré-freeze deve comparar manifest, CURRENT_STATE, rollback atestado e metadata antes de empacotar; qualquer correção invalida receipts de input e exige novo ciclo.

### 10.199 — Sanitizer `Debug -O0` pode tornar kernel denso operacionalmente inexequível sem ampliar cobertura
**Achado observado (2026-08-25):** o gate `nd_generative_mechanics_test --core` da Micro v3/NDGM v5, com 11.229.760 parâmetros, permaneceu mais de 10 minutos sob ASan/UBSan em `Debug -O0` sem emitir erro nem status terminal. O mesmo source, mesmos fixtures, mesmos sanitizers, `-Werror`, leak detection e mesmos asserts, recompilado como `Debug` instrumentado com `-O1 -g`, concluiu o core integral em 12,41 s com oracle `maxAbs=0`, COW/prefix e speculative 8/8 + rejection/rollback PASS.
**Correção/regra permanente:** para kernels numéricos densos, o gate sanitizer pode usar otimização bounded `-O1 -g` desde que ASan e UBSan continuem ativos, warnings permaneçam erros, asserts/testes/probes não sejam reduzidos e a configuração esteja explícita no pipeline. Otimizar a compilação do sanitizer não é autorização para retirar casos. Mudança das flags oficiais de sanitizer altera o input canônico do release e exige novo VERIFY/SANITIZER no digest resultante.
