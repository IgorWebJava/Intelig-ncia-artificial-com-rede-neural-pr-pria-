import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.plugins.ternary_bitwise import TernaryBitwisePlugin
from qcnn.plugins.milui_expansion import MiluiExpansionPlugin
from qcnn.plugins.adjacency_filter import AdjacencyFilterPlugin
from qcnn.plugins.harmonic_frequency import HarmonicFrequencyPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS, TRANSICOES_PERMITIDAS

class TestSymbolicFoundations(unittest.TestCase):
    def test_matriz_22_letras_integrity(self):
        self.assertEqual(len(MATRIZ_22_LETRAS), 22)
        for letra, data in MATRIZ_22_LETRAS.items():
            self.assertIn("caractere", data)
            self.assertIn("gematria", data)
            self.assertIn("milui", data)
            self.assertIn("frequencia_hz", data)
            self.assertIn(letra, TRANSICOES_PERMITIDAS)

    def test_ternary_bitwise_plugin(self):
        plugin = TernaryBitwisePlugin()
        ctx = QcnnExecutionContext(prompt="Alef")
        ctx = plugin.execute(ctx)
        
        self.assertIn("Alef", ctx.active_nodes)
        node_alef = ctx.active_nodes["Alef"]
        self.assertEqual(node_alef.letra, "Alef")
        self.assertEqual(node_alef.obter_estado_str(), "00 (Vácuo / Superposição)")
        
        node_alef.definir_estado(1)
        self.assertTrue(node_alef.bit_ativacao)
        self.assertEqual(node_alef.obter_estado_str(), "10 (Ativação Construtiva)")

    def test_milui_expansion_plugin(self):
        plugin = MiluiExpansionPlugin()
        ctx = QcnnExecutionContext(prompt="Shin")
        ctx = plugin.execute(ctx)
        
        self.assertEqual(ctx.target_seed, "Shin")
        self.assertIn("camada_1", ctx.metadata)
        self.assertEqual(ctx.metadata["camada_1"], ["Shin", "Yud", "Nun"])

    def test_adjacency_filter_plugin(self):
        plugin = AdjacencyFilterPlugin()
        ctx = QcnnExecutionContext(prompt="Alef")
        ctx.target_seed = "Alef"
        ctx.metadata["camada_1"] = ["Alef", "Lamed", "Pei"]
        ctx = plugin.execute(ctx)
        
        self.assertTrue(len(ctx.chain) > 0)
        self.assertEqual(ctx.chain[0], "Alef")

    def test_harmonic_frequency_plugin(self):
        plugin = HarmonicFrequencyPlugin()
        ctx = QcnnExecutionContext(prompt="Alef")
        ctx.chain = ["Alef", "Lamed"]
        ctx = plugin.execute(ctx)
        
        expected_hz = round(MATRIZ_22_LETRAS["Alef"]["frequencia_hz"] + MATRIZ_22_LETRAS["Lamed"]["frequencia_hz"], 2)
        self.assertEqual(ctx.total_frequency_hz, expected_hz)

if __name__ == "__main__":
    unittest.main()
