<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 92 — Database Schema & Ownership

Recommended logical schemas:

```text
platform
identity
configuration
chat
knowledge
tools
training
audit
integration
```

Do not allow pages to share arbitrary tables.

Access is mediated by services with explicit ownership.
