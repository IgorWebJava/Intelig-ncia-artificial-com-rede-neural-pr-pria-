#!/usr/bin/env python3
from pathlib import Path
import json,os,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
import android_toolchain_admission as a
r=a.inspect();assert not r['apkGenerated'] and not r['apkSigned'] and not r['artDeviceExecuted']
with tempfile.TemporaryDirectory() as td:
 d=Path(td);old=os.environ.get('PATH','');manifest={}
 for n in a.TOOLS:
  p=d/n;p.write_text('#!/bin/sh\nexit 0\n');p.chmod(0o755);manifest[n]={'sha256':a.sha(p)}
 m=d/'manifest.json';m.write_text(json.dumps(manifest));os.environ['PATH']=str(d);rr=a.inspect(m);os.environ['PATH']=old;assert rr['admitted'] and not rr['apkGenerated']
print('ANDROID_TOOLCHAIN_ADMISSION PASS real_state=%s fixture_hash_pin=true apk=false art=false'%r['state'])
