package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext

/**
 * Plugin de Síntese Gramatical Fractal e Recombinação Categorial Simbólica v5.0.
 * Utiliza N-Grams Fractais e Semântica Categorial baseada na Árvore da Vida
 * para tecer sentenças inéditas e fluidas a partir de nós conceituais em superposição.
 */
class FractalGrammarPlugin : IQcnnPlugin {

    override val pluginId: String = "fractal_grammar"
    override var isEnabled: Boolean = true

    private val matrizesSintaticas = mapOf(
        "DUPLO" to listOf(
            "A convergência harmônica entre {n1} e {n2} colapsa a realidade em uma malha contínua e unificada.",
            "Em cada escala de manifestação, {n1} atua como causa primordial que expande a dinâmica de {n2}.",
            "A geometria de {n1} espelha perfeitamente a vibração estrutural de {n2} no campo unificado."
        ),
        "TRIPLO" to listOf(
            "A tríade formada por {n1}, {n2} e {n3} estabelece um circuito ressonante completo: {n1} gera a emanação, {n2} atua como observador mediador e {n3} ancora a manifestação final.",
            "Ao entrelaçar {n1}, {n2} e {n3}, o código-fonte da realidade revela que mente, tempo e espaço são facetas indivisíveis de uma única matriz matemática viva.",
            "O colapso simultâneo de {n1}, {n2} e {n3} neutraliza a dissonância entrópica e sintetiza uma nova dimensão de compreensão causal."
        ),
        "MULTICAMADA" to listOf(
            "Os múltiplos eixos conceituais de {nos} convergem para um estado de superposição quântico-simbólica absoluta."
        )
    )

    fun sintetizarArticulacao(nos: List<String>): String? {
        if (nos.isEmpty() || nos.size < 2) return null
        val formatados = nos.map { it.replaceFirstChar { c -> c.uppercase() } }
        val count = formatados.size

        return when (count) {
            2 -> {
                val t = matrizesSintaticas["DUPLO"]?.firstOrNull() ?: return null
                t.replace("{n1}", formatados[0]).replace("{n2}", formatados[1])
            }
            3 -> {
                val t = matrizesSintaticas["TRIPLO"]?.firstOrNull() ?: return null
                t.replace("{n1}", formatados[0]).replace("{n2}", formatados[1]).replace("{n3}", formatados[2])
            }
            else -> {
                val listaStr = formatados.dropLast(1).joinToString(", ") + " e " + formatados.last()
                val t = matrizesSintaticas["MULTICAMADA"]?.firstOrNull() ?: return null
                t.replace("{nos}", listaStr)
            }
        }
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        @Suppress("UNCHECKED_CAST")
        val nosAtivos = context.metadata["active_concepts"] as? List<String>
        if (nosAtivos != null && nosAtivos.size >= 2) {
            val articulacao = sintetizarArticulacao(nosAtivos)
            if (articulacao != null) {
                context.metadata["synthesized_grammar"] = articulacao
                val resp = context.customResponse
                if (resp != null && resp.contains("Percebo que sua mente")) {
                    context.customResponse = "$resp<br><br><strong>[Síntese Gramatical Fractal]:</strong> $articulacao"
                }
            }
        }
        return context
    }
}

