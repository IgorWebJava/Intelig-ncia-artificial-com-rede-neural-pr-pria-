#include "nd_generative.h"
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    NDGenerativeModel *model = NULL;
    uint32_t tokens[ND_GEN_CONTEXT];
    float logits[ND_GEN_VOCAB];
    int i;
    if (argc < 3 || argc > (int)ND_GEN_CONTEXT + 2) {
        fprintf(stderr, "usage: %s MODEL TOKEN [TOKEN...]\n", argv[0]);
        return 2;
    }
    for (i = 2; i < argc; ++i) {
        char *end = NULL;
        unsigned long value;
        errno = 0;
        value = strtoul(argv[i], &end, 10);
        if (errno != 0 || end == argv[i] || *end != '\0' || value >= ND_GEN_VOCAB) {
            return 3;
        }
        tokens[i - 2] = (uint32_t)value;
    }
    if (nd_gen_load(argv[1], &model) != 0) {
        return 4;
    }
    if (nd_gen_full_forward(model, tokens, (size_t)(argc - 2), logits, ND_GEN_VOCAB) != 0) {
        nd_gen_free(model);
        return 5;
    }
    for (i = 0; i < (int)ND_GEN_VOCAB; ++i) {
        printf("%d %.9g\n", i, (double)logits[i]);
    }
    nd_gen_free(model);
    return 0;
}
