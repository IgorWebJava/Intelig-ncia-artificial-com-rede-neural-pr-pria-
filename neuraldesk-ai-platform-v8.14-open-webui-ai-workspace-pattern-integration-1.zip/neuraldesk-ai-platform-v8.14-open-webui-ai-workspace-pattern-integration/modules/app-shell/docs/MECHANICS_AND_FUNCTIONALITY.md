<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/MECHANICS_AND_FUNCTIONALITY.md -->
# Mechanics and Functionality — App Shell

## Scope

This document is the authoritative functional map for the current `app-shell` template UI. It distinguishes visual/template behavior from future executable engine behavior.

## Specialized mechanic

**Continue + Work Graph + Waiting for You**

## Mechanic → future engine traceability

| UI mechanic | Current template status | Future engine status | Future engine owners |
|---|---|---|---|
| Continue | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.project-runtime`, `neural-engine.task-runtime`, `neural-engine.checkpoint-resume-runtime`, `neural-engine.notification-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Work Graph | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.project-runtime`, `neural-engine.task-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Waiting for You | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.notification-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.task-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Quick Create | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.project-runtime`, `neural-engine.conversation-runtime`, `neural-engine.agent-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Recent Work | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.project-runtime`, `neural-engine.task-runtime`, `neural-engine.checkpoint-resume-runtime`, `neural-engine.notification-runtime`, `neural-engine.approval-policy-guardrails`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Running Tasks | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.task-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Approvals | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.approval-policy-guardrails`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Context Lens | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.context-compiler`, `neural-engine.project-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Provenance | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Trust Layer | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.approval-policy-guardrails`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |

## Truthfulness rule

A visible control, status, timeline, agent/tool indicator or result card must not be documented as executable unless the corresponding future engine modules are actually implemented and integration tests prove the capability.

## Source of truth

- UI: module canonical HTML/CSS/JS.
- Capability contracts: `module.manifest.json` and `contracts/`.
- Future engine traceability: `neural-engine/registry/ui-mechanic-traceability.json`.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
