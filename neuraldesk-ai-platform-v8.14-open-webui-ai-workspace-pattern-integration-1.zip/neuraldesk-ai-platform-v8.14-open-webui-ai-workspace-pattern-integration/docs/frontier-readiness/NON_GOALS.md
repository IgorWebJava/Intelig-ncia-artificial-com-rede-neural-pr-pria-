# Non-Goals

For the documentation phase:
- no executable engine;
- no model training;
- no backend;
- no provider integration;
- no real agents/tools;
- no production security implementation.

For early executable phases:
- do not train a frontier foundation model before product/runtime baselines;
- do not default to multi-agent when a simpler path works;
- do not use computer-use when an API/tool integration is available;
- do not optimize kernels before correctness and workload measurement;
- do not declare market superiority based on feature lists.
