<!-- neuraldesk-documentation-sync: V8.8 -->

# App Shell migrations

Only this module owns migrations for its private data schema.
