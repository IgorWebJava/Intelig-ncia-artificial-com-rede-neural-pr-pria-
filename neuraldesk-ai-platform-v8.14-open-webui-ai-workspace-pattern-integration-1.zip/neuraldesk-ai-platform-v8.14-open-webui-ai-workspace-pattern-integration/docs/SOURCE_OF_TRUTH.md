<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.documentation -->
# Source of Truth

## Precedence

1. `memória/ESTADO_ATUAL.json`
2. `docs/CURRENT_STATE.md`
3. platform Module/Capability/Contract registries
4. interface `module.manifest.json`
5. interface contracts/data ownership/current module docs
6. `docs/frontier-readiness/FRONTIER_READINESS_REGISTRY.json` for future implementation sequencing
7. `platform/engine-ui-bridge/registry.json`
8. `neural-engine/registry/engine-modules.json`
9. `neural-engine/registry/capabilities.json`
9. `neural-engine/registry/ui-mechanic-traceability.json`
10. `neural-engine/registry/frontier-readiness.json`
11. engine `module.blueprint.json`
12. engine module `CURRENT_STATE.md` and `FRONTIER_READINESS.md`
13. current architecture/governance/AI handoff docs
14. reference-detail documents
15. historical baselines

## Conflict rule

If a historical/reference document disagrees with a current source, the current source wins.

## Future capability rule

A readiness document describes a **target**, not an implemented capability. `D0`, `UI0`, `PARITY-TARGET` and `DIFFERENTIATION-TARGET` must never be interpreted as executable status.

Never infer executable Neural Engine capability from documentation alone.

## Kimi K3 research evidence
`neural-engine/research/kimi-k3-2026/` is a research-reference layer. It can propose patterns but cannot override current NeuralDesk contracts, capabilities or executable-status truth.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
