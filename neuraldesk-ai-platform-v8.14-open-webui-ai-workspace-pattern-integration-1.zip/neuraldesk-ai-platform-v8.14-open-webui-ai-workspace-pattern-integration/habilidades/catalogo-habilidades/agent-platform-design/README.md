<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Agent Projects & Multi-Agent Orchestration

Skill ID: `neuraldesk.agent-platform-design.v1`

Covers project-scoped agent definitions, runtime skill registries, tool/knowledge/model bindings, agent task contracts, teams, handoffs, workflows, evaluations, versions, deployment, rollback, security and observability. Runtime agent skills remain separate from development `habilidades/`.
