#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
PHASE="${ND_VERIFY_PHASE:-all}"
CHECKPOINT=(python3 "$ROOT/scripts/verification_checkpoint.py")

precheck() { python3 "$ROOT/scripts/pre_generation_lessons_check.py"; }
mark() { "${CHECKPOINT[@]}" mark verify "$1"; }
require_phases() { "${CHECKPOINT[@]}" require verify "$@"; }

phase_static() {
  precheck
  ./scripts/clean.sh
  python3 tests/verify_cleanliness.py
  python3 tests/verify_lessons_protocol.py
  python3 -m py_compile training/*.py tests/*.py scripts/*.py
  python3 -m json.tool PROJECT_MANIFEST.json >/dev/null
  python3 tests/verify_documentation_consistency.py
  python3 tests/verify_release_pipeline.py
  mark static
}

phase_checkpoint() {
  precheck
  python3 tests/verify_verification_checkpoint.py
  mark checkpoint
}

phase_build() {
  precheck
  require_phases static
  ./scripts/build_host.sh
  mark build
}
phase_models() {
  precheck
  require_phases static build
  test -x build/ndassistant || { echo 'build/ndassistant missing; rerun prebuild phase' >&2; exit 2; }
  python3 tests/verify_retriever_model.py
  python3 tests/verify_knowledge_base.py
  python3 tests/verify_relation_model.py
  python3 tests/verify_pointer_model.py
  python3 tests/verify_materialized_datasets.py
  python3 tests/verify_dataset_hashes.py
  python3 tests/verify_open_knowledge_provenance.py
  python3 tests/verify_knowledge_retriever.py
  python3 tests/verify_relation_classifier.py
  python3 tests/verify_context_pointer_v05.py
  python3 tests/verify_open_knowledge.py
  python3 tests/verify_open_knowledge_reproducibility.py
  python3 tests/verify_semantic_ranker.py
  python3 tests/verify_historical_pira_candidate.py
  python3 tests/verify_training_checkpoint.py
  python3 tests/verify_model_authority.py
  python3 tests/verify_weight_averaging.py
  python3 tests/verify_generative_corpus_v074.py
  python3 tests/verify_generative_corpus_v074_v2.py
  python3 tests/verify_generative_holdout_isolation_v074.py
  python3 tests/verify_governance_v075.py
  python3 tests/verify_gradient_accumulation_v075.py
  python3 tests/verify_python_c_generative_parity_v074_v3.py
  mark models
}

phase_behavior() {
  precheck
  require_phases static build models
  test -x build/ndassistant || { echo 'build/ndassistant missing; rerun prebuild phase' >&2; exit 2; }
  python3 tests/verify_relation_assisted_holdout.py
  python3 tests/evaluate_context_composition.py
  ./build/nd_calculator_test
  ./build/nd_memory_test
  ./build/nd_planner_test
  SYNTH_OUT="$(./build/nd_context_synth_test \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    'Qual é a versão atual do projeto Atlas-77?' \
    'A versão anterior do projeto Atlas-77 era v3.9.1. A versão atual do projeto Atlas-77 é v4.0.0.')"
  printf '%s\n' "$SYNTH_OUT"
  grep -q 'found=1' <<<"$SYNTH_OUT"
  grep -q 'v4.0.0' <<<"$SYNTH_OUT"
  ./build/nd_candidate_acceptance_test \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build/nd_multigoal_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build/nd_assistant_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build/nd_open_knowledge_assistant_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build/nd_conversational_correctness_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build/nd_dialogue_grounding_v062_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build/nd_robust_intent_v063_recovery_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build/nd_post_dialogue_holdout_v074_test .
  ./build/nd_semantic_test
  ./build/nd_safety_test
  ./build/nd_resource_test
  ./build/nd_hardware_routing_test
  ./build/nd_execution_control_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build/nd_text_utils_test
  ./build/nd_rag_test models/neuraldesk-semantic-ranker-v0.7.1.ndsr
  ./build/nd_run_journal_test
  ./build/nd_historical_convergence_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build/nd_network_policy_test
  ./build/nd_pilot_test
  ./build/nd_model_acquisition_test
  ./build/nd_outbox_test
  ./build/nd_project_test
  ./build/nd_benchmark_test
  python3 tests/build_generative_fixture_v074.py --out-dir build/generative-fixtures
  ./build/nd_generative_mechanics_test \
    build/generative-fixtures/fixture-fp32.ndgm \
    build/generative-fixtures/fixture-q8.ndgm \
    build/generative-fixtures/fixture-q4.ndgm
  ./build/nd_generative_stream_test build/generative-fixtures/fixture-fp32.ndgm
  python3 tests/build_generative_text_fixture_v075.py --out build/generative-fixtures/text-fp32.ndgm
  ./build/nd_generative_text_stream_test \
    build/generative-fixtures/text-fp32.ndgm \
    training/data/generative_v074_v2/tokenizer-v2.ndtk
  ./build/nd_tokenizer_test training/data/generative_v074/tokenizer-v1.ndtk
  ./build/nd_offline_continuity_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  python3 tests/verify_live_qa.py
  python3 tests/verify_fail_closed.py
  python3 tests/verify_canonical_hashes.py
  python3 tests/verify_project.py
  mark behavior
}

phase_integration() {
  precheck
  require_phases static build models behavior
  ./scripts/verify_jni_host.sh
  ./scripts/verify_kotlin_host.sh
  python3 tests/verify_android_wiring.py
  python3 tests/verify_device_lab.py
  python3 tests/verify_android_toolchain_admission.py
  python3 tests/verify_cross_target_abi.py
  mark integration
}

phase_final() {
  precheck
  require_phases checkpoint static build models behavior integration
  VERSION="$(python3 -c 'import json; print(json.load(open("PROJECT_MANIFEST.json", encoding="utf-8"))["version"])')"
  DIGEST="$("${CHECKPOINT[@]}" digest)"
  printf 'VERIFY RECEIPTS PASS version=%s digest=%s phases=checkpoint,static,build,models,behavior,integration\n' "$VERSION" "$DIGEST"
  printf 'VERIFY PASS version=%s\n' "$VERSION"
}

case "$PHASE" in
  all)
    "${CHECKPOINT[@]}" reset verify
    phase_checkpoint
    phase_static
    phase_build
    phase_models
    phase_behavior
    phase_integration
    phase_final
    ;;
  checkpoint) phase_checkpoint ;;
  static) phase_static ;;
  build) phase_build ;;
  models) phase_models ;;
  behavior) phase_behavior ;;
  integration) phase_integration ;;
  final) phase_final ;;
  *) echo "ND_VERIFY_PHASE inválido: $PHASE" >&2; exit 2 ;;
esac
