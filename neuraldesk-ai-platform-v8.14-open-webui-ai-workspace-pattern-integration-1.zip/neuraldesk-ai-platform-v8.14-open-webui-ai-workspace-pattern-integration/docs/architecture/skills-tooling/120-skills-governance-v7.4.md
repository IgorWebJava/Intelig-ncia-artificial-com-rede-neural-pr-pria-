<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 120 — Skills Governance

A skill is added only when it represents durable/reproducible knowledge or process.

Tool names are implementation details; capabilities are the durable interface.

No skills document may contain secrets or private chain-of-thought.
