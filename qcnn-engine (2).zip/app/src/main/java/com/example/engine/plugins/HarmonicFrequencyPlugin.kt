package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.QcnnExecutionContext

class HarmonicFrequencyPlugin : IQcnnPlugin {
    override val pluginId: String = "harmonic_frequency"
    override var isEnabled: Boolean = true

    val tabelaHz: Map<String, Double> = MatrizLetras.MATRIZ_22.mapValues { it.value.frequenciaHz }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        var freqTotal = 0.0
        for (letra in context.chain) {
            freqTotal += tabelaHz[letra] ?: 0.0
        }
        if (freqTotal == 0.0) {
            freqTotal = tabelaHz[context.targetSeed] ?: 1.618
        }
        context.totalFrequencyHz = freqTotal
        return context
    }
}
