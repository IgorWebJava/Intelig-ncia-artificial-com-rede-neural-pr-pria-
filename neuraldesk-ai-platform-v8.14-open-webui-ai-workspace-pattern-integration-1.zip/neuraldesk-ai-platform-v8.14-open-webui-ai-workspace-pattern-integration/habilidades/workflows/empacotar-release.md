<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Empacotar Release

Pré-condições:
- validators PASS;
- documentação/memória/habilidades sincronizadas;
- testes atualizados;
- changelog;
- verification report.

Saída:
- diretório versionado;
- ZIP versionado;
- release anterior preservado.
