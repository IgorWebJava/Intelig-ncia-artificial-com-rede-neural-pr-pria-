<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Tooling Acceptance

A development tool/provider is acceptable when:

- it provides the declared abstract capability;
- it does not require architectural coupling to one AI vendor;
- it respects secrets/privacy rules;
- it can produce reproducible artifacts;
- it can participate in the required quality gate;
- its replacement does not change project semantics.
