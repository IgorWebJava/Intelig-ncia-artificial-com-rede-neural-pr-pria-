#ifndef ND_TEXT_UTILS_H
#define ND_TEXT_UTILS_H

#include <stddef.h>

int nd_text_summary_extractive(const char *text, unsigned max_sentences, char *out, size_t outcap);
int nd_text_keywords(const char *text, unsigned max_keywords, char *out, size_t outcap);

#endif
