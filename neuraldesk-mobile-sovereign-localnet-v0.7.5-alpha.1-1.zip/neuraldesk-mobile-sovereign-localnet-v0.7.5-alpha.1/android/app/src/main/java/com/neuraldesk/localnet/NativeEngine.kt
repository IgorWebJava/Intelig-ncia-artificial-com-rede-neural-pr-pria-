package com.neuraldesk.localnet

object NativeEngine {
    init { System.loadLibrary("neuraldesk_jni") }

    interface StreamCallback { fun onChunk(text: String) }

    private external fun nativeLoad(retrieverPath: String, knowledgeBasePath: String, contextQaPath: String,
        relationPath: String, openKnowledgePath: String, semanticRankerPath: String, memoryPath: String): Long
    private external fun nativeSetProfile(handle: Long, profile: Int)
    private external fun nativeSetThermalStatus(handle: Long, status: Int)
    private external fun nativeSetMasterKill(handle: Long, enabled: Boolean)
    private external fun nativeRagAddDocument(handle: Long, docId: String, text: String): Boolean
    private external fun nativeRagClear(handle: Long)
    private external fun nativeRagSave(handle: Long, path: String): Boolean
    private external fun nativeRagLoad(handle: Long, path: String): Boolean
    private external fun nativeAnswer(handle: Long, question: String, context: String?, rich: Boolean): String
    private external fun nativeAnswerStream(handle: Long, question: String, context: String?, rich: Boolean, callback: StreamCallback): String
    private external fun nativeCancel(handle: Long)
    private external fun nativeFree(handle: Long)

    @Synchronized fun load(retrieverPath: String, knowledgeBasePath: String, contextQaPath: String,
        relationPath: String, openKnowledgePath: String, semanticRankerPath: String, memoryPath: String): Long =
        nativeLoad(retrieverPath, knowledgeBasePath, contextQaPath, relationPath, openKnowledgePath, semanticRankerPath, memoryPath)
    @Synchronized fun setProfile(handle: Long, profile: MobileProfile) = nativeSetProfile(handle, profile.nativeId)
    @Synchronized fun setThermalStatus(handle: Long, status: Int) = nativeSetThermalStatus(handle, status.coerceIn(0, 6))
    @Synchronized fun setMasterKill(handle: Long, enabled: Boolean) = nativeSetMasterKill(handle, enabled)
    @Synchronized fun ragAddDocument(handle: Long, docId: String, text: String): Boolean = nativeRagAddDocument(handle, docId, text)
    @Synchronized fun ragClear(handle: Long) = nativeRagClear(handle)
    @Synchronized fun ragSave(handle: Long, path: String): Boolean = nativeRagSave(handle, path)
    @Synchronized fun ragLoad(handle: Long, path: String): Boolean = nativeRagLoad(handle, path)
    @Synchronized fun answer(handle: Long, question: String, context: String?, rich: Boolean = true): String = nativeAnswer(handle, question, context, rich)
    fun answerStream(handle: Long, question: String, context: String?, rich: Boolean = true, onChunk: (String) -> Unit): String =
        nativeAnswerStream(handle, question, context, rich, object : StreamCallback { override fun onChunk(text: String) = onChunk(text) })
    fun cancel(handle: Long) = nativeCancel(handle)
    @Synchronized fun free(handle: Long) = nativeFree(handle)
}
