# Deployment and Migration Strategy

Promotion path:
development -> sandbox -> evaluation -> safety -> shadow -> canary -> staging -> production.

Every deployable model, agent, tool, workflow or configuration must have:
version, compatibility contract, migration plan, health checks, observability, rollback and retention window.

Production objects are immutable; edits create a new version.
