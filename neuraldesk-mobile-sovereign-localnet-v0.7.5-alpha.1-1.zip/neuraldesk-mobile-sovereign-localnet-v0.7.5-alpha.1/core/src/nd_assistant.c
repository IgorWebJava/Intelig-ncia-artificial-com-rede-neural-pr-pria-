#include "nd_assistant.h"
#include "nd_context_synth.h"
#include "nd_planner.h"
#include "nd_tools.h"
#include "nd_safety.h"
#include "nd_semantic.h"
#include "nd_text_utils.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

static int has_structured_entity(const char *q) {
    if (!q) return 0;
    const unsigned char *p = (const unsigned char *)q;
    while (*p) {
        while (*p && !isalnum(*p) && *p < 128u) p++;
        int alpha = 0, digit = 0, structured = 0;
        while (*p && (isalnum(*p) || *p == '-' || *p == '_' || *p >= 128u)) {
            if (isalpha(*p) || *p >= 128u) alpha = 1;
            if (isdigit(*p)) digit = 1;
            if (*p == '-' || *p == '_') structured = 1;
            p++;
        }
        if (alpha && digit && structured) return 1;
        if (*p) p++;
    }
    return 0;
}

static uint32_t source_bit(NDAnswerSource s) {
    return (s > ND_ANSWER_NONE && s <= ND_ANSWER_BLOCKED && s != ND_ANSWER_COMPOSED)
               ? (1u << (unsigned)s)
               : 0u;
}

static unsigned char ascii_lo(unsigned char c) {
    return (c >= 'A' && c <= 'Z') ? (unsigned char)(c + ('a' - 'A')) : c;
}

static const char *find_ci_local(const char *s, const char *needle) {
    size_t n = strlen(s), m = strlen(needle);
    if (!m || m > n) return NULL;
    for (size_t i = 0; i + m <= n; i++) {
        size_t j = 0;
        for (; j < m; j++) {
            if (ascii_lo((unsigned char)s[i + j]) != ascii_lo((unsigned char)needle[j])) break;
        }
        if (j == m) return s + i;
    }
    return NULL;
}

static int contains_ci_local(const char *s, const char *needle) {
    return find_ci_local(s, needle) != NULL;
}

static int execution_checkpoint(const NDExecutionControl *control, char *err, size_t errcap) {
    if (control && control->should_stop && control->should_stop(control->user_data)) {
        if (err && errcap) snprintf(err, errcap, "execution cancelled or deadline exceeded");
        return 1;
    }
    return 0;
}

static int append_text(char *out, size_t cap, size_t *used, const char *s);

static void record_turn(NDAssistant *a, const char *q, const char *out) {
    if (!a || !q || !out) return;
    size_t qn = strlen(q);
    if (qn >= sizeof(a->last_question)) qn = sizeof(a->last_question) - 1u;
    memcpy(a->last_question, q, qn);
    a->last_question[qn] = 0;
    size_t an = strlen(out);
    if (an >= sizeof(a->last_answer)) an = sizeof(a->last_answer) - 1u;
    memcpy(a->last_answer, out, an);
    a->last_answer[an] = 0;
    a->has_last_turn = 1;

    size_t idx;
    if (a->history_count < ND_ASSISTANT_HISTORY_TURNS) {
        idx = a->history_count++;
    } else {
        memmove(&a->history_questions[0], &a->history_questions[1],
                (ND_ASSISTANT_HISTORY_TURNS - 1u) * sizeof(a->history_questions[0]));
        memmove(&a->history_answers[0], &a->history_answers[1],
                (ND_ASSISTANT_HISTORY_TURNS - 1u) * sizeof(a->history_answers[0]));
        idx = ND_ASSISTANT_HISTORY_TURNS - 1u;
    }
    snprintf(a->history_questions[idx], sizeof(a->history_questions[idx]), "%.*s",
             (int)(sizeof(a->history_questions[idx]) - 1u), q);
    snprintf(a->history_answers[idx], sizeof(a->history_answers[idx]), "%.*s",
             (int)(sizeof(a->history_answers[idx]) - 1u), out);
}

static int is_followup(const char *q) {
    if (!q || strlen(q) > 240u) return 0;
    const char *p = q;
    while (*p && isspace((unsigned char)*p)) p++;
    return (ascii_lo((unsigned char)p[0]) == 'e' && isspace((unsigned char)p[1])) ||
           contains_ci_local(p, "isso") || contains_ci_local(p, "essa") ||
           contains_ci_local(p, "esse") || contains_ci_local(p, "aquilo") ||
           contains_ci_local(p, "nesse caso") || contains_ci_local(p, "na prática") ||
           contains_ci_local(p, "na pratica");
}

static int is_greeting_capability(const char *q) {
    if (!q) return 0;
    int greeting = contains_ci_local(q, "olá") || contains_ci_local(q, "ola") ||
                   contains_ci_local(q, "oi") || contains_ci_local(q, "bom dia") ||
                   contains_ci_local(q, "boa tarde") || contains_ci_local(q, "boa noite");
    int capability = contains_ci_local(q, "consegue fazer") || contains_ci_local(q, "pode fazer") ||
                     contains_ci_local(q, "o que você faz") || contains_ci_local(q, "o que voce faz") ||
                     contains_ci_local(q, "como você está") || contains_ci_local(q, "como voce esta");
    return greeting && capability;
}

static int is_absolute_comparison(const char *q) {
    if (!q) return 0;
    return contains_ci_local(q, "melhor em qualquer situação") ||
           contains_ci_local(q, "melhor em qualquer situacao") ||
           contains_ci_local(q, "sempre melhor") ||
           contains_ci_local(q, "melhor em todos os casos") ||
           contains_ci_local(q, "sempre superior a") ||
           contains_ci_local(q, "superior em qualquer tarefa") ||
           contains_ci_local(q, "superior em qualquer situação") ||
           contains_ci_local(q, "superior em qualquer situacao");
}

static int token_is_acronym(const char *s, size_t n) {
    if (n < 2u || n > 12u) return 0;
    size_t upper = 0u, alpha = 0u;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') {
            upper++;
            alpha++;
        } else if (c >= 'a' && c <= 'z') {
            alpha++;
            return 0;
        } else if (!isdigit(c)) {
            return 0;
        }
    }
    return alpha >= 2u && upper == alpha;
}

static int has_new_acronym(const char *q, const char *previous) {
    size_t n = strlen(q), i = 0u;
    while (i < n) {
        while (i < n && !isalnum((unsigned char)q[i])) i++;
        size_t j = i;
        while (j < n && isalnum((unsigned char)q[j])) j++;
        if (j > i && token_is_acronym(q + i, j - i)) {
            char token[16];
            size_t z = j - i;
            memcpy(token, q + i, z);
            token[z] = 0;
            if (!previous || !contains_ci_local(previous, token)) return 1;
        }
        i = j > i ? j : i + 1u;
    }
    return 0;
}

static int should_inherit_followup(const NDAssistant *a, const char *q) {
    if (!a || !a->has_last_turn || !is_followup(q)) return 0;
    if (has_new_acronym(q, a->last_question)) return 0;
    if (has_structured_entity(q) && !contains_ci_local(a->last_question, "-")) return 0;
    return 1;
}

static int is_non_entailment_followup(const char *q) {
    if (!q) return 0;
    int absolute = contains_ci_local(q, "necessariamente") || contains_ci_local(q, "sempre");
    int universal = contains_ci_local(q, "qualquer") || contains_ci_local(q, "todo ") ||
                    contains_ci_local(q, "toda ");
    int implication = contains_ci_local(q, "significa") || contains_ci_local(q, "implica");
    int negative = contains_ci_local(q, "errad") || contains_ci_local(q, "incorret");
    return absolute && universal && implication && negative;
}

static int is_summary_request(const char *q) {
    if (!q) return 0;
    return (contains_ci_local(q, "resuma") || contains_ci_local(q, "resumo") ||
            contains_ci_local(q, "sintetize") || contains_ci_local(q, "síntese") ||
            contains_ci_local(q, "sintese")) &&
           (contains_ci_local(q, "conversa") || contains_ci_local(q, "diálogo") ||
            contains_ci_local(q, "dialogo") || contains_ci_local(q, "turnos") ||
            contains_ci_local(q, "histórico") || contains_ci_local(q, "historico") ||
            contains_ci_local(q, "recentes"));
}

static int build_bounded_summary(const NDAssistant *a, unsigned max_sentences, char *out, size_t cap) {
    if (!a || !out || !cap || !a->history_count) return 0;
    if (max_sentences == 0u) max_sentences = 3u;
    if (max_sentences > 4u) max_sentences = 4u;
    if (max_sentences > a->history_count) max_sentences = (unsigned)a->history_count;
    size_t used = 0u;
    size_t cursor = 0u;
    for (unsigned sentence = 0u; sentence < max_sentences; sentence++) {
        size_t remaining_turns = a->history_count - cursor;
        size_t remaining_sentences = (size_t)(max_sentences - sentence);
        size_t take = (remaining_turns + remaining_sentences - 1u) / remaining_sentences;
        if (sentence && append_text(out, cap, &used, " ")) return -1;
        if (sentence == 0u && append_text(out, cap, &used, "Nos turnos recentes, foram discutidos: ")) return -1;
        else if (sentence > 0u && append_text(out, cap, &used, "Também apareceram: ")) return -1;
        for (size_t j = 0u; j < take && cursor < a->history_count; j++, cursor++) {
            if (j && append_text(out, cap, &used, "; ")) return -1;
            const char *q = a->history_questions[cursor];
            size_t n = strlen(q);
            if (n > 120u) n = 120u;
            if (used + n + 2u > cap) return -1;
            memcpy(out + used, q, n);
            used += n;
            out[used] = 0;
        }
        if (append_text(out, cap, &used, ".")) return -1;
    }
    return 0;
}

static int context_explicitly_blocks_entailment(const char *q, const char *ctx) {
    if (!q || !ctx) return 0;
    int asks_proof = contains_ci_local(q, "prova") || contains_ci_local(q, "demonstra") ||
                     contains_ci_local(q, "implica") || contains_ci_local(q, "significa");
    int absence = contains_ci_local(ctx, "não informa") || contains_ci_local(ctx, "nao informa") ||
                  contains_ci_local(ctx, "não diz") || contains_ci_local(ctx, "nao diz") ||
                  contains_ci_local(ctx, "não estabelece") || contains_ci_local(ctx, "nao estabelece") ||
                  contains_ci_local(ctx, "não consta") || contains_ci_local(ctx, "nao consta");
    return asks_proof && absence;
}

static int inverse_capital_followup(const NDAssistant *a, const char *q, char *out, size_t cap) {
    if (!a || !a->has_last_turn || !q || !out || !cap) return 0;
    if (!(contains_ci_local(q, "qual país") || contains_ci_local(q, "qual pais")) ||
        !contains_ci_local(q, "capital")) return 0;
    const char *start = find_ci_local(a->last_answer, "A capital de ");
    if (!start) return 0;
    start += strlen("A capital de ");
    const char *end = find_ci_local(start, " é ");
    if (!end) end = find_ci_local(start, " e ");
    if (!end || end <= start) return 0;
    while (end > start && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - start);
    if (!n || n + 1u > cap) return 0;
    memcpy(out, start, n);
    out[n] = 0;
    return 1;
}

static int extract_type_attribute(const char *q, const char *evidence,
                                  char *out, size_t cap) {
    static const char *patterns[] = {"tipo de ", "tipo da ", "tipo do "};
    const char *hit = NULL;
    size_t plen = 0u;
    for (size_t i = 0; i < sizeof(patterns) / sizeof(patterns[0]); i++) {
        hit = find_ci_local(q, patterns[i]);
        if (hit) {
            plen = strlen(patterns[i]);
            break;
        }
    }
    if (!hit) return 0;
    const char *a = hit + plen;
    while (*a && isspace((unsigned char)*a)) a++;
    const char *ae = a;
    while (*ae && (isalnum((unsigned char)*ae) || (unsigned char)*ae >= 128u || *ae == '-' || *ae == '_')) ae++;
    if (ae == a || (size_t)(ae - a) >= 96u) return 0;
    char attr[96];
    memcpy(attr, a, (size_t)(ae - a));
    attr[ae - a] = 0;
    const char *eh = find_ci_local(evidence, attr);
    if (!eh) return 0;
    const char *v = eh + strlen(attr);
    while (*v && isspace((unsigned char)*v)) v++;
    if (ascii_lo((unsigned char)v[0]) == 'd' && (v[1] == 'e' || v[1] == 'a' || v[1] == 'o') &&
        isspace((unsigned char)v[2])) {
        v += 3;
    } else if (*v == ':' || *v == '=') {
        v++;
        while (*v && isspace((unsigned char)*v)) v++;
    } else {
        return 0;
    }
    const char *end = v;
    while (*end) {
        if (*end == ',' || *end == ';' || *end == '.') break;
        if (end[0] == ' ' && ascii_lo((unsigned char)end[1]) == 'e' && end[2] == ' ') break;
        end++;
    }
    while (end > v && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - v);
    if (!n || n + 1u > cap || n > 160u) return 0;
    memcpy(out, v, n);
    out[n] = 0;
    return 1;
}

static int append_text(char *out, size_t cap, size_t *used, const char *s) {
    size_t n = strlen(s);
    if (*used + n + 1u > cap) return -1;
    memcpy(out + *used, s, n);
    *used += n;
    out[*used] = 0;
    return 0;
}

int nd_assistant_load_ex(NDAssistant *a,
                         const char *rp,
                         const char *kp,
                         const char *qp,
                         const char *lp,
                         const char *op,
                         const char *mp,
                         char *e,
                         size_t ec) {
    if (!a) return -1;
    memset(a, 0, sizeof(*a));
    nd_memory_init(&a->memory);
    nd_rag_init(&a->rag);
    memset(&a->semantic_ranker, 0, sizeof(a->semantic_ranker));
    a->semantic_ranker_loaded = 0;
    nd_run_journal_init(&a->journal);
    nd_pilot_init(&a->pilot);
    a->resource_policy = nd_resource_policy(ND_PROFILE_MOBILE);
    if (nd_knowledge_load(kp, &a->kb, e, ec)) return -1;
    if (nd_retriever_load(rp, a->kb.count, &a->retriever, e, ec)) {
        nd_knowledge_free(&a->kb);
        return -1;
    }
    if (nd_context_qa_load(qp, &a->context_qa, e, ec)) {
        nd_retriever_free(&a->retriever);
        nd_knowledge_free(&a->kb);
        return -1;
    }
    if (nd_relation_load(lp, &a->relation, e, ec)) {
        nd_context_qa_free(&a->context_qa);
        nd_retriever_free(&a->retriever);
        nd_knowledge_free(&a->kb);
        return -1;
    }
    if (op && op[0]) {
        if (nd_open_knowledge_load(op, &a->open_knowledge, e, ec)) {
            nd_relation_free(&a->relation);
            nd_context_qa_free(&a->context_qa);
            nd_retriever_free(&a->retriever);
            nd_knowledge_free(&a->kb);
            return -1;
        }
        a->open_knowledge_loaded = 1;
    }
    if (nd_memory_load(&a->memory, mp, e, ec)) {
        if (a->open_knowledge_loaded) nd_open_knowledge_free(&a->open_knowledge);
        nd_relation_free(&a->relation);
        nd_context_qa_free(&a->context_qa);
        nd_retriever_free(&a->retriever);
        nd_knowledge_free(&a->kb);
        return -1;
    }
    if (mp && mp[0]) {
        char journal_path[1024];
        int w = snprintf(journal_path, sizeof(journal_path), "%s.runs", mp);
        if (w < 0 || (size_t)w >= sizeof(journal_path) ||
            nd_assistant_set_journal_path(a, journal_path, e, ec)) {
            nd_memory_free(&a->memory);
            if (a->open_knowledge_loaded) nd_open_knowledge_free(&a->open_knowledge);
            nd_relation_free(&a->relation);
            nd_context_qa_free(&a->context_qa);
            nd_retriever_free(&a->retriever);
            nd_knowledge_free(&a->kb);
            return -1;
        }
    }
    return 0;
}

int nd_assistant_load(NDAssistant *a,
                      const char *rp,
                      const char *kp,
                      const char *qp,
                      const char *lp,
                      char *e,
                      size_t ec) {
    return nd_assistant_load_ex(a, rp, kp, qp, lp, NULL, NULL, e, ec);
}

void nd_assistant_free(NDAssistant *a) {
    if (!a) return;
    if (a->semantic_ranker_loaded) nd_semantic_ranker_free(&a->semantic_ranker);
    nd_memory_free(&a->memory);
    if (a->open_knowledge_loaded) nd_open_knowledge_free(&a->open_knowledge);
    nd_relation_free(&a->relation);
    nd_context_qa_free(&a->context_qa);
    nd_retriever_free(&a->retriever);
    nd_knowledge_free(&a->kb);
    memset(a, 0, sizeof(*a));
}

static int answer_single(NDAssistant *a,
                         const char *q,
                         const char *ctx,
                         int rich,
                         const NDExecutionControl *control,
                         char *out,
                         size_t cap,
                         NDAnswerMeta *meta,
                         char *e,
                         size_t ec) {
    if (execution_checkpoint(control, e, ec)) return 1;
    NDAnswerMeta m;
    memset(&m, 0, sizeof(m));
    m.goal_count = 1u;

    if (ctx && ctx[0]) {
        NDContextSynthesisResult cr;
        m.context_considered = 1;
        if (nd_context_synthesize_ex(&a->context_qa, &a->relation, q, ctx, rich,
                                     out, cap, &cr, e, ec)) return -1;
        m.confidence = cr.best_score;
        m.evidence_count = cr.evidence_count;
        m.goal_count = cr.goal_count ? cr.goal_count : 1u;
        m.covered_goals = cr.covered_goals;
        if (cr.found && cr.covered_goals == cr.goal_count) {
            m.source = ND_ANSWER_CONTEXT;
            m.sources_mask |= source_bit(m.source);
            if (meta) *meta = m;
            return 0;
        }
        /* A context-specific entity question must not fall through to generic
         * knowledge when the supplied evidence does not support the requested
         * relation.  That would turn topical similarity into false coverage. */
        if (has_structured_entity(q)) {
            m.source = ND_ANSWER_UNCERTAIN;
            m.covered_goals = 0u;
            if (meta) *meta = m;
            return 0;
        }
    }

    NDCalculatorResult calc;
    int tc = nd_calculator_try(q, rich, out, cap, &calc, e, ec);
    if (tc < 0) return -1;
    if (tc > 0) {
        m.tool_calls++;
        m.source = calc.ok ? ND_ANSWER_CALCULATOR : ND_ANSWER_UNCERTAIN;
        m.confidence = calc.ok ? 1.0f : 0.0f;
        m.covered_goals = calc.ok ? 1u : 0u;
        if (calc.ok) m.sources_mask |= source_bit(ND_ANSWER_CALCULATOR);
        if (meta) *meta = m;
        return 0;
    }

    NDMemoryFactResult mfr;
    if (nd_memory_query_fact(&a->memory, q, &mfr, e, ec)) return -1;
    if (mfr.conflict) {
        const char *z = "Há fatos conflitantes na memória local para essa entidade e relação; não vou escolher um valor arbitrariamente.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        m.source = ND_ANSWER_UNCERTAIN;
        m.confidence = 0.0f;
        m.covered_goals = 0u;
        if (meta) *meta = m;
        return 0;
    }
    if (mfr.found && mfr.value && mfr.evidence) {
        int w = rich ? snprintf(out, cap, "Resposta direta: %s\n\nEvidência na memória: %s", mfr.value, mfr.evidence)
                     : snprintf(out, cap, "%s", mfr.value);
        if (w < 0 || (size_t)w >= cap) {
            if (e && ec) snprintf(e, ec, "structured memory answer buffer too small");
            return -1;
        }
        m.source = ND_ANSWER_MEMORY;
        m.confidence = mfr.score;
        m.memory_hits = 1u;
        m.evidence_count = 1u;
        m.covered_goals = 1u;
        m.sources_mask |= source_bit(ND_ANSWER_MEMORY);
        if (meta) *meta = m;
        return 0;
    }

    NDMemoryResult mr;
    if (nd_memory_query(&a->memory, q, &mr, e, ec)) return -1;
    if (mr.found && mr.text) {
        NDRelationResult qr;
        if (nd_relation_infer(&a->relation, q, &qr, e, ec)) return -1;
        char lexical_value[192];
        if (!qr.accepted && extract_type_attribute(q, mr.text, lexical_value, sizeof(lexical_value))) {
            int w = rich ? snprintf(out, cap, "Resposta direta: %s\n\nEvidência na memória: %s", lexical_value, mr.text)
                         : snprintf(out, cap, "%s", lexical_value);
            if (w < 0 || (size_t)w >= cap) {
                if (e && ec) snprintf(e, ec, "memory lexical answer buffer too small");
                return -1;
            }
            m.source = ND_ANSWER_MEMORY;
            m.confidence = mr.score;
            m.memory_hits = 1u;
            m.evidence_count = 1u;
            m.covered_goals = 1u;
            m.sources_mask |= source_bit(ND_ANSWER_MEMORY);
            if (meta) *meta = m;
            return 0;
        }
        NDContextSynthesisResult cr;
        char scratch[256];
        int rc = nd_context_synthesize_ex(&a->context_qa, &a->relation, q, mr.text, rich,
                                          out, cap, &cr, scratch, sizeof(scratch));
        if (rc != 0 || !cr.found) {
            int w = snprintf(out, cap, "Na memória local: %s", mr.text);
            if (w < 0 || (size_t)w >= cap) {
                if (e && ec) snprintf(e, ec, "memory answer buffer too small");
                return -1;
            }
            m.evidence_count = 1u;
        } else {
            m.evidence_count = cr.evidence_count;
        }
        m.source = ND_ANSWER_MEMORY;
        m.confidence = mr.score;
        m.memory_hits = 1u;
        m.covered_goals = 1u;
        m.sources_mask |= source_bit(ND_ANSWER_MEMORY);
        if (meta) *meta = m;
        return 0;
    }

    NDRetrievalResult rr;
    int want_rich = rich && !nd_knowledge_prefers_short(q);
    if (nd_knowledge_answer(&a->kb, &a->retriever, q, want_rich, out, cap, &rr, e, ec)) return -1;
    if (rr.accepted) {
        m.source = ND_ANSWER_KNOWLEDGE;
        m.confidence = rr.confidence;
        m.margin = rr.margin;
        m.covered_goals = 1u;
        m.sources_mask |= source_bit(ND_ANSWER_KNOWLEDGE);
        if (meta) *meta = m;
        return 0;
    }

    if (a->open_knowledge_loaded) {
        NDOpenKnowledgeResult okr;
        if (nd_open_knowledge_search(&a->open_knowledge, q, &okr, e, ec)) return -1;
        if (okr.found) {
            int w;
            if (rich) {
                w = snprintf(out, cap,
                             "Conhecimento aberto local (Pirá 2.0, ID %s): %s",
                             okr.source_id, okr.answer);
            } else {
                w = snprintf(out, cap, "%s", okr.answer);
            }
            if (w < 0 || (size_t)w >= cap) {
                if (e && ec) snprintf(e, ec, "open knowledge answer buffer too small");
                return -1;
            }
            m.source = ND_ANSWER_OPEN_KNOWLEDGE;
            m.confidence = (float)okr.score;
            m.margin = (float)okr.margin;
            m.evidence_count = 1u;
            m.covered_goals = 1u;
            m.open_knowledge_hits = 1u;
            m.sources_mask |= source_bit(ND_ANSWER_OPEN_KNOWLEDGE);
            if (meta) *meta = m;
            return 0;
        }
    }

    m.source = ND_ANSWER_UNCERTAIN;
    m.confidence = rr.confidence;
    m.margin = rr.margin;
    m.covered_goals = 0u;
    if (meta) *meta = m;
    return 0;
}

static int assistant_answer_core(NDAssistant *a,
                        const char *q,
                        const char *ctx,
                        int rich,
                        const NDExecutionControl *control,
                        char *out,
                        size_t cap,
                        NDAnswerMeta *meta,
                        char *e,
                        size_t ec) {
    if (!a || !q || !out || !cap) return -1;
    if (execution_checkpoint(control, e, ec)) return 1;
    out[0] = 0;

    NDSemanticFrame frame;
    if (nd_semantic_analyze(q, &frame)) return -1;

    if (frame.intent == ND_INTENT_SUMMARY_CONTEXT && ctx && ctx[0]) {
        unsigned limit = frame.sentence_limit ? frame.sentence_limit : 3u;
        int n = nd_text_summary_extractive(ctx, limit, out, cap);
        if (n < 0) {
            if (e && ec) snprintf(e, ec, "context summary buffer too small");
            return -1;
        }
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_TEXT_UTILITY;
        m.confidence = n > 0 ? 1.0f : 0.0f;
        m.goal_count = 1u;
        m.covered_goals = n > 0 ? 1u : 0u;
        m.evidence_count = (size_t)(n > 0 ? n : 0);
        m.sources_mask = source_bit(m.source);
        m.context_considered = 1;
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (frame.intent == ND_INTENT_KEYWORDS_CONTEXT && ctx && ctx[0]) {
        int n = nd_text_keywords(ctx, 8u, out, cap);
        if (n < 0) {
            if (e && ec) snprintf(e, ec, "context keywords buffer too small");
            return -1;
        }
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_TEXT_UTILITY;
        m.confidence = n > 0 ? 1.0f : 0.0f;
        m.goal_count = 1u;
        m.covered_goals = n > 0 ? 1u : 0u;
        m.evidence_count = (size_t)(n > 0 ? n : 0);
        m.sources_mask = source_bit(m.source);
        m.context_considered = 1;
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (ctx && ctx[0] && context_explicitly_blocks_entailment(q, ctx)) {
        const char *z = "Não. A evidência fornecida não prova essa conclusão: o próprio contexto declara que a informação necessária não foi fornecida. Seria preciso evidência adicional sobre a autoria ou relação específica perguntada.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONTEXT;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.evidence_count = 1u;
        m.context_considered = 1;
        m.sources_mask = source_bit(m.source);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    char direct[2048];
    int dr = nd_semantic_direct_answer(&frame, q, direct, sizeof(direct));
    if (dr < 0) return -1;
    if (dr > 0) {
        if (strlen(direct) + 1u > cap) return -1;
        strcpy(out, direct);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONVERSATION;
        m.confidence = 1.0f;
        m.goal_count = (frame.intent == ND_INTENT_COMPARE_QUANT_KV ||
                        (frame.intent == ND_INTENT_DEFINE_RAG && contains_ci_local(q, "por que"))) ? 2u : 1u;
        m.covered_goals = m.goal_count;
        m.sources_mask = source_bit(m.source);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (frame.intent == ND_INTENT_DYNAMIC_EVENT && (!ctx || !ctx[0])) {
        const char *z = "Não sei com segurança: essa pergunta depende de informação temporal atual e não há evidência local atualizada fornecida para validá-la.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_UNCERTAIN;
        m.goal_count = 1u;
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (frame.intent == ND_INTENT_CREATIVE) {
        const char *z = "A rota generativa livre ainda não possui um backbone promovido nesta release; por segurança, não vou fingir geração criativa com templates ou conhecimento recuperado.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_UNCERTAIN;
        m.goal_count = 1u;
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    int handled = 0;
    if (nd_memory_handle_command(&a->memory, q, out, cap, &handled, e, ec)) return -1;
    if (handled) {
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_MEMORY;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.memory_hits = 1u;
        m.sources_mask = source_bit(ND_ANSWER_MEMORY);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if ((frame.intent == ND_INTENT_SUMMARY_HISTORY || is_summary_request(q)) && a->history_count) {
        if (build_bounded_summary(a, frame.sentence_limit, out, cap)) {
            if (e && ec) snprintf(e, ec, "conversation summary buffer too small");
            return -1;
        }
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONVERSATION;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.evidence_count = a->history_count;
        m.sources_mask = source_bit(ND_ANSWER_CONVERSATION);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (inverse_capital_followup(a, q, out, cap)) {
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONVERSATION;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.evidence_count = 1u;
        m.sources_mask = source_bit(m.source);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (a->has_last_turn && is_non_entailment_followup(q)) {
        const char *z = "Não. A evidência anterior mostra que uma opção pode ser usada, mas isso não prova que toda alternativa esteja necessariamente errada. Seria necessária evidência comparativa explícita para sustentar exclusividade ou superioridade universal.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONVERSATION;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.evidence_count = 1u;
        m.sources_mask = source_bit(ND_ANSWER_CONVERSATION);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (is_greeting_capability(q)) {
        const char *z = "Olá. Estou operacional como um sistema local: posso responder conhecimento interno e aberto auditável, usar contexto fornecido, calcular expressões, consultar memória explícita e decompor perguntas multipartes. Quando não há evidência suficiente, devo declarar incerteza em vez de inventar.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONVERSATION;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.sources_mask = source_bit(ND_ANSWER_CONVERSATION);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    if (is_absolute_comparison(q)) {
        const char *z = "Não existe uma arquitetura comprovadamente melhor em qualquer situação sem definir critérios. A escolha depende da tarefa, dos dados, da latência, da memória disponível, do hardware e da qualidade medida no cenário real.";
        if (strlen(z) + 1u > cap) return -1;
        strcpy(out, z);
        NDAnswerMeta m;
        memset(&m, 0, sizeof(m));
        m.source = ND_ANSWER_CONVERSATION;
        m.confidence = 1.0f;
        m.goal_count = 1u;
        m.covered_goals = 1u;
        m.sources_mask = source_bit(ND_ANSWER_CONVERSATION);
        if (meta) *meta = m;
        record_turn(a, q, out);
        return 0;
    }

    char followup_query[8192];
    const char *working_q = q;
    if (should_inherit_followup(a, q)) {
        int w = snprintf(followup_query, sizeof(followup_query), "%s %s", a->last_question, q);
        if (w > 0 && (size_t)w < sizeof(followup_query)) working_q = followup_query;
    }

    char rag_context[16384];
    const char *effective_ctx = ctx;
    int rag_used = 0;
    NDRagResult rag_result;
    memset(&rag_result, 0, sizeof(rag_result));
    if ((!ctx || !ctx[0]) && a->rag.count) {
        if (execution_checkpoint(control, e, ec)) return 1;
        if (nd_rag_query_ranked(&a->rag, working_q, a->resource_policy.max_rag_chunks,
                                a->semantic_ranker_loaded ? &a->semantic_ranker : NULL,
                                rag_context, sizeof(rag_context), &rag_result, e, ec)) return -1;
        if (rag_result.found) {
            effective_ctx = rag_context;
            rag_used = 1;
        }
    }

    if (frame.intent == ND_INTENT_PERCENTAGE && !effective_ctx) {
        int rc = answer_single(a, working_q, NULL, rich, control, out, cap, meta, e, ec);
        if (!rc) record_turn(a, q, out);
        return rc;
    }

    if (execution_checkpoint(control, e, ec)) return 1;
    NDPlan plan;
    if (nd_plan_build(working_q, &plan, e, ec)) return -1;
    if (plan.goal_count == 1u) {
        int rc = answer_single(a, working_q, effective_ctx, rich, control, out, cap, meta, e, ec);
        if (!rc && rag_used && meta && meta->source == ND_ANSWER_CONTEXT) {
            meta->source = ND_ANSWER_RAG;
            meta->rag_hits = rag_result.hit_count;
            meta->sources_mask |= source_bit(ND_ANSWER_RAG);
        }
        if (!rc) record_turn(a, q, out);
        return rc;
    }

    NDAnswerMeta total;
    memset(&total, 0, sizeof(total));
    total.source = ND_ANSWER_COMPOSED;
    total.goal_count = plan.goal_count;
    total.context_considered = (effective_ctx && effective_ctx[0]) ? 1 : 0;
    float conf_sum = 0.0f;
    float min_margin = 0.0f;
    int have_margin = 0;
    size_t used = 0;

    for (size_t i = 0; i < plan.goal_count; i++) {
        if (execution_checkpoint(control, e, ec)) return 1;
        char sub[8192];
        NDAnswerMeta sm;
        if (answer_single(a, plan.goals[i].text, effective_ctx, rich, control, sub, sizeof(sub), &sm, e, ec)) return -1;
        total.evidence_count += sm.evidence_count;
        total.tool_calls += sm.tool_calls;
        total.memory_hits += sm.memory_hits;
        total.open_knowledge_hits += sm.open_knowledge_hits;
        total.rag_hits += sm.rag_hits;
        total.sources_mask |= sm.sources_mask;
        if (sm.source != ND_ANSWER_UNCERTAIN && sm.source != ND_ANSWER_NONE) {
            total.covered_goals++;
            conf_sum += sm.confidence;
        }
        if (sm.margin > 0.0f && (!have_margin || sm.margin < min_margin)) {
            min_margin = sm.margin;
            have_margin = 1;
        }
        if (rich) {
            char head[64];
            int w = snprintf(head, sizeof(head), "%zu. ", i + 1u);
            if (w < 0 || (size_t)w >= sizeof(head) || append_text(out, cap, &used, head) ||
                append_text(out, cap, &used, sub) ||
                (i + 1u < plan.goal_count && append_text(out, cap, &used, "\n\n"))) {
                if (e && ec) snprintf(e, ec, "composed answer buffer too small");
                return -1;
            }
        } else {
            if (append_text(out, cap, &used, sub) ||
                (i + 1u < plan.goal_count && append_text(out, cap, &used, " "))) {
                if (e && ec) snprintf(e, ec, "composed answer buffer too small");
                return -1;
            }
        }
    }
    if (total.covered_goals == 0u) total.source = ND_ANSWER_UNCERTAIN;
    total.confidence = total.covered_goals ? conf_sum / (float)total.covered_goals : 0.0f;
    total.margin = have_margin ? min_margin : 0.0f;
    if (rag_used) {
        total.rag_hits = rag_result.hit_count;
        total.sources_mask |= source_bit(ND_ANSWER_RAG);
    }
    if (meta) *meta = total;
    record_turn(a, q, out);
    return 0;
}



int nd_assistant_load_semantic_ranker(NDAssistant *a, const char *path, char *err, size_t errcap) {
    if (!a || !path || !path[0]) {
        if (err && errcap) snprintf(err, errcap, "invalid semantic ranker path");
        return -1;
    }
    nd_semantic_ranker_free(&a->semantic_ranker);
    a->semantic_ranker_loaded = 0;
    if (nd_semantic_ranker_load(&a->semantic_ranker, path, err, errcap) != 0) return -1;
    a->semantic_ranker_loaded = 1;
    return 0;
}
int nd_assistant_set_master_kill(NDAssistant *a, int enabled, int64_t timestamp) {
    if (!a) return -1;
    return nd_pilot_set_master_kill(&a->pilot, enabled, timestamp);
}

int nd_assistant_set_pilot_feature(NDAssistant *a, NDPilotFeature feature, int enabled, int64_t timestamp) {
    if (!a) return -1;
    return nd_pilot_set_feature(&a->pilot, feature, enabled, timestamp);
}

int nd_assistant_set_profile(NDAssistant *a, NDMobileProfile profile) {
    if (!a) return -1;
    a->resource_policy = nd_resource_policy(profile);
    return 0;
}

int nd_assistant_set_thermal_status(NDAssistant *a, unsigned thermal_status) {
    if (!a) return -1;
    a->thermal_status = thermal_status > 6u ? 6u : thermal_status;
    return 0;
}

int nd_assistant_set_journal_path(NDAssistant *a, const char *path, char *err, size_t errcap) {
    if (!a) return -1;
    if (nd_run_journal_set_path(&a->journal, path, err, errcap)) return -1;
    size_t abandoned = 0u;
    if (nd_run_journal_recover(&a->journal, &abandoned, err, errcap)) return -1;
    (void)abandoned;
    a->journal_enabled = path && path[0];
    return 0;
}

int nd_assistant_rag_add_document(NDAssistant *a, const char *doc_id, const char *text,
                                  char *err, size_t errcap) {
    if (!a) return -1;
    return nd_rag_add_document(&a->rag, doc_id, text, err, errcap);
}

void nd_assistant_rag_clear(NDAssistant *a) {
    if (a) nd_rag_clear(&a->rag);
}

int nd_assistant_rag_save(const NDAssistant *a, const char *path, char *err, size_t errcap) {
    if (!a) return -1;
    return nd_rag_save(&a->rag, path, err, errcap);
}

int nd_assistant_rag_load(NDAssistant *a, const char *path, char *err, size_t errcap) {
    if (!a) return -1;
    return nd_rag_load(&a->rag, path, err, errcap);
}

static float clamp01(float x) {
    if (!(x == x)) return 0.0f;
    if (x < 0.0f) return 0.0f;
    if (x > 1.0f) return 1.0f;
    return x;
}

static const char *source_name(NDAnswerSource s) {
    switch (s) {
        case ND_ANSWER_CONTEXT: return "CONTEXT";
        case ND_ANSWER_CALCULATOR: return "CALCULATOR";
        case ND_ANSWER_KNOWLEDGE: return "KNOWLEDGE";
        case ND_ANSWER_UNCERTAIN: return "UNCERTAIN";
        case ND_ANSWER_MEMORY: return "MEMORY";
        case ND_ANSWER_OPEN_KNOWLEDGE: return "OPEN_KNOWLEDGE";
        case ND_ANSWER_COMPOSED: return "COMPOSED";
        case ND_ANSWER_CONVERSATION: return "CONVERSATION";
        case ND_ANSWER_RAG: return "RAG";
        case ND_ANSWER_TEXT_UTILITY: return "TEXT_UTILITY";
        case ND_ANSWER_BLOCKED: return "BLOCKED";
        default: return "NONE";
    }
}

int nd_assistant_answer_controlled(NDAssistant *a,
                                   const char *q,
                                   const char *ctx,
                                   int rich,
                                   const NDExecutionControl *control,
                                   char *out,
                                   size_t cap,
                                   NDAnswerMeta *meta,
                                   char *e,
                                   size_t ec) {
    if (!a || !q || !out || !cap) return -1;
    if (execution_checkpoint(control, e, ec)) return 1;
    size_t resource_cap = nd_resource_effective_output_bytes(&a->resource_policy, a->thermal_status);
    if (resource_cap == 0u) return -1;
    if (cap > resource_cap + 1u) cap = resource_cap + 1u;
    if (!nd_pilot_allowed(&a->pilot, ND_PILOT_LOCAL_INFERENCE)) {
        int w = snprintf(out, cap, "Inferência local bloqueada pelo controle de piloto.");
        if (w < 0 || (size_t)w >= cap) return -1;
        if (meta) {
            memset(meta, 0, sizeof(*meta));
            meta->source = ND_ANSWER_BLOCKED;
            meta->goal_count = 1u;
            meta->sources_mask = source_bit(ND_ANSWER_BLOCKED);
        }
        return 0;
    }
    if (!nd_resource_admit(&a->resource_policy, strlen(q), ctx ? strlen(ctx) : 0u)) {
        if (e && ec) snprintf(e, ec, "resource governor rejected request for profile %s",
                              nd_resource_profile_name(a->resource_policy.profile));
        return -1;
    }
    NDSafetyDecision sd = nd_safety_prompt_check(q);
    if (sd != ND_SAFETY_ALLOW) {
        int w = snprintf(out, cap, "Solicitação bloqueada pelo safety gate local (%s).", nd_safety_reason(sd));
        if (w < 0 || (size_t)w >= cap) return -1;
        if (meta) {
            memset(meta, 0, sizeof(*meta));
            meta->source = ND_ANSWER_BLOCKED;
            meta->goal_count = 1u;
            meta->safety_blocked = 1;
            meta->sources_mask = source_bit(ND_ANSWER_BLOCKED);
        }
        return 0;
    }

    uint64_t run_id = 0u;
    if (a->journal_enabled && nd_run_journal_begin(&a->journal,
            nd_resource_profile_name(a->resource_policy.profile), &run_id, e, ec)) return -1;

    NDAnswerMeta local_meta;
    NDAnswerMeta *m = meta ? meta : &local_meta;
    if (a->journal_enabled && run_id != 0u) {
        char journal_err[128];
        if (nd_run_journal_progress(&a->journal, run_id, "ROUTING", "LOCAL", journal_err, sizeof(journal_err))) {
            if (e && ec) snprintf(e, ec, "%s", journal_err);
            return -1;
        }
    }
    int rc = assistant_answer_core(a, q, ctx, rich, control, out, cap, m, e, ec);
    if (rc == 0 && execution_checkpoint(control, e, ec)) rc = 1;
    if (a->journal_enabled && run_id != 0u && rc == 0) {
        char journal_err[128];
        if (nd_run_journal_progress(&a->journal, run_id, "OUTPUT_GUARD", source_name(m->source), journal_err, sizeof(journal_err))) {
            if (e && ec) snprintf(e, ec, "%s", journal_err);
            rc = -1;
        }
    } else if (a->journal_enabled && run_id != 0u && rc == 1) {
        char journal_err[128];
        if (nd_run_journal_drain(&a->journal, run_id, "CANCELLED", journal_err, sizeof(journal_err))) {
            if (e && ec) snprintf(e, ec, "%s", journal_err);
            rc = -1;
        }
    }
    if (rc == 0) {
        NDSafetyDecision od = nd_safety_output_check(out);
        if (od != ND_SAFETY_ALLOW) {
            int w = snprintf(out, cap, "Saída bloqueada pelo safety gate local (%s).", nd_safety_reason(od));
            if (w < 0 || (size_t)w >= cap) rc = -1;
            memset(m, 0, sizeof(*m));
            m->source = ND_ANSWER_BLOCKED;
            m->goal_count = 1u;
            m->safety_blocked = 1;
            m->sources_mask = source_bit(ND_ANSWER_BLOCKED);
        }
        m->confidence = clamp01(m->confidence);
        m->margin = clamp01(m->margin);
    }
    if (a->journal_enabled) {
        const char *status = rc == 0 ? "COMPLETED" : "FAILED";
        const char *src = rc == 0 ? source_name(m->source) : "ERROR";
        char journal_err[128];
        if (nd_run_journal_end(&a->journal, run_id, status, src, journal_err, sizeof(journal_err)) && rc == 0) {
            if (e && ec) snprintf(e, ec, "%s", journal_err);
            rc = -1;
        }
    }
    return rc;
}

int nd_assistant_answer(NDAssistant *a,
                        const char *q,
                        const char *ctx,
                        int rich,
                        char *out,
                        size_t cap,
                        NDAnswerMeta *meta,
                        char *e,
                        size_t ec) {
    return nd_assistant_answer_controlled(a, q, ctx, rich, NULL, out, cap, meta, e, ec);
}

int nd_assistant_answer_stream_controlled(NDAssistant *a,
                                          const char *q,
                                          const char *ctx,
                                          int rich,
                                          const NDExecutionControl *control,
                                          NDAnswerChunkCallback callback,
                               void *user_data,
                               char *out,
                               size_t cap,
                               NDAnswerMeta *meta,
                               char *e,
                               size_t ec) {
    int rc = nd_assistant_answer_controlled(a, q, ctx, rich, control, out, cap, meta, e, ec);
    if (rc || !callback) return rc;
    size_t n = strlen(out), pos = 0u;
    const size_t chunk = 192u;
    while (pos < n) {
        if (execution_checkpoint(control, e, ec)) return 1;
        size_t take = n - pos;
        if (take > chunk) take = chunk;
        while (take > 1u && ((unsigned char)out[pos + take] & 0xc0u) == 0x80u) take--;
        if (callback(out + pos, take, user_data)) {
            if (e && ec) snprintf(e, ec, "response streaming cancelled");
            return 1;
        }
        pos += take;
    }
    return 0;
}

int nd_assistant_answer_stream(NDAssistant *a,
                               const char *q,
                               const char *ctx,
                               int rich,
                               NDAnswerChunkCallback callback,
                               void *user_data,
                               char *out,
                               size_t cap,
                               NDAnswerMeta *meta,
                               char *e,
                               size_t ec) {
    return nd_assistant_answer_stream_controlled(a, q, ctx, rich, NULL, callback, user_data,
                                                 out, cap, meta, e, ec);
}
