package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext

/**
 * Módulo 15: Mycelium Semantic Index & Organic Routing (Rede de Micélio Bio-Inspirada).
 * Roteamento associativo não-hierárquico para inferências com RAM < 12MB.
 */
class MyceliumIndexPlugin : IQcnnPlugin {

    override val pluginId: String = "mycelium_index"
    override var isEnabled: Boolean = true

    private val hyphaeNetwork = mutableMapOf<String, MutableMap<String, Double>>()

    init {
        initBaseMycelium()
    }

    private fun initBaseMycelium() {
        val base = mapOf(
            "vida" to mapOf("energia" to 0.95, "tempo" to 0.82, "consciencia" to 0.90, "harmonia" to 0.88),
            "tempo" to mapOf("espaco" to 0.98, "entropia" to 0.92, "memoria" to 0.85, "movimento" to 0.89),
            "mente" to mapOf("consciencia" to 0.99, "pensamento" to 0.96, "simbolo" to 0.91, "vontade" to 0.87),
            "universo" to mapOf("cosmos" to 0.99, "energia" to 0.94, "materia" to 0.93, "gravidade" to 0.91),
            "decisao" to mapOf("vontade" to 0.92, "consequencia" to 0.95, "futuro" to 0.91, "equilibrio" to 0.89),
            "harmonia" to mapOf("equilibrio" to 0.97, "frequencia" to 0.94, "ressonancia" to 0.96, "beleza" to 0.89),
            "direito" to mapOf("justica" to 0.98, "ordem" to 0.93, "constituicao" to 0.96, "etica" to 0.91),
            "saude" to mapOf("equilibrio" to 0.94, "celula" to 0.95, "vitalidade" to 0.92, "cura" to 0.90),
            "gravidade" to mapOf("curvatura" to 0.97, "massa" to 0.96, "espaco_tempo" to 0.98, "atracao" to 0.93)
        )
        for ((k, neighbors) in base) {
            val map = hyphaeNetwork.getOrPut(k) { mutableMapOf() }
            for ((n, weight) in neighbors) {
                map[n] = weight
            }
        }
    }

    fun growHypha(conceptA: String, conceptB: String, strength: Double = 0.85) {
        val cA = conceptA.lowercase().trim()
        val cB = conceptB.lowercase().trim()
        val mapA = hyphaeNetwork.getOrPut(cA) { mutableMapOf() }
        val mapB = hyphaeNetwork.getOrPut(cB) { mutableMapOf() }

        val currentW = mapA[cB] ?: 0.5
        val newW = (currentW + strength * 0.1).coerceAtMost(1.0)
        mapA[cB] = newW
        mapB[cA] = newW
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context
        val words = context.prompt.lowercase().split("\\s+".toRegex()).filter { it.length > 3 }

        for (i in 0 until words.size - 1) {
            growHypha(words[i], words[i + 1], strength = 0.5)
        }

        context.metadata["mycelium_nodes_count"] = hyphaeNetwork.size
        return context
    }
}
