<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 123 — Teams, Handoffs & Workflows

Agent-as-tool retains caller control. Handoff transfers control. Teams may use supervisor, sequential, parallel, router, hierarchical or human checkpoint patterns. Workflows use versioned node/edge contracts.
