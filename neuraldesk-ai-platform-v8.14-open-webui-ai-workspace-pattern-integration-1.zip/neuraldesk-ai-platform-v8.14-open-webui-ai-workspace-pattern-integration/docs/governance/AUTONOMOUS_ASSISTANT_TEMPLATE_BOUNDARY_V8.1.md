<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
# Autonomous Assistant Template Boundary — V8.1

## Rule
The V8.1 assistant experience is a UI/template contract, not an autonomous runtime.

### Allowed now
- visual task/project states;
- local pause/resume representation;
- local checkpoints;
- Mission Control visualization;
- mode selectors;
- agent/tool/knowledge visibility;
- artifact delivery surface;
- safe activity summaries;
- explicit voice controls with no microphone activation.

### Future executable capability
- autonomous planning/orchestration;
- agents/tools/web execution;
- persistent memory/task runtime;
- background execution;
- computer use;
- live continuous voice.
