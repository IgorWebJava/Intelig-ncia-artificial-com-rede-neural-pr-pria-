# Local RAG & Semantic Reranking — v0.7.1-alpha.1

Documentos locais podem ser ingeridos no `NDRagIndex`, segmentados com overlap e recuperados por BM25 bounded. Quando o Semantic Ranker promovido está carregado, apenas os candidatos sparse top-N são reordenados neuralmente. Sem ranker, o comportamento cai deterministicamente para BM25; não existe fallback remoto.

No Android, o ranker é um asset canônico instalado atomicamente e passado ao JNI junto aos cinco assets herdados. O shard Pirá full de 1.281 registros não é ativado por esta mecânica.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
