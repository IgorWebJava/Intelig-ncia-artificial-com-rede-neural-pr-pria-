<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 121 — Module Preview Registry — V7.6

Every canonical module now owns a real visual preview generated from its canonical HTML/CSS.

```text
modules/<module>/preview/page-preview.png
modules/<module>/preview/preview.json
```

Standard profile:

```text
module-preview-v1
1600x1000
```

Previews travel with modules and must be regenerated after meaningful visual changes.
