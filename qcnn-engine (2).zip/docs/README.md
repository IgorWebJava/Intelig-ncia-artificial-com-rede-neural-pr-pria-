# 📚 DOCUMENTAÇÃO GERAL DO PROJETO QCNN ENGINE v5.0

Bem-vindo à documentação oficial e exaustiva do **QCNN Engine (Rede Quântico-Cabalística v5.0)**, um ecossistema computacional independente, autônomo, modular e de altíssima performance baseado em **Lógica Ternária Bitwise**, **Expansão Fractal (Milui)**, **Filtros de Adjacência Gramatical**, **Conversação por Ressonância Harmônica**, **Absorção Contínua de Novos Temas Offline** e **Núcleo de Emaranhamento Externo (Web Scraping Leve)**.

---

## 🎯 Missão e Filosofia do Projeto

1. **Autonomia 100% Pura (Sem LLMs de Terceiros)**:
   - Não utilizamos APIs externas de IA generativa (OpenAI, Google Gemini, Claude, etc.).
   - Todo o processamento de linguagem, decodificação semântica, cálculo áureo de frequências e emaranhamento conceitual é executado pelo nosso próprio motor matemático.
2. **Arquitetura Orientada a Objetos & Sistema Plug-and-Play**:
   - Cada funcionalidade do sistema é implementada como um plugin isolado (`BaseQcnnPlugin` em Python e `IQcnnPlugin` em Kotlin).
   - Módulos podem ser ativados, desativados, substituídos ou estendidos sem afetar o núcleo do pipeline.
3. **Eficiência Extrema & Zero Dependências Pesadas**:
   - Consumo de memória RAM rigorosamente inferior a 12MB.
   - Tempo de resposta e inferência na casa dos microssegundos / sub-milissegundos (< 1ms).
   - Funciona em qualquer dispositivo Android (smartphone, tablet) e servidores desktop locais.

---

## 🗺️ Fluxo de Decisão do Multiverso Semântico (v5.0)

Quando o observador envia uma entrada (por texto ou comando de voz), o pipeline executa a seguinte cascata inteligente em milissegundos:

```text
[ ENTRADA DO USUÁRIO (Texto / Voz) ]
               │
               ▼
   [ 1. BUSCA NO GRAFO INTERNO (RAM) ] ──────── (Achou?) ──────► [ Resposta Instantânea < 1ms ]
               │ (Vácuo Harmônico 0 Hz)
               ▼
   [ 2. SCRAPING EM ARQUIVOS .TXT LOCAL ] ───── (Achou?) ──────► [ Vetoriza Áureo & Responde ]
               │ (Não encontrado em disco)
               ▼
   [ 3. DISPARO DO NÚCLEO EXTERNO (WEB LEVE) ]
               │
               ▼
[ Extração de Resumo Puro ] ──► [ Cálculo de Hz Áureo ] ──► [ Salva em .TXT e no Grafo RAM ] ──► [ Resposta Final ]
```

---

## 📂 Visão Geral dos Módulos do Sistema

| Módulo / Plugin | Camadas | Responsabilidade |
| :--- | :--- | :--- |
| **`TernaryBitwisePlugin`** | Python / Kotlin / JS | Emulação ternária quântica `[-1, 0, 1]` via flags bitwise `10`, `01`, `00` (M3). |
| **`MiluiExpansionPlugin`** | Python / Kotlin / JS | Descompactação fractal genealógica das 22 sementes fundamentais (Alef a Tav) (M1). |
| **`AdjacencyFilterPlugin`** | Python / Kotlin / JS | Filtro gramatical e grafo de transição que previne loops e anagramas dissonantes (M6). |
| **`HarmonicFrequencyPlugin`** | Python / Kotlin / JS | Tabela harmônica e acumulador de frequências áureas em Hertz (M7). |
| **`HyperdimensionalComputingPlugin`** | Python / Kotlin | Computação Hiperdimensional ($D=10.000$ bits) com operações de Binding ($\otimes$), Bundling ($\oplus$) e Permutação ($\Pi$). |
| **`FractalGrammarPlugin`** | Python / Kotlin | Síntese gramatical e articulação semântica estruturada para superposição de conceitos múltiplos. |
| **`ConceptualDialoguePlugin`** | Python / Kotlin / JS | Motor de diálogo semântico, absorção local e conexão web leve com filtro de stop-words e absorção direta (M11). |
| **`OrganMultiplexerPlugin`** | Python / Kotlin | Modo Expedidor com chaveamento bitwise `0b10 << pos` de múltiplos órgãos (Direito, Medicina, etc.) (M10). |
| **`OctaveRegulatorPlugin`** | Python / Kotlin | Regulador de Oitavas Cognitivas ($1..5$) e Zoom Recursivo Áureo $\phi^{(n-1)/2}$ (M4). |
| **`FractalBreakerPlugin`** | Python / Kotlin | Disjuntor Fractal com atenuação exponencial $e^{-\lambda \cdot depth}$ blindando o consumo de RAM (M8). |
| **`ContextCrystallizerPlugin`** | Python / Kotlin | Cristalização persistente de identidade (`inconsciente.dat`) e retenção de Eco de Hz Residual (M9 & M12). |
| **`AssistantToolkitPlugin`** | Python / Kotlin | Assistente Universal Simbólico com resolvedor aritmético exato, planejador de workflows e conversor de grandezas físicas (M13). |
| **`MultiverseOraclePlugin`** | Python / Kotlin / JS | Oráculo Analítico Multi-V e Simulador Quântico de Realidades Paralelas com 4 linhas de tempo e parametrização do Observador (M14). |
| **`MyceliumIndexPlugin`** | Python / Kotlin | Roteamento Semântico Micelial Bio-Inspirado e Grafo Orgânico de Nutrientes Conceituais (M15). |
| **`MetaCognitiveAuditorPlugin`** | Python / Kotlin | Auditor Meta-Cognitivo e Validador Epistêmico de Coerência com $C$-Score de 100% (M16). |
| **`AudioSynthesisPlugin`** | Kotlin / JS | Síntese sonora senoidal PCM 16-bit nativa em tempo real via `AudioTrack` (M5). |
| **`HardwareTelemetryPlugin` / `TelemetryMeterPlugin`** | Python / Kotlin | Coleta de métricas reais de hardware (latência em nanossegundos e consumo de RAM em MB). |
| **`AndroidBridge` & Web Speech** | Kotlin / HTML5 / JS | Ponte bidirecional JavaScript-Kotlin e transcrição de áudio nativa por voz em português. |

---

## 📂 Estrutura de Documentação Detalhada

| Arquivo | Conteúdo |
| :--- | :--- |
| **`docs/CATALOGO_MODULOS.md`** | 📦 Especificação técnica exaustiva de cada classe, método, função e estrutura de dados do projeto. |
| **`docs/ARQUITETURA_MODULAR_PLUGINS.md`** | 🧩 Especificação de interfaces, ciclo de vida, padrões SOLID e guia de conexão de plugins. |
| **`docs/REGISTRO_ERROS_ACERTOS.md`** | 🛡️ Registro histórico com os 8 grandes marcos aprovados, armadilhas superadas e checklist de validação. |
| **`docs/REGISTRO_TESTES_RESULTADOS.md`** | 📋 Registro permanente e oficial de todos os testes reais executados no motor com métricas de Hz, RAM e latência. |

---

## 🚀 Como Executar o Projeto

### 1. Servidor Python Local
```bash
pip install flask
python app.py
```
Acesse no navegador: `http://127.0.0.1:5000`

### 2. No Aplicativo Nativo Android
Compile e instale diretamente via Gradle:
```bash
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```
A interface gráfica HTML5 é carregada embutida via WebView com aceleração por hardware, suporte a voz nativa e síntese senoidal instantânea.
