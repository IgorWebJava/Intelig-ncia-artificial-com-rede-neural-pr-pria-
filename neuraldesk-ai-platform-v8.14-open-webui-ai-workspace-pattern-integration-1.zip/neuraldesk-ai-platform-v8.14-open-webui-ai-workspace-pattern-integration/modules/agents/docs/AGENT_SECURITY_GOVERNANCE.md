<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent Security & Governance

Least privilege applies per agent/tool binding. Autonomy modes are Assisted, Supervised, Autonomous Within Policy. Budgets limit cost/tokens/tools/runtime/retries/delegation. HIGH risk requires human approval; CRITICAL is blocked by default unless explicit policy permits.
