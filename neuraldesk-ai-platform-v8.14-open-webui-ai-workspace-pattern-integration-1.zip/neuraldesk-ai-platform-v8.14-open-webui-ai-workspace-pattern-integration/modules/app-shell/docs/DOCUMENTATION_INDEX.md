<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/DOCUMENTATION_INDEX.md -->
# App Shell — Documentation Index

## Current truth

- `CURRENT_STATE.md`
- `MECHANICS_AND_FUNCTIONALITY.md`
- `AI_MODULE_HANDOFF.md`
- `MODULE_ARCHITECTURE.md`
- `CONTRACTS_AND_CAPABILITIES.md`
- `DATA_OWNERSHIP_AND_CONSISTENCY.md`
- `INTEGRATION_AND_REPLACEMENT.md`
- `UI_RUNTIME_AND_DESIGN_SYSTEM.md`
- `RESPONSIVE_MULTIMODAL_UI.md`
- `MULTIMODAL_AI_INTEGRATION.md`
- `TESTING_AND_QUALITY.md`
- `DEVELOPMENT_SKILLS_AND_TOOLING.md`
- `MODULE_PREVIEW.md`

## Additional domain/reference docs

- `DATA_CONTRACT.md`
- `INTELLIGENCE_EXPERIENCE_V8.2.md`
- `index-acceptance-criteria.md`
- `index-launcher-page.md`
- `FUTURE_EXECUTABLE_READINESS.md` — V8.7 roadmap from current UI mechanics to verified executable behavior.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
