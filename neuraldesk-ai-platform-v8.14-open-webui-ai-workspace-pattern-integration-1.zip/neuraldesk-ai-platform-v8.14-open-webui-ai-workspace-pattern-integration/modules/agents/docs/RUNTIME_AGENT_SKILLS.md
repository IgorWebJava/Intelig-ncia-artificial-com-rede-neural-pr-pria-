<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Runtime Agent Skills

Runtime skills are cataloged by `platform/agent-skill-registry/`. They are distinct from `habilidades/`, which documents how humans/AIs develop NeuralDesk. Runtime skills may declare required capabilities, suggested tools, inputs/outputs, guardrails and evaluation criteria.
