#include "nd_project.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    const char *path = "/tmp/neuraldesk-projects-v072-test.ndpr";
    remove(path);
    NDProjectStore s;
    nd_project_store_init(&s);
    char err[256], scoped[256];
    int fail = 0;
    fail += nd_project_store_set_path(&s, path, err, sizeof(err)) != 0;
    fail += nd_project_store_restore(&s, err, sizeof(err)) != 0;
    fail += s.count != 1u || strcmp(nd_project_current(&s)->id, "default") != 0;
    fail += nd_project_create(&s, "aurora-3", "  Projeto   Aurora  ", 100u, err, sizeof(err)) != 0;
    fail += nd_project_select(&s, "aurora-3", err, sizeof(err)) != 0;
    fail += strcmp(nd_project_current(&s)->name, "Projeto Aurora") != 0;
    fail += nd_project_rename(&s, "aurora-3", "Aurora Pesquisa", 200u, err, sizeof(err)) != 0;
    fail += nd_project_storage_path("/data/neuraldesk", "aurora-3", "memory.ndmem", scoped, sizeof(scoped)) != 0;
    fail += strcmp(scoped, "/data/neuraldesk/aurora-3/memory.ndmem") != 0;
    fail += nd_project_remove(&s, "default", err, sizeof(err)) == 0;
    fail += nd_project_remove(&s, "aurora-3", err, sizeof(err)) != 0;
    fail += strcmp(nd_project_current(&s)->id, "default") != 0;
    NDProjectStore r;
    nd_project_store_init(&r);
    fail += nd_project_store_set_path(&r, path, err, sizeof(err)) != 0;
    fail += nd_project_store_restore(&r, err, sizeof(err)) != 0;
    fail += r.count != 1u || strcmp(nd_project_current(&r)->id, "default") != 0;
    remove(path);
    printf("LOCAL_PROJECTS %s projects=%zu\n", fail ? "FAIL" : "PASS", r.count);
    return fail ? 1 : 0;
}
