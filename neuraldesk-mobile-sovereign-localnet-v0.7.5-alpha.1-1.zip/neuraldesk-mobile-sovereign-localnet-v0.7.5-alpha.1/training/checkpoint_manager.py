#!/usr/bin/env python3
"""Integrity-bound training checkpoint manager; checkpoints are transient and never promoted models."""
from __future__ import annotations
import hashlib,json,os,tempfile
from pathlib import Path
import numpy as np

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def canonical(o)->bytes:return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def save_checkpoint(directory:Path,*,phase:str,step:int,model:dict[str,np.ndarray],optimizer:dict[str,np.ndarray],bindings:dict)->Path:
    directory.mkdir(parents=True,exist_ok=True)
    meta={'schema':'neuraldesk-training-checkpoint-v1','phase':phase,'step':int(step),'bindings':dict(bindings),'modelKeys':sorted(model),'optimizerKeys':sorted(optimizer)}
    target=directory/f'{phase}-step-{step:08d}.npz'; meta_path=target.with_suffix('.json'); side=target.with_suffix('.sha256')
    arrays={f'model::{k}':np.asarray(model[k]) for k in sorted(model)}|{f'optimizer::{k}':np.asarray(optimizer[k]) for k in sorted(optimizer)}
    with tempfile.NamedTemporaryFile(dir=directory,suffix='.npz',delete=False) as tmp:
        np.savez(tmp,**arrays); tmp_path=Path(tmp.name)
    data=tmp_path.read_bytes(); digest=sha_bytes(data); tmp_path.replace(target)
    meta['checkpointSha256']=digest; meta_path.write_bytes(canonical(meta)+b'\n'); side.write_text(digest+'\n')
    return target

def load_checkpoint(path:Path,*,expected_bindings:dict):
    meta=json.loads(path.with_suffix('.json').read_text()); digest=sha_bytes(path.read_bytes())
    if digest!=meta.get('checkpointSha256') or path.with_suffix('.sha256').read_text().strip()!=digest: raise ValueError('checkpoint integrity mismatch')
    if meta.get('bindings')!=expected_bindings: raise ValueError('checkpoint binding drift')
    z=np.load(path,allow_pickle=False)
    model={k.split('::',1)[1]:z[k].copy() for k in z.files if k.startswith('model::')}
    opt={k.split('::',1)[1]:z[k].copy() for k in z.files if k.startswith('optimizer::')}
    return meta,model,opt
