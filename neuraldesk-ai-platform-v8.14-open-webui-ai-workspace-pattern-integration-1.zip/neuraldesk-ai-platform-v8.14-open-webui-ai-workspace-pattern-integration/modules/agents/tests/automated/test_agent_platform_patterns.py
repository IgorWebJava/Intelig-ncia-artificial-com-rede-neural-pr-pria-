import sys, unittest, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class AgentPlatformPatternTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.ctx=TestContext(__file__)
    def test_v812_marker(self): self.assertIn('id="autogpt-pattern-v812"', self.ctx.html)
    def test_pattern_label(self): self.assertIn('Agent Platform Pattern V8.12', self.ctx.normalized_html)
    def test_truth_boundary(self): self.assertIn('engine not connected', self.ctx.normalized_html.lower())
    def test_manifest_profile(self): self.assertEqual(self.ctx.manifest.get('ui_surface',{}).get('agent_platform_pattern_profile'),'agent-platform-patterns-v1')
    def test_research_doc(self): self.assertTrue((self.ctx.project_root/'neural-engine/research/autogpt-platform-2026/README.md').exists())
if __name__=='__main__': unittest.main()
