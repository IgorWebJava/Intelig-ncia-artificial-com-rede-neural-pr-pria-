<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# AI Capability Fabric & Model Routing

    Skill ID: `neuraldesk.ai-capability-fabric.v1`

    ## Category

    `ai`

    ## Introduced

    `V7.0`

    ## Required development capabilities

    - `ai.capability.fabric.design.v1`
- `ai.model-replacement.design.v1`
- `multimodal.contract.design.v1`

    ## Used by

    - `chat`
- `training`
- `knowledge`
- `tools`
- `system-config`

    ## Related project artifacts

    - `platform/ai-fabric/`
- `adapters/ai/`
- `contracts/ai/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
