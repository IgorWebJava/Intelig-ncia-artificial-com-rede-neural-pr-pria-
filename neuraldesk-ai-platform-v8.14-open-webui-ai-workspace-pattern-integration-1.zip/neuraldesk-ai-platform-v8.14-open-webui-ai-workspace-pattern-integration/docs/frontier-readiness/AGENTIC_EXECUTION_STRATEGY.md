# Agentic Execution Strategy

Prefer the simplest execution structure that meets the task.

Order of complexity:
1. direct model response;
2. model + retrieval;
3. model + tool;
4. deterministic workflow;
5. single agent;
6. supervisor + specialists;
7. multi-agent graph.

Multi-agent orchestration must prove improvement against simpler baselines because extra agents increase latency, cost and failure surface.

All side effects use policy, idempotency, approvals and audit.
