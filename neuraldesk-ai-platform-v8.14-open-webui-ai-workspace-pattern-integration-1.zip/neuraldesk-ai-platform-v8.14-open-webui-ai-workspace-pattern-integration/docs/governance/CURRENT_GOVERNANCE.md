<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.governance -->
# Current Governance — V8.11

## Scope

Govern the implemented interface platform and the documentation-only future Neural Engine as one coordinated system while preserving the truth boundary between them.

## Mandatory rules

1. **No regression:** `preserve → extend → bridge` is mandatory. Removal or semantic breakage requires an explicit migration/versioning decision and must fail the non-regression gate otherwise.
2. **Truth boundary:** `IMPLEMENTED-TEMPLATE-UI` / `UI_CONTRACT_READY` is not `IMPLEMENTED-ENGINE`.
3. **Canonical ownership:** canonical UI lives under `modules/<module>/ui/`; root HTML files remain compatibility aliases.
4. **Module ownership:** modules own private implementation/data; consumers depend only on public contracts/capabilities.
5. **Engine/UI cooperation:** all 94 future engine modules must have UI ownership or an explicit headless/control-plane representation.
6. **Provider neutrality:** model, inference, training, storage, tool and agent providers remain replaceable behind stable NeuralDesk capabilities.
7. **Research governance:** external GitHub/paper claims require local reproduction/evidence before adoption.
8. **Safety and approvals:** irreversible/high-risk future actions require policy, authorization, durable intent, approval semantics and auditability.
9. **Documentation synchronization:** interface docs, engine docs, registries, memory, skills, tests, previews and AI handoff move together.
10. **Historical preservation:** historical/reference documents remain preserved and clearly classified; CURRENT sources win conflicts.
11. **Visual evidence:** meaningful UI changes require regenerated previews and browser/responsive validation.
12. **Engine implementation:** executable Neural Engine code remains prohibited until an explicit future implementation phase is requested.
13. **Release packaging:** prior versions are preserved; every delivery ends with one complete ZIP.

## Current maturity

- Interface/template: **V8.11**, cooperative additive UI with local-only interaction runtime.
- Current resolved UI/platform capabilities: **106**.
- Neural Engine blueprint: **V8.11**, 94 modules / 391 capabilities, documentation-only.
- Documentation / memory / skills: **V8.11**.
- Engine executable status: **NOT IMPLEMENTED**.

## Required gates

At minimum: architecture, documentation, documentation sync/completeness/status/inventory, testing, skills, previews, responsive/browser visual, Neural Engine research/documentation, Engine↔UI compatibility and non-regression validation.
