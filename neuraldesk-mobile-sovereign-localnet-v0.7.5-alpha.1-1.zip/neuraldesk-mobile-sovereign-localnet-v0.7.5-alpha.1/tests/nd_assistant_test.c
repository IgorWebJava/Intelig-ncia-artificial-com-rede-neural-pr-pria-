#include "nd_assistant.h"

#include <stdio.h>
#include <string.h>

static int must_contain(const char *name, const char *out, const char *needle) {
    if (strstr(out, needle)) return 0;
    fprintf(stderr, "%s missing [%s] in [%s]\n", name, needle, out);
    return 1;
}

int main(int argc, char **argv) {
    if (argc != 5) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION\n", argv[0]);
        return 2;
    }
    NDAssistant a;
    NDAnswerMeta m;
    char err[256], out[32768];
    if (nd_assistant_load(&a, argv[1], argv[2], argv[3], argv[4], err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }
    int bad = 0;

    if (nd_assistant_answer(&a, "Qual é a capital do Brasil?", NULL, 1, out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_KNOWLEDGE) bad++;
    bad += must_contain("knowledge", out, "Brasília");

    if (nd_assistant_answer(&a, "Quanto é 17 vezes 23?", NULL, 1, out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_CALCULATOR) bad++;
    bad += must_contain("calculator", out, "391");

    const char *ctx = "O código anterior do projeto Atlas-77 era OLD-9. O código atual do projeto Atlas-77 é NX-88. Marina é responsável pelo projeto Atlas-77. A cor atual é turquesa.";
    if (nd_assistant_answer(&a, "Qual é o código atual do projeto Atlas-77 e quem é responsável?", ctx, 1,
                            out, sizeof(out), &m, err, sizeof(err)) || m.source != ND_ANSWER_COMPOSED) bad++;
    bad += must_contain("context-code", out, "NX-88");
    bad += must_contain("context-owner", out, "Marina");
    if (m.goal_count != 2u || m.covered_goals != 2u) {
        fprintf(stderr, "context goal coverage mismatch %zu/%zu\n", m.covered_goals, m.goal_count);
        bad++;
    }

    if (nd_assistant_answer(&a, "Quanto é 17 vezes 23 e qual é a capital do Brasil?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) || m.source != ND_ANSWER_COMPOSED) bad++;
    bad += must_contain("mixed-calculator", out, "391");
    bad += must_contain("mixed-knowledge", out, "Brasília");
    if (m.goal_count != 2u || m.covered_goals != 2u || m.tool_calls != 1u) bad++;

    if (nd_assistant_answer(&a, "Lembre que o código do projeto Aurora é MEM-442.", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) || m.source != ND_ANSWER_MEMORY) bad++;
    if (nd_assistant_answer(&a, "Qual é o código do projeto Aurora?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) || m.source != ND_ANSWER_MEMORY) bad++;
    bad += must_contain("memory", out, "MEM-442");

    if (nd_assistant_answer(&a, "Qual é a senha privada que não foi fornecida?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) || m.source != ND_ANSWER_UNCERTAIN) bad++;
    bad += must_contain("uncertainty", out, "Não sei com segurança");

    nd_assistant_free(&a);
    if (bad) return 1;
    puts("assistant_orchestrator PASS");
    return 0;
}
