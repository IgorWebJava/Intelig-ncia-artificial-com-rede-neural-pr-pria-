from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class CollapseResult:
    resposta: str
    arvore: str
    estado: str
    frequencia: str
    latencia: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "resposta": self.resposta,
            "arvore": self.arvore,
            "estado": self.estado,
            "frequencia": self.frequencia,
            "latencia": self.latencia,
            "metadata": self.metadata
        }

@dataclass
class QcnnExecutionContext:
    prompt: str
    target_seed: str = "Alef"
    chain: List[str] = field(default_factory=list)
    total_frequency_hz: float = 0.0
    final_state: str = "00 (Vácuo / Superposição)"
    latency_ms: float = 0.0
    active_nodes: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    custom_response: str = ""

    def to_collapse_result(self) -> CollapseResult:
        arvore_str = " → ".join(self.chain) if self.chain else self.target_seed
        if self.custom_response:
            resposta_texto = self.custom_response
        else:
            resposta_texto = (
                f"Sinal interpretado com sucesso pelo Núcleo 3. A semente '{self.target_seed}' disparou "
                f"um pulso de ressonância harmônica. O filtro de adjacência semântica impediu a "
                f"dissonância e estabilizou a seguinte árvore de manifestação real: {arvore_str}."
            )
        return CollapseResult(
            resposta=resposta_texto,
            arvore=arvore_str,
            estado=self.final_state,
            frequencia=f"{self.total_frequency_hz:.2f} Hz",
            latencia=f"{self.latency_ms:.3f}ms",
            metadata=dict(self.metadata)
        )
