<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Security, Authorization & Secrets

    Skill ID: `neuraldesk.security-governance.v1`

    ## Category

    `security`

    ## Introduced

    `V6.8`

    ## Required development capabilities

    - `security.threat-model.v1`
- `audit.trace.design.v1`
- `data.ownership.design.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `platform/authorization/`
- `platform/secrets/`
- `database/platform/rls.sql`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
