<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
# V8.0 — Next-Generation AI Workspace OS

## Experience

All 10 canonical UIs were rebuilt around a consistent Workspace Shell, readable typography and progressive disclosure.

## Runtime

Added module-owned JavaScript runtime (`workspace-runtime-v1`) with real local UI interactions. No global JS runtime dependency and no fake backend calls.

## Platform

Added `platform/design-system/`, `platform/experience-runtime/` and new UI capabilities.

## Quality

Testing profile upgraded to `module-quality-v2` with runtime isolation/interaction tests. Previews now hash runtime JS as well as HTML/CSS.
