<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.agents; current: modules/agents/docs/TESTING_AND_QUALITY.md -->
# Agent Projects & Multi-Agent Studio — Testing & Quality

Profile: `module-quality-v2`

## Executable now

- architecture/manifest checks;
- contract/capability checks;
- UI semantics;
- module-owned runtime isolation;
- security/data static checks;
- responsive checks;
- browser visual checks;
- preview freshness;
- Intelligence Experience V2 surfaces;
- documentation/skills synchronization.

## Future integration/E2E

Backend/API/database/event/AI/tool behavior remains explicitly future until executable services exist. Tests must not claim those paths passed today.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


## Engine Bridge V8.11
Non-regression, truth-boundary and bridge-marker coverage is executable through `test_engine_bridge.py` plus `scenarios/engine-ui-bridge-v811.json`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
