package com.example.engine.core

/**
 * Emulação Ternária [-1, 0, 1] usando Dupla Flag Bitwise.
 */
class NoTernario(
    val letra: String,
    val frequenciaBase: Double
) {
    var bitAtivacao: Boolean = false // Flag para estado 1
    var bitInibicao: Boolean = false // Flag para estado -1
    var contadorAtencao: Int = 0

    fun definirEstado(valorTernario: Int) {
        when (valorTernario) {
            0 -> {
                bitAtivacao = false
                bitInibicao = false
            }
            1 -> {
                bitAtivacao = true
                bitInibicao = false
                contadorAtencao++
            }
            -1 -> {
                bitAtivacao = false
                bitInibicao = true
            }
        }
    }

    fun obterEstadoStr(): String {
        return when {
            !bitAtivacao && !bitInibicao -> "00 (Vácuo / Superposição)"
            bitAtivacao && !bitInibicao -> "10 (Ativação Construtiva)"
            !bitAtivacao && bitInibicao -> "01 (Inibição / Ruído)"
            else -> "00"
        }
    }
}
