<!-- neuraldesk-documentation-sync: V8.11 -->

# Test Plan — System Audit, Trace & Control Center

## Objective

Prove that `neuraldesk.audit` can evolve, integrate and be replaced without violating NeuralDesk architecture.

## Test pyramid

```text
Static / contract tests        — run now
Browser visual tests           — run now with Playwright
Integration / API / DB tests   — run when backend exists
Event / distributed tests      — run when event platform exists
AI / agent / tool E2E tests    — run when runtime exists
Replacement / canary tests     — run before switching production binding
```

## Functional mechanics in scope

- Display audit overview and coverage
- Display live system events
- Filter/search Audit Explorer
- Inspect event metadata/before-after/related events
- Inspect distributed traces
- Audit user activity
- Audit agent runs and safe operational trajectory
- Audit services/automation
- Audit page/module namespaces
- Audit knowledge events
- Audit tools/MCP invocations
- Audit model activity
- Audit training/model lifecycle
- Audit security events/redaction policy
- Audit human approvals
- Audit system evolution and module/model replacements
- Audit deployments
- Correlate incidents
- Provide read-only query console
- Represent policy-controlled admin actions
- Verify integrity/hash-chain concepts
- Represent retention/archive policy
- Represent audit settings
- Audit multimodal/media events

## Device coverage

```text
Phone      390x844
Tablet     768x1024
Notebook   1366x768
Desktop/TV 1920x1080
TV/4K      3840x2160
```

## Release rule

This test package is owned by the module and must travel with it.


## Engine Bridge V8.11
Non-regression, truth-boundary and bridge-marker coverage is executable through `test_engine_bridge.py` plus `scenarios/engine-ui-bridge-v811.json`.
