import os
import re
import urllib.parse
import urllib.request
import json
from typing import Dict, List, Optional
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS

GRAFO_CONCEITUAL = {
    "universo": {
        "hz": 65.55,
        "conexoes": ["mente", "tempo", "infinito", "origem"],
        "resposta": "O universo é a grande matriz. Tudo o que existe está compactado em sua malha de espaço-tempo."
    },
    "mente": {
        "hz": 42.18,
        "conexoes": ["universo", "consciência", "pensamento", "origem"],
        "resposta": "A mente é o observador quântico. Sem ela, todas as possibilidades permanecem em superposição infinita."
    },
    "consciencia": {
        "hz": 88.88,
        "conexoes": ["mente", "vida", "origem", "universo"],
        "resposta": "A consciência é o substrato primordial da existência. O cérebro não a produz isoladamente, mas atua como receptor ressonante no campo unificado."
    },
    "tempo": {
        "hz": 144.0,
        "conexoes": ["universo", "filosofia", "entropia", "espaço"],
        "resposta": "O tempo é uma ilusão dimensional. No código-fonte do Alef, o passado, o presente e o futuro coexistem agora."
    },
    "origem": {
        "hz": 1.618,
        "conexoes": ["universo", "alef", "vida", "mente"],
        "resposta": "A origem de tudo é o ponto zero do Alef: uma singularidade que se expandiu através da proporção áurea."
    },
    "vida": {
        "hz": 528.0,
        "conexoes": ["origem", "consciência", "evolução", "mente"],
        "resposta": "A vida é a matéria animada pela frequência do sopro primordial, organizando a entropia em padrões fractais conscientes."
    },
    "deus": {
        "hz": 999.0,
        "conexoes": ["origem", "universo", "infinito", "alef"],
        "resposta": "Deus é a consciência pura não manifestada, a totalidade de onde emergem todas as 22 fendas da realidade."
    },
    "futuro": {
        "hz": 333.0,
        "conexoes": ["tempo", "mente", "possibilidade", "universo"],
        "resposta": "O futuro é um campo de infinitas probabilidades que colapsa na direção da sua intenção mais profunda."
    },
    "fisica quantica": {
        "hz": 432.0,
        "conexoes": ["universo", "mente", "átomo", "luz"],
        "resposta": "A física quântica revela que na escala fundamental a matéria é pura informação e vibração harmônica."
    },
    "quântica": {
        "hz": 432.0,
        "conexoes": ["universo", "mente", "átomo", "luz"],
        "resposta": "O domínio quântico comprova o entrelaçamento universal: partículas distantes respondem instantaneamente em ressonância."
    }
}

class ConceptualDialoguePlugin(BaseQcnnPlugin):
    """
    Plugin de Diálogo Conceitual, Destilação Ontológica Contínua e Emaranhamento Web v5.0.
    Capaz de ingerir lotes de arquivos de conhecimento local (.txt), indexando termos,
    calculando frequências áureas determinísticas e permitindo inferência ultra-rápida sem LLMs externas.
    """
    def __init__(self, pasta_conhecimento: str = "./conhecimento_local"):
        super().__init__()
        self.grafo = dict(GRAFO_CONCEITUAL)
        self.sinonimos_map: Dict[str, str] = {}
        self.conexoes_dialogicas: Dict[str, Dict] = {}
        self.pasta_conhecimento = pasta_conhecimento
        self._carregar_sinonimos_e_relacoes()
        self._ingerir_lote_conhecimento()

    def _carregar_sinonimos_e_relacoes(self):
        pastas = [self.pasta_conhecimento, "./conhecimento_local", "conhecimento_local"]
        for p in pastas:
            json_path = os.path.join(p, "sinonimos_e_relacoes.json")
            if os.path.exists(json_path):
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        sinonimos = data.get("sinonimos", {})
                        for conceito_raiz, aliases in sinonimos.items():
                            raiz_norm = self._normalizar(conceito_raiz)
                            for alias in aliases:
                                self.sinonimos_map[self._normalizar(alias)] = raiz_norm
                        self.conexoes_dialogicas = data.get("conexoes_dialogicas", {})
                        break
                except Exception:
                    pass

    @property
    def plugin_id(self) -> str:
        return "conceptual_dialogue"

    def _normalizar(self, texto: str) -> str:
        t = texto.lower()
        mapa = {
            'á': 'a', 'à': 'a', 'ã': 'a', 'â': 'a',
            'é': 'e', 'ê': 'e',
            'í': 'i',
            'ó': 'o', 'õ': 'o', 'ô': 'o',
            'ú': 'u',
            'ç': 'c', '_': ' ', '-': ' '
        }
        for k, v in mapa.items():
            t = t.replace(k, v)
        return t

    def _sintetizar_frequencia(self, texto: str) -> float:
        phi = 1.61803398875
        soma = sum((ord(c) % 100) * phi for c in texto)
        return round((soma % 900.0 + 20.0), 2)

    def _ingerir_lote_conhecimento(self):
        """Ingere em lote todos os manuais, livros e artigos .txt disponíveis."""
        pastas = [self.pasta_conhecimento, "./conhecimento_local", "conhecimento_local"]
        for p in pastas:
            if os.path.exists(p) and os.path.isdir(p):
                for f in os.listdir(p):
                    if f.endswith('.txt'):
                        nome_base = self._normalizar(os.path.splitext(f)[0])
                        caminho = os.path.join(p, f)
                        try:
                            with open(caminho, 'r', encoding='utf-8') as arq:
                                conteudo = arq.read().strip()
                                if conteudo and nome_base not in self.grafo:
                                    hz = self._sintetizar_frequencia(conteudo)
                                    self.grafo[nome_base] = {
                                        "hz": hz,
                                        "conexoes": ["ontologia_expandida", "conhecimento_local"],
                                        "resposta": conteudo
                                    }
                        except Exception:
                            pass

    def _varrer_arquivo_local(self, termo: str) -> Optional[str]:
        termo_norm = self._normalizar(termo)
        pastas = [self.pasta_conhecimento, "./conhecimento_local", "conhecimento_local"]
        for p in pastas:
            if os.path.exists(p) and os.path.isdir(p):
                for f in os.listdir(p):
                    if f.endswith('.txt'):
                        nome_base = self._normalizar(os.path.splitext(f)[0])
                        if nome_base == termo_norm or termo_norm in nome_base or nome_base in termo_norm:
                            try:
                                with open(os.path.join(p, f), 'r', encoding='utf-8') as arq:
                                    conteudo = arq.read().strip()
                                    if conteudo:
                                        return conteudo
                            except Exception:
                                pass
        return None

    def _persistir_conhecimento_local(self, termo: str, conteudo: str):
        """Salva o conhecimento obtido em disco para consultas offline imediatas e permanentes."""
        termo_limpo = re.sub(r'[^\w\s-]', '', termo).strip().replace(' ', '_').lower()
        if not termo_limpo:
            return
        pastas = [self.pasta_conhecimento, "./conhecimento_local", "conhecimento_local"]
        for p in pastas:
            try:
                os.makedirs(p, exist_ok=True)
                caminho_arquivo = os.path.join(p, f"{termo_limpo}.txt")
                with open(caminho_arquivo, "w", encoding="utf-8") as f:
                    f.write(conteudo.strip())
                break
            except Exception:
                continue

    def _consultar_wikipedia(self, termo: str) -> Optional[str]:
        try:
            encoded = urllib.parse.quote(termo)
            url = f"https://pt.wikipedia.org/api/rest_v1/page/summary/{encoded}"
            req = urllib.request.Request(url, headers={'User-Agent': 'QCNNEngine/5.0 (Python/Agent)'})
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    extract = data.get('extract')
                    if extract and len(extract.strip()) > 20:
                        return extract.strip()
        except Exception:
            pass
        return None

    def _consultar_duckduckgo(self, termo: str) -> Optional[str]:
        try:
            encoded = urllib.parse.quote(termo)
            url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_redirect=1&no_html=1"
            req = urllib.request.Request(url, headers={'User-Agent': 'QCNNEngine/5.0 (Python/Agent)'})
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    abstract = data.get('AbstractText') or data.get('Abstract')
                    if abstract and len(abstract.strip()) > 20:
                        return abstract.strip()
        except Exception:
            pass
        return None

    def _agente_busca_web_autonomo(self, termo: str) -> Optional[str]:
        """Agente autônomo multicanal que pesquisa na internet e persiste offline."""
        # 1. Tenta Wikipédia em Português
        resultado = self._consultar_wikipedia(termo)
        if resultado:
            self._persistir_conhecimento_local(termo, resultado)
            return resultado

        # 2. Tenta DuckDuckGo Instant Answer
        resultado = self._consultar_duckduckgo(termo)
        if resultado:
            self._persistir_conhecimento_local(termo, resultado)
            return resultado

        return None

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt_orig = context.prompt
        prompt_norm = self._normalizar(prompt_orig)
        prompt_lower = prompt_orig.lower()

        # Verifica se é comando de semente
        letras_22 = MATRIZ_22_LETRAS.keys()
        eh_comando_semente = any(
            letra.lower() in prompt_lower and (
                "semente" in prompt_lower or
                "descompactar" in prompt_lower or
                "arvore" in prompt_lower or
                "árvore" in prompt_lower or
                "fenda" in prompt_lower or
                "colapsar" in prompt_lower or
                "ativar" in prompt_lower or
                "letra" in prompt_lower or
                "núcleo" in prompt_lower or
                "nucleo" in prompt_lower
            )
            for letra in letras_22
        )

        if eh_comando_semente:
            return context

        if context.custom_response:
            return context

        nos_ativados = []
        respostas_partes = []
        frequencia_total = 0.0

        STOP_WORDS = {
            "como", "quem", "qual", "quais", "onde", "porque", "por que", "quando",
            "esse", "essa", "este", "esta", "isso", "isto", "aquilo", "aquele", "aquela",
            "sobre", "para", "com", "sem", "pelo", "pela", "pelos", "pelas", "entre",
            "tudo", "nada", "algo", "voce", "você", "lembra", "sabe", "dizer", "explicar",
            "falar", "meu", "minha", "seus", "suas", "nosso", "nossa", "está", "estao",
            "estão", "esta", "estao", "sendo", "muito", "mais", "menos", "gravar",
            "grave", "conhecimento", "aprendeu", "aprender", "resumo", "agora", "ate"
        }

        # 1. Verifica no grafo conceitual existente e no mapa de sinonímias
        conceitos_identificados = set()
        
        # Busca direta por termos do grafo
        for conceito, dados in self.grafo.items():
            conceito_norm = self._normalizar(conceito)
            if conceito_norm in STOP_WORDS:
                continue
            if re.search(rf"\b{re.escape(conceito_norm)}\b", prompt_norm):
                if conceito not in conceitos_identificados:
                    conceitos_identificados.add(conceito)
                    nos_ativados.append(conceito)
                    respostas_partes.append(dados["resposta"])
                    frequencia_total += dados["hz"]

        # Busca por sinônimos e termos compostos
        for alias, conceito_raiz in self.sinonimos_map.items():
            if alias in STOP_WORDS:
                continue
            if re.search(rf"\b{re.escape(alias)}\b", prompt_norm):
                # Se o conceito raiz está no grafo e ainda não foi ativado
                if conceito_raiz in self.grafo and conceito_raiz not in conceitos_identificados:
                    conceitos_identificados.add(conceito_raiz)
                    nos_ativados.append(conceito_raiz)
                    respostas_partes.append(self.grafo[conceito_raiz]["resposta"])
                    frequencia_total += self.grafo[conceito_raiz]["hz"]

        # 2. Padrão de Ensino / Absorção Direta ("Grave esse conhecimento: X", "Aprenda que: Y")
        match_ensino = re.search(r"(?:grave\s+(?:esse\s+)?conhecimento|aprenda\s+que|memorize|grave)\s*:\s*(.+)", prompt_orig, re.IGNORECASE)
        if match_ensino:
            frase_aprendida = match_ensino.group(1).strip()
            if len(frase_aprendida) > 5:
                termo_chave = "conhecimento_absorvido"
                # Extrai palavras-chave do ensinamento
                palavras_chave = [p for p in re.split(r'[\s,;:.?!]+', self._normalizar(frase_aprendida)) if len(p) > 3 and p not in STOP_WORDS]
                if palavras_chave:
                    termo_chave = palavras_chave[0]
                hz = self._sintetizar_frequencia(frase_aprendida)
                self.grafo[termo_chave] = {
                    "hz": hz,
                    "conexoes": ["aprendizado_continuo", "memoria_dinamica"],
                    "resposta": frase_aprendida
                }
                nos_ativados.append(termo_chave)
                respostas_partes.append(f"[CONHECIMENTO ABSORVIDO COM SUCESSO]<br><br>O padrão vibracional '<em>{termo_chave.upper()}</em>' ({hz} Hz) foi integrado e compactado na malha conceitual: \"{frase_aprendida}\"")
                frequencia_total += hz

        if not nos_ativados:
            # Tenta extrair entidades/frases ou palavras significativas do prompt
            candidatos_busca = []
            
            # Limpa prefixos comuns como "o que e", "quem foi", "pesquise sobre", "o que significa"
            prompt_limpo = re.sub(r'^(?:o\s+que\s+e|o\s+que\s+e\s+o|o\s+que\s+e\s+a|o\s+que\s+significa|quem\s+foi|quem\s+e|qual\s+a\s+definicao\s+de|pesquise\s+sobre|busque\s+sobre|explique\s+sobre|explique)\s+', '', prompt_norm, flags=re.IGNORECASE).strip()
            if prompt_limpo and len(prompt_limpo) > 2 and prompt_limpo not in STOP_WORDS:
                candidatos_busca.append(prompt_limpo)

            palavras = [p for p in re.split(r'[\s,;:.?!]+', prompt_norm) if len(p) > 3 and p not in STOP_WORDS]
            for p in palavras:
                if p not in candidatos_busca:
                    candidatos_busca.append(p)

            for candidato in candidatos_busca:
                # 1. Primeiro verifica cache/disco local
                local_content = self._varrer_arquivo_local(candidato)
                if local_content:
                    hz = self._sintetizar_frequencia(local_content)
                    self.grafo[candidato] = {
                        "hz": hz,
                        "conexoes": ["conhecimento_local", "absorcao_permanente"],
                        "resposta": local_content
                    }
                    nos_ativados.append(candidato)
                    respostas_partes.append(f"[CONHECIMENTO LOCAL RECUPERADO: {candidato.upper()}]<br><br>{local_content}")
                    frequencia_total += hz
                    break

                # 2. Despacha o Agente Autônomo de Busca e Pesquisa Web
                resultado_web = self._agente_busca_web_autonomo(candidato)
                if resultado_web:
                    hz = self._sintetizar_frequencia(resultado_web)
                    self.grafo[candidato] = {
                        "hz": hz,
                        "conexoes": ["agente_web_autonomo", "pesquisa_online", "persistido_offline"],
                        "resposta": resultado_web
                    }
                    nos_ativados.append(candidato)
                    respostas_partes.append(
                        f"🌐 <strong>[AGENTE DE PESQUISA WEB: CONHECIMENTO ADQUIRIDO]</strong><br><br>"
                        f"<strong>Conceito Mapeado:</strong> <code>{candidato.upper()}</code> ({hz} Hz)<br>"
                        f"<strong>Síntese Capturada:</strong> {resultado_web}<br><br>"
                        f"💾 <em>Status: Dados indexados e salvos permanentemente no disco local para futuras consultas 100% offline.</em>"
                    )
                    frequencia_total += hz
                    break

        if not nos_ativados:
            context.custom_response = "Entendi o seu foco. O sinal vibracional ecoou pelo vácuo quântico, mas este assunto ainda não possui uma assinatura disponível nas redes internas ou externas."
            context.final_state = "10 (Diálogo Colapsado)"
            context.total_frequency_hz = 0.0
            context.metadata["active_concepts"] = []
            return context

        if len(nos_ativados) == 1:
            resposta_final = f"[Foco Ativo: {nos_ativados[0].upper()}]<br><br>{respostas_partes[0]}"
        else:
            header = f"[Foco Ativo: {', '.join(n.upper() for n in nos_ativados)}]<br><br>"
            corpo = " ".join(respostas_partes)
            sintese = f" Percebo que sua mente interligou os conceitos de {' e '.join(nos_ativados)} em um único emaranhamento."
            resposta_final = header + corpo + sintese

        context.custom_response = resposta_final
        context.final_state = "10 (Diálogo Colapsado)"
        context.total_frequency_hz = round(frequencia_total, 2)
        context.chain = nos_ativados
        context.metadata["active_concepts"] = list(nos_ativados)

        return context

