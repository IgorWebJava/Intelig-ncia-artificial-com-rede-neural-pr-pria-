#ifndef ND_ASSISTANT_H
#define ND_ASSISTANT_H

#include <stddef.h>
#include <stdint.h>
#include "nd_context_qa.h"
#include "nd_knowledge.h"
#include "nd_memory.h"
#include "nd_open_knowledge.h"
#include "nd_pilot.h"
#include "nd_rag.h"
#include "nd_relation.h"
#include "nd_resource.h"
#include "nd_run_journal.h"
#include "nd_semantic_ranker.h"

typedef enum {
    ND_ANSWER_NONE = 0,
    ND_ANSWER_CONTEXT = 1,
    ND_ANSWER_CALCULATOR = 2,
    ND_ANSWER_KNOWLEDGE = 3,
    ND_ANSWER_UNCERTAIN = 4,
    ND_ANSWER_MEMORY = 5,
    ND_ANSWER_OPEN_KNOWLEDGE = 6,
    ND_ANSWER_COMPOSED = 7,
    ND_ANSWER_CONVERSATION = 8,
    ND_ANSWER_RAG = 9,
    ND_ANSWER_TEXT_UTILITY = 10,
    ND_ANSWER_BLOCKED = 11
} NDAnswerSource;

#define ND_ASSISTANT_LAST_QUESTION_BYTES 4097u
#define ND_ASSISTANT_LAST_ANSWER_BYTES 8192u
#define ND_ASSISTANT_HISTORY_TURNS 8u
#define ND_ASSISTANT_HISTORY_QUESTION_BYTES 1024u
#define ND_ASSISTANT_HISTORY_ANSWER_BYTES 2048u

typedef struct {
    NDKnowledgeBase kb;
    NDKnowledgeRetriever retriever;
    NDContextQA context_qa;
    NDRelationClassifier relation;
    NDMemory memory;
    NDOpenKnowledgeShard open_knowledge;
    int open_knowledge_loaded;
    NDRagIndex rag;
    NDResourcePolicy resource_policy;
    unsigned thermal_status;
    NDRunJournal journal;
    NDPilotControl pilot;
    int journal_enabled;
    NDSemanticRanker semantic_ranker;
    int semantic_ranker_loaded;
    int has_last_turn;
    char last_question[ND_ASSISTANT_LAST_QUESTION_BYTES];
    char last_answer[ND_ASSISTANT_LAST_ANSWER_BYTES];
    size_t history_count;
    char history_questions[ND_ASSISTANT_HISTORY_TURNS][ND_ASSISTANT_HISTORY_QUESTION_BYTES];
    char history_answers[ND_ASSISTANT_HISTORY_TURNS][ND_ASSISTANT_HISTORY_ANSWER_BYTES];
} NDAssistant;

typedef struct {
    NDAnswerSource source;
    float confidence;
    float margin;
    size_t evidence_count;
    size_t goal_count;
    size_t covered_goals;
    size_t tool_calls;
    size_t memory_hits;
    size_t open_knowledge_hits;
    size_t rag_hits;
    uint32_t sources_mask;
    int context_considered;
    int safety_blocked;
} NDAnswerMeta;

typedef int (*NDAnswerChunkCallback)(const char *chunk, size_t bytes, void *user_data);

typedef struct {
    int (*should_stop)(void *user_data);
    void *user_data;
} NDExecutionControl;

int nd_assistant_load(NDAssistant *a,
                      const char *retriever_path,
                      const char *kb_path,
                      const char *context_qa_path,
                      const char *relation_path,
                      char *err,
                      size_t errcap);
int nd_assistant_load_ex(NDAssistant *a,
                         const char *retriever_path,
                         const char *kb_path,
                         const char *context_qa_path,
                         const char *relation_path,
                         const char *open_knowledge_path,
                         const char *memory_path,
                         char *err,
                         size_t errcap);
void nd_assistant_free(NDAssistant *a);
int nd_assistant_set_profile(NDAssistant *a, NDMobileProfile profile);
int nd_assistant_set_thermal_status(NDAssistant *a, unsigned thermal_status);
int nd_assistant_set_master_kill(NDAssistant *a, int enabled, int64_t timestamp);
int nd_assistant_set_pilot_feature(NDAssistant *a, NDPilotFeature feature, int enabled, int64_t timestamp);
int nd_assistant_load_semantic_ranker(NDAssistant *a, const char *path, char *err, size_t errcap);
int nd_assistant_set_journal_path(NDAssistant *a, const char *path, char *err, size_t errcap);
int nd_assistant_rag_add_document(NDAssistant *a, const char *doc_id, const char *text,
                                  char *err, size_t errcap);
void nd_assistant_rag_clear(NDAssistant *a);
int nd_assistant_rag_save(const NDAssistant *a, const char *path, char *err, size_t errcap);
int nd_assistant_rag_load(NDAssistant *a, const char *path, char *err, size_t errcap);
int nd_assistant_answer(NDAssistant *a,
                        const char *question,
                        const char *context,
                        int rich,
                        char *out,
                        size_t outcap,
                        NDAnswerMeta *meta,
                        char *err,
                        size_t errcap);
int nd_assistant_answer_controlled(NDAssistant *a,
                                   const char *question,
                                   const char *context,
                                   int rich,
                                   const NDExecutionControl *control,
                                   char *out,
                                   size_t outcap,
                                   NDAnswerMeta *meta,
                                   char *err,
                                   size_t errcap);
int nd_assistant_answer_stream(NDAssistant *a,
                               const char *question,
                               const char *context,
                               int rich,
                               NDAnswerChunkCallback callback,
                               void *user_data,
                               char *out,
                               size_t outcap,
                               NDAnswerMeta *meta,
                               char *err,
                               size_t errcap);
int nd_assistant_answer_stream_controlled(NDAssistant *a,
                                          const char *question,
                                          const char *context,
                                          int rich,
                                          const NDExecutionControl *control,
                                          NDAnswerChunkCallback callback,
                                          void *user_data,
                                          char *out,
                                          size_t outcap,
                                          NDAnswerMeta *meta,
                                          char *err,
                                          size_t errcap);

#endif
