# Evaluation and Benchmark Strategy

Evaluation hierarchy:
- unit/contract tests;
- deterministic fixtures;
- golden datasets;
- model quality benchmarks;
- tool success benchmarks;
- agent task-completion benchmarks;
- RAG/citation benchmarks;
- multimodal benchmarks;
- voice/realtime benchmarks;
- red-team/safety;
- human preference;
- online production metrics.

Every promotion compares candidate vs baseline and records statistical uncertainty where appropriate.
