<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.architecture -->
# Current Interface ↔ Neural Engine Traceability

The authoritative traceability registry contains **149** interface mechanics. Every future Neural Engine module is also mapped to an interface owner through `platform/engine-ui-bridge/registry.json`.

| UI module | Tracked mechanics | Primary engine modules owned | Bridge status |
|---|---:|---:|---|
| `agents` | 12 | 18 | `READY` |
| `app-shell` | 11 | 5 | `READY` |
| `audit` | 12 | 0 | `READY` |
| `chat` | 18 | 4 | `READY` |
| `knowledge` | 12 | 15 | `READY` |
| `operations` | 15 | 10 | `READY` |
| `settings` | 15 | 0 | `READY` |
| `system-config` | 18 | 13 | `READY` |
| `tools` | 16 | 0 | `READY` |
| `training` | 14 | 29 | `READY` |

Global/cross-module mechanics: **6**.

## Coverage

- Future engine modules: **94**
- Engine modules with UI ownership mapping: **94/94**
- Future engine capabilities: **391**
- Current resolved UI/platform capabilities: **106**
- Bridge profile: `cooperative-engine-bridge-v1`
- Policy: `preserve-extend-bridge`

## Truth boundary

`IMPLEMENTED-TEMPLATE-UI` and `UI_CONTRACT_READY` describe the current interface. All future engine behaviors remain `DOCUMENTATION_ONLY / NOT_IMPLEMENTED` until executable providers, integration tests and production evidence exist.
