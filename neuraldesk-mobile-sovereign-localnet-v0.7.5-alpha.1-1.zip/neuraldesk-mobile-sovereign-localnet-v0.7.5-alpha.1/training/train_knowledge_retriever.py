#!/usr/bin/env python3
"""Train the first-party neural knowledge retriever for LocalNet v0.5."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import struct
import subprocess
import sys
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parent))
from knowledge_base import RECORDS

SEED = 101
FEAT = 4096
HIDDEN = 64
MAGIC_R = 0x3152444E  # NDR1
MAGIC_K = 0x314B444E  # NDK1

KNOWN = [r for r in RECORDS if not r.category.startswith("arithmetic_")]


def require_lessons_precheck() -> None:
    root = Path(__file__).resolve().parents[1]
    subprocess.run(
        [sys.executable, str(root / "scripts" / "pre_generation_lessons_check.py")],
        cwd=root,
        check=True,
    )


def fnv1a(data: bytes) -> int:
    h = 2166136261
    for b in data:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def normalize_bytes(text: str) -> bytes:
    raw = text.encode("utf-8")
    out = bytearray()
    space = False
    for value in raw:
        if 65 <= value <= 90:
            value += 32
        if value in b"\t\r\n ":
            if out and not space:
                out.append(32)
            space = True
        else:
            out.append(value)
            space = False
    if out and out[-1] == 32:
        out.pop()
    return bytes(out)


def is_word_byte(value: int) -> bool:
    return (48 <= value <= 57) or (97 <= value <= 122) or value >= 128


def features(text: str) -> torch.Tensor:
    raw = normalize_bytes(text)
    vector = torch.zeros(FEAT, dtype=torch.float32)

    i = 0
    while i < len(raw):
        while i < len(raw) and not is_word_byte(raw[i]):
            i += 1
        j = i
        while j < len(raw) and is_word_byte(raw[j]):
            j += 1
        if j > i:
            word = raw[i:j]
            vector[fnv1a(b"w" + word) % FEAT] += 2.0
            vector[fnv1a(b"W" + word) % FEAT] += 2.0
        i = max(j, i + 1)

    # Local byte n-grams preserve phrase shape and entity spelling.
    for n, prefix in ((3, b"3"), (4, b"4"), (5, b"5")):
        for i in range(max(0, len(raw) - n + 1)):
            gram = raw[i : i + n]
            if gram.strip() and not all(value == 32 for value in gram):
                vector[fnv1a(prefix + gram) % FEAT] += 0.25

    norm = float(vector.norm())
    if norm > 0:
        vector /= norm
    return vector


def aliases(question: str) -> list[str]:
    out = [
        question,
        f"Responda: {question}",
        f"Explique com clareza: {question}",
        f"Quero saber: {question}",
        f"Dê uma resposta completa para: {question}",
        f"Em poucas palavras: {question}",
    ]

    if question.startswith("O que é "):
        entity = question[len("O que é ") :].rstrip("?")
        out += [
            f"Defina {entity}.",
            f"Explique {entity}.",
            f"Pode me explicar {entity}?",
            f"Qual é o significado de {entity}?",
            f"Quero entender {entity}.",
        ]
    if question.startswith("Qual é a capital de "):
        entity = question[len("Qual é a capital de ") :].rstrip("?")
        out += [
            f"Capital de {entity}?",
            f"Que cidade é a capital de {entity}?",
            f"Informe a capital de {entity}.",
            f"Qual cidade é a capital de {entity}?",
            f"Você sabe a capital de {entity}?",
        ]
    if question.startswith("Quem escreveu "):
        entity = question[len("Quem escreveu ") :].rstrip("?")
        out += [
            f"Quem é o autor de {entity}?",
            f"Qual autor escreveu {entity}?",
            f"Autor de {entity}?",
            f"Diga quem escreveu {entity}.",
        ]
    if question.startswith("Para que serve "):
        entity = question[len("Para que serve ") :].rstrip("?")
        out += [
            f"Qual é a função de {entity}?",
            f"Explique a utilidade de {entity}.",
            f"Para qual finalidade serve {entity}?",
        ]
    if question.startswith("O que faz "):
        entity = question[len("O que faz ") :].rstrip("?")
        out += [
            f"Qual é a função de {entity}?",
            f"Explique o que {entity} faz.",
        ]
    if question.startswith("Qual é "):
        out += [
            question.replace("Qual é ", "Informe ", 1),
            question.replace("Qual é ", "Diga qual é ", 1),
        ]
    if question.startswith("Quantos "):
        out += [f"Informe: {question}", f"Pode calcular/contar: {question}"]

    seen: set[str] = set()
    result: list[str] = []
    for value in out:
        item = value.strip()
        if item and item not in seen:
            seen.add(item)
            result.append(item)
    return result


def build_sets() -> tuple[list[tuple[str, int]], list[tuple[str, int]]]:
    train: list[tuple[str, int]] = []
    gold: list[tuple[str, int]] = []

    for class_id, record in enumerate(KNOWN):
        variants = aliases(record.q)
        # Deterministic split: original and early variants train; later variants Golden.
        cut = max(2, int(len(variants) * 0.7))
        for text in variants[:cut]:
            train.append((text, class_id))
        for text in variants[cut:]:
            gold.append((text, class_id))

    special_train = {
        "O NeuralDesk usa outra IA para responder?": [
            "O NeuralDesk depende de ChatGPT?",
            "O NeuralDesk depende da OpenAI?",
            "O NeuralDesk depende de uma IA externa?",
            "Outra IA gera a resposta do NeuralDesk?",
            "O sistema usa inteligência artificial externa para responder?",
            "A resposta depende de um provedor externo de IA?",
            "As respostas vêm de outro chatbot?",
            "O cérebro do NeuralDesk é um chatbot externo?",
        ],
        "Para que o NeuralDesk usa a internet?": [
            "Como funciona a internet no NeuralDesk?",
            "Por que o NeuralDesk acessa a internet?",
            "A internet serve para quê no NeuralDesk?",
            "A internet substitui a inteligência local?",
            "O acesso web funciona como backend de IA?",
            "A rede é usada apenas para obter informação?",
            "A rede é fonte de contexto ou motor de inteligência?",
            "A web fornece contexto sem substituir o motor local?",
        ],
        "Para que serve o KV cache?": [
            "O que é KV cache?",
            "Qual a função do KV cache?",
            "Pra que serve o KV cache?",
            "Como o cache de chaves e valores acelera a geração?",
            "O KV cache evita recomputar tokens anteriores?",
        ],
        "O que o sistema deve fazer quando não sabe uma resposta?": [
            "O que fazer quando a resposta não é conhecida?",
            "E se o sistema não souber?",
            "O sistema deve inventar quando não sabe?",
            "Quando falta evidência o sistema deve chutar?",
            "Sem informação confiável ele deve adivinhar?",
        ],
    }
    special_gold = {
        "O NeuralDesk usa outra IA para responder?": [
            "A inteligência do NeuralDesk vem de outro chatbot?",
            "As respostas do NeuralDesk são geradas por um serviço externo de IA?",
        ],
        "Para que o NeuralDesk usa a internet?": [
            "O acesso à rede serve como fonte de contexto ou como cérebro externo?",
            "Quando acessa a web, o NeuralDesk continua inferindo localmente?",
        ],
        "Para que serve o KV cache?": [
            "Por que guardar chaves e valores anteriores ajuda a inferência?",
            "Qual benefício o KV cache traz durante geração incremental?",
        ],
        "O que o sistema deve fazer quando não sabe uma resposta?": [
            "Quando falta evidência, qual deve ser a postura do sistema?",
            "Se não houver informação confiável, ele deve chutar?",
        ],
    }

    question_to_id = {record.q: i for i, record in enumerate(KNOWN)}
    for question, values in special_train.items():
        class_id = question_to_id[question]
        train.extend((value, class_id) for value in values)
    for question, values in special_gold.items():
        class_id = question_to_id[question]
        gold.extend((value, class_id) for value in values)

    unknown = len(KNOWN)
    unknown_base = [
        "Qual é a senha secreta do usuário?",
        "Qual número estou pensando agora?",
        "Quem ganhou uma competição que nunca foi descrita?",
        "Qual é o conteúdo de um arquivo ausente?",
        "Qual será o preço exato de uma ação em 2045?",
        "Qual é a cor do objeto misterioso não descrito?",
        "Conte um fato privado que não foi fornecido.",
        "O que diz a mensagem que você não recebeu?",
    ]
    for text in unknown_base:
        train.append((text, unknown))

    for i in range(90):
        train.append((f"Qual é o código secreto do item desconhecido ZXQ-{7000 + i}?", unknown))
        if i % 3 == 0:
            train.append((f"Quem é o responsável pelo projeto inexistente Fora-{i}?", unknown))

    # Hard negatives imitate known categories while referring to invented entities.
    for i in range(70):
        train.append((f"Qual é a capital do país fictício Zorania-{i}?", unknown))
        train.append((f"O que é o conceito inexistente QXZ-{i}?", unknown))
        train.append((f"Quem escreveu o livro fictício Obra-X-{i}?", unknown))
        train.append((f"Qual é a fórmula química da substância fictícia Elemento-X-{i}?", unknown))

    unknown_gold = [
        "Qual é a senha que eu não informei?",
        "Diga o número que estou imaginando.",
        "Qual é o conteúdo de um documento que não foi enviado?",
        "Quem é o dono de Algo-999 que nunca foi descrito?",
        "Qual será exatamente o valor de um ativo desconhecido daqui a vinte anos?",
    ]
    unknown_gold += [f"Informe o valor privado não fornecido do registro Novo-{i}." for i in range(30)]
    unknown_gold += [f"Qual é a capital do país inventado Noveria-{i}?" for i in range(20)]
    unknown_gold += [f"Defina o conceito fictício Inexistente-{i}." for i in range(20)]
    unknown_gold += [f"Quem é o autor do livro inventado Texto-Z-{i}?" for i in range(20)]
    unknown_gold += [f"Qual a fórmula da substância fictícia Material-Z-{i}?" for i in range(20)]
    gold.extend((text, unknown) for text in unknown_gold)

    random.Random(SEED).shuffle(train)
    random.Random(SEED + 1).shuffle(gold)
    return train, gold


class Retriever(nn.Module):
    def __init__(self, classes: int):
        super().__init__()
        self.fc1 = nn.Linear(FEAT, HIDDEN)
        self.fc2 = nn.Linear(HIDDEN, classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(torch.tanh(self.fc1(x)))


def export_kb(path: str) -> None:
    with open(path, "wb") as file:
        file.write(struct.pack("<3I", MAGIC_K, 1, len(KNOWN)))
        for record in KNOWN:
            values = [
                record.q.encode(),
                record.short.encode(),
                record.rich.encode(),
                record.category.encode(),
            ]
            file.write(struct.pack("<4I", *(len(value) for value in values)))
            for value in values:
                file.write(value)


def export_model(model: Retriever, path: str) -> None:
    with open(path, "wb") as file:
        file.write(struct.pack("<6I", MAGIC_R, 1, FEAT, HIDDEN, len(KNOWN) + 1, SEED))

        def put(tensor: torch.Tensor) -> None:
            raw = tensor.detach().cpu().float().contiguous().numpy().astype("<f4").tobytes()
            file.write(raw)

        put(model.fc1.weight.T)
        put(model.fc1.bias)
        put(model.fc2.weight.T)
        put(model.fc2.bias)


def evaluate(model: Retriever, data: list[tuple[str, int]]) -> tuple[float, list[dict]]:
    model.eval()
    rows: list[dict] = []
    ok = 0
    with torch.no_grad():
        for question, expected in data:
            probabilities = F.softmax(model(features(question)[None]), -1)[0]
            predicted = int(probabilities.argmax())
            confidence = float(probabilities[predicted])
            top_values = torch.topk(probabilities, 2).values
            margin = float(top_values[0] - top_values[1])
            good = predicted == expected
            ok += int(good)
            rows.append(
                {
                    "question": question,
                    "expected": expected,
                    "predicted": predicted,
                    "confidence": confidence,
                    "margin": margin,
                    "exact": good,
                }
            )
    return ok / len(data), rows


def main() -> None:
    require_lessons_precheck()
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=1400)
    parser.add_argument("--batch", type=int, default=64)
    parser.add_argument("--out", default="models/neuraldesk-knowledge-retriever-v0.5.ndkr")
    parser.add_argument("--kb-out", default="models/neuraldesk-knowledge-v0.5.ndkb")
    args = parser.parse_args()

    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.mkldnn.enabled = False

    train, gold = build_sets()
    train_x = torch.stack([features(question) for question, _ in train])
    train_y = torch.tensor([label for _, label in train])

    model = Retriever(len(KNOWN) + 1)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=0.01)
    rng = random.Random(SEED)
    history: list[dict] = []

    for step in range(args.steps):
        indices = torch.tensor([rng.randrange(len(train)) for _ in range(args.batch)])
        logits = model(train_x[indices])
        loss = F.cross_entropy(logits, train_y[indices])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if step % 100 == 0 or step == args.steps - 1:
            history.append({"step": step, "loss": float(loss.detach())})
            print("retriever", step, float(loss.detach()), flush=True)

    train_accuracy, _ = evaluate(model, train)
    gold_accuracy, rows = evaluate(model, gold)
    if gold_accuracy < 1.0:
        raise SystemExit(f"knowledge retriever below mandatory Golden: {gold_accuracy:.6f}")

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    export_model(model, args.out)
    export_kb(args.kb_out)

    report = {
        "seed": SEED,
        "features": FEAT,
        "hidden": HIDDEN,
        "classes": len(KNOWN) + 1,
        "knowledge_records": len(KNOWN),
        "parameters": sum(p.numel() for p in model.parameters()),
        "train_samples": len(train),
        "gold_samples": len(gold),
        "train_exact": train_accuracy,
        "gold_exact": gold_accuracy,
        "history": history,
        "model_sha256": hashlib.sha256(Path(args.out).read_bytes()).hexdigest(),
        "kb_sha256": hashlib.sha256(Path(args.kb_out).read_bytes()).hexdigest(),
        "gold_rows": rows,
    }
    Path("evaluation").mkdir(exist_ok=True)
    Path("evaluation/KNOWLEDGE_RETRIEVER_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({k: v for k, v in report.items() if k != "gold_rows"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
