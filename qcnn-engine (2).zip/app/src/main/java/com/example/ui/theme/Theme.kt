package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = QuantumCyan,
    secondary = QuantumPink,
    tertiary = QuantumGold,
    background = QuantumBgDark,
    surface = QuantumPanelDark
)

@Composable
fun QcnnTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
