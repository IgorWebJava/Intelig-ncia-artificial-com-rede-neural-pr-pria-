<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 119 — Development Capability Model

Development capabilities are separate from runtime/business capabilities.

Examples:

```text
filesystem.write.v1
browser.viewport-test.v1
openapi.author.v1
sql.postgresql.design.v1
ai.capability.fabric.design.v1
test.static.execute.v1
release.package.v1
```

This prevents the project from becoming tied to one assistant/tool product.
