#include "nd_outbox.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NDBX_MAGIC 0x5842444eu
#define NDBX_VERSION 1u
#define NDBX_MAX_ATTEMPTS 5u
#define NDBX_BASE_DELAY_MS 2000ull
#define NDBX_MAX_DELAY_MS 300000ull

static void set_error(char *err, size_t cap, const char *msg) {
    if (err && cap) snprintf(err, cap, "%s", msg);
}

static size_t profile_max_items(NDMobileProfile p) {
    if (p == ND_PROFILE_MOBILE_PLUS) return 75u;
    if (p == ND_PROFILE_MOBILE) return 50u;
    return 20u;
}

static size_t profile_max_bytes(NDMobileProfile p) {
    if (p == ND_PROFILE_MOBILE_PLUS) return 512u * 1024u;
    if (p == ND_PROFILE_MOBILE) return 256u * 1024u;
    return 64u * 1024u;
}

static size_t profile_max_item_bytes(NDMobileProfile p) {
    if (p == ND_PROFILE_MOBILE_PLUS) return 32u * 1024u;
    if (p == ND_PROFILE_MOBILE) return 16u * 1024u;
    return 8u * 1024u;
}

static int write_bytes(FILE *f, const void *p, size_t n) {
    return fwrite(p, 1u, n, f) == n ? 0 : -1;
}

static int read_bytes(FILE *f, void *p, size_t n) {
    return fread(p, 1u, n, f) == n ? 0 : -1;
}

static int write_u32(FILE *f, uint32_t v) {
    unsigned char b[4];
    b[0] = (unsigned char)(v & 0xffu);
    b[1] = (unsigned char)((v >> 8) & 0xffu);
    b[2] = (unsigned char)((v >> 16) & 0xffu);
    b[3] = (unsigned char)((v >> 24) & 0xffu);
    return write_bytes(f, b, sizeof(b));
}

static int write_u64(FILE *f, uint64_t v) {
    unsigned char b[8];
    for (unsigned i = 0u; i < 8u; i++) b[i] = (unsigned char)((v >> (8u * i)) & 0xffu);
    return write_bytes(f, b, sizeof(b));
}

static int read_u32(FILE *f, uint32_t *v) {
    unsigned char b[4];
    if (read_bytes(f, b, sizeof(b))) return -1;
    *v = (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
    return 0;
}

static int read_u64(FILE *f, uint64_t *v) {
    unsigned char b[8];
    if (read_bytes(f, b, sizeof(b))) return -1;
    *v = 0u;
    for (unsigned i = 0u; i < 8u; i++) *v |= ((uint64_t)b[i]) << (8u * i);
    return 0;
}

static void free_item(NDOutboxItem *item) {
    if (!item) return;
    free(item->content);
    item->content = NULL;
    item->content_bytes = 0u;
}

void nd_outbox_init(NDOutbox *o) {
    if (!o) return;
    memset(o, 0, sizeof(*o));
    o->profile = ND_PROFILE_MICRO;
    o->next_id = 1u;
    o->ttl_ms = 7ull * 24ull * 60ull * 60ull * 1000ull;
    o->max_items = profile_max_items(o->profile);
    o->max_bytes = profile_max_bytes(o->profile);
    o->max_item_bytes = profile_max_item_bytes(o->profile);
}

void nd_outbox_free(NDOutbox *o) {
    if (!o) return;
    for (size_t i = 0u; i < o->count; i++) free_item(&o->items[i]);
    free(o->items);
    memset(o, 0, sizeof(*o));
}

static int reserve_items(NDOutbox *o, size_t needed, char *err, size_t ec) {
    if (needed <= o->capacity) return 0;
    size_t cap = o->capacity ? o->capacity * 2u : 8u;
    while (cap < needed) cap *= 2u;
    if (cap > o->max_items) cap = o->max_items;
    if (cap < needed) {
        set_error(err, ec, "outbox item quota exceeded");
        return -1;
    }
    NDOutboxItem *next = (NDOutboxItem *)realloc(o->items, cap * sizeof(*next));
    if (!next) {
        set_error(err, ec, "outbox allocation failed");
        return -1;
    }
    if (cap > o->capacity) memset(next + o->capacity, 0, (cap - o->capacity) * sizeof(*next));
    o->items = next;
    o->capacity = cap;
    return 0;
}

static size_t total_bytes(const NDOutbox *o) {
    size_t n = 0u;
    for (size_t i = 0u; i < o->count; i++) n += o->items[i].content_bytes;
    return n;
}

static int valid_project_id(const char *s) {
    if (!s || !*s || strlen(s) >= ND_OUTBOX_PROJECT_ID_BYTES) return 0;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p < 0x20u || *p == '\t' || *p == '\n' || *p == '\r') return 0;
    }
    return 1;
}

static NDOutboxItem *find_item(NDOutbox *o, uint64_t id) {
    for (size_t i = 0u; i < o->count; i++) if (o->items[i].id == id) return &o->items[i];
    return NULL;
}

static const NDOutboxItem *find_item_const(const NDOutbox *o, uint64_t id) {
    for (size_t i = 0u; i < o->count; i++) if (o->items[i].id == id) return &o->items[i];
    return NULL;
}

static int persist(const NDOutbox *o, char *err, size_t ec) {
    if (!o->path[0]) return 0;
    char tmp[1100];
    if (snprintf(tmp, sizeof(tmp), "%s.tmp", o->path) >= (int)sizeof(tmp)) {
        set_error(err, ec, "outbox path too long");
        return -1;
    }
    FILE *f = fopen(tmp, "wb");
    if (!f) {
        set_error(err, ec, "cannot open outbox temp file");
        return -1;
    }
    int failed = 0;
    failed |= write_u32(f, NDBX_MAGIC);
    failed |= write_u32(f, NDBX_VERSION);
    failed |= write_u64(f, o->next_id);
    failed |= write_u32(f, (uint32_t)o->count);
    for (size_t i = 0u; i < o->count && !failed; i++) {
        const NDOutboxItem *it = &o->items[i];
        failed |= write_u64(f, it->id);
        failed |= write_u64(f, it->created_at_ms);
        failed |= write_u64(f, it->expires_at_ms);
        failed |= write_u64(f, it->next_attempt_at_ms);
        failed |= write_u32(f, it->attempts);
        failed |= write_u32(f, (uint32_t)it->state);
        failed |= write_u32(f, (uint32_t)it->last_error);
        failed |= write_u32(f, it->requires_network ? 1u : 0u);
        failed |= write_bytes(f, it->project_id, sizeof(it->project_id));
        failed |= write_bytes(f, it->idempotency_key, sizeof(it->idempotency_key));
        failed |= write_u32(f, (uint32_t)it->dependency_count);
        for (size_t j = 0u; j < ND_OUTBOX_MAX_DEPENDENCIES; j++) failed |= write_u64(f, it->dependencies[j]);
        failed |= write_u32(f, (uint32_t)it->missing_dependency_count);
        for (size_t j = 0u; j < ND_OUTBOX_MAX_DEPENDENCIES; j++) failed |= write_u64(f, it->missing_dependencies[j]);
        failed |= write_u32(f, (uint32_t)it->content_bytes);
        if (it->content_bytes) failed |= write_bytes(f, it->content, it->content_bytes);
    }
    if (fflush(f) != 0 || fclose(f) != 0) failed = 1;
    if (failed) {
        remove(tmp);
        set_error(err, ec, "cannot persist outbox");
        return -1;
    }
    if (rename(tmp, o->path) != 0) {
        remove(tmp);
        set_error(err, ec, "cannot commit outbox");
        return -1;
    }
    return 0;
}

int nd_outbox_configure(NDOutbox *o, NDMobileProfile profile, const char *path, char *err, size_t ec) {
    if (!o || profile < ND_PROFILE_MICRO || profile > ND_PROFILE_MOBILE_PLUS) {
        set_error(err, ec, "invalid outbox profile");
        return -1;
    }
    if (path && strlen(path) >= sizeof(o->path)) {
        set_error(err, ec, "outbox path too long");
        return -1;
    }
    o->profile = profile;
    o->max_items = profile_max_items(profile);
    o->max_bytes = profile_max_bytes(profile);
    o->max_item_bytes = profile_max_item_bytes(profile);
    if (path) snprintf(o->path, sizeof(o->path), "%s", path);
    else o->path[0] = 0;
    if (o->count > o->max_items || total_bytes(o) > o->max_bytes) {
        set_error(err, ec, "existing outbox exceeds profile quota");
        return -1;
    }
    return 0;
}

static int has_id(const NDOutbox *o, uint64_t id) {
    return find_item_const(o, id) != NULL;
}

static int normalize_dependencies(NDOutbox *o, NDOutboxItem *it) {
    int changed = 0;
    it->missing_dependency_count = 0u;
    for (size_t j = 0u; j < it->dependency_count; j++) {
        if (!has_id(o, it->dependencies[j])) {
            if (it->missing_dependency_count < ND_OUTBOX_MAX_DEPENDENCIES) {
                it->missing_dependencies[it->missing_dependency_count++] = it->dependencies[j];
            }
        }
    }
    if (it->missing_dependency_count) {
        if (it->state != ND_OUTBOX_BLOCKED_DEPENDENCY) changed = 1;
        it->state = ND_OUTBOX_BLOCKED_DEPENDENCY;
        it->next_attempt_at_ms = 0u;
    }
    return changed;
}

int nd_outbox_restore(NDOutbox *o, uint64_t now_ms, char *err, size_t ec) {
    if (!o || !o->path[0]) return 0;
    FILE *f = fopen(o->path, "rb");
    if (!f) return 0;
    uint32_t magic = 0u, version = 0u, count = 0u;
    uint64_t next_id = 0u;
    if (read_u32(f, &magic) || read_u32(f, &version) || read_u64(f, &next_id) || read_u32(f, &count) ||
        magic != NDBX_MAGIC || version != NDBX_VERSION || count > o->max_items) {
        fclose(f);
        set_error(err, ec, "outbox header corrupt");
        return -1;
    }
    for (size_t i = 0u; i < o->count; i++) free_item(&o->items[i]);
    o->count = 0u;
    if (reserve_items(o, count, err, ec)) {
        fclose(f);
        return -1;
    }
    int changed = 0;
    for (uint32_t i = 0u; i < count; i++) {
        NDOutboxItem *it = &o->items[o->count];
        memset(it, 0, sizeof(*it));
        uint32_t state = 0u, last_error = 0u, requires_network = 0u, dc = 0u, mc = 0u, cb = 0u;
        if (read_u64(f, &it->id) || read_u64(f, &it->created_at_ms) || read_u64(f, &it->expires_at_ms) ||
            read_u64(f, &it->next_attempt_at_ms) || read_u32(f, &it->attempts) || read_u32(f, &state) ||
            read_u32(f, &last_error) || read_u32(f, &requires_network) ||
            read_bytes(f, it->project_id, sizeof(it->project_id)) ||
            read_bytes(f, it->idempotency_key, sizeof(it->idempotency_key)) || read_u32(f, &dc)) {
            fclose(f);
            set_error(err, ec, "outbox record truncated");
            return -1;
        }
        if (state > ND_OUTBOX_EXPIRED || last_error > ND_OUTBOX_ERR_UNKNOWN || dc > ND_OUTBOX_MAX_DEPENDENCIES) {
            fclose(f);
            set_error(err, ec, "outbox record invalid");
            return -1;
        }
        it->state = (NDOutboxState)state;
        it->last_error = (NDOutboxErrorCategory)last_error;
        it->requires_network = requires_network ? 1 : 0;
        it->dependency_count = dc;
        for (size_t j = 0u; j < ND_OUTBOX_MAX_DEPENDENCIES; j++) if (read_u64(f, &it->dependencies[j])) {
            fclose(f); set_error(err, ec, "outbox dependencies truncated"); return -1;
        }
        if (read_u32(f, &mc) || mc > ND_OUTBOX_MAX_DEPENDENCIES) {
            fclose(f); set_error(err, ec, "outbox missing dependencies invalid"); return -1;
        }
        it->missing_dependency_count = mc;
        for (size_t j = 0u; j < ND_OUTBOX_MAX_DEPENDENCIES; j++) if (read_u64(f, &it->missing_dependencies[j])) {
            fclose(f); set_error(err, ec, "outbox missing dependencies truncated"); return -1;
        }
        if (read_u32(f, &cb) || cb > o->max_item_bytes || total_bytes(o) + cb > o->max_bytes) {
            fclose(f); set_error(err, ec, "outbox content size invalid"); return -1;
        }
        it->content = (char *)malloc((size_t)cb + 1u);
        if (!it->content) {
            fclose(f); set_error(err, ec, "outbox content allocation failed"); return -1;
        }
        if (cb && read_bytes(f, it->content, cb)) {
            fclose(f); set_error(err, ec, "outbox content truncated"); return -1;
        }
        it->content[cb] = 0;
        it->content_bytes = cb;
        if (!valid_project_id(it->project_id)) {
            fclose(f); set_error(err, ec, "outbox project id invalid"); return -1;
        }
        if (it->state == ND_OUTBOX_SENDING) {
            it->state = ND_OUTBOX_RETRY_WAIT;
            it->next_attempt_at_ms = now_ms;
            it->last_error = ND_OUTBOX_ERR_UNKNOWN;
            changed = 1;
        }
        if (it->state != ND_OUTBOX_EXPIRED && it->expires_at_ms <= now_ms) {
            it->state = ND_OUTBOX_EXPIRED;
            it->next_attempt_at_ms = 0u;
            changed = 1;
        }
        o->count++;
    }
    if (fgetc(f) != EOF) {
        fclose(f);
        set_error(err, ec, "outbox trailing bytes");
        return -1;
    }
    fclose(f);
    o->next_id = next_id > 0u ? next_id : 1u;
    for (size_t i = 0u; i < o->count; i++) changed |= normalize_dependencies(o, &o->items[i]);
    if (changed) return persist(o, err, ec);
    return 0;
}

static int dependency_available(const NDOutbox *o, uint64_t id, const char *project) {
    const NDOutboxItem *it = find_item_const(o, id);
    if (!it || strcmp(it->project_id, project) != 0) return 0;
    return it->state != ND_OUTBOX_EXPIRED && it->state != ND_OUTBOX_BLOCKED_DEPENDENCY;
}

int nd_outbox_enqueue(NDOutbox *o, const char *project, const char *content,
                      const uint64_t *deps, size_t dep_count, int requires_network,
                      uint64_t now_ms, uint64_t *out_id, char *err, size_t ec) {
    if (!o || !valid_project_id(project) || !content || !*content || dep_count > ND_OUTBOX_MAX_DEPENDENCIES) {
        set_error(err, ec, "invalid outbox enqueue");
        return -1;
    }
    size_t cb = strlen(content);
    if (cb > o->max_item_bytes || o->count >= o->max_items || total_bytes(o) + cb > o->max_bytes) {
        set_error(err, ec, "outbox quota exceeded");
        return -1;
    }
    for (size_t i = 0u; i < dep_count; i++) {
        if (!dependency_available(o, deps[i], project)) {
            set_error(err, ec, "outbox dependency unavailable");
            return -1;
        }
        for (size_t j = 0u; j < i; j++) if (deps[j] == deps[i]) {
            set_error(err, ec, "outbox duplicate dependency");
            return -1;
        }
    }
    if (reserve_items(o, o->count + 1u, err, ec)) return -1;
    NDOutboxItem *it = &o->items[o->count];
    memset(it, 0, sizeof(*it));
    it->id = o->next_id++;
    it->created_at_ms = now_ms;
    it->expires_at_ms = now_ms + o->ttl_ms;
    it->state = ND_OUTBOX_QUEUED;
    it->requires_network = requires_network ? 1 : 0;
    snprintf(it->project_id, sizeof(it->project_id), "%s", project);
    snprintf(it->idempotency_key, sizeof(it->idempotency_key), "nd-%016llx", (unsigned long long)it->id);
    it->dependency_count = dep_count;
    for (size_t i = 0u; i < dep_count; i++) it->dependencies[i] = deps[i];
    it->content = (char *)malloc(cb + 1u);
    if (!it->content) {
        set_error(err, ec, "outbox content allocation failed");
        return -1;
    }
    memcpy(it->content, content, cb + 1u);
    it->content_bytes = cb;
    o->count++;
    if (persist(o, err, ec)) {
        o->count--;
        free_item(it);
        return -1;
    }
    if (out_id) *out_id = it->id;
    return 0;
}

static size_t item_index(const NDOutbox *o, uint64_t id) {
    for (size_t i = 0u; i < o->count; i++) if (o->items[i].id == id) return i;
    return (size_t)-1;
}

static void erase_index(NDOutbox *o, size_t idx) {
    free_item(&o->items[idx]);
    if (idx + 1u < o->count) memmove(&o->items[idx], &o->items[idx + 1u], (o->count - idx - 1u) * sizeof(o->items[0]));
    o->count--;
    memset(&o->items[o->count], 0, sizeof(o->items[0]));
}

int nd_outbox_remove(NDOutbox *o, uint64_t id, char *err, size_t ec) {
    if (!o) return -1;
    size_t idx = item_index(o, id);
    if (idx == (size_t)-1) return 0;
    for (size_t i = 0u; i < o->count; i++) {
        if (i == idx) continue;
        NDOutboxItem *child = &o->items[i];
        for (size_t j = 0u; j < child->dependency_count; j++) {
            if (child->dependencies[j] == id) {
                child->state = ND_OUTBOX_BLOCKED_DEPENDENCY;
                child->next_attempt_at_ms = 0u;
                if (child->missing_dependency_count < ND_OUTBOX_MAX_DEPENDENCIES) {
                    child->missing_dependencies[child->missing_dependency_count++] = id;
                }
            }
        }
    }
    erase_index(o, idx);
    return persist(o, err, ec);
}

static int visit_cycle(const NDOutbox *o, uint64_t current, uint64_t target, uint64_t *stack, size_t depth) {
    if (current == target) return 1;
    if (depth >= o->count + 1u) return 1;
    for (size_t i = 0u; i < depth; i++) if (stack[i] == current) return 0;
    stack[depth] = current;
    const NDOutboxItem *it = find_item_const(o, current);
    if (!it) return 0;
    for (size_t i = 0u; i < it->dependency_count; i++) {
        if (visit_cycle(o, it->dependencies[i], target, stack, depth + 1u)) return 1;
    }
    return 0;
}

int nd_outbox_relink(NDOutbox *o, uint64_t id, const uint64_t *deps, size_t dep_count,
                     uint64_t now_ms, char *err, size_t ec) {
    NDOutboxItem *it = o ? find_item(o, id) : NULL;
    if (!it || it->state != ND_OUTBOX_BLOCKED_DEPENDENCY || dep_count > ND_OUTBOX_MAX_DEPENDENCIES) {
        set_error(err, ec, "outbox relink requires blocked item");
        return -1;
    }
    for (size_t i = 0u; i < dep_count; i++) {
        if (deps[i] == id || !dependency_available(o, deps[i], it->project_id)) {
            set_error(err, ec, "outbox relink dependency invalid");
            return -1;
        }
        uint64_t stack[128];
        if (visit_cycle(o, deps[i], id, stack, 0u)) {
            set_error(err, ec, "outbox relink would create cycle");
            return -1;
        }
    }
    memset(it->dependencies, 0, sizeof(it->dependencies));
    memset(it->missing_dependencies, 0, sizeof(it->missing_dependencies));
    it->dependency_count = dep_count;
    it->missing_dependency_count = 0u;
    for (size_t i = 0u; i < dep_count; i++) it->dependencies[i] = deps[i];
    it->state = ND_OUTBOX_QUEUED;
    it->next_attempt_at_ms = now_ms;
    return persist(o, err, ec);
}

int nd_outbox_mark_sending(NDOutbox *o, uint64_t id, char *err, size_t ec) {
    NDOutboxItem *it = o ? find_item(o, id) : NULL;
    if (!it || (it->state != ND_OUTBOX_QUEUED && it->state != ND_OUTBOX_RETRY_WAIT)) {
        set_error(err, ec, "outbox item is not sendable");
        return -1;
    }
    it->state = ND_OUTBOX_SENDING;
    return persist(o, err, ec);
}

int nd_outbox_mark_success(NDOutbox *o, uint64_t id, char *err, size_t ec) {
    if (!o) return -1;
    size_t idx = item_index(o, id);
    if (idx == (size_t)-1) return 0;
    for (size_t i = 0u; i < o->count; i++) {
        if (i == idx) continue;
        NDOutboxItem *child = &o->items[i];
        size_t w = 0u;
        for (size_t j = 0u; j < child->dependency_count; j++) {
            if (child->dependencies[j] != id) child->dependencies[w++] = child->dependencies[j];
        }
        child->dependency_count = w;
        for (size_t j = w; j < ND_OUTBOX_MAX_DEPENDENCIES; j++) child->dependencies[j] = 0u;
        if (child->state == ND_OUTBOX_BLOCKED_DEPENDENCY && child->missing_dependency_count == 0u && w == 0u) {
            child->state = ND_OUTBOX_QUEUED;
        }
    }
    erase_index(o, idx);
    return persist(o, err, ec);
}

static uint64_t retry_delay(uint64_t id, uint32_t attempts) {
    uint64_t base = NDBX_BASE_DELAY_MS;
    for (uint32_t i = 1u; i < attempts && base < NDBX_MAX_DELAY_MS; i++) {
        if (base > NDBX_MAX_DELAY_MS / 2u) { base = NDBX_MAX_DELAY_MS; break; }
        base *= 2u;
    }
    if (base > NDBX_MAX_DELAY_MS) base = NDBX_MAX_DELAY_MS;
    uint64_t mix = id * 11400714819323198485ull + (uint64_t)attempts * 0x9e3779b97f4a7c15ull;
    unsigned pct = 80u + (unsigned)((mix >> 32) % 41u);
    return (base * pct) / 100u;
}

int nd_outbox_mark_failure(NDOutbox *o, uint64_t id, NDOutboxErrorCategory cat,
                           uint64_t now_ms, char *err, size_t ec) {
    NDOutboxItem *it = o ? find_item(o, id) : NULL;
    if (!it || cat < ND_OUTBOX_ERR_NETWORK || cat > ND_OUTBOX_ERR_UNKNOWN) {
        set_error(err, ec, "invalid outbox failure");
        return -1;
    }
    it->attempts++;
    it->last_error = cat;
    if (it->attempts >= NDBX_MAX_ATTEMPTS) {
        it->state = ND_OUTBOX_PAUSED;
        it->next_attempt_at_ms = 0u;
    } else {
        it->state = ND_OUTBOX_RETRY_WAIT;
        it->next_attempt_at_ms = now_ms + retry_delay(it->id, it->attempts);
    }
    return persist(o, err, ec);
}

const NDOutboxItem *nd_outbox_next_eligible(NDOutbox *o, const NDNetworkSnapshot *network,
                                            int manual, uint64_t now_ms) {
    if (!o || !o->count) return NULL;
    int changed = 0;
    for (size_t i = 0u; i < o->count; i++) {
        NDOutboxItem *it = &o->items[i];
        if (it->state != ND_OUTBOX_EXPIRED && it->expires_at_ms <= now_ms) {
            it->state = ND_OUTBOX_EXPIRED;
            it->next_attempt_at_ms = 0u;
            changed = 1;
        }
        if (it->state == ND_OUTBOX_EXPIRED || it->state == ND_OUTBOX_BLOCKED_DEPENDENCY || it->state == ND_OUTBOX_PAUSED) break;
        if (it->dependency_count) break;
        if (it->state == ND_OUTBOX_RETRY_WAIT && it->next_attempt_at_ms > now_ms) break;
        if (it->state != ND_OUTBOX_QUEUED && it->state != ND_OUTBOX_RETRY_WAIT) break;
        if (it->requires_network && !nd_network_allows(network, ND_NETWORK_OP_DURABLE_TASK_RETRY, manual)) break;
        if (changed) (void)persist(o, NULL, 0u);
        return it;
    }
    if (changed) (void)persist(o, NULL, 0u);
    return NULL;
}

NDOutboxSummary nd_outbox_summary(const NDOutbox *o) {
    NDOutboxSummary s;
    memset(&s, 0, sizeof(s));
    if (!o) return s;
    s.items = o->count;
    for (size_t i = 0u; i < o->count; i++) {
        const NDOutboxItem *it = &o->items[i];
        s.bytes += it->content_bytes;
        if (it->state == ND_OUTBOX_QUEUED || it->state == ND_OUTBOX_RETRY_WAIT) s.queued++;
        else if (it->state == ND_OUTBOX_PAUSED) s.paused++;
        else if (it->state == ND_OUTBOX_BLOCKED_DEPENDENCY) s.blocked++;
        else if (it->state == ND_OUTBOX_EXPIRED) s.expired++;
    }
    return s;
}

const char *nd_outbox_state_name(NDOutboxState state) {
    if (state == ND_OUTBOX_RETRY_WAIT) return "RETRY_WAIT";
    if (state == ND_OUTBOX_SENDING) return "SENDING";
    if (state == ND_OUTBOX_PAUSED) return "PAUSED";
    if (state == ND_OUTBOX_BLOCKED_DEPENDENCY) return "BLOCKED_DEPENDENCY";
    if (state == ND_OUTBOX_EXPIRED) return "EXPIRED";
    return "QUEUED";
}
