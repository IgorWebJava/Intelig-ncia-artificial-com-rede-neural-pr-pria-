<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 54 — Mapeamento Chat UI → Backend

| UI | Serviço futuro |
|---|---|
| New Chat | Conversation Service |
| Projects | Project Service |
| History | Conversation Store |
| Model selector | Model Router |
| Mode selector | Orchestration Policy |
| Knowledge | Retrieval Service |
| Web | Web/Search Service |
| Files | File Service |
| Tools | Tool Gateway |
| Agent Activity | Agent Runtime |
| Tool Call | Tool Execution Service |
| Approval | Approval Service |
| Citations | Grounding/Citation Service |
| Research | Research Orchestrator |
| Artifacts | Artifact Service |
| Project Memory | Memory/Context Service |
| Context Inspector | Context Orchestrator |
| Feedback | Evaluation/Feedback Service |

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
