#ifndef ND_SEMANTIC_RANKER_H
#define ND_SEMANTIC_RANKER_H
#include <stddef.h>
#include <stdint.h>
#define ND_SEMANTIC_FEATURE_DIM 1024u
#define ND_SEMANTIC_EMBED_DIM 64u
typedef struct { float *q_w,*q_b,*c_w,*c_b; int loaded; } NDSemanticRanker;
int nd_semantic_ranker_load(NDSemanticRanker *r,const char *path,char *err,size_t errcap);
void nd_semantic_ranker_free(NDSemanticRanker *r);
int nd_semantic_ranker_embed_query(const NDSemanticRanker *r,const char *text,float out[ND_SEMANTIC_EMBED_DIM]);
int nd_semantic_ranker_embed_candidate(const NDSemanticRanker *r,const char *text,float out[ND_SEMANTIC_EMBED_DIM]);
float nd_semantic_ranker_similarity(const NDSemanticRanker *r,const char *query,const char *candidate);
#endif
