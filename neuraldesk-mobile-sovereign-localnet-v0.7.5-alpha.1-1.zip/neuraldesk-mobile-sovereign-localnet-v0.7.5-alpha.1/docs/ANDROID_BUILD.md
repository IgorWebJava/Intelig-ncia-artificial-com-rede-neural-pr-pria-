## Delta Android v0.7.5

`MobileProfilePolicy` agora também modela ABI/provider. O route default é CPU_C99; GPU/NPU requests sem executor falham `PROVIDER_UNAVAILABLE`. Isso é capability admission, não accelerator execution. O código nativo generativo possui streaming computacional/UTF-8 como mecânica, porém o `NDAssistant` continua sem backbone generativo promovido e não é substituído silenciosamente.

# Android / JNI — v0.7.5-alpha.1

- applicationId: `com.neuraldesk.localnet`;
- versionCode: **16**;
- versionName: `0.7.5-alpha.1`;
- minSdk 26 / targetSdk 36;
- assets canônicos vêm de `../../models`;
- `CanonicalAssetStore`: `missing -> install`, `same -> preserve`, `stale -> replace` atomicamente;
- JNI carrega os cinco assets herdados + `neuraldesk-semantic-ranker-v0.7.1.ndsr`;
- Local RAG, streaming/cancel e Pilot/Master Kill permanecem locais;
- APK/AAB, ART/device e campanha física não foram comprovados neste ambiente.

## Delta mobile v0.7.3

- API 29+: `PowerManager.currentThermalStatus` é enviado ao Resource Governor;
- RAG local pode persistir/recarregar `NDRAG001`; arquivo corrompido é rejeitado;
- Research Memory é opt-in e AES-GCM/Android Keystore, máximo 128 entradas, sem resposta gerada;
- o callback atual do assistant é entrega chunked de resposta bounded, **não token streaming autoregressivo**;
- APK/AAB/ART/aparelho físico continuam pendentes.

## Configuração

- namespace/applicationId: `com.neuraldesk.localnet`;
- minSdk: 26;
- targetSdk/compileSdk: 36;
- versionCode: 14;
- versionName: `0.7.3-alpha.1`.

## Única fonte de assets

`android/app/build.gradle.kts` usa `assets.srcDir("../../models")`. A pasta `models/` contém os quatro assets v0.5 e o NDOS v0.6. Não existem cópias manuais em `src/main/assets`. No primeiro uso e em upgrades, `CanonicalAssetStore` copia o `InputStream` empacotado em blocos de **64 KiB**, calcula SHA-256 incremental, valida staging, executa `fsync` e faz replace atômico apenas quando o conteúdo em `filesDir` diverge. A rota normal não usa `readBytes()` para materializar o modelo inteiro.

## JNI canônico

`NativeEngine.nativeLoad(...)` recebe retriever, KB, pointer, relation classifier, open-knowledge NDOS e memória. O bridge chama o mesmo `NDAssistant` C99 do host. O NDOS é carregado uma vez no handle e liberado no mesmo lifecycle.

## Concorrência

`MainActivity` usa executor single-thread para o mesmo handle. No JNI, mutex/condition impõem single-flight; cancelamento fica acessível durante a operação e `nativeFree()` marca destroying, cancela e espera idle antes de liberar. Deadline monotônico é derivado do Resource Governor.

## Gates disponíveis

- JNI C `-Wall -Wextra -Werror -Wshadow -Wpointer-arith -Wstrict-prototypes` contra headers OpenJDK;
- subset Kotlin compilado por `kotlinc`;
- probe JVM executável de sincronização de asset: `missing -> install`, `same -> preserve`, `stale -> replace`;
- host C99 e ASan/UBSan;
- mesma pasta de assets canônica usada no build Android.

## Identidade pública

`RuntimeIdentity.VERSION` é `0.7.5-alpha.1` e alimenta título/UI e User-Agent dos clientes de evidência. `tests/verify_documentation_consistency.py` exige paridade com `PROJECT_MANIFEST.json` e `android/app/build.gradle.kts`.

## Limite

Não há evidência nesta release de execução física Android, APK/AAB certificado, consumo térmico/bateria ou ART real. Esses limites não são promovidos por testes host.

### JNI error-path audit

A auditoria alpha.2 passou a rejeitar `jstring` obrigatório nulo e organiza `GetStringUTFChars`/`ReleaseStringUTFChars` de forma linear também em falhas parciais. O gate host recompila essa boundary com warnings como erro; OOM real/ART continua fora da evidência física.

## Delta v0.6.1

Não houve mudança do contrato de assets ou aumento de modelos. O `NDAssistant` C compartilhado ganhou estado conversacional bounded e políticas de correção, portanto host/JNI continuam apontando para a mesma implementação canônica. Isso ainda precisa passar pelo gate JNI/Kotlin completo da candidata e não constitui evidência ART/device.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

