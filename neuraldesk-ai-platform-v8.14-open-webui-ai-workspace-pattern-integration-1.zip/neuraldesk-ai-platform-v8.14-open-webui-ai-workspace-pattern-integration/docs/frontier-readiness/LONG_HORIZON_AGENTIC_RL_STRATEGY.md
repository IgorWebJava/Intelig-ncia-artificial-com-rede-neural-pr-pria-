<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Long-Horizon Agentic RL Strategy

Future post-training may evaluate persistent rollout state, sandbox state, coding/agentic environments, multi-turn tool trajectories and multiple reasoning-effort levels.

The runtime must checkpoint environment/trajectory state, enforce tool permissions, cap spend/time, redact secrets, detect reward hacking, support deterministic replay where possible and preserve evaluation isolation.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
