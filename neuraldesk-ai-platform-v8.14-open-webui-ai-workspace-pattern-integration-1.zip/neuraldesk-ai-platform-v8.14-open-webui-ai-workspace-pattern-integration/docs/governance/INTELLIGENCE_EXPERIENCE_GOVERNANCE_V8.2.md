<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
# Intelligence Experience Governance — V8.2

1. Do not force every module into the same dashboard mechanic.
2. Preserve progressive disclosure.
3. Functional text floor: 11 px.
4. Context/Provenance/Trust must not imply backend execution.
5. Module-owned runtime only.
6. Visual versioning is a reversible-workspace affordance, not persistence proof.
