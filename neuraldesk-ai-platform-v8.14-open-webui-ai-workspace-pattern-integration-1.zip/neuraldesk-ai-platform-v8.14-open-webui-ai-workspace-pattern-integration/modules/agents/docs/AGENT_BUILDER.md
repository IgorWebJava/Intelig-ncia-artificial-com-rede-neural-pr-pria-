<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent Builder

Builder stages: Identity → Task Contract → Instructions → Model Profile → Skills → Tools → Knowledge → Memory → Guardrails → Handoffs → Budgets → Playground → Evaluation → Publish. Production versions are immutable; edits create a new draft.
