import os
import re
from typing import Dict, List, Any
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class OrgaoEspecializado:
    def __init__(self, nome: str, bit_pos: int, gatilhos: List[str], base_conhecimento: str):
        self.nome = nome
        self.bit_pos = bit_pos
        self.gatilhos = gatilhos
        self.base_conhecimento = base_conhecimento
        self.bit_acordado = False
        self.bit_sono = True

    def matches_prompt(self, prompt: str) -> bool:
        for g in self.gatilhos:
            pattern = rf"\b{re.escape(g)}\b"
            if re.search(pattern, prompt, re.IGNORECASE):
                return True
        return False

    def ativar(self):
        self.bit_acordado = True
        self.bit_sono = False

    def dormir(self):
        self.bit_acordado = False
        self.bit_sono = True

class OrganMultiplexerPlugin(BaseQcnnPlugin):
    """
    Módulo 10: Modo Expedidor & Bit-Mask Multiplexing de Órgãos (KODEX ALEPH v12.5).
    Multiplexa múltiplos órgãos especializados (Direito, Medicina, Filosofia, Engenharia)
    na RAM aplicando operações binárias bitwise diretas.
    """
    def __init__(self):
        self._enabled = True
        self.orgaos: Dict[str, OrgaoEspecializado] = {
            "direito": OrgaoEspecializado(
                "Direito", 0,
                ["lei", "leis", "crime", "contrato", "constituição", "jurídico", "direito", "norma", "código"],
                "Princípios Jurídicos: Todos são iguais perante a lei e a ordem constitucional garante os direitos fundamentais."
            ),
            "medicina": OrgaoEspecializado(
                "Medicina", 2,
                ["saúde", "sintoma", "dor", "médico", "biologia", "celular", "homeostase", "organismo"],
                "Princípios Médicos: A homeostase e a integridade celular protegem os tecidos vivos contra estresse oxidativo e patologias."
            ),
            "engenharia": OrgaoEspecializado(
                "Engenharia", 4,
                ["sistema", "código", "circuito", "algoritmo", "hardware", "software", "estrutura", "edge", "robótica"],
                "Princípios de Engenharia: A robustez arquitetural e a tolerância a falhas garantem eficiência máxima com menor consumo energético."
            ),
            "filosofia": OrgaoEspecializado(
                "Filosofia", 6,
                ["mente", "consciência", "verdade", "ética", "existência", "pensamento", "ontologia"],
                "Princípios Filosóficos: O observador consciente colapsa o significado e fundamenta a relação entre essência e manifestação."
            ),
            "financas": OrgaoEspecializado(
                "Finanças", 8,
                ["economia", "moeda", "mercado", "inflação", "finanças", "dinheiro", "capital", "ativo"],
                "Princípios Financeiros: A liquidez, a gestão de risco e o valor temporal do capital regem a estabilidade dos fluxos econômicos."
            ),
            "astronomia": OrgaoEspecializado(
                "Astronomia", 10,
                ["estrela", "galáxia", "buraco negro", "planeta", "cosmo", "astronomia", "órbita", "gravitação"],
                "Princípios Astronômicos: A curvatura do espaço-tempo gravitacional organiza galáxias e corpos celestes em harmonia cosmológica."
            )
        }

    def register_custom_organ(self, chave: str, orgao: OrgaoEspecializado):
        """Permite carregar dinamicamente órgãos adicionais na RAM sem recompilação."""
        self.orgaos[chave.lower()] = orgao

    @property
    def plugin_id(self) -> str:
        return "organ_multiplexer"

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @is_enabled.setter
    def is_enabled(self, value: bool):
        self._enabled = value

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt_lower = context.prompt.lower()
        registrador_estado = 0b00000000
        orgaos_ativados: List[OrgaoEspecializado] = []

        # Detecção de ativação por bitmask com correspondência exata de palavras
        ativar_todos = bool(re.search(r"\b(todos|geral|ecossistema)\b", prompt_lower))

        for chave, orgao in self.orgaos.items():
            if ativar_todos or orgao.matches_prompt(context.prompt):
                orgao.ativar()
                registrador_estado |= (0b10 << orgao.bit_pos)
                orgaos_ativados.append(orgao)
            else:
                orgao.dormir()

        context.metadata["organ_bitmask"] = bin(registrador_estado)
        context.metadata["active_organs"] = [o.nome for o in orgaos_ativados]

        if orgaos_ativados and not context.custom_response:
            respostas_orgaos = []
            hz_adicional = 0.0
            for o in orgaos_ativados:
                respostas_orgaos.append(f"[{o.nome.upper()}]: {o.base_conhecimento}")
                hz_adicional += 33.3

            context.custom_response = "<br><br>───<br>".join(respostas_orgaos)
            context.total_frequency_hz = max(context.total_frequency_hz, hz_adicional)
            context.final_state = f"10 (Bitmask {bin(registrador_estado)})"
            context.chain = [o.nome for o in orgaos_ativados]

        return context

