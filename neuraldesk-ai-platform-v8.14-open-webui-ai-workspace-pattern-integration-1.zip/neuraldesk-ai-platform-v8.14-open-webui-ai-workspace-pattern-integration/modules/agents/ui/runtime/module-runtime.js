(() => {
  'use strict';
  const d=document;
  const body=d.body;
  const qs=(s,r=d)=>r.querySelector(s);
  const qsa=(s,r=d)=>[...r.querySelectorAll(s)];
  const setOpen=(el,on)=>{if(!el)return; el.hidden=!on; el.setAttribute('aria-hidden',String(!on));};
  const toast=(msg,tone='info')=>{
    const host=qs('[data-toast-host]'); if(!host)return;
    const node=d.createElement('div'); node.className=`nd-toast ${tone}`; node.textContent=msg; host.append(node);
    requestAnimationFrame(()=>node.classList.add('show'));
    setTimeout(()=>{node.classList.remove('show'); setTimeout(()=>node.remove(),180);},2400);
  };
  const closeOverlays=()=>qsa('[data-overlay]').forEach(el=>setOpen(el,false));
  const openOverlay=(name)=>{closeOverlays(); setOpen(qs(`[data-overlay="${name}"]`),true); const input=qs(`[data-overlay="${name}"] input[autofocus]`); if(input)setTimeout(()=>input.focus(),0);};
  const activateTab=(btn)=>{
    const group=btn.closest('[data-tabs]'); if(!group)return;
    const target=btn.dataset.tab;
    qsa('[data-tab]',group).forEach(x=>{x.classList.toggle('active',x===btn);x.setAttribute('aria-selected',String(x===btn));});
    const scope=group.parentElement||d;
    qsa('[data-panel]',scope).forEach(p=>p.hidden=p.dataset.panel!==target);
  };
  const filterItems=(input)=>{
    const selector=input.dataset.filterInput; const scope=selector?qs(selector):d;
    const term=input.value.trim().toLowerCase();
    qsa('[data-search-item]',scope||d).forEach(el=>el.hidden=!!term&&!el.textContent.toLowerCase().includes(term));
  };
  d.addEventListener('click',e=>{
    const a=e.target.closest('[data-action]');
    if(a){
      const action=a.dataset.action;
      if(action==='open-command') openOverlay('command');
      else if(action==='open-create') openOverlay('create');
      else if(action==='open-tasks') openOverlay('tasks');
      else if(action==='open-notifications') openOverlay('notifications');
      else if(action==='close-overlays') closeOverlays();
      else if(action==='toggle-inspector') body.classList.toggle('inspector-collapsed');
      else if(action==='toggle-nav') body.classList.toggle('nav-open');
      else if(action==='show-toast') toast(a.dataset.message||'Ação registrada.',a.dataset.tone||'info');
      else if(action==='toggle-artifact') body.classList.toggle('artifact-open');
      else if(action==='demo-agent-draft'){
        const out=qs('#agent-draft-status'); if(out){out.innerHTML='<strong>Draft estruturado</strong><span>Task contract, skills, tools, knowledge, guardrails e budget preparados para revisão.</span>';out.classList.add('ready');}
        toast('Draft local preparado para revisão. Nenhuma IA externa foi chamada.','success');
      }
      else if(action==='run-ui-test'){
        const out=qs('#runtime-test-output'); if(out){out.innerHTML='<strong>UI test complete</strong><span>Interface state validated locally. Backend/AI execution is not connected in this template.</span>';out.classList.add('ready');}
        toast('Teste de interface concluído.','success');
      }
      else if(action==='apply-filter'){toast('Filtros aplicados à visualização local.','success');}
      else if(action==='copy-text'){
        const text=a.dataset.copyText||''; if(navigator.clipboard)navigator.clipboard.writeText(text); toast('Copiado.','success');
      }
    }
    const tab=e.target.closest('[data-tab]'); if(tab)activateTab(tab);
    const sel=e.target.closest('[data-selectable]'); if(sel){const scope=sel.parentElement;qsa('[data-selectable]',scope).forEach(x=>x.classList.remove('selected'));sel.classList.add('selected');}
    const toggle=e.target.closest('[data-toggle]'); if(toggle){const on=toggle.getAttribute('aria-pressed')!=='true';toggle.setAttribute('aria-pressed',String(on));toggle.classList.toggle('on',on);}
    if(e.target.matches('[data-overlay]')) closeOverlays();
  });
  d.addEventListener('input',e=>{
    if(e.target.matches('[data-filter-input]'))filterItems(e.target);
    if(e.target.matches('[data-command-search]')){
      const term=e.target.value.trim().toLowerCase();
      qsa('[data-command-item]').forEach(el=>el.hidden=!!term&&!el.textContent.toLowerCase().includes(term));
    }
  });
  d.addEventListener('keydown',e=>{
    if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openOverlay('command');}
    else if(e.key==='Escape'){closeOverlays();body.classList.remove('nav-open');}
    else if(e.key==='/'&&!/input|textarea|select/i.test(d.activeElement?.tagName||'')){e.preventDefault();(qs('[data-page-search]')||qs('[data-filter-input]'))?.focus();}
  });
  qsa('[data-tabs]').forEach(group=>{const active=qs('[data-tab].active',group)||qs('[data-tab]',group); if(active)activateTab(active);});
  // Lightweight workflow node dragging for builder prototypes.
  qsa('[data-draggable-node]').forEach(node=>{
    let sx=0,sy=0,ox=0,oy=0,drag=false;
    node.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;drag=true;sx=ev.clientX;sy=ev.clientY;const tr=node.dataset.translate?.split(',').map(Number)||[0,0];ox=tr[0]||0;oy=tr[1]||0;node.setPointerCapture(ev.pointerId);node.classList.add('dragging');});
    node.addEventListener('pointermove',ev=>{if(!drag)return;const x=ox+ev.clientX-sx,y=oy+ev.clientY-sy;node.style.transform=`translate(${x}px,${y}px)`;node.dataset.translate=`${x},${y}`;});
    node.addEventListener('pointerup',()=>{drag=false;node.classList.remove('dragging');});
  });
  body.classList.add('runtime-ready');
})();

;(() => {
  'use strict';
  const d=document, body=d.body;
  const q=(s,r=d)=>r.querySelector(s), qa=(s,r=d)=>[...r.querySelectorAll(s)];
  const toast=(msg)=>{const host=q('[data-toast-host]');if(!host)return;const n=d.createElement('div');n.className='nd-toast';n.textContent=msg;host.append(n);requestAnimationFrame(()=>n.classList.add('show'));setTimeout(()=>{n.classList.remove('show');setTimeout(()=>n.remove(),180)},2200)};
  const setOverlay=(name)=>{qa('[data-overlay]').forEach(el=>{el.hidden=true;el.setAttribute('aria-hidden','true')});const el=q(`[data-overlay="${name}"]`);if(el){el.hidden=false;el.setAttribute('aria-hidden','false')}};
  const setDensity=(density)=>{body.dataset.density=density;qa('[data-density-value]').forEach(b=>b.classList.toggle('active',b.dataset.densityValue===density));try{localStorage.setItem('neuraldesk-density',density)}catch(_){ }toast(`Density: ${density}. Local UI preference.`)};
  const setModuleMode=(btn)=>{const mode=btn.dataset.moduleMode;qa('[data-module-mode]').forEach(b=>b.classList.toggle('active',b.dataset.moduleMode===mode));qa('[data-module-panel]').forEach(p=>p.hidden=p.dataset.modulePanel!==mode);body.dataset.moduleMode=mode;toast(`${mode} workspace selected.`)};
  d.addEventListener('click',e=>{
    const density=e.target.closest('[data-density-value]');if(density){setDensity(density.dataset.densityValue);return}
    const mode=e.target.closest('[data-module-mode]');if(mode){setModuleMode(mode);return}
    const a=e.target.closest('[data-action]');if(!a)return;
    if(a.dataset.action==='open-context-lens')setOverlay('context-lens');
    else if(a.dataset.action==='open-provenance')setOverlay('provenance');
    else if(a.dataset.action==='open-trust')setOverlay('trust');
    else if(a.dataset.action==='cycle-inspector'){const states=['closed','peek','open','pinned'];const cur=body.dataset.inspectorState||'open';const next=states[(states.indexOf(cur)+1)%states.length];body.dataset.inspectorState=next;toast(`Inspector: ${next}`)}
    else if(a.dataset.action==='toggle-work-mode'){body.classList.toggle('simple-experience');a.textContent=body.classList.contains('simple-experience')?'Enter Work mode':'Enter Simple mode';toast(body.classList.contains('simple-experience')?'Simple experience enabled.':'Work experience enabled.')}
    else if(a.dataset.action==='visual-simulate')toast(a.dataset.message||'Template simulation updated locally.');
  });
  const saved=(()=>{try{return localStorage.getItem('neuraldesk-density')}catch(_){return null}})();setDensity(saved||'balanced');
  qa('[data-module-panel]').forEach((p,i)=>{if(i>0)p.hidden=true});
})();


;(() => {
  'use strict';
  const d=document, body=d.body;
  const q=(s,r=d)=>r.querySelector(s), qa=(s,r=d)=>[...r.querySelectorAll(s)];
  const setOpen=(el,on)=>{if(!el)return;el.hidden=!on;el.setAttribute('aria-hidden',String(!on));};
  const close=()=>qa('[data-overlay]').forEach(el=>setOpen(el,false));
  const toast=(msg)=>{const host=q('[data-toast-host]');if(!host)return;const n=d.createElement('div');n.className='nd-toast';n.textContent=msg;host.append(n);requestAnimationFrame(()=>n.classList.add('show'));setTimeout(()=>{n.classList.remove('show');setTimeout(()=>n.remove(),180)},2300)};
  d.addEventListener('click',e=>{
    const a=e.target.closest('[data-action]'); if(!a)return;
    if(a.dataset.action==='open-engine-bridge'){close();setOpen(q('[data-overlay="engine-bridge"]'),true);}
    else if(a.dataset.action==='engine-simulate'){const out=q('[data-engine-bridge-status]');if(out)out.textContent=a.dataset.state||'UI state simulated';body.dataset.engineSimulation=a.dataset.state||'simulated';toast((a.dataset.state||'Engine state')+' · local UI simulation only.');}
  });
})();
