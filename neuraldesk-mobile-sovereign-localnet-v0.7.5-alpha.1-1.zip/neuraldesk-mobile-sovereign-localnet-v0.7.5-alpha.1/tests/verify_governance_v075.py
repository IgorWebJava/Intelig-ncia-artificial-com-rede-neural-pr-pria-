#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(ROOT/'training/build_governance_v075.py')],cwd=ROOT,check=True)
p=ROOT/'training/data/governance_v075/CURRENT_CORPUS_GOVERNANCE.json'
o=json.loads(p.read_text(encoding='utf-8'))
assert o['current']['richSft']['rows']==2563
assert o['current']['contextSft']['rows']==52500
assert o['current']['causalReplay']['rows']==55063
assert o['current']['piraValidation']['rows']==140
assert o['current']['globalQuestionCrossSplitLeakage']==0
assert o['historicalV063']['historicalGolden250Imported'] is False
assert o['historicalV063']['rawCurated490Recovered'] is False
assert o['historicalV063']['attestedHashes']['golden250Sha256']=='5b7382967349fd2bc884d0fd6d63829895a6d0a35febe3fa880fc707f4e59b4d'
assert all('trainingEligibility' in s and 'rights' in s and 'piiPolicy' in s for s in o['sources'])
assert any(s['trainingEligibility'].startswith('REFERENCE_ONLY') for s in o['sources'])
assert o['promotionAuthorized'] is False
print('GOVERNANCE_V075 PASS sources=%d leakage=0 historicalGolden250Imported=false noFabrication=true' % len(o['sources']))
