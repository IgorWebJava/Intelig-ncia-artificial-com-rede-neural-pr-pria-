# Human Approval Governance

Risk tiers:
- Low: automatic if policy allows.
- Medium: policy-dependent.
- High: explicit approval.
- Critical: explicit approval and possibly organizational controls.

Approval objects record:
requester, proposed action, affected resources, data, estimated cost, risk, reversibility, expiration and decision.

Approval is a stateful contract, not a UI button.
