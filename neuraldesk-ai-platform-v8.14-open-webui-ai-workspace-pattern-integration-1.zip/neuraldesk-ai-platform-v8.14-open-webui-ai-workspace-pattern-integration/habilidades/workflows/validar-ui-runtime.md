<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Workflow — Validar UI Runtime

Per module validate:

- exactly one module-owned CSS file;
- exactly one module-owned `ui/runtime/module-runtime.js` entrypoint;
- no external provider/database SDK;
- no backend calls in the template runtime;
- command palette / create / tasks / notifications / tabs / filters work locally;
- keyboard shortcuts and Escape behavior;
- responsive layouts at 390x844, 768x1024, 1366x768, 1920x1080 and 3840x2160;
- focus-visible, reduced motion and high-contrast handling.
