import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.plugins.multiverse_oracle import MultiverseOraclePlugin
from qcnn.plugins.mycelium_index import MyceliumIndexPlugin
from qcnn.plugins.metacognitive_auditor import MetaCognitiveAuditorPlugin
from qcnn.core.context import QcnnExecutionContext

class TestMultiverseAndEpistemics(unittest.TestCase):
    def test_multiverse_oracle_decision_simulation(self):
        oracle = MultiverseOraclePlugin()
        prompt = "Devo expandir a infraestrutura de servidores agora ou manter reservas de caixa?"
        ctx = QcnnExecutionContext(prompt=prompt)
        ctx.metadata["prisma_risco"] = 0.8
        ctx.metadata["filosofia"] = "Estoicismo"
        ctx.metadata["rigor_logico"] = 0.95
        
        ctx = oracle.execute(ctx)
        
        self.assertEqual(ctx.final_state, "11 (Superposição Multiverso Colapsada)")
        self.assertIn("multiverse_data", ctx.metadata)
        
        m_data = ctx.metadata["multiverse_data"]
        self.assertEqual(len(m_data["cenarios"]), 4)
        
        ids = [c["id"].lower() for c in m_data["cenarios"]]
        self.assertEqual(ids, ["alpha", "beta", "gamma", "delta"])
        
        # Dominant scenario exists
        self.assertIn("colapso_primario", m_data)
        self.assertIn(m_data["colapso_primario"]["id"].lower(), ["alpha", "beta", "gamma", "delta"])

    def test_multiverse_risk_modulation(self):
        oracle = MultiverseOraclePlugin()
        prompt = "Devo investir em novos servidores agora?"
        
        # High risk vs Low risk
        ctx_high = QcnnExecutionContext(prompt=prompt)
        ctx_high.metadata["prisma_risco"] = 0.95
        ctx_high = oracle.execute(ctx_high)
        self.assertIn("multiverse_data", ctx_high.metadata)
        prob_alpha_high_str = next(c["probabilidade"] for c in ctx_high.metadata["multiverse_data"]["cenarios"] if c["id"].lower() == "alpha")
        prob_alpha_high = float(prob_alpha_high_str.replace("%", ""))
        
        ctx_low = QcnnExecutionContext(prompt=prompt)
        ctx_low.metadata["prisma_risco"] = 0.05
        ctx_low = oracle.execute(ctx_low)
        self.assertIn("multiverse_data", ctx_low.metadata)
        prob_alpha_low_str = next(c["probabilidade"] for c in ctx_low.metadata["multiverse_data"]["cenarios"] if c["id"].lower() == "alpha")
        prob_alpha_low = float(prob_alpha_low_str.replace("%", ""))
        
        self.assertGreater(prob_alpha_high, prob_alpha_low)

    def test_mycelium_index_organic_routing(self):
        mycelium = MyceliumIndexPlugin()
        ctx = QcnnExecutionContext(prompt="Como a inteligência quântica e a biologia convergem?")
        ctx = mycelium.execute(ctx)
        
        self.assertIn("mycelium_pathways", ctx.metadata)
        self.assertIn("mycelium_nodes_count", ctx.metadata)

    def test_metacognitive_auditor_validation(self):
        auditor = MetaCognitiveAuditorPlugin()
        ctx = QcnnExecutionContext(prompt="Explique o princípio da não-contradição")
        ctx.custom_response = "O princípio da não-contradição afirma que uma proposição não pode ser verdadeira e falsa simultaneamente."
        ctx.total_frequency_hz = 528.0
        
        ctx = auditor.execute(ctx)
        
        self.assertIn("meta_cognition", ctx.metadata)
        meta = ctx.metadata["meta_cognition"]
        self.assertEqual(meta["status"], "VALIDADO_EPISTEMICAMENTE")
        self.assertTrue("coerencia_simbolica" in meta)
        self.assertIn("Preservação de Não-Contradição", meta["invariantes_verificados"])
        self.assertIn("Alinhamento Harmônico Áureo", meta["invariantes_verificados"])

if __name__ == "__main__":
    unittest.main()
