#include "nd_network_policy.h"

NDNetworkSnapshot nd_network_snapshot(int online, int save_data, unsigned downstream_kbps) {
    NDNetworkSnapshot s;
    s.online = online ? 1 : 0;
    s.save_data = save_data ? 1 : 0;
    s.downstream_kbps = downstream_kbps;
    if (!s.online) {
        s.state = ND_NETWORK_OFFLINE;
    } else if (s.save_data || (s.downstream_kbps > 0u && s.downstream_kbps < 512u)) {
        s.state = ND_NETWORK_CONSTRAINED;
    } else {
        s.state = ND_NETWORK_NORMAL;
    }
    return s;
}

int nd_network_allows(const NDNetworkSnapshot *s, NDNetworkOperation operation, int manual) {
    if (!s) return 0;
    if (operation < ND_NETWORK_OP_DURABLE_TASK_RETRY || operation > ND_NETWORK_OP_WEB_CONTEXT) return 0;
    if (!s->online) return 0;
    if (manual) return 1;
    return s->state == ND_NETWORK_NORMAL;
}

const char *nd_network_state_name(NDNetworkState state) {
    if (state == ND_NETWORK_NORMAL) return "NORMAL";
    if (state == ND_NETWORK_CONSTRAINED) return "CONSTRAINED";
    return "OFFLINE";
}
