#!/usr/bin/env python3
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import model_authority as a
prom=ROOT/'verification/model-promotion-v0.7.2.json';act=ROOT/'verification/model-activation-v0.7.2.json'
pp=a.verify_signed(prom);ap=a.verify_signed(act)
paths=[x['path'] for x in pp['assets']]
assert 'models/neuraldesk-semantic-ranker-v0.7.1.ndsr' in paths and len(paths)==6
ranker=next(x for x in pp['assets'] if x['path'].endswith('.ndsr'));assert ranker['combinedRatio']>=0.985
assert pp['generationActivated'] is False and pp['unpromotedCandidate']['activation']=='PROHIBITED_PENDING_QUALITY_GATE'
assert ap['promotionManifestSha256']==a.sha(prom)
assert ap['generativeBackbone']=='NOT_ACTIVATED_NO_PROMOTED_BACKBONE' and ap['fullPiraCandidate']=='NOT_ACTIVATED_PENDING_PRECISION'
assert ap['productionServingAuthorized'] is False and ap['publicServingAuthorized'] is False
d=json.loads(prom.read_text());d['assets'][0]['sha256']='0'*64
sig=base64.b64decode(d.pop('signatureEd25519Base64'));key=a.serialization.load_pem_public_key(a.PUB.read_bytes())
try:key.verify(sig,a.canonical(d));raise AssertionError('tampered promotion accepted')
except Exception:pass
print('MODEL_AUTHORITY PASS promotion_assets=6 activation_separate=true tamper_rejected=true generative=false full_pira=false')
