<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.agents; current: docs/architecture/CURRENT_AGENT_PLATFORM.md -->
# Current Agent Platform

`neuraldesk.agents` is the first-class project-scoped Agent Design Studio. It owns agent definitions/versions/templates, bindings, team/workflow/handoff representation, guardrails/budgets, playground/evaluation/deployment surfaces and run metadata models.

Shared project identity remains in Project Registry. Runtime Agent Skills remain separate from development `habilidades/`. Production agent/tool/model execution is future runtime work; V8.11 implements the current interface contracts and cooperative Engine Bridge only.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
