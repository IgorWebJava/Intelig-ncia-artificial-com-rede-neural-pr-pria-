#ifndef ND_MODEL_ACQUISITION_H
#define ND_MODEL_ACQUISITION_H

#include <stddef.h>
#include <stdint.h>
#include "nd_network_policy.h"
#include "nd_resource.h"

typedef enum {
    ND_MODEL_ACQUISITION_REQUIRES_CONFIRMATION = 0,
    ND_MODEL_ACQUISITION_CACHE_ONLY_OFFLINE = 1,
    ND_MODEL_ACQUISITION_BLOCKED_RESOURCE = 2,
    ND_MODEL_ACQUISITION_BLOCKED_STORAGE = 3
} NDModelAcquisitionDecision;

typedef struct {
    uint64_t estimated_model_bytes;
    uint64_t reserve_bytes;
    uint64_t free_bytes;
    int free_bytes_known;
    NDModelAcquisitionDecision decision;
    NDNetworkState network_state;
    NDMobileProfile profile;
} NDModelAcquisitionReport;

uint64_t nd_model_estimate_bytes(uint64_t parameters, unsigned bits_per_weight, uint64_t runtime_overhead_bytes);
NDModelAcquisitionReport nd_model_acquisition_assess(uint64_t parameters,
                                                     unsigned bits_per_weight,
                                                     uint64_t runtime_overhead_bytes,
                                                     uint64_t storage_quota_bytes,
                                                     uint64_t storage_used_bytes,
                                                     int storage_known,
                                                     const NDResourcePolicy *resource,
                                                     const NDNetworkSnapshot *network);
const char *nd_model_acquisition_decision_name(NDModelAcquisitionDecision decision);

#endif
