#!/usr/bin/env python3
"""Mandatory pre-generation gate.

This gate deliberately reads the canonical lessons file before any dataset/model
materialization or release generation. It cannot prove human comprehension, so
PROJECT policy additionally requires the operator/AI to analyze the document.
"""
from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]
LESSONS = ROOT / "memória" / "LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md"
REQUIRED = [
    "Regra zero:",
    "O que fizemos certo",
    "O que fizemos errado",
    "Gates mínimos antes de qualquer promoção",
    "Este arquivo é a primeira leitura obrigatória do projeto.",
]

def main() -> int:
    if not LESSONS.is_file():
        print(f"LESSONS PRECHECK FAIL: missing {LESSONS.relative_to(ROOT)}", file=sys.stderr)
        return 2
    text = LESSONS.read_text(encoding="utf-8")
    missing = [x for x in REQUIRED if x not in text]
    if missing:
        print("LESSONS PRECHECK FAIL: required sections missing: " + repr(missing), file=sys.stderr)
        return 3
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    print(f"LESSONS PRECHECK PASS: read {LESSONS.relative_to(ROOT)} sha256={digest}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
