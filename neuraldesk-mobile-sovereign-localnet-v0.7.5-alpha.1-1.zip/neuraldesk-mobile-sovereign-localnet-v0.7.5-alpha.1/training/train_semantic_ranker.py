#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,math,random,re,struct,sys,subprocess
from pathlib import Path
import torch
import torch.nn as nn
import torch.nn.functional as F
ROOT=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(ROOT/'scripts/pre_generation_lessons_check.py')],cwd=ROOT,check=True)
sys.path.insert(0,str(ROOT/'training'))
from knowledge_base import R
F_DIM=1024; E_DIM=64; MAGIC=b'NDSRANK1'; VERSION=1

def fnv64(b:bytes)->int:
    h=14695981039346656037
    for x in b: h=((h^x)*1099511628211)&0xffffffffffffffff
    return h

def norm(s:str)->str:
    import unicodedata
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
    return ' '.join(re.findall(r'[a-z0-9_-]+',s))

def feat(s:str):
    n=norm(s); toks=n.split(); v=torch.zeros(F_DIM)
    items=[]
    items += [('w:'+t,1.0) for t in toks]
    items += [('b:'+toks[i]+'_'+toks[i+1],0.75) for i in range(len(toks)-1)]
    compact=''.join(ch for ch in n if ch!=' ')
    for k in (3,4,5):
        items += [('c:'+compact[i:i+k],0.18) for i in range(max(0,len(compact)-k+1))]
    for x,w in items: v[fnv64(x.encode())&(F_DIM-1)] += w
    d=float(v.norm())
    if d: v/=d
    return v

def read_tsv(path):
    out=[]
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        a,b=line.split('\t',1); out.append((int(a),b))
    return out

cands=[r.q+' '+r.short+' '+r.rich for r in R]
cf=torch.stack([feat(x) for x in cands])
train=[x for x in read_tsv(ROOT/'training/data/knowledge_retriever_train.tsv') if x[0]<201]
gold=[x for x in read_tsv(ROOT/'training/data/knowledge_retriever_golden.tsv') if x[0]<201]
# Add current 31 Pira pairs only to training representation quality, never golden answers.
pira=[json.loads(x) for x in (ROOT/'training/data/open_knowledge/pira_reconstruction_records_v1.jsonl').read_text(encoding='utf-8').splitlines()]
pira_offset=len(cands)
for r in pira: cands.append(r['question']+' '+r['answer'])
cf=torch.cat([cf,torch.stack([feat(x) for x in cands[pira_offset:]])])
for i,r in enumerate(pira): train.append((pira_offset+i,r['question']))

# Full-catalog contrastive classification.  Query and candidate projections remain
# separate; every other candidate is a negative at each step.
qtrain=torch.stack([feat(q) for _,q in train])

class Ranker(nn.Module):
    def __init__(self):
        super().__init__(); self.q=nn.Linear(F_DIM,E_DIM); self.c=nn.Linear(F_DIM,E_DIM)
    def embq(self,x): return F.normalize(self.q(x),dim=-1)
    def embc(self,x): return F.normalize(self.c(x),dim=-1)

torch.manual_seed(7071); random.seed(7071); torch.set_num_threads(5)
m=Ranker(); opt=torch.optim.AdamW(m.parameters(),lr=2e-3,weight_decay=1e-4)
y=torch.tensor([a for a,_ in train]); idx=torch.arange(len(train))
for step in range(1100):
    g=torch.Generator().manual_seed(7071+step)
    b=idx[torch.randperm(len(idx),generator=g)[:min(256,len(idx))]]
    q=m.embq(qtrain[b])
    ce=m.embc(cf)
    logits=(q@ce.T)/0.08
    loss=F.cross_entropy(logits,y[b])
    opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(m.parameters(),1.0); opt.step()
    if step in (0,99,299,699,1099): print(f'step={step+1} loss={loss.item():.6f}',flush=True)

# evaluate correct against lexical strongest wrong; this is a relative-reranking gate
qg=torch.stack([feat(q) for _,q in gold]); yg=torch.tensor([a for a,_ in gold])
lex=qg@cf[:201].T
for i,yv in enumerate(yg): lex[i,yv]=-1e9
ng=lex.argmax(1)
with torch.no_grad():
    eq=m.embq(qg); pc=m.embc(cf[yg]); nc=m.embc(cf[ng]); margins=(eq*pc).sum(1)-(eq*nc).sum(1)
passed=int((margins>0).sum()); total=len(gold)
# Critical Pira semantic comparisons held out from ranker optimization: validation paraphrases vs deterministic unrelated records.
val=[json.loads(x) for x in (ROOT/'training/data/open_knowledge/pira_reconstruction_validation_v1.jsonl').read_text(encoding='utf-8').splitlines()]
crit=0; crit_rows=[]
byid={r['source_id']:r for r in pira}
for j,row in enumerate(val[:8]):
    src=byid.get(row['expected_source_id']);
    if not src: continue
    wrong=pira[(j+11)%len(pira)]
    with torch.no_grad():
        qe=m.embq(feat(row['query']).unsqueeze(0)); pe=m.embc(feat(src['question']+' '+src['answer']).unsqueeze(0)); ne=m.embc(feat(wrong['question']+' '+wrong['answer']).unsqueeze(0))
        margin=float((qe*pe).sum()-(qe*ne).sum())
    ok=margin>0; crit+=int(ok); crit_rows.append({'source_id':row['expected_source_id'],'margin':margin,'pass':ok})
combined=passed+crit; combined_total=total+len(crit_rows)
print(f'gold={passed}/{total} critical={crit}/{len(crit_rows)} combined={combined}/{combined_total}')
if combined/combined_total < 0.985: raise SystemExit('semantic ranker gate failed')

out=ROOT/'models/neuraldesk-semantic-ranker-v0.7.1.ndsr'
with out.open('wb') as f:
    f.write(struct.pack('<8sIIIIQ',MAGIC,VERSION,F_DIM,E_DIM,0,0))
    # torch linear stores [out,in]; runtime uses x dot row
    for t in (m.q.weight,m.q.bias,m.c.weight,m.c.bias): f.write(t.detach().float().contiguous().numpy().tobytes())
assert out.stat().st_size==524832, out.stat().st_size
sha=hashlib.sha256(out.read_bytes()).hexdigest()
report={'schema':'neuraldesk-semantic-ranker-training-v1','parameters':sum(p.numel() for p in m.parameters()),'featureDim':F_DIM,'embeddingDim':E_DIM,'trainPairs':len(train),'goldKnownComparisons':total,'goldPassed':passed,'criticalComparisons':len(crit_rows),'criticalPassed':crit,'combinedPassed':combined,'combinedTotal':combined_total,'combinedRatio':combined/combined_total,'asset':str(out.relative_to(ROOT)),'bytes':out.stat().st_size,'sha256':sha,'criticalRows':crit_rows,'unknownGoldenExcludedFromRanker':115,'unknownHandledBy':'retriever-answerability-fail-closed'}
(ROOT/'evaluation/SEMANTIC_RANKER_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'SEMANTIC_RANKER_TRAIN PASS parameters={report["parameters"]} bytes={report["bytes"]} sha256={sha}')
