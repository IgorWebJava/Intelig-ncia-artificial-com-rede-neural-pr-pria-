"""
SUÍTE DE TESTES DE ESTRESSE, LONGA DURAÇÃO E AUTO-RECUPERAÇÃO HOLOGRÁFICA (ETAPA 4)
Valida a robustez do ecossistema QCNN Multi-V sob:
- Múltiplos ciclos contínuos de consolidação autônoma.
- Ingestão volumosa e persistência sob pressão.
- Injeção forçada de ruído entrópico e auto-recuperação (Self-Healing M22/M25).
- Estabilidade de consumo de memória e latência determinística.
"""

import unittest
import os
import time
from qcnn.core.pipeline import QcnnPipeline
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.ternary_bitwise import TernaryBitwisePlugin
from qcnn.plugins.milui_expansion import MiluiExpansionPlugin
from qcnn.plugins.adjacency_filter import AdjacencyFilterPlugin
from qcnn.plugins.harmonic_frequency import HarmonicFrequencyPlugin
from qcnn.plugins.hyperdimensional_computing import HyperdimensionalComputingPlugin
from qcnn.plugins.fractal_grammar import FractalGrammarPlugin
from qcnn.plugins.conceptual_dialogue import ConceptualDialoguePlugin
from qcnn.plugins.self_healing_consensus import SelfHealingConsensusPlugin
from qcnn.plugins.metacognitive_auditor import MetaCognitiveAuditorPlugin
from qcnn.plugins.autonomous_consolidation import AutonomousConsolidationPlugin
from qcnn.plugins.goal_driven_agent_loop import GoalDrivenAgentLoopPlugin
from qcnn.plugins.holographic_snapshot_store import HolographicSnapshotStorePlugin


class TestStressAndSelfHealing(unittest.TestCase):
    def setUp(self):
        self.db_path = "./storage_android/test_stress_holographic.db"
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

        self.pipeline = QcnnPipeline()
        self.pipeline.register_plugin(TernaryBitwisePlugin())
        self.pipeline.register_plugin(MiluiExpansionPlugin())
        self.pipeline.register_plugin(AdjacencyFilterPlugin())
        self.pipeline.register_plugin(HarmonicFrequencyPlugin())
        self.pipeline.register_plugin(HyperdimensionalComputingPlugin())
        self.pipeline.register_plugin(FractalGrammarPlugin())
        self.pipeline.register_plugin(ConceptualDialoguePlugin())
        self.pipeline.register_plugin(MetaCognitiveAuditorPlugin())
        self.pipeline.register_plugin(SelfHealingConsensusPlugin())
        self.pipeline.register_plugin(AutonomousConsolidationPlugin())
        self.pipeline.register_plugin(GoalDrivenAgentLoopPlugin())
        self.pipeline.register_plugin(HolographicSnapshotStorePlugin(db_path=self.db_path))

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_continuous_multi_cycle_consolidation_stress(self):
        """Executa 100 ciclos contínuos de consolidação para validar que a entropia decresce e a memória permanece estável."""
        consolidation_plugin = AutonomousConsolidationPlugin()
        conceitos = ["quantica", "relatividade", "gravidade", "consciencia", "matematica", "entropia", "energia", "tempo"]
        
        start_time = time.time()
        for _ in range(100):
            res = consolidation_plugin.consolidar_memoria(conceitos)
            self.assertEqual(res["status"], "CONSOLIDADO")
            self.assertGreaterEqual(res["reducao_entropia"], 0.0)
        
        elapsed = time.time() - start_time
        # Deve executar 100 ciclos de consolidação em menos de 0.2 segundos
        self.assertLess(elapsed, 0.2)
        self.assertEqual(consolidation_plugin.ciclos_executados, 100)

    def test_proactive_self_healing_under_entropy_injection(self):
        """Simula perturbação no estado do contexto e valida que o SelfHealing reconstitui a coerência."""
        prompt = "fisica quantica e relatividade geral"
        
        # 1. Executa pipeline normal
        res = self.pipeline.process(prompt)
        self.assertIsNotNone(res.resposta)
        
        # 2. Injeta anomalia / ruído destrutivo
        ctx = QcnnExecutionContext(prompt=prompt, target_seed="Alef")
        ctx.total_frequency_hz = 0.0
        ctx.chain = []
        ctx.metadata["c_score"] = 0.40
        
        # 3. Executa o SelfHealing diretamente
        healer = SelfHealingConsensusPlugin()
        ctx = healer.execute(ctx)
        
        self.assertTrue(ctx.metadata.get("self_healing_applied"))
        self.assertEqual(ctx.metadata.get("cross_consensus_status"), "COERÊNCIA_REGENERADA")
        self.assertEqual(ctx.metadata.get("c_score"), 0.98)
        self.assertEqual(ctx.total_frequency_hz, 432.00)
        self.assertTrue(len(ctx.chain) >= 2)

    def test_goal_driven_multiturn_agent_stress(self):
        """Executa múltiplos planos agênticos complexos em sequência sem travamentos ou degradação."""
        metas = [
            "meta: Otimizar frequências harmônicas do núcleo quântico",
            "meta: Reorganizar índice ontológico de astronomia e cosmologia",
            "meta: Executar síntese fractal de matemática e relatividade",
            "meta: Auditar consistência holográfica de todos os módulos"
        ]
        
        for meta in metas:
            res = self.pipeline.process(meta)
            self.assertIn("PLANO AGÊNTICO AUTÔNOMO", res.resposta)
            
            goal_meta = res.metadata.get("goal_driven_loop")
            self.assertIsNotNone(goal_meta)
            self.assertEqual(goal_meta["status_geral"], "SUCESSO_AUTONOMO")
            self.assertEqual(len(goal_meta["etapas_executadas"]), 4)


if __name__ == "__main__":
    unittest.main()
