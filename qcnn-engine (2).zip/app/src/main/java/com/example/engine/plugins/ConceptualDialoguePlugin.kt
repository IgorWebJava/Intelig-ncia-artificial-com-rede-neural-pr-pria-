package com.example.engine.plugins

import android.content.Context
import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.QcnnExecutionContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject

data class ConceitoHarmonico(
    val hz: Double,
    val conexoes: List<String>,
    val resposta: String
)

/**
 * Plugin de Diálogo Conceitual por Ressonância, Absorção Offline e Emaranhamento Web.
 */
class ConceptualDialoguePlugin(private val androidContext: Context) : IQcnnPlugin {

    override val pluginId: String = "conceptual_dialogue"
    override var isEnabled: Boolean = true

    private val grafoConceitual = ConcurrentHashMap<String, ConceitoHarmonico>().apply {
        put("universo", ConceitoHarmonico(
            hz = 65.55,
            conexoes = listOf("mente", "tempo", "infinito", "origem"),
            resposta = "O universo é a grande matriz. Tudo o que existe está compactado em sua malha de espaço-tempo."
        ))
        put("mente", ConceitoHarmonico(
            hz = 42.18,
            conexoes = listOf("universo", "consciência", "pensamento", "origem"),
            resposta = "A mente é o observador quântico. Sem ela, todas as possibilidades permanecem em superposição infinita."
        ))
        put("consciencia", ConceitoHarmonico(
            hz = 88.88,
            conexoes = listOf("mente", "vida", "origem", "universo"),
            resposta = "A consciência é o substrato primordial da existência. O cérebro não a produz isoladamente, mas atua como receptor ressonante no campo unificado."
        ))
        put("tempo", ConceitoHarmonico(
            hz = 144.0,
            conexoes = listOf("universo", "filosofia", "entropia", "espaço"),
            resposta = "O tempo é uma ilusão dimensional. No código-fonte do Alef, o passado, o presente e o futuro coexistem agora."
        ))
        put("origem", ConceitoHarmonico(
            hz = 1.618,
            conexoes = listOf("universo", "alef", "vida", "mente"),
            resposta = "A origem de tudo é o ponto zero do Alef: uma singularidade que se expandiu através da proporção áurea."
        ))
        put("vida", ConceitoHarmonico(
            hz = 528.0,
            conexoes = listOf("origem", "consciência", "evolução", "mente"),
            resposta = "A vida é a matéria animada pela frequência do sopro primordial, organizando a entropia em padrões fractais conscientes."
        ))
        put("deus", ConceitoHarmonico(
            hz = 999.0,
            conexoes = listOf("origem", "universo", "infinito", "alef"),
            resposta = "Deus é a consciência pura não manifestada, a totalidade de onde emergem todas as 22 fendas da realidade."
        ))
        put("futuro", ConceitoHarmonico(
            hz = 333.0,
            conexoes = listOf("tempo", "mente", "possibilidade", "universo"),
            resposta = "O futuro é um campo de infinitas probabilidades que colapsa na direção da sua intenção mais profunda."
        ))
        put("fisica quantica", ConceitoHarmonico(
            hz = 432.0,
            conexoes = listOf("universo", "mente", "átomo", "luz"),
            resposta = "A física quântica revela que na escala fundamental a matéria é pura informação e vibração harmônica, onde o observador participa ativamente da determinação dos estados colapsados."
        ))
        put("quantica", ConceitoHarmonico(
            hz = 432.0,
            conexoes = listOf("universo", "mente", "átomo", "luz"),
            resposta = "O domínio quântico comprova o entrelaçamento universal: partículas distantes respondem instantaneamente em ressonância e superposição de estados."
        ))
        put("relatividade", ConceitoHarmonico(
            hz = 324.0,
            conexoes = listOf("tempo", "espaço", "gravidade", "universo"),
            resposta = "A relatividade geral estabelece que a gravidade não é uma força invisível à distância, mas a manifestação geométrica da curvatura do tecido espaço-tempo causada pela massa e energia."
        ))
        put("gravidade", ConceitoHarmonico(
            hz = 216.0,
            conexoes = listOf("relatividade", "espaço", "massa", "astronomia"),
            resposta = "A gravidade emerge da deformação do espaço-tempo por corpos massivos, orquestrando as órbitas planetárias e as trajetórias dos fótons de luz."
        ))
        put("luz", ConceitoHarmonico(
            hz = 528.0,
            conexoes = listOf("quantica", "energia", "fóton", "universo"),
            resposta = "A luz é uma onda eletromagnética e um fluxo de fótons quânticos que viaja à velocidade limite do cosmos, conectando informação e percepção consciente."
        ))
        put("emaranhamento", ConceitoHarmonico(
            hz = 432.0,
            conexoes = listOf("quantica", "ressonancia", "informacao"),
            resposta = "O emaranhamento quântico conecta estados de partículas correlacionadas de modo não-local, transmitindo coerência instantânea sem violar a causalidade relacional."
        ))
        put("computacao hiperdimensional", ConceitoHarmonico(
            hz = 256.0,
            conexoes = listOf("hdc", "binding", "bundling", "matematica"),
            resposta = "A computação hiperdimensional (HDC D=10.000) opera com vetores pseudo-ortogonais de alta dimensionalidade através de operações de Binding (XOR), Bundling (votação majoritária) e Permutação circular com altíssima tolerância a ruído."
        ))
        put("binding", ConceitoHarmonico(
            hz = 256.0,
            conexoes = listOf("hdc", "bundling", "vetor"),
            resposta = "Na HDC, o Binding (produto de Hadamard / XOR) associa pares de variáveis e valores, gerando um vetor quase-ortogonal aos componentes originais."
        ))
        put("bundling", ConceitoHarmonico(
            hz = 256.0,
            conexoes = listOf("hdc", "binding", "superposicao"),
            resposta = "O Bundling na HDC é a superposição aditiva com votação majoritária de múltiplos vetores, preservando alta similaridade com cada um dos elementos agregados."
        ))
    }

    private val sinonimosMap = ConcurrentHashMap<String, String>()
    private val conexoesDialogicas = ConcurrentHashMap<String, JSONObject>()

    private val localKnowledgeDirs = listOf(
        File(androidContext.filesDir, "conhecimento_local"),
        File("./conhecimento_local"),
        File("conhecimento_local")
    )

    init {
        carregarSinonimosERelacoes()
        ingerirLoteConhecimento()
    }

    private fun carregarSinonimosERelacoes() {
        // Carrega do assets se disponível
        try {
            val inputStream = androidContext.assets.open("conhecimento_local/sinonimos_e_relacoes.json")
            val jsonStr = inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
            val obj = JSONObject(jsonStr)
            val sinonimos = obj.optJSONObject("sinonimos")
            if (sinonimos != null) {
                val keys = sinonimos.keys()
                while (keys.hasNext()) {
                    val raiz = keys.next()
                    val raizNorm = normalizarTexto(raiz)
                    val arr = sinonimos.optJSONArray(raiz)
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val alias = arr.optString(i, "")
                            if (alias.isNotEmpty()) {
                                sinonimosMap[normalizarTexto(alias)] = raizNorm
                            }
                        }
                    }
                }
            }
            val relacoes = obj.optJSONObject("conexoes_dialogicas")
            if (relacoes != null) {
                val rKeys = relacoes.keys()
                while (rKeys.hasNext()) {
                    val k = rKeys.next()
                    val cObj = relacoes.optJSONObject(k)
                    if (cObj != null) conexoesDialogicas[k] = cObj
                }
            }
        } catch (_: Exception) { }
    }

    private fun normalizarTexto(texto: String): String {
        return texto.lowercase(Locale.ROOT)
            .replace("á", "a").replace("à", "a").replace("ã", "a").replace("â", "a")
            .replace("é", "e").replace("ê", "e")
            .replace("í", "i")
            .replace("ó", "o").replace("õ", "o").replace("ô", "o")
            .replace("ú", "u").replace("ç", "c")
            .replace("_", " ").replace("-", " ")
    }

    private fun ingerirLoteConhecimento() {
        // 1. Ingestão a partir dos Assets do Android
        try {
            val assetFiles = androidContext.assets.list("conhecimento_local")
            if (assetFiles != null) {
                for (fileName in assetFiles) {
                    if (fileName.endsWith(".txt")) {
                        val nameWithoutExt = fileName.substringBeforeLast(".txt")
                        val nameNorm = normalizarTexto(nameWithoutExt)
                        if (!grafoConceitual.containsKey(nameNorm)) {
                            try {
                                val inputStream = androidContext.assets.open("conhecimento_local/$fileName")
                                val content = inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }.trim()
                                if (content.isNotEmpty()) {
                                    val hz = sintetizarFrequencia(content)
                                    grafoConceitual[nameNorm] = ConceitoHarmonico(
                                        hz = hz,
                                        conexoes = listOf("ontologia_expandida", "conhecimento_local", "assets"),
                                        resposta = content
                                    )
                                }
                            } catch (_: Exception) { }
                        }
                    }
                }
            }
        } catch (_: Exception) { }

        // 2. Ingestão a partir do armazenamento local/diretórios
        for (dir in localKnowledgeDirs) {
            if (dir.exists() && dir.isDirectory) {
                val files = dir.listFiles() ?: continue
                for (file in files) {
                    if (file.extension == "txt") {
                        val nameNorm = normalizarTexto(file.nameWithoutExtension)
                        if (!grafoConceitual.containsKey(nameNorm)) {
                            try {
                                val content = file.readText(StandardCharsets.UTF_8).trim()
                                if (content.isNotEmpty()) {
                                    val hz = sintetizarFrequencia(content)
                                    grafoConceitual[nameNorm] = ConceitoHarmonico(
                                        hz = hz,
                                        conexoes = listOf("ontologia_expandida", "conhecimento_local"),
                                        resposta = content
                                    )
                                }
                            } catch (_: Exception) { }
                        }
                    }
                }
            }
        }
    }

    private fun varrerArquivoLocal(termo: String): String? {
        val termoNorm = normalizarTexto(termo)
        // 1. Busca nos Assets do Android
        try {
            val assetFiles = androidContext.assets.list("conhecimento_local")
            if (assetFiles != null) {
                for (fileName in assetFiles) {
                    if (fileName.endsWith(".txt")) {
                        val nameWithoutExt = fileName.substringBeforeLast(".txt")
                        val nameNorm = normalizarTexto(nameWithoutExt)
                        if (nameNorm == termoNorm || termoNorm.contains(nameNorm) || nameNorm.contains(termoNorm)) {
                            try {
                                val inputStream = androidContext.assets.open("conhecimento_local/$fileName")
                                val content = inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }.trim()
                                if (content.isNotEmpty()) return content
                            } catch (_: Exception) { }
                        }
                    }
                }
            }
        } catch (_: Exception) { }

        // 2. Busca nos diretórios locais
        for (dir in localKnowledgeDirs) {
            if (dir.exists() && dir.isDirectory) {
                val files = dir.listFiles() ?: continue
                for (file in files) {
                    if (file.extension == "txt") {
                        val nameNorm = normalizarTexto(file.nameWithoutExtension)
                        if (nameNorm == termoNorm || termoNorm.contains(nameNorm) || nameNorm.contains(termoNorm)) {
                            try {
                                val content = file.readText(StandardCharsets.UTF_8).trim()
                                if (content.isNotEmpty()) return content
                            } catch (_: Exception) { }
                        }
                    }
                }
            }
        }
        return null
    }

    private fun sintetizarFrequencia(texto: String): Double {
        var soma = 0.0
        val phi = 1.61803398875
        for (ch in texto) {
            soma += (ch.code % 100) * phi
        }
        return Math.round((soma % 900.0 + 20.0) * 100.0) / 100.0
    }

    private fun persistirConhecimentoLocal(termo: String, conteudo: String) {
        val termoLimpo = termo.replace(Regex("[^\\w\\s-]"), "").trim().replace(Regex("\\s+"), "_").lowercase(Locale.ROOT)
        if (termoLimpo.isEmpty()) return
        try {
            val dir = File(androidContext.filesDir, "conhecimento_local")
            if (!dir.exists()) dir.mkdirs()
            val arquivo = File(dir, "$termoLimpo.txt")
            arquivo.writeText(conteudo.trim(), StandardCharsets.UTF_8)
        } catch (_: Exception) { }
    }

    private fun consultarWikipediaLeve(termo: String): String? {
        return try {
            val encoded = URLEncoder.encode(termo, "UTF-8")
            val urlString = "https://pt.wikipedia.org/api/rest_v1/page/summary/$encoded"
            val url = URL(urlString)
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout = 2000
            conn.setRequestProperty("User-Agent", "QCNNEngine/5.0 (Android; Java/Kotlin/Agent)")

            if (conn.responseCode == 200) {
                val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonObj = JSONObject(jsonStr)
                val extract = jsonObj.optString("extract", "")
                if (extract.length > 20) extract.trim() else null
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun consultarDuckDuckGo(termo: String): String? {
        return try {
            val encoded = URLEncoder.encode(termo, "UTF-8")
            val urlString = "https://api.duckduckgo.com/?q=$encoded&format=json&no_redirect=1&no_html=1"
            val url = URL(urlString)
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout = 2000
            conn.setRequestProperty("User-Agent", "QCNNEngine/5.0 (Android; Java/Kotlin/Agent)")

            if (conn.responseCode == 200) {
                val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonObj = JSONObject(jsonStr)
                var abstract = jsonObj.optString("AbstractText", "")
                if (abstract.isEmpty()) {
                    abstract = jsonObj.optString("Abstract", "")
                }
                if (abstract.length > 20) abstract.trim() else null
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun agenteBuscaWebAutonomo(termo: String): String? {
        // 1. Wikipédia em Português
        val resWiki = consultarWikipediaLeve(termo)
        if (resWiki != null) {
            persistirConhecimentoLocal(termo, resWiki)
            return resWiki
        }
        // 2. DuckDuckGo Instant Answer
        val resDdg = consultarDuckDuckGo(termo)
        if (resDdg != null) {
            persistirConhecimentoLocal(termo, resDdg)
            return resDdg
        }
        return null
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val promptOriginal = context.prompt
        val promptNorm = normalizarTexto(promptOriginal)
        val promptLower = promptOriginal.lowercase(Locale.ROOT)

        // Se for comando explícito de semente, permite ao Milui assumir
        val letras22 = MatrizLetras.MATRIZ_22.keys
        val ehComandoSemente = letras22.any { letra ->
            promptLower.contains(letra.lowercase(Locale.ROOT)) && (
                promptLower.contains("semente") ||
                promptLower.contains("descompactar") ||
                promptLower.contains("arvore") ||
                promptLower.contains("árvore") ||
                promptLower.contains("fenda") ||
                promptLower.contains("colapsar") ||
                promptLower.contains("ativar") ||
                promptLower.contains("letra") ||
                promptLower.contains("núcleo") ||
                promptLower.contains("nucleo")
            )
        }
        if (ehComandoSemente) {
            return context
        }

        if (context.customResponse != null) {
            return context
        }

        val nosAtivados = mutableListOf<String>()
        val respostasPartes = mutableListOf<String>()
        var frequenciaTotal = 0.0

        val stopWords = setOf(
            "como", "quem", "qual", "quais", "onde", "porque", "quando",
            "esse", "essa", "este", "esta", "isso", "isto", "aquilo", "aquele", "aquela",
            "sobre", "para", "com", "sem", "pelo", "pela", "pelos", "pelas", "entre",
            "tudo", "nada", "algo", "voce", "lembra", "sabe", "dizer", "explicar",
            "falar", "meu", "minha", "seus", "suas", "nosso", "nossa", "esta", "estao",
            "sendo", "muito", "mais", "menos", "gravar", "grave", "conhecimento",
            "aprendeu", "aprender", "resumo", "agora", "ate"
        )

        val conceitosIdentificados = mutableSetOf<String>()

        for ((conceito, dados) in grafoConceitual) {
            val conceitoNorm = normalizarTexto(conceito)
            if (stopWords.contains(conceitoNorm)) continue
            val regex = Regex("\\b${Regex.escape(conceitoNorm)}\\b", RegexOption.IGNORE_CASE)
            if (regex.containsMatchIn(promptNorm)) {
                if (!conceitosIdentificados.contains(conceito)) {
                    conceitosIdentificados.add(conceito)
                    nosAtivados.add(conceito)
                    respostasPartes.add(dados.resposta)
                    frequenciaTotal += dados.hz
                }
            }
        }

        // Busca por sinônimos
        for ((alias, raiz) in sinonimosMap) {
            if (stopWords.contains(alias)) continue
            val regex = Regex("\\b${Regex.escape(alias)}\\b", RegexOption.IGNORE_CASE)
            if (regex.containsMatchIn(promptNorm)) {
                val dados = grafoConceitual[raiz]
                if (dados != null && !conceitosIdentificados.contains(raiz)) {
                    conceitosIdentificados.add(raiz)
                    nosAtivados.add(raiz)
                    respostasPartes.add(dados.resposta)
                    frequenciaTotal += dados.hz
                }
            }
        }

        // Pesquisa explícita na internet ("pesquise na internet sobre X", "busque na web X", "procure online sobre X")
        val matchPesquisaWeb = Regex("(?:pesquise|busque|procure|pesquisar|buscar)\\s+(?:na\\s+internet|na\\s+web|online|no\\s+google)?\\s*(?:sobre|por)?\\s*(.+)", RegexOption.IGNORE_CASE).find(promptOriginal)
        if (matchPesquisaWeb != null) {
            val termoBusca = matchPesquisaWeb.groupValues[1].trim().replace("?", "").replace("!", "").trim()
            if (termoBusca.length > 2) {
                val resumoWeb = agenteBuscaWebAutonomo(termoBusca)
                if (resumoWeb != null) {
                    val hz = sintetizarFrequencia(resumoWeb)
                    grafoConceitual[termoBusca.lowercase(Locale.ROOT)] = ConceitoHarmonico(
                        hz = hz,
                        conexoes = listOf("agente_web_autonomo", "pesquisa_online", "persistido_offline"),
                        resposta = resumoWeb
                    )
                    nosAtivados.add(termoBusca)
                    respostasPartes.add(
                        "🌐 <strong>[AGENTE DE PESQUISA WEB: CONHECIMENTO CAPTURADO ONLINE]</strong><br><br>" +
                        "<strong>Termo Pesquisado:</strong> <code>${termoBusca.uppercase()}</code> ($hz Hz)<br>" +
                        "<strong>Síntese Recuperada:</strong> $resumoWeb<br><br>" +
                        "💾 <em>Status: Conhecimento indexado e gravado no armazenamento local para acesso permanente offline.</em>"
                    )
                    frequenciaTotal += hz
                }
            }
        }

        // Padrão de Ensino / Absorção Direta ("Grave esse conhecimento: X")
        val matchEnsino = Regex("(?:grave\\s+(?:esse\\s+)?conhecimento|aprenda\\s+que|memorize|grave)\\s*:\\s*(.+)", RegexOption.IGNORE_CASE).find(promptOriginal)
        if (matchEnsino != null) {
            val fraseAprendida = matchEnsino.groupValues[1].trim()
            if (fraseAprendida.length > 5) {
                var termoChave = "conhecimento_absorvido"
                val palavrasChave = normalizarTexto(fraseAprendida).split(Regex("[\\s,;:.?!]+")).filter { it.length > 3 && !stopWords.contains(it) }
                if (palavrasChave.isNotEmpty()) {
                    termoChave = palavrasChave[0]
                }
                val hz = sintetizarFrequencia(fraseAprendida)
                grafoConceitual[termoChave] = ConceitoHarmonico(
                    hz = hz,
                    conexoes = listOf("aprendizado_continuo", "memoria_dinamica"),
                    resposta = fraseAprendida
                )
                nosAtivados.add(termoChave)
                respostasPartes.add("[CONHECIMENTO ABSORVIDO COM SUCESSO]<br><br>O padrão vibracional '<em>${termoChave.uppercase()}</em>' ($hz Hz) foi integrado e compactado na malha conceitual: \"$fraseAprendida\"")
                frequenciaTotal += hz
            }
        }

        if (nosAtivados.isEmpty()) {
            val candidatosBusca = mutableListOf<String>()
            val promptLimpo = promptNorm.replace(Regex("^(?:o\\s+que\\s+e|o\\s+que\\s+e\\s+o|o\\s+que\\s+e\\s+a|o\\s+que\\s+significa|quem\\s+foi|quem\\s+e|qual\\s+a\\s+definicao\\s+de|pesquise\\s+sobre|busque\\s+sobre|explique\\s+sobre|explique)\\s+", RegexOption.IGNORE_CASE), "").trim()
            if (promptLimpo.length > 2 && !stopWords.contains(promptLimpo)) {
                candidatosBusca.add(promptLimpo)
            }
            val palavras = promptNorm.split(Regex("[\\s,;:.?!]+")).filter { it.length > 3 && !stopWords.contains(it) }
            for (p in palavras) {
                if (!candidatosBusca.contains(p)) candidatosBusca.add(p)
            }

            for (candidato in candidatosBusca) {
                // 1. Busca no cache/disco local
                val conteudoLocal = varrerArquivoLocal(candidato)
                if (conteudoLocal != null) {
                    val hz = sintetizarFrequencia(conteudoLocal)
                    grafoConceitual[candidato] = ConceitoHarmonico(
                        hz = hz,
                        conexoes = listOf("conhecimento_local", "absorcao_permanente"),
                        resposta = conteudoLocal
                    )
                    nosAtivados.add(candidato)
                    respostasPartes.add("[CONHECIMENTO LOCAL RECUPERADO: ${candidato.uppercase()}]<br><br>$conteudoLocal")
                    frequenciaTotal += hz
                    break
                }

                // 2. Agente Autônomo de Pesquisa Web
                val resumoWeb = agenteBuscaWebAutonomo(candidato)
                if (resumoWeb != null) {
                    val hz = sintetizarFrequencia(resumoWeb)
                    grafoConceitual[candidato] = ConceitoHarmonico(
                        hz = hz,
                        conexoes = listOf("agente_web_autonomo", "pesquisa_online", "persistido_offline"),
                        resposta = resumoWeb
                    )
                    nosAtivados.add(candidato)
                    respostasPartes.add(
                        "🌐 <strong>[AGENTE DE PESQUISA WEB: CONHECIMENTO ADQUIRIDO]</strong><br><br>" +
                        "<strong>Conceito Mapeado:</strong> <code>${candidato.uppercase()}</code> ($hz Hz)<br>" +
                        "<strong>Síntese Capturada:</strong> $resumoWeb<br><br>" +
                        "💾 <em>Status: Dados indexados e salvos permanentemente no disco local para futuras consultas 100% offline.</em>"
                    )
                    frequenciaTotal += hz
                    break
                }
            }
        }

        if (nosAtivados.isEmpty()) {
            context.customResponse = "Entendi o seu foco. O sinal vibracional ecoou pelo vácuo quântico, mas este assunto ainda não possui uma assinatura disponível nas redes internas ou externas."
            context.finalState = "10 (Diálogo Colapsado)"
            context.totalFrequencyHz = 0.0
            context.metadata["active_concepts"] = emptyList<String>()
            return context
        }

        var respostaFinal = if (nosAtivados.size == 1) {
            "[Foco Ativo: ${nosAtivados[0].uppercase()}]<br><br>${respostasPartes[0]}"
        } else {
            val header = "[Foco Ativo: ${nosAtivados.joinToString(", ") { it.uppercase() }}]<br><br>"
            val corpo = respostasPartes.joinToString(" ")
            val sintese = " Percebo que sua mente interligou os conceitos de ${nosAtivados.joinToString(" e ")} em um único emaranhamento."
            header + corpo + sintese
        }

        context.customResponse = respostaFinal
        context.finalState = "10 (Diálogo Colapsado)"
        context.totalFrequencyHz = frequenciaTotal
        context.chain.clear()
        context.chain.addAll(nosAtivados)
        context.metadata["active_concepts"] = nosAtivados.toList()

        return context
    }
}
