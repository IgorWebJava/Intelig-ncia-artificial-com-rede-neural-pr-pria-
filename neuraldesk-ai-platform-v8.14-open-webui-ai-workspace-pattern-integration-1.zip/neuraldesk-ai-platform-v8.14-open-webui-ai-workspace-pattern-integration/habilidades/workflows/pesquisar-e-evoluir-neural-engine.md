<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Workflow — Pesquisar e Evoluir o Neural Engine

1. Define the capability/problem, not a favorite library.
2. Search primary repositories/papers.
3. Record candidates in `neural-engine/research/`.
4. Map candidate patterns to an owning future module.
5. Define reference baseline and benchmark matrix.
6. Review license/supply chain.
7. Update architecture/capabilities/contracts documentation.
8. Do not implement code while blueprint status is documentation-only.
9. When implementation is authorized, use research-to-production gates.
