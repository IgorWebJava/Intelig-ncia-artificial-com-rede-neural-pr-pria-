<!-- neuraldesk-documentation-sync: V8.8 -->

# Module Preview — System Audit, Trace & Control Center

Canonical preview:

```text
modules/audit/preview/page-preview.png
```

Source UI:

```text
modules/audit/ui/audit-center.html
```

Standard capture profile:

```text
module-preview-v1
1600x1000
viewport capture
```

Regenerate after any meaningful visual UI change.

Command:

```text
python tools/generate_module_previews.py --module audit
```
