#include "nd_assistant.h"

#include <stdio.h>
#include <string.h>

typedef struct {
    unsigned calls;
    unsigned stop_at;
} StopState;

static int should_stop(void *user_data) {
    StopState *state = (StopState *)user_data;
    state->calls++;
    return state->stop_at != 0u && state->calls >= state->stop_at;
}

static int collect_chunk(const char *chunk, size_t bytes, void *user_data) {
    size_t *total = (size_t *)user_data;
    if (!chunk || bytes == 0u) return 1;
    *total += bytes;
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 5) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION\n", argv[0]);
        return 2;
    }

    NDAssistant assistant;
    NDAnswerMeta meta;
    char err[256];
    char out[32768];
    if (nd_assistant_load(&assistant, argv[1], argv[2], argv[3], argv[4], err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }

    StopState stopped = {0u, 1u};
    NDExecutionControl cancel = {should_stop, &stopped};
    int rc = nd_assistant_answer_controlled(&assistant,
                                             "Qual é a capital do Brasil?",
                                             NULL,
                                             1,
                                             &cancel,
                                             out,
                                             sizeof(out),
                                             &meta,
                                             err,
                                             sizeof(err));
    if (rc == 0 || strstr(err, "cancelled or deadline exceeded") == NULL || stopped.calls == 0u) {
        fprintf(stderr, "controlled cancellation failed rc=%d calls=%u err=%s\n", rc, stopped.calls, err);
        nd_assistant_free(&assistant);
        return 1;
    }

    StopState running = {0u, 0u};
    NDExecutionControl allow = {should_stop, &running};
    memset(err, 0, sizeof(err));
    rc = nd_assistant_answer_controlled(&assistant,
                                        "Qual é a capital do Brasil?",
                                        NULL,
                                        1,
                                        &allow,
                                        out,
                                        sizeof(out),
                                        &meta,
                                        err,
                                        sizeof(err));
    if (rc != 0 || strstr(out, "Brasília") == NULL || running.calls < 2u) {
        fprintf(stderr, "controlled success failed rc=%d calls=%u out=%s err=%s\n",
                rc, running.calls, out, err);
        nd_assistant_free(&assistant);
        return 1;
    }

    size_t streamed = 0u;
    running.calls = 0u;
    memset(err, 0, sizeof(err));
    rc = nd_assistant_answer_stream_controlled(&assistant,
                                               "Quanto é 17 vezes 23?",
                                               NULL,
                                               1,
                                               &allow,
                                               collect_chunk,
                                               &streamed,
                                               out,
                                               sizeof(out),
                                               &meta,
                                               err,
                                               sizeof(err));
    if (rc != 0 || streamed == 0u || strstr(out, "391") == NULL) {
        fprintf(stderr, "controlled stream failed rc=%d streamed=%zu out=%s err=%s\n",
                rc, streamed, out, err);
        nd_assistant_free(&assistant);
        return 1;
    }

    nd_assistant_free(&assistant);
    printf("EXECUTION_CONTROL PASS cancel_checkpoints=%u success_checkpoints=%u streamed_bytes=%zu\n",
           stopped.calls, running.calls, streamed);
    return 0;
}
