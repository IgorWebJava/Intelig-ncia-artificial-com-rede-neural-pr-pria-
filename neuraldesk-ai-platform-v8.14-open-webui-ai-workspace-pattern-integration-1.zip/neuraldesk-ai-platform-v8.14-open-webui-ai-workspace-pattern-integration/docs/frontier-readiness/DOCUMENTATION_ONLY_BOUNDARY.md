<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Documentation-Only Boundary

V8.7 is a planning/documentation release.

Allowed:
- Markdown;
- JSON/YAML registries and schemas used as documentation;
- diagrams in text;
- acceptance criteria;
- roadmaps;
- updated memory/handoffs.

Not introduced by V8.7:
- executable source files;
- backend routes;
- DB migrations;
- browser logic;
- model code;
- inference code;
- training code.

Existing project code from prior releases is preserved byte-for-byte where canonical implementation applies.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
