<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Documentation Governance — V7.1

## Module-specific documentation

Must live in:

```text
modules/<module>/docs/
```

Every module must contain at least:

- `README.md`
- `DOCUMENTATION_INDEX.md`
- `MODULE_ARCHITECTURE.md`
- `CONTRACTS_AND_CAPABILITIES.md`
- `DATA_OWNERSHIP_AND_CONSISTENCY.md`
- `INTEGRATION_AND_REPLACEMENT.md`
- `MULTIMODAL_AI_INTEGRATION.md`

## Global documentation

Cross-module concerns belong in:

```text
docs/architecture/
docs/governance/
docs/history/
docs/verification/
```

## Memory

Project continuity belongs in:

```text
memória/
```

## Version rule

A structural release is not complete until:

1. manifests/contracts are updated;
2. module documentation is updated;
3. global architecture is updated if needed;
4. memory/state/history/version map are updated;
5. validation reports pass.
