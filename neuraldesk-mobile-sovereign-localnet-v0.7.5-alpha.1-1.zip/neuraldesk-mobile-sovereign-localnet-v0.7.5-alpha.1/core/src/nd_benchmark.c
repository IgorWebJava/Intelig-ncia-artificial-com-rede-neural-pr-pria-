#include "nd_benchmark.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

static int cmp_double(const void *a, const void *b) {
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

static double percentile(double *values, size_t n, unsigned p) {
    if (!n) return 0.0;
    qsort(values, n, sizeof(values[0]), cmp_double);
    size_t idx = ((n * (size_t)p) + 99u) / 100u;
    if (idx == 0u) idx = 1u;
    if (idx > n) idx = n;
    return values[idx - 1u];
}

void nd_benchmark_init(NDBenchmark *b) {
    if (b) memset(b, 0, sizeof(*b));
}

int nd_benchmark_add(NDBenchmark *b, const NDBenchmarkSample *s) {
    if (!b || !s || b->count >= ND_BENCHMARK_MAX_SAMPLES || s->profile < ND_PROFILE_MICRO ||
        s->profile > ND_PROFILE_MOBILE_PLUS || s->status < ND_BENCHMARK_COMPLETED ||
        s->status > ND_BENCHMARK_ABANDONED || !isfinite(s->latency_ms) || !isfinite(s->ttft_ms) ||
        !isfinite(s->tokens_per_second) || s->latency_ms < 0.0 || s->ttft_ms < 0.0 || s->tokens_per_second < 0.0) return -1;
    b->samples[b->count++] = *s;
    return 0;
}

NDBenchmarkScorecard nd_benchmark_default_scorecard(void) {
    NDBenchmarkScorecard s;
    s.min_samples = 3u;
    s.max_p95_latency_ms = 30000.0;
    s.max_p95_ttft_ms = 8000.0;
    s.min_p50_tokens_per_second = 1.0;
    s.min_success_rate = 0.8;
    return s;
}

int nd_benchmark_evaluate(const NDBenchmark *b, NDMobileProfile profile,
                          const NDBenchmarkScorecard *scorecard, NDBenchmarkReport *r) {
    if (!b || !scorecard || !r) return -1;
    memset(r, 0, sizeof(*r));
    double lat[ND_BENCHMARK_MAX_SAMPLES], ttft[ND_BENCHMARK_MAX_SAMPLES], tps[ND_BENCHMARK_MAX_SAMPLES];
    size_t n = 0u;
    for (size_t i = 0u; i < b->count; i++) {
        const NDBenchmarkSample *s = &b->samples[i];
        if (s->profile != profile) continue;
        r->total++;
        if (s->status == ND_BENCHMARK_COMPLETED) {
            r->completed++;
            lat[n] = s->latency_ms;
            ttft[n] = s->ttft_ms;
            tps[n] = s->tokens_per_second;
            n++;
        } else if (s->status == ND_BENCHMARK_FAILED) r->failed++;
        else if (s->status == ND_BENCHMARK_INTERRUPTED) r->interrupted++;
        else r->abandoned++;
    }
    r->success_rate = r->total ? (double)r->completed / (double)r->total : 0.0;
    double a[ND_BENCHMARK_MAX_SAMPLES], c[ND_BENCHMARK_MAX_SAMPLES];
    memcpy(a, lat, n * sizeof(double)); r->latency_p50_ms = percentile(a, n, 50u);
    memcpy(a, lat, n * sizeof(double)); r->latency_p95_ms = percentile(a, n, 95u);
    memcpy(a, lat, n * sizeof(double)); r->latency_p99_ms = percentile(a, n, 99u);
    memcpy(a, ttft, n * sizeof(double)); r->ttft_p95_ms = percentile(a, n, 95u);
    memcpy(c, tps, n * sizeof(double)); r->tokens_per_second_p50 = percentile(c, n, 50u);
    r->enough_samples = r->completed >= scorecard->min_samples;
    r->within_thresholds = r->enough_samples && r->success_rate >= scorecard->min_success_rate &&
        r->latency_p95_ms <= scorecard->max_p95_latency_ms && r->ttft_p95_ms <= scorecard->max_p95_ttft_ms &&
        r->tokens_per_second_p50 >= scorecard->min_p50_tokens_per_second;
    r->certification = "MEASURED_NOT_CERTIFIED";
    return 0;
}
