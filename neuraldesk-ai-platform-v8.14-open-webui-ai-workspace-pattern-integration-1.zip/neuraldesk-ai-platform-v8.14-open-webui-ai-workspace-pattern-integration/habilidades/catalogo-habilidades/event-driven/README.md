<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Transactional Outbox & Event-Driven Consistency

    Skill ID: `neuraldesk.event-driven.v1`

    ## Category

    `data-eventing`

    ## Introduced

    `V6.9`

    ## Required development capabilities

    - `eventing.outbox.design.v1`
- `asyncapi.author.v1`
- `observability.design.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `platform/eventing/`
- `contracts/events/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
