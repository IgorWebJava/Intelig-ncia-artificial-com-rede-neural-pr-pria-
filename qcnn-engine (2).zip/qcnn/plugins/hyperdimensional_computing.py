import math
from typing import List, Dict, Tuple
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS

class HyperdimensionalComputingPlugin(BaseQcnnPlugin):
    """
    Plugin de Computação Hiperdimensional (Hyperdimensional Computing - HDC) v5.0.
    Opera em vetores hiperdimensionais bipolares {-1, +1}^D com D=10.000 bits.
    Permite raciocínio simbólico instantâneo por Binding (⊗), Bundling (⊕),
    Permutação Cíclica (Π) e Similaridade de Cosseno em nanossegundos.
    """
    def __init__(self, dimension: int = 10000):
        super().__init__()
        self.dimension = dimension
        self.item_memory: Dict[str, List[int]] = {}
        for letra, info in MATRIZ_22_LETRAS.items():
            self.item_memory[letra] = self._generate_hypervector(letra, info["gematria"])

    @property
    def plugin_id(self) -> str:
        return "hyperdimensional_computing"

    def _generate_hypervector(self, symbol: str, seed_mod: int) -> List[int]:
        """Gera um hipervetor determinístico pseudo-aleatório balanceado e esparso."""
        vec = [0] * self.dimension
        seed = 0
        for idx, char in enumerate(symbol):
            seed = (seed * 31 + ord(char) * (idx + 1) + seed_mod * 1337) & 0xFFFFFFFFFFFFFFFF
        for i in range(self.dimension):
            seed = (seed * 6364136223846793005 + 1442695040888963407) & 0xFFFFFFFFFFFFFFFF
            vec[i] = 1 if ((seed >> 32) & 1) == 1 else -1
        return vec

    def get_or_create_vector(self, symbol: str) -> List[int]:
        """Obtém ou projeta hipervetor para qualquer símbolo ou conceito."""
        if symbol not in self.item_memory:
            self.item_memory[symbol] = self._generate_hypervector(symbol, len(symbol))
        return self.item_memory[symbol]

    def bind(self, v1: List[int], v2: List[int]) -> List[int]:
        """Operação de Binding (⊗): Multiplicação element-wise (XOR lógico bipolar)."""
        return [v1[i] * v2[i] for i in range(self.dimension)]

    def bundle(self, vectors: List[List[int]]) -> List[int]:
        """Operação de Bundling (⊕): Superposição por votação majoritária."""
        if not vectors:
            return [0] * self.dimension
        sums = [0] * self.dimension
        for v in vectors:
            for i in range(self.dimension):
                sums[i] += v[i]
        return [1 if sums[i] >= 0 else -1 for i in range(self.dimension)]

    def permute(self, v: List[int], shift: int = 1) -> List[int]:
        """Operação de Permutação Cíclica (Π): Shift circular preservando a ordem sintática."""
        s = ((shift % self.dimension) + self.dimension) % self.dimension
        return v[-s:] + v[:-s] if s != 0 else list(v)

    def similarity(self, v1: List[int], v2: List[int]) -> float:
        """Medição de similaridade de cosseno (produto escalar normalizado)."""
        dot = sum(v1[i] * v2[i] for i in range(self.dimension))
        return dot / float(self.dimension)

    def hamming_distance(self, v1: List[int], v2: List[int]) -> int:
        """Distância de Hamming para vetores bipolares (número de bits discordantes)."""
        return sum(1 for i in range(self.dimension) if v1[i] != v2[i])

    def analogical_reasoning(self, a: str, b: str, c: str) -> Tuple[str, float]:
        """
        Raciocínio Analógico Hiperdimensional: 'A está para B assim como C está para ?'
        Equação Vetorial: D* = C ⊗ (B ⊗ A)
        """
        vA = self.get_or_create_vector(a)
        vB = self.get_or_create_vector(b)
        vC = self.get_or_create_vector(c)

        # Relação = B ⊗ A
        relation = self.bind(vB, vA)
        # Alvo estimado = C ⊗ relation
        target_vec = self.bind(vC, relation)

        # Busca o símbolo mais próximo na memória de itens
        best_symbol = ""
        best_sim = -2.0
        for sym, vec in self.item_memory.items():
            if sym in (a, b, c):
                continue
            sim = self.similarity(target_vec, vec)
            if sim > best_sim:
                best_sim = sim
                best_symbol = sym

        return (best_symbol or c, round(best_sim, 3))

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        target = context.target_seed
        base_vec = self.get_or_create_vector(target)

        chain_vecs = [base_vec]
        for idx, node in enumerate(context.chain):
            vec = self.get_or_create_vector(node)
            permuted = self.permute(vec, idx + 1)
            chain_vecs.append(permuted)

        composite = self.bundle(chain_vecs)
        score = round(self.similarity(composite, base_vec), 3)

        context.metadata["hdc_dimension"] = self.dimension
        context.metadata["hdc_resonance_score"] = score
        context.metadata["hdc_dominant_symbol"] = target
        return context

