<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Versioning, Validation & Packaging

    Skill ID: `neuraldesk.release-engineering.v1`

    ## Category

    `release`

    ## Introduced

    `V6.7`

    ## Required development capabilities

    - `release.versioning.v1`
- `release.gates.execute.v1`
- `release.package.v1`
- `documentation.sync.v1`
- `project.memory.update.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `docs/history/`
- `docs/verification/`
- `tools/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
