#include "nd_planner.h"

#include <stdio.h>
#include <string.h>

int main(void) {
    char err[256];
    NDPlan p;
    int bad = 0;

    if (nd_plan_build("Qual é a capital do Brasil?", &p, err, sizeof(err)) || p.goal_count != 1u) bad++;
    if (nd_plan_build("Quanto é 17 vezes 23 e qual é a capital do Brasil?", &p, err, sizeof(err)) ||
        p.goal_count != 2u || strstr(p.goals[0].text, "17") == NULL || strstr(p.goals[1].text, "capital") == NULL) bad++;
    if (nd_plan_build("Qual é o código do projeto Atlas-77 e quem é responsável?", &p, err, sizeof(err)) ||
        p.goal_count != 2u || strstr(p.goals[1].text, "Atlas-77") == NULL) bad++;
    if (nd_plan_build("Qual é a versão do Atlas; quem é responsável; onde fica?", &p, err, sizeof(err)) ||
        p.goal_count != 3u) bad++;
    if (nd_plan_build("Explique KV cache e atenção causal.", &p, err, sizeof(err)) || p.goal_count != 1u) bad++;
    if (nd_plan_build("Para estimar fluxos ar-mar de calor sensíveis e latentes, qual método é utilizado?",
                      &p, err, sizeof(err)) ||
        p.goal_count != 1u || strstr(p.goals[0].text, "calor sensíveis e latentes") == NULL ||
        strstr(p.goals[0].text, "qual método") == NULL) bad++;
    if (nd_plan_build("Sobre o projeto Atlas-77, qual é o código e quem é responsável?",
                      &p, err, sizeof(err)) ||
        p.goal_count != 2u || strstr(p.goals[0].text, "Atlas-77") == NULL ||
        strstr(p.goals[1].text, "Atlas-77") == NULL) bad++;
    if (nd_plan_build("Nas fases 1 e 2 do Parque das Conchas, quais campos de petróleo aparecem?",
                      &p, err, sizeof(err)) ||
        p.goal_count != 1u || strstr(p.goals[0].text, "Parque das Conchas") == NULL ||
        strstr(p.goals[0].text, "quais campos") == NULL) bad++;
    if (nd_plan_build("Se eu usar quantização e KV cache na inferência, o que cada técnica tende a economizar?",
                      &p, err, sizeof(err)) ||
        p.goal_count != 2u || strstr(p.goals[0].text, "quantização") == NULL ||
        strstr(p.goals[0].text, "KV cache") != NULL ||
        strstr(p.goals[1].text, "KV cache") == NULL ||
        strstr(p.goals[1].text, "quantização") != NULL) bad++;
    if (nd_plan_build("Com base apenas neste contexto, qual é a versão e o responsável do Atlas-77?",
                      &p, err, sizeof(err)) ||
        p.goal_count != 2u || strstr(p.goals[0].text, "Atlas-77") == NULL ||
        strstr(p.goals[1].text, "Atlas-77") == NULL ||
        strstr(p.goals[0].text, "versão") == NULL ||
        strstr(p.goals[1].text, "responsável") == NULL) bad++;

    if (bad) {
        fprintf(stderr, "planner failures=%d\n", bad);
        return 1;
    }
    puts("planner PASS");
    return 0;
}
