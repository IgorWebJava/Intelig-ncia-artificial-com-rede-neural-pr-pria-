<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 47 — Arquitetura CSS por Página

## Decisão

Cada página HTML é acompanhada por um CSS exclusivo e autossuficiente.

```text
index.html              → css/index.css
chat.html               → css/chat.css
dashboard-center.html   → css/dashboard-center.css
training.html           → css/training.css
knowledge-center.html   → css/knowledge-center.css
tools-center.html       → css/tools-center.css
settings.html           → css/settings.css
```

## Objetivo

Permitir que qualquer página seja:

- copiada;
- incorporada;
- servida;
- convertida em componente;
- usada como referência visual;

sem depender de outro HTML ou CSS do projeto.

## Trade-off

A arquitetura aumenta duplicação de estilos, mas reduz acoplamento.

Esse trade-off foi aceito porque o template será incorporado posteriormente a um sistema real.

## Regra

Um HTML não deve importar:

- CSS global;
- CSS de outra página;
- CSS compartilhado;
- cadeia de `@import`.

Cada página deve carregar um único stylesheet dedicado.
