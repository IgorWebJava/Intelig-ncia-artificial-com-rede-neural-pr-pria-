# Phase Exit Checklist

Before advancing a phase:
- [ ] all phase requirements have owners;
- [ ] public contracts are versioned;
- [ ] data ownership is defined;
- [ ] threat model exists;
- [ ] failure/degraded modes exist;
- [ ] observability requirements exist;
- [ ] tests and acceptance criteria exist;
- [ ] benchmark baseline exists;
- [ ] cost model exists;
- [ ] rollback/fallback exists;
- [ ] dependent UI states are truthful;
- [ ] documentation/memory/handoff are synchronized.
