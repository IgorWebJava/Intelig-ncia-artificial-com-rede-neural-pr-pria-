<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 49 — Advanced AI Chat Workspace 2026

## Objetivo

A página `modules/chat/ui/chat.html` evolui de um chat tradicional para um **AI Workspace** preparado para sistemas modernos com:

- projects;
- multimodal inputs;
- RAG;
- web;
- tools;
- agents;
- human approval;
- research;
- citations;
- artifacts;
- context inspector;
- memory;
- multiple model classes.

## Layout

```text
Sidebar
   │
   ├── New Chat
   ├── Search
   ├── Projects
   ├── Recent
   └── Pinned

Chat Workspace
   │
   ├── Header
   ├── Model / Mode / Sources
   ├── Messages
   ├── Agent Activity
   ├── Tool Calls
   ├── Research
   ├── Approvals
   ├── Artifacts
   └── Composer

Context Panel
   │
   ├── Context Sources
   ├── Context Usage
   ├── Top Sources
   ├── Agent Status
   ├── Tools
   └── Outputs
```

## Regra

Todo comportamento é representacional. O template não executa IA, tools, web, research, approval ou upload.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
