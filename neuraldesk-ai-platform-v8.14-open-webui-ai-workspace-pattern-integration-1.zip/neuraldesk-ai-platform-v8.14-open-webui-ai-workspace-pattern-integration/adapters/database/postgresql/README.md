<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.database.postgresql

    Replaceable adapter template.

    Provides:
    - `data.relational.v1`
- `data.transaction.v1`
- `data.outbox.v1`

    Domain modules must never import this adapter implementation directly.
    Binding occurs through the corresponding platform gateway/registry.
