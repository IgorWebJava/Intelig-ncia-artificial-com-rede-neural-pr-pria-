<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 81 — Audit Center Acceptance Criteria

- [x] Independent `modules/audit/ui/audit-center.html`.
- [x] Dedicated `modules/audit/ui/audit-center.css`.
- [x] HTML + CSS only.
- [x] 0 JavaScript.
- [x] Overview.
- [x] Live Events.
- [x] Audit Explorer.
- [x] Event Inspector.
- [x] Trace Explorer.
- [x] User Audit.
- [x] Agent Audit.
- [x] Services Audit.
- [x] Page namespaces.
- [x] Knowledge Audit.
- [x] Tool & MCP Audit.
- [x] Model Audit.
- [x] Training Audit.
- [x] Security Audit.
- [x] Approval Audit.
- [x] System Change Audit.
- [x] Deployments.
- [x] Incidents.
- [x] Read-only Audit Console.
- [x] Admin Control model.
- [x] Integrity.
- [x] Retention.
- [x] Audit Settings.
- [x] Responsive layout.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
