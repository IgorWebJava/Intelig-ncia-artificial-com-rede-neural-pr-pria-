#include "nd_context_qa.h"
#include "nd_context_synth.h"
#include "nd_relation.h"

#include <stdio.h>
#include <string.h>

typedef struct {
    const char *question;
    const char *context;
    const char *expected;
} Case;

static const Case CASES[] = {
    {"Qual é o código do protótipo?", "O protótipo experimental possui o código ZX-731.", "ZX-731"},
    {"Qual é a cor da unidade Aurora?", "A unidade Aurora está marcada com a cor turquesa.", "turquesa"},
    {"Quem é o responsável pelo projeto Atlas?", "O responsável registrado pelo projeto Atlas é Marina.", "Marina"},
    {"Quem é responsável pelo projeto Atlas-77?", "Marina é responsável pelo projeto Atlas-77.", "Marina"},
    {"Qual é a porta do serviço?", "O serviço de teste usa a porta 8443.", "8443"},
    {"Qual é a licença do componente?", "O componente é distribuído sob a licença Apache-2.0.", "Apache-2.0"},
    {"Qual é a latência observada?", "A latência observada foi 17 milissegundos.", "17 milissegundos"},
    {"Qual protocolo está ativo?", "O protocolo ativo no enlace é HTTP/3.", "HTTP/3"},
    {"Quem fabricou a unidade?", "A unidade foi fabricada pela Vector Forge.", "Vector Forge"},
    {"Qual a prioridade da tarefa?", "A tarefa está marcada com prioridade crítica.", "crítica"},
    {"Em qual região está a implantação?", "A implantação está localizada na região eu-west-3.", "eu-west-3"},
    {"Qual é o checksum do pacote?", "O checksum do pacote é a1b2c3d4e5f6.", "a1b2c3d4e5f6"},
};

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "usage: %s CONTEXT_QA RELATION\n", argv[0]);
        return 2;
    }
    NDContextQA qa;
    NDRelationClassifier relation;
    char err[256];
    if (nd_context_qa_load(argv[1], &qa, err, sizeof(err))) {
        fprintf(stderr, "qa: %s\n", err);
        return 1;
    }
    if (nd_relation_load(argv[2], &relation, err, sizeof(err))) {
        fprintf(stderr, "relation: %s\n", err);
        nd_context_qa_free(&qa);
        return 1;
    }

    int bad = 0;
    size_t rejected = 0u;
    for (size_t i = 0; i < sizeof(CASES) / sizeof(CASES[0]); i++) {
        char out[8192];
        NDContextSynthesisResult r;
        if (nd_context_synthesize_ex(&qa, &relation, CASES[i].question, CASES[i].context,
                                     1, out, sizeof(out), &r, err, sizeof(err))) {
            fprintf(stderr, "case %zu error: %s\n", i, err);
            bad++;
            continue;
        }
        if (!r.found || !strstr(out, CASES[i].expected)) {
            fprintf(stderr, "case %zu missing [%s] in [%s]\n", i, CASES[i].expected, out);
            bad++;
        }
        if (r.pointer_rejected) rejected++;
    }
    nd_relation_free(&relation);
    nd_context_qa_free(&qa);
    if (bad) return 1;
    printf("candidate-acceptance PASS %zu/%zu fallback_rejections=%zu\n",
           sizeof(CASES) / sizeof(CASES[0]), sizeof(CASES) / sizeof(CASES[0]), rejected);
    return 0;
}
