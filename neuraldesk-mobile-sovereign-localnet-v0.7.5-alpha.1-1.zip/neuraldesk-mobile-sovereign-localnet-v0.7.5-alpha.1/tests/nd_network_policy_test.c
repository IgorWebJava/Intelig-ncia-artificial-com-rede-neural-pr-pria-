#include "nd_network_policy.h"
#include <stdio.h>

int main(void) {
    NDNetworkSnapshot off = nd_network_snapshot(0, 0, 0u);
    NDNetworkSnapshot slow = nd_network_snapshot(1, 0, 256u);
    NDNetworkSnapshot saver = nd_network_snapshot(1, 1, 5000u);
    NDNetworkSnapshot normal = nd_network_snapshot(1, 0, 5000u);
    int fail = 0;
    fail += off.state != ND_NETWORK_OFFLINE;
    fail += slow.state != ND_NETWORK_CONSTRAINED;
    fail += saver.state != ND_NETWORK_CONSTRAINED;
    fail += normal.state != ND_NETWORK_NORMAL;
    fail += nd_network_allows(&off, ND_NETWORK_OP_WEB_CONTEXT, 1) != 0;
    fail += nd_network_allows(&slow, ND_NETWORK_OP_WEB_CONTEXT, 0) != 0;
    fail += nd_network_allows(&slow, ND_NETWORK_OP_WEB_CONTEXT, 1) != 1;
    fail += nd_network_allows(&normal, ND_NETWORK_OP_DURABLE_TASK_RETRY, 0) != 1;
    printf("NETWORK_POLICY %s state=%s\n", fail ? "FAIL" : "PASS", nd_network_state_name(normal.state));
    return fail ? 1 : 0;
}
