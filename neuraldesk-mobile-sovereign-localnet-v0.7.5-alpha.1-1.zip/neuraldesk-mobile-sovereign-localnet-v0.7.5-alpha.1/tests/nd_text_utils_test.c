#include "nd_text_utils.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    const char *text = "O KV cache evita recomputar estados anteriores durante a geração. A quantização reduz o tamanho dos pesos e o custo de memória. O sistema usa memória estruturada para fatos explícitos. O armazenamento local preserva privacidade.";
    char out[1024];
    int n = nd_text_summary_extractive(text, 2u, out, sizeof(out));
    if (n != 2) return 1;
    if (!strstr(out, ".")) return 1;
    char kw[256];
    int k = nd_text_keywords(text, 5u, kw, sizeof(kw));
    if (k != 5 || !kw[0]) return 1;
    printf("TEXT_UTILS PASS summary_sentences=%d keywords=%d\n", n, k);
    return 0;
}
