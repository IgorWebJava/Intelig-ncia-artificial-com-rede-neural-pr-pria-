<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: habilidades -->
# AutoGPT Agent Platform Research Integration

Integrate architecture research from modern agent platforms into NeuralDesk without copying upstream code or weakening existing contracts.

## Required practices
- distinguish current platform from legacy/unsupported branches
- inspect license/security advisories
- extract provider-agnostic patterns
- preserve → extend → bridge
- create engine modules/capabilities, UI readiness, tests and provenance
- benchmark claims before promotion
