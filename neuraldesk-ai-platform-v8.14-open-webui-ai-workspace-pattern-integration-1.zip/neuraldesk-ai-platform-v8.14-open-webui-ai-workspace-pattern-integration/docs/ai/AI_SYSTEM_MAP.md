<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.ai-handoff; current: docs/ai/AI_SYSTEM_MAP.md -->
# AI System Map

```text
Workspace Home
├── Chat / Adaptive Workspace / Artifacts
├── Agent Design Studio
├── Knowledge Library + Labs
├── Tools Marketplace + Testbench
├── Training Experiment Lab
└── User Settings

Control Plane
├── AI Operations
├── Audit Investigation Workspace
└── System Configuration / Change Planner

Shared Platform
├── Module / Capability / Contract Registries
├── Project Registry
├── Agent Skill Registry
├── Intelligence Design System
├── Experience Runtime contract
├── Adaptive UI / Preview / Quality
├── AI Capability Fabric
├── Media / Authorization / Secrets
└── Eventing / Observability / Data Platform
```

## V8.7 frontier readiness

Before planning executable Neural Engine work, read:
- `../frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
- `../frontier-readiness/EXECUTION_ROADMAP.md`
- `../../neural-engine/registry/frontier-readiness.json`

Treat `D0`, `UI0`, parity targets and differentiation targets as documentation states, never as implemented capabilities.



## V8.10 agent-harness research
Before implementing project/session/agent/tool runtime behavior, read `neural-engine/research/deepseek-harness-2026/README.md`, the 12 modules under `neural-engine/modules/11-agent-harness-runtime/`, and the semantic durability/session evolution strategies. Preserve the documentation-only boundary until an executable-engine release is explicitly authorized.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.


## Engine ↔ UI Bridge V8.11
Before changing interface or engine docs, inspect `platform/engine-ui-bridge/registry.json` and run both non-regression/compatibility gates. Do not mark engine states executable while `neural_engine_code_status` is `NOT_IMPLEMENTED`.


## V8.11 cooperative Engine/UI bridge

```text
CURRENT UI MODULES
       ↓
cooperative-engine-bridge-v1
       ↓
ENGINE/UI OWNERSHIP REGISTRY
       ↓
94 DOCUMENTATION-ONLY NEURAL ENGINE MODULES
```

The bridge is a contract/observability surface, not an executable engine.
