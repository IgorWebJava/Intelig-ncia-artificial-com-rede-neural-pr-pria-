package com.example.engine.core

import kotlin.math.ln

data class HolographicRecord(
    val concept: String,
    val frequency: Double,
    val state: String = "10 (Ativo)",
    val timestamp: Long = System.currentTimeMillis(),
    val metadata: Map<String, Any> = emptyMap(),
    val entropy: Double = 0.0
)

/**
 * Repositório de Memória Holográfica Independente por Módulo/Subagente no Android.
 * Princípio Hermético-Fractal: "O que está dentro é como o que está fora".
 */
class HolographicMemoryStore(
    val ownerId: String,
    val dimension: Int = 10000,
    val capacity: Int = 100
) {
    private val records = mutableListOf<HolographicRecord>()
    private val conceptIndex = mutableMapOf<String, HolographicRecord>()

    fun memorize(
        concept: String,
        frequency: Double,
        state: String = "10 (Ativo)",
        metadata: Map<String, Any> = emptyMap()
    ): HolographicRecord {
        val entropy = computeEntropy(concept)
        val record = HolographicRecord(
            concept = concept,
            frequency = frequency,
            state = state,
            timestamp = System.currentTimeMillis(),
            metadata = metadata,
            entropy = entropy
        )

        records.add(record)
        conceptIndex[concept.lowercase().trim()] = record

        if (records.size > capacity) {
            val oldest = records.removeAt(0)
            conceptIndex.remove(oldest.concept.lowercase().trim())
        }

        return record
    }

    fun recall(concept: String): HolographicRecord? {
        return conceptIndex[concept.lowercase().trim()]
    }

    fun calculateCoherence(): Double {
        if (records.isEmpty()) return 1.0
        val avgEntropy = records.map { it.entropy }.average()
        return (1.0 - (avgEntropy / 10.0)).coerceIn(0.0, 1.0)
    }

    fun count(): Int = records.size

    private fun computeEntropy(concept: String): Double {
        if (concept.isEmpty()) return 5.0
        val counts = mutableMapOf<Char, Int>()
        for (c in concept) {
            counts[c] = (counts[c] ?: 0) + 1
        }
        var entropy = 0.0
        val total = concept.length.toDouble()
        for (count in counts.values) {
            val p = count / total
            if (p > 0) {
                entropy -= p * (ln(p) / ln(2.0))
            }
        }
        return entropy
    }
}
