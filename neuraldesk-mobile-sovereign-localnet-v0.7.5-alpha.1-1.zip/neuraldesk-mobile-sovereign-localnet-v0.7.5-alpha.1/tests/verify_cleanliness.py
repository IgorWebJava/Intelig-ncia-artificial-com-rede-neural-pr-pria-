#!/usr/bin/env python3
from pathlib import Path
root=Path('.')
forbidden_dirs={'build','build-sanitize','build-werror','rejected','experiments','__pycache__','checkpoints','.pytest_cache'}
for p in root.rglob('*'):
    if p.is_dir() and p.name in forbidden_dirs:
        raise AssertionError(f'forbidden directory in release: {p}')
forbidden_files={
    'training/model.py','training/pipeline.py','training/train_knowledge_expert.py','training/knowledge_base_v03.py',
    'training/train_response_policy.py','training/response_policy_data.py','training/train_evidence_reranker.py',
    'core/src/nd_model.c','core/src/nd_runtime.c','core/src/nd_sampler.c','core/src/nd_chat.c',
    'core/include/nd_model.h','core/include/nd_runtime.h','core/include/nd_sampler.h','core/include/nd_chat.h',
    'models/neuraldesk-knowledge-v0.2.ndm','models/neuraldesk-v0.2.ndtok','models/neuraldesk-context-pointer-v0.2.ndqa',
    'models/neuraldesk-knowledge-v0.3.ndm','models/neuraldesk-v0.3.ndtok',
    'models/neuraldesk-context-pointer-v0.3.ndqa','models/neuraldesk-knowledge-retriever-v0.3.ndkr','models/neuraldesk-knowledge-v0.3.ndkb',
    'models/neuraldesk-context-pointer-v0.4.ndqa','models/neuraldesk-knowledge-retriever-v0.4.ndkr','models/neuraldesk-knowledge-v0.4.ndkb',
}
for rel in forbidden_files:
    if (root/rel).exists(): raise AssertionError(f'superseded artifact present: {rel}')

# The v0.7.4 tokenizer owner is new NDTK v1, not the superseded legacy .ndtok runtime.
tok_src=(root/'core/src/nd_tokenizer.c')
tok_hdr=(root/'core/include/nd_tokenizer.h')
assert tok_src.is_file() and tok_hdr.is_file(), 'canonical NDTK tokenizer owner missing'
assert 'NDTKV001' in tok_src.read_text(encoding='utf-8'), 'tokenizer format identity drift'
assert not any((root/'models').glob('*.ndtok')), 'legacy .ndtok runtime asset returned'

# Private release/signing keys are external-only. Public verification keys are allowed.
for p in root.rglob('*'):
    if not p.is_file():
        continue
    low=p.name.lower()
    if (('private' in low and p.suffix.lower() in {'.pem','.key'}) or low.endswith('private.key')):
        raise AssertionError(f'private key material must not be packaged: {p}')

# One canonical model authority owner only.
assert (root/'scripts/model_authority.py').is_file(), 'canonical model authority missing'
assert not (root/'tools/model_authority.py').exists(), 'parallel model authority detected'
assets=root/'android/app/src/main/assets'
if assets.exists() and any(p.is_file() for p in assets.rglob('*')):
    raise AssertionError('Android model asset duplication detected')
models=sorted(p.name for p in (root/'models').iterdir() if p.is_file())
expected=[
    'neuraldesk-context-pointer-v0.5.ndqa',
    'neuraldesk-knowledge-retriever-v0.5.ndkr',
    'neuraldesk-knowledge-v0.5.ndkb',
    'neuraldesk-open-knowledge-pira-v0.6.ndos',
    'neuraldesk-relation-classifier-v0.5.ndrl',
    'neuraldesk-semantic-ranker-v0.7.1.ndsr',
]
assert models==expected,(models,expected)
text=(root/'android/app/build.gradle.kts').read_text(encoding='utf-8')
assert 'assets.srcDir("../../models")' in text
print('release-cleanliness PASS',len([p for p in root.rglob('*') if p.is_file()]),'files')
