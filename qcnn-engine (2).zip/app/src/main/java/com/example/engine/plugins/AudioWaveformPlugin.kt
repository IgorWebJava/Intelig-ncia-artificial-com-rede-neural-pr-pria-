package com.example.engine.plugins

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import kotlin.concurrent.thread
import kotlin.math.sin

/**
 * Plugin Kotlin para Síntese e Execução Direta de Áudio PCM Harmônico no Android.
 */
class AudioWaveformPlugin(private val context: Context? = null) : IQcnnPlugin {
    override val pluginId: String = "audio_waveform"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        val entrada = context.prompt.trim().lowercase()

        if (entrada.contains("gerar audio") || entrada.contains("criar audio") || entrada.contains("tocar frequencia") || entrada.contains("gerar som")) {
            val freq = if (context.totalFrequencyHz > 0) context.totalFrequencyHz else 432.0
            
            // Tocar em background thread usando AudioTrack nativo do Android
            tocarTomSenoidal(freq, 1.2)

            context.metadata["audio_duracao_seg"] = 1.2
            context.metadata["audio_hz"] = freq
            context.metadata["modulo_audio"] = pluginId

            if (entrada.contains("gerar audio") || entrada.contains("criar audio") || entrada.contains("gerar som") || entrada.contains("tocar frequencia")) {
                context.customResponse = "🎵 **[Multi-V Audio Waveform]** Onda Harmônica Emitida via AudioTrack PCM!\n\n- **Frequência:** `${String.format("%.2f", freq)} Hz`\n- **Duração:** `1.2s`\n- **Modo:** Estéreo Senoidal Nativo\n\n✨ *Execução sonora direta no hardware sem bibliotecas externas.*"
            }
        }
        return context
    }

    private fun tocarTomSenoidal(freq: Double, duracaoSeg: Double, sampleRate: Int = 44100) {
        thread(start = true, isDaemon = true) {
            try {
                val numSamples = (duracaoSeg * sampleRate).toInt()
                val buffer = ShortArray(numSamples)

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val envelope = when {
                        t < 0.05 -> t / 0.05
                        t > (duracaoSeg - 0.05) -> (duracaoSeg - t) / 0.05
                        else -> 1.0
                    }
                    val sample = sin(2.0 * Math.PI * freq * t) * 0.85 + sin(2.0 * Math.PI * (freq * 2.0) * t) * 0.15
                    buffer[i] = (sample * 32767.0 * envelope).toInt().toShort()
                }

                val minBufSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBufSize, numSamples * 2))
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, numSamples)
                audioTrack.play()
                Thread.sleep((duracaoSeg * 1000).toLong() + 100)
                audioTrack.stop()
                audioTrack.release()
            } catch (e: Exception) {
                // Log silencioso sem travar o pipeline
            }
        }
    }
}
