<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Storage-Aware Inference Strategy

For models larger than accelerator/host memory, storage becomes a serving tier. Future experiments must measure bytes/token, sequentiality, queue depth, prefetch overlap, direct-I/O versus page cache, NUMA/storage topology, cold/warm behavior and device wear/cost.

Storage-aware inference is an optional degraded/edge/self-hosting capability, not a substitute for high-throughput GPU serving.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
