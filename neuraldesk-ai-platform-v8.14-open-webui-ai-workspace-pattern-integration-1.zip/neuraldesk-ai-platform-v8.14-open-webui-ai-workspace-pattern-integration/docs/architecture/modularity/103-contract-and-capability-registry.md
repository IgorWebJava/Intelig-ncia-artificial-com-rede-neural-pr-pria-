<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 103 — Contracts & Capabilities

Synchronous contracts use OpenAPI.
Asynchronous contracts use AsyncAPI.
Config contracts use JSON Schema.

Modules depend on capability IDs such as:

```text
knowledge.retrieve.v1
tools.execute.v1
ai.execute.v1
audit.write.v1
```
