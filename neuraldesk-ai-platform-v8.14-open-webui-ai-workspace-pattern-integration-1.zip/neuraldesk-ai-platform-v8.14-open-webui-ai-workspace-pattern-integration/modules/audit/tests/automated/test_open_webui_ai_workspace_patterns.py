import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class OpenWebUIAIWorkspacePatternTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.ctx=TestContext(__file__)
    def test_v814_marker(self): self.assertIn('id="open-webui-pattern-v814"', self.ctx.html)
    def test_truth_boundary(self): self.assertIn('workspace engine not connected', self.ctx.normalized_html.lower())
    def test_manifest_profile(self):
        self.assertEqual(self.ctx.manifest.get('version'),'8.14.0')
        self.assertEqual(self.ctx.manifest.get('ui_surface',{}).get('open_webui_ai_workspace_pattern_profile'),'open-webui-ai-workspace-patterns-v1')
    def test_required_workspace_capabilities(self):
        expected=['ui.feature.access.resolve.v1', 'ui.extension.trust.v1', 'ui.channels.collaboration.v1', 'ui.tool.native.injection.v1']
        self.assertTrue(set(expected).issubset(set(self.ctx.manifest.get('requires_capabilities',[]))))
    def test_preserves_previous_layers(self):
        self.assertIn('coding-pattern-v813', self.ctx.html)
        self.assertIn('autogpt-pattern-v812', self.ctx.html)

if __name__=='__main__': unittest.main()
