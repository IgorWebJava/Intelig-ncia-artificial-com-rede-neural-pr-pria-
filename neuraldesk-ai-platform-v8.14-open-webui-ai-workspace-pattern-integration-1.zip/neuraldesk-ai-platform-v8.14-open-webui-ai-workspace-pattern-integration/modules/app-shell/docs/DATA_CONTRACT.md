<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CURRENT_STATE.md -->
# Data Contract — index.html

## Responsibility

Launcher/Module Registry reader

## Access rule

```text
Page / Client
→ API / BFF
→ Application Service
→ Data Platform
```

The browser/page does **not** receive direct database credentials.

## Authoritative data

- `module_registry`
- `feature_flags`

## Events consumed/emitted

- `config.changed`
- `module.updated`

## Consistency

Durable changes use a database transaction. When other modules must react, the transaction also writes an outbox event. Consumers refresh their state from the authoritative service/data source.

## Security

- authenticated access;
- authorization before writes;
- tenant/project scope where applicable;
- audit for sensitive changes;
- secrets stored as external secret references, not plaintext configuration.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/app-shell/
UI:        modules/app-shell/ui/index.html
CSS:       modules/app-shell/ui/index.css
Manifest:  modules/app-shell/module.manifest.json
Contracts: modules/app-shell/contracts/
Data:      modules/app-shell/data/
Docs:      modules/app-shell/docs/
```

The root `index.html` file, when present, is only a backward-compatible route alias.
