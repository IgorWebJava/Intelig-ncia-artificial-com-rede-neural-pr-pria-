#define _POSIX_C_SOURCE 200809L

#include <jni.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nd_assistant.h"

typedef struct {
    NDAssistant assistant;
    pthread_mutex_t mutex;
    pthread_cond_t idle;
    unsigned active_operations;
    int destroying;
    int cancel_requested;
    uint64_t deadline_ns;
} H;

typedef struct {
    JNIEnv *env;
    jobject callback;
    jmethodID on_chunk;
    H *handle;
} StreamBridge;

static uint64_t monotonic_ns(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0u;
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
}

static int begin_operation(H *h) {
    if (!h) return 0;
    if (pthread_mutex_lock(&h->mutex) != 0) return 0;
    int allowed = !h->destroying && h->active_operations == 0u;
    if (allowed) {
        h->active_operations = 1u;
        h->cancel_requested = 0;
        unsigned deadline_ms = nd_resource_effective_deadline_ms(
            &h->assistant.resource_policy, h->assistant.thermal_status);
        uint64_t now = monotonic_ns();
        h->deadline_ns = now && deadline_ms
            ? now + (uint64_t)deadline_ms * UINT64_C(1000000)
            : 0u;
    }
    pthread_mutex_unlock(&h->mutex);
    return allowed;
}

static void end_operation(H *h) {
    if (!h) return;
    if (pthread_mutex_lock(&h->mutex) != 0) return;
    if (h->active_operations > 0u) h->active_operations--;
    h->deadline_ns = 0u;
    pthread_cond_broadcast(&h->idle);
    pthread_mutex_unlock(&h->mutex);
}

static int operation_should_stop(void *user_data) {
    H *h = (H *)user_data;
    if (!h) return 1;
    if (pthread_mutex_lock(&h->mutex) != 0) return 1;
    int stop = h->destroying || h->cancel_requested;
    if (!stop && h->deadline_ns != 0u) {
        uint64_t now = monotonic_ns();
        if (now != 0u && now >= h->deadline_ns) {
            h->cancel_requested = 1;
            stop = 1;
        }
    }
    pthread_mutex_unlock(&h->mutex);
    return stop;
}

static int begin_mutation(H *h) {
    if (!h) return 0;
    if (pthread_mutex_lock(&h->mutex) != 0) return 0;
    if (h->destroying || h->active_operations != 0u) {
        pthread_mutex_unlock(&h->mutex);
        return 0;
    }
    return 1;
}

static void end_mutation(H *h) {
    if (h) pthread_mutex_unlock(&h->mutex);
}

static jstring utf8_string(JNIEnv *env, const char *buf, size_t len) {
    jbyteArray arr = (*env)->NewByteArray(env, (jsize)len);
    if (!arr) return (*env)->NewStringUTF(env, "");
    (*env)->SetByteArrayRegion(env, arr, 0, (jsize)len, (const jbyte *)buf);
    jclass sc = (*env)->FindClass(env, "java/lang/String");
    if (!sc) return (*env)->NewStringUTF(env, "");
    jmethodID ctor = (*env)->GetMethodID(env, sc, "<init>", "([BLjava/lang/String;)V");
    if (!ctor) return (*env)->NewStringUTF(env, "");
    jstring charset = (*env)->NewStringUTF(env, "UTF-8");
    if (!charset) return (*env)->NewStringUTF(env, "");
    return (jstring)(*env)->NewObject(env, sc, ctor, arr, charset);
}

static int stream_bridge_callback(const char *chunk, size_t bytes, void *user_data) {
    StreamBridge *bridge = (StreamBridge *)user_data;
    if (!bridge || !bridge->handle || operation_should_stop(bridge->handle)) return 1;
    jstring text = utf8_string(bridge->env, chunk, bytes);
    if (!text) return 1;
    (*bridge->env)->CallVoidMethod(bridge->env, bridge->callback, bridge->on_chunk, text);
    (*bridge->env)->DeleteLocalRef(bridge->env, text);
    if ((*bridge->env)->ExceptionCheck(bridge->env)) return 1;
    return operation_should_stop(bridge->handle);
}

static void destroy_handle(H *h) {
    if (!h) return;
    nd_assistant_free(&h->assistant);
    pthread_cond_destroy(&h->idle);
    pthread_mutex_destroy(&h->mutex);
    free(h);
}

JNIEXPORT jlong JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeLoad(JNIEnv *env,
                                                      jobject obj,
                                                      jstring retriever_path,
                                                      jstring knowledge_base_path,
                                                      jstring context_qa_path,
                                                      jstring relation_path,
                                                      jstring open_knowledge_path,
                                                      jstring semantic_ranker_path,
                                                      jstring memory_path) {
    (void)obj;
    if (!retriever_path || !knowledge_base_path || !context_qa_path ||
        !relation_path || !open_knowledge_path || !semantic_ranker_path || !memory_path) return (jlong)0;
    const char *rp = NULL;
    const char *kp = NULL;
    const char *qp = NULL;
    const char *lp = NULL;
    const char *op = NULL;
    const char *sp = NULL;
    const char *mp = NULL;
    H *h = NULL;
    rp = (*env)->GetStringUTFChars(env, retriever_path, 0);
    if (rp) kp = (*env)->GetStringUTFChars(env, knowledge_base_path, 0);
    if (kp) qp = (*env)->GetStringUTFChars(env, context_qa_path, 0);
    if (qp) lp = (*env)->GetStringUTFChars(env, relation_path, 0);
    if (lp) op = (*env)->GetStringUTFChars(env, open_knowledge_path, 0);
    if (op) sp = (*env)->GetStringUTFChars(env, semantic_ranker_path, 0);
    if (sp) mp = (*env)->GetStringUTFChars(env, memory_path, 0);
    if (rp && kp && qp && lp && op && sp && mp) {
        h = (H *)calloc(1u, sizeof(*h));
        int mutex_ok = h && pthread_mutex_init(&h->mutex, NULL) == 0;
        int cond_ok = mutex_ok && pthread_cond_init(&h->idle, NULL) == 0;
        char err[256];
        if (!cond_ok || nd_assistant_load_ex(&h->assistant, rp, kp, qp, lp, op, mp, err, sizeof(err)) ||
            nd_assistant_load_semantic_ranker(&h->assistant, sp, err, sizeof(err))) {
            if (h) {
                if (cond_ok) pthread_cond_destroy(&h->idle);
                if (mutex_ok) pthread_mutex_destroy(&h->mutex);
                nd_assistant_free(&h->assistant);
                free(h);
            }
            h = NULL;
        }
    }
    if (mp) (*env)->ReleaseStringUTFChars(env, memory_path, mp);
    if (sp) (*env)->ReleaseStringUTFChars(env, semantic_ranker_path, sp);
    if (op) (*env)->ReleaseStringUTFChars(env, open_knowledge_path, op);
    if (lp) (*env)->ReleaseStringUTFChars(env, relation_path, lp);
    if (qp) (*env)->ReleaseStringUTFChars(env, context_qa_path, qp);
    if (kp) (*env)->ReleaseStringUTFChars(env, knowledge_base_path, kp);
    if (rp) (*env)->ReleaseStringUTFChars(env, retriever_path, rp);
    return (jlong)(intptr_t)h;
}

JNIEXPORT void JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeSetProfile(JNIEnv *env, jobject obj, jlong handle, jint profile) {
    (void)env;
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !begin_mutation(h)) return;
    if (profile < 0 || profile > 2) profile = 0;
    (void)nd_assistant_set_profile(&h->assistant, (NDMobileProfile)profile);
    end_mutation(h);
}

JNIEXPORT void JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeSetThermalStatus(JNIEnv *env, jobject obj, jlong handle, jint status) {
    (void)env;
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !begin_mutation(h)) return;
    if (status < 0) status = 0;
    if (status > 6) status = 6;
    (void)nd_assistant_set_thermal_status(&h->assistant, (unsigned)status);
    end_mutation(h);
}

JNIEXPORT void JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeSetMasterKill(JNIEnv *env, jobject obj, jlong handle, jboolean enabled) {
    (void)env;
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !begin_mutation(h)) return;
    (void)nd_assistant_set_master_kill(&h->assistant, enabled ? 1 : 0, 0);
    end_mutation(h);
}

JNIEXPORT jboolean JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeRagAddDocument(JNIEnv *env, jobject obj, jlong handle,
                                                                jstring doc_id, jstring text) {
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !doc_id || !text || !begin_mutation(h)) return JNI_FALSE;
    const char *id = (*env)->GetStringUTFChars(env, doc_id, 0);
    if (!id) {
        end_mutation(h);
        return JNI_FALSE;
    }
    const char *body = (*env)->GetStringUTFChars(env, text, 0);
    if (!body) {
        (*env)->ReleaseStringUTFChars(env, doc_id, id);
        end_mutation(h);
        return JNI_FALSE;
    }
    char err[256];
    int rc = nd_assistant_rag_add_document(&h->assistant, id, body, err, sizeof(err));
    (*env)->ReleaseStringUTFChars(env, text, body);
    (*env)->ReleaseStringUTFChars(env, doc_id, id);
    end_mutation(h);
    return rc == 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeRagClear(JNIEnv *env, jobject obj, jlong handle) {
    (void)env;
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !begin_mutation(h)) return;
    nd_assistant_rag_clear(&h->assistant);
    end_mutation(h);
}

JNIEXPORT jboolean JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeRagSave(JNIEnv *env, jobject obj, jlong handle, jstring path) {
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !path || !begin_mutation(h)) return JNI_FALSE;
    const char *p = (*env)->GetStringUTFChars(env, path, 0);
    if (!p) {
        end_mutation(h);
        return JNI_FALSE;
    }
    char err[256];
    int rc = nd_assistant_rag_save(&h->assistant, p, err, sizeof(err));
    (*env)->ReleaseStringUTFChars(env, path, p);
    end_mutation(h);
    return rc == 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeRagLoad(JNIEnv *env, jobject obj, jlong handle, jstring path) {
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !path || !begin_mutation(h)) return JNI_FALSE;
    const char *p = (*env)->GetStringUTFChars(env, path, 0);
    if (!p) {
        end_mutation(h);
        return JNI_FALSE;
    }
    char err[256];
    int rc = nd_assistant_rag_load(&h->assistant, p, err, sizeof(err));
    (*env)->ReleaseStringUTFChars(env, path, p);
    end_mutation(h);
    return rc == 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeAnswer(JNIEnv *env, jobject obj, jlong handle,
                                                        jstring question, jstring context, jboolean rich) {
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !question) return (*env)->NewStringUTF(env, "");
    const char *q = (*env)->GetStringUTFChars(env, question, 0);
    if (!q) return (*env)->NewStringUTF(env, "");
    const char *c = NULL;
    if (context) {
        c = (*env)->GetStringUTFChars(env, context, 0);
        if (!c) {
            (*env)->ReleaseStringUTFChars(env, question, q);
            return (*env)->NewStringUTF(env, "");
        }
    }
    if (!begin_operation(h)) {
        if (c) (*env)->ReleaseStringUTFChars(env, context, c);
        (*env)->ReleaseStringUTFChars(env, question, q);
        return (*env)->NewStringUTF(env, "");
    }
    size_t cap = nd_resource_effective_output_bytes(&h->assistant.resource_policy, h->assistant.thermal_status) + 1u;
    char *out = (char *)calloc(cap, 1u);
    char err[256];
    NDAnswerMeta meta;
    NDExecutionControl control = {operation_should_stop, h};
    int rc = out ? nd_assistant_answer_controlled(&h->assistant, q, c, rich ? 1 : 0,
                                                   &control, out, cap, &meta, err, sizeof(err)) : -1;
    if (c) (*env)->ReleaseStringUTFChars(env, context, c);
    (*env)->ReleaseStringUTFChars(env, question, q);
    end_operation(h);
    if (rc != 0 || !out) {
        free(out);
        return (*env)->NewStringUTF(env, "");
    }
    jstring result = utf8_string(env, out, strlen(out));
    free(out);
    return result;
}

JNIEXPORT jstring JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeAnswerStream(JNIEnv *env, jobject obj, jlong handle,
                                                              jstring question, jstring context, jboolean rich,
                                                              jobject callback) {
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h || !question || !callback) return (*env)->NewStringUTF(env, "");
    const char *q = (*env)->GetStringUTFChars(env, question, 0);
    if (!q) return (*env)->NewStringUTF(env, "");
    const char *c = NULL;
    if (context) {
        c = (*env)->GetStringUTFChars(env, context, 0);
        if (!c) {
            (*env)->ReleaseStringUTFChars(env, question, q);
            return (*env)->NewStringUTF(env, "");
        }
    }
    jclass cls = (*env)->GetObjectClass(env, callback);
    jmethodID mid = cls ? (*env)->GetMethodID(env, cls, "onChunk", "(Ljava/lang/String;)V") : NULL;
    if (!mid) {
        if (c) (*env)->ReleaseStringUTFChars(env, context, c);
        (*env)->ReleaseStringUTFChars(env, question, q);
        return (*env)->NewStringUTF(env, "");
    }
    if (!begin_operation(h)) {
        if (c) (*env)->ReleaseStringUTFChars(env, context, c);
        (*env)->ReleaseStringUTFChars(env, question, q);
        return (*env)->NewStringUTF(env, "");
    }
    size_t cap = nd_resource_effective_output_bytes(&h->assistant.resource_policy, h->assistant.thermal_status) + 1u;
    char *out = (char *)calloc(cap, 1u);
    char err[256];
    NDAnswerMeta meta;
    NDExecutionControl control = {operation_should_stop, h};
    StreamBridge bridge = {env, callback, mid, h};
    int rc = out ? nd_assistant_answer_stream_controlled(&h->assistant, q, c, rich ? 1 : 0,
                                                          &control, stream_bridge_callback, &bridge,
                                                          out, cap, &meta, err, sizeof(err)) : -1;
    if (c) (*env)->ReleaseStringUTFChars(env, context, c);
    (*env)->ReleaseStringUTFChars(env, question, q);
    end_operation(h);
    if (rc != 0 || !out) {
        free(out);
        return (*env)->NewStringUTF(env, "");
    }
    jstring result = utf8_string(env, out, strlen(out));
    free(out);
    return result;
}

JNIEXPORT void JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeCancel(JNIEnv *env, jobject obj, jlong handle) {
    (void)env;
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h) return;
    if (pthread_mutex_lock(&h->mutex) != 0) return;
    h->cancel_requested = 1;
    pthread_mutex_unlock(&h->mutex);
}

JNIEXPORT void JNICALL
Java_com_neuraldesk_localnet_NativeEngine_nativeFree(JNIEnv *env, jobject obj, jlong handle) {
    (void)env;
    (void)obj;
    H *h = (H *)(intptr_t)handle;
    if (!h) return;
    if (pthread_mutex_lock(&h->mutex) != 0) return;
    h->destroying = 1;
    h->cancel_requested = 1;
    while (h->active_operations != 0u) {
        if (pthread_cond_wait(&h->idle, &h->mutex) != 0) break;
    }
    pthread_mutex_unlock(&h->mutex);
    destroy_handle(h);
}
