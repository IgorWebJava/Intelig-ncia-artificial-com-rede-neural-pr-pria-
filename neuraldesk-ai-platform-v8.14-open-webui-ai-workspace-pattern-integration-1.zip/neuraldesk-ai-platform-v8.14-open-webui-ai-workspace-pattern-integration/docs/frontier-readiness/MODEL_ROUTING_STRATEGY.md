# Model Routing Strategy

Routing is a controlled optimization problem, not random model selection.

Inputs:
- task class;
- quality target;
- modality;
- latency budget;
- cost budget;
- context requirements;
- privacy/data residency;
- tool/structured-output requirements;
- provider health.

Routing modes:
- fixed profile;
- policy-based;
- benchmark-ranked;
- cascade;
- ensemble/verification;
- local-first/privacy-first.

The router must log the decision without exposing private chain-of-thought.
