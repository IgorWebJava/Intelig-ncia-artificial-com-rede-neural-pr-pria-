#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re,subprocess,unicodedata
from pathlib import Path
R=Path(__file__).resolve().parents[1]; BIN=R/'build/nd_generative_generate'; TOK=R/'training/data/generative_v074/tokenizer-v1.ndtk'; PROBES=json.loads((R/'evaluation/generative_v074/HOLDOUT_PROBES.json').read_text())['probes']
def norm(s): return unicodedata.normalize('NFKC',s).casefold()
def run(model,prompt,max_tokens=64):
    p=subprocess.run([str(BIN),str(model),str(TOK),str(max_tokens),prompt],cwd=R,capture_output=True)
    if p.returncode!=0:return [],'',f'rc={p.returncode} stderr={p.stderr.decode("utf-8","replace")[:120]}'
    raw=p.stdout; lines=raw.split(b'\n',1); toks=[int(x) for x in lines[0].split()[1:]] if lines else []
    text='';
    if len(lines)>1 and lines[1].startswith(b'TEXT '):
        try:text=lines[1][5:].rstrip(b'\n').decode('utf-8','strict')
        except UnicodeDecodeError:return toks,'','invalid_utf8'
    return toks,text,''
def semantic_ok(text,p):
    n=norm(text); words=re.findall(r'[\wáéíóúâêôãõç-]+',n)
    if len(text)<20 or len(words)<4:return False,'too_short'
    if len(words)>=8 and len(set(words))/len(words)<0.28:return False,'repetition'
    for group in p['required']:
        if not any(term in n for term in group):return False,'missing:'+('|'.join(group))
    return True,'ok'
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fp32',required=True);ap.add_argument('--q8',required=True);ap.add_argument('--q4',required=True);a=ap.parse_args(); models={'fp32':Path(a.fp32),'q8':Path(a.q8),'q4':Path(a.q4)}; outputs={}; fmt_ok={}
    for fmt,model in models.items():
        ok=0; outputs[fmt]=[]
        for p in PROBES:
            toks,text,err=run(model,p['prompt']); good,reason=semantic_ok(text,p) if not err else (False,err); ok+=int(good); outputs[fmt].append({'id':p['id'],'ok':good,'reason':reason,'tokens':toks,'text':text}); print(f'[{fmt}] {p["id"]} ok={good} reason={reason} :: {text}',flush=True)
        fmt_ok[fmt]=ok
    # First-token parity over the six strict holdouts plus 14 deterministic training questions.
    extra=[json.loads(x)['question'] for x in (R/'training/data/generative_v074/sft_train.jsonl').read_text(encoding='utf-8').splitlines()[:14]]; prompts=[p['prompt'] for p in PROBES]+extra; first={k:[] for k in models}
    for prompt in prompts:
        for fmt,model in models.items(): first[fmt].append(run(model,prompt,1)[0][0])
    q8=sum(a==b for a,b in zip(first['fp32'],first['q8']));q4=sum(a==b for a,b in zip(first['fp32'],first['q4']))
    report={'schema':'neuraldesk-generative-runtime-quality-v074-v1','formats':fmt_ok,'q8FirstTokenParity':f'{q8}/20','q4FirstTokenParity':f'{q4}/20','outputs':outputs,'promotionGatePassed':fmt_ok=={'fp32':6,'q8':6,'q4':6} and q8>=18 and q4>=15}
    out=R/'evaluation/generative_v074/RUNTIME_QUALITY_REPORT.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(f'GENERATIVE_RUNTIME_QUALITY formats={fmt_ok} q8={q8}/20 q4={q4}/20 promotionGatePassed={report["promotionGatePassed"]}')
    return 0 if report['promotionGatePassed'] else 1
if __name__=='__main__':raise SystemExit(main())
