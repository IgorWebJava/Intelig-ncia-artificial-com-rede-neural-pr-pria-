<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# HTML/CSS Modular UI

    Skill ID: `neuraldesk.html-css-ui.v1`

    ## Category

    `ui`

    ## Introduced

    `V3`

    ## Required development capabilities

    - `html.author.v1`
- `css.author.v1`
- `accessibility.structural.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/<module>/ui/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
