#ifndef ND_NETWORK_POLICY_H
#define ND_NETWORK_POLICY_H

typedef enum {
    ND_NETWORK_OFFLINE = 0,
    ND_NETWORK_CONSTRAINED = 1,
    ND_NETWORK_NORMAL = 2
} NDNetworkState;

typedef enum {
    ND_NETWORK_OP_DURABLE_TASK_RETRY = 0,
    ND_NETWORK_OP_MODEL_ACQUISITION = 1,
    ND_NETWORK_OP_MEDIA_PREFETCH = 2,
    ND_NETWORK_OP_WEB_CONTEXT = 3
} NDNetworkOperation;

typedef struct {
    int online;
    int save_data;
    unsigned downstream_kbps;
    NDNetworkState state;
} NDNetworkSnapshot;

NDNetworkSnapshot nd_network_snapshot(int online, int save_data, unsigned downstream_kbps);
int nd_network_allows(const NDNetworkSnapshot *snapshot, NDNetworkOperation operation, int manual);
const char *nd_network_state_name(NDNetworkState state);

#endif
