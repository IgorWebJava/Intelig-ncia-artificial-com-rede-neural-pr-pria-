<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 99 — Migration / Rollout Plan

## Phase 1
Define schemas, config hierarchy and service ownership.

## Phase 2
Implement Configuration Service and Module Registry.

## Phase 3
Implement PostgreSQL tables, versioning and audit.

## Phase 4
Implement transactional outbox.

## Phase 5
Implement event stream and consumer refresh.

## Phase 6
Connect Chat, Knowledge, Tools, Training and Audit one-by-one.

## Phase 7
Add feature flags, drift detection and rollback.

## Phase 8
Production hardening: RLS, backup, recovery, observability, load tests.
