<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# NeuralDesk AI Platform — Template V5

Template visual profissional para uma plataforma de Inteligência Artificial, destinado à incorporação em um sistema real existente.

## Tecnologias

- HTML5
- CSS3

## Não contém

- JavaScript
- React
- TypeScript
- backend
- banco de dados
- chamadas reais de IA
- credenciais
- secrets

## Módulos

### Workspace principal

`index.html`

Contém o template visual de Chat, Dashboard, Knowledge & AI Training Studio, Base de Conhecimento e Configurações.

### Knowledge Center

`knowledge-center.html`

Infraestrutura visual avançada para knowledge management, semantic search, retrieval, graph, permissions, quality, versions e lineage.

### Tool & Integration Center

`tools-center.html`

Infraestrutura visual para tools, apps, MCP, agents, workflows, routing, gateway, approvals, executions, traces, observability e governance.

## CSS

```text
css/styles.css
css/launch.css
css/knowledge-center.css
css/tools-center.css
```

## Documentação

A pasta `docs/` descreve arquitetura, comportamentos conceituais, integração futura, segurança, governança e critérios de aceitação.

## Regra de integração

O sistema hospedeiro deve transformar os elementos visuais em componentes reais, conectando estado, eventos, APIs e permissões. O template original deve permanecer livre de lógica de negócio.


## V6 — AI Operations & Intelligence Dashboard

Nova página: `dashboard-center.html`

CSS: `css/dashboard-center.css`

O Dashboard reúne visão executiva e operacional de Models, Agents, Knowledge/RAG, Tools/MCP, Traces, FinOps, Safety, Approvals, Incidents, SLOs, Adoption e Feedback. Todos os valores são demonstrativos.
