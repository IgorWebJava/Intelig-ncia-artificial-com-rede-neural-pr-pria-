<!-- neuraldesk-documentation-sync: V8.8 -->

# Advanced AI Chat Workspace — Modular Package

Canonical module ID: `neuraldesk.chat`

## Layout

```text
chat/
├── module.manifest.json
├── ui/
├── contracts/
├── data/
├── docs/
└── compatibility/
```

## Dependency rule

This module may depend only on:
1. versioned public contracts;
2. declared capabilities;
3. stable platform primitives.

It must not depend on another module's private implementation, private database tables, or direct AI provider SDKs.
