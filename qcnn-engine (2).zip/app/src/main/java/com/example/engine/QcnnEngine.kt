package com.example.engine

import android.content.Context
import com.example.engine.core.CollapseResult
import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.NoTernario
import com.example.engine.core.QcnnExecutionContext
import com.example.engine.plugins.AdjacencyFilterPlugin
import com.example.engine.plugins.AudioSynthesisPlugin
import com.example.engine.plugins.ConceptualDialoguePlugin
import com.example.engine.plugins.ContextCrystallizerPlugin
import com.example.engine.plugins.AssistantToolkitPlugin
import com.example.engine.plugins.ContinuousIngestionPlugin
import com.example.engine.plugins.FractalBreakerPlugin
import com.example.engine.plugins.FractalGrammarPlugin
import com.example.engine.plugins.HarmonicFrequencyPlugin
import com.example.engine.plugins.GoalDrivenAgentLoopPlugin
import com.example.engine.plugins.HardwareTelemetryPlugin
import com.example.engine.plugins.HyperdimensionalComputingPlugin
import com.example.engine.plugins.MetaCognitiveAuditorPlugin
import com.example.engine.plugins.SelfHealingConsensusPlugin
import com.example.engine.plugins.MiluiExpansionPlugin
import com.example.engine.plugins.MultiverseOraclePlugin
import com.example.engine.plugins.MyceliumIndexPlugin
import com.example.engine.plugins.OctaveRegulatorPlugin
import com.example.engine.plugins.OrganMultiplexerPlugin
import com.example.engine.plugins.VisualMatrixPlugin
import com.example.engine.plugins.CodeSynthesisPlugin
import com.example.engine.plugins.AudioWaveformPlugin
import com.example.engine.plugins.FileManagerPlugin
import com.example.engine.plugins.VideoSequencerPlugin
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Orquestrador do Motor Quântico-Cabalístico QCNN v6.0 / MULTI-V Multimodal no Android.
 * Gerencia a execução encadeada de plugins modulares e desacoplados.
 */
class QcnnEngine(val context: Context) {

    private val plugins = CopyOnWriteArrayList<IQcnnPlugin>()
    private val pluginMap = mutableMapOf<String, IQcnnPlugin>()

    init {
        // Registro padrão dos módulos do Pipeline Central Multimodal
        registerPlugin(MiluiExpansionPlugin())
        registerPlugin(AdjacencyFilterPlugin())
        registerPlugin(HarmonicFrequencyPlugin())
        registerPlugin(HyperdimensionalComputingPlugin())
        registerPlugin(FractalGrammarPlugin())
        registerPlugin(ContinuousIngestionPlugin(context.filesDir))
        registerPlugin(GoalDrivenAgentLoopPlugin())
        registerPlugin(AssistantToolkitPlugin(context.filesDir))
        registerPlugin(MultiverseOraclePlugin())
        registerPlugin(MyceliumIndexPlugin())
        registerPlugin(ConceptualDialoguePlugin(context))
        registerPlugin(VisualMatrixPlugin())
        registerPlugin(CodeSynthesisPlugin())
        registerPlugin(AudioWaveformPlugin(context))
        registerPlugin(FileManagerPlugin(context))
        registerPlugin(VideoSequencerPlugin())
        registerPlugin(OrganMultiplexerPlugin())
        registerPlugin(OctaveRegulatorPlugin())
        registerPlugin(FractalBreakerPlugin())
        registerPlugin(ContextCrystallizerPlugin(context))
        registerPlugin(MetaCognitiveAuditorPlugin())
        registerPlugin(SelfHealingConsensusPlugin())
        registerPlugin(AudioSynthesisPlugin())
        registerPlugin(HardwareTelemetryPlugin(context))
    }

    /**
     * Conecta dinamicamente um novo módulo/plugin ao pipeline.
     */
    fun registerPlugin(plugin: IQcnnPlugin) {
        unregisterPlugin(plugin.pluginId)
        plugins.add(plugin)
        pluginMap[plugin.pluginId] = plugin
    }

    /**
     * Desconecta dinamicamente um módulo/plugin do pipeline.
     */
    fun unregisterPlugin(pluginId: String): IQcnnPlugin? {
        val plugin = pluginMap.remove(pluginId)
        if (plugin != null) {
            plugins.remove(plugin)
        }
        return plugin
    }

    /**
     * Obtém uma referência a um plugin conectado.
     */
    fun getPlugin(pluginId: String): IQcnnPlugin? = pluginMap[pluginId]

    /**
     * Lista todos os identificadores de plugins ativos.
     */
    fun listPluginIds(): List<String> = plugins.map { it.pluginId }

    /**
     * Executa a descompactação quântico-cabalística através do pipeline de plugins com parâmetros do Observador.
     */
    fun processSeed(
        promptObservador: String,
        riskFactor: Double = 0.5,
        philosophy: String = "Dialética",
        rigor: Double = 0.8
    ): CollapseResult {
        val inicioTempo = System.nanoTime()
        val contextObj = QcnnExecutionContext(prompt = promptObservador.trim()).apply {
            metadata["prisma_risco"] = riskFactor
            metadata["filosofia"] = philosophy
            metadata["rigor_logico"] = rigor
        }

        // Inicializa nós ativos ternários para o ciclo usando a Matriz 22 Letras
        for ((letra, info) in MatrizLetras.MATRIZ_22) {
            contextObj.activeNodes[letra] = NoTernario(letra, info.frequenciaHz)
        }

        // Execução sequencial dos plugins habilitados
        for (plugin in plugins) {
            if (plugin.isEnabled) {
                plugin.execute(contextObj)
            }
        }

        val fimTempo = System.nanoTime()
        contextObj.latencyMs = (fimTempo - inicioTempo) / 1_000_000.0

        return contextObj.toCollapseResult()
    }
}
