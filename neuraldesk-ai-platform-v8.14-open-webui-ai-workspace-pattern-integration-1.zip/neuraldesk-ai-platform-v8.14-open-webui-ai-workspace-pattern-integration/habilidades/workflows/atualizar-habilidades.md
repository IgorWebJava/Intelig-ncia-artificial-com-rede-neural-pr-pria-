<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Atualizar Habilidades

1. Pergunte se a mudança introduziu nova competência/processo/tooling durável.
2. Se sim, crie/atualize skill record.
3. Defina capabilities abstratas.
4. Mapeie providers atuais.
5. Atualize workflow relevante.
6. Atualize manifests `development_requirements` se aplicável.
7. Atualize `ESTADO_ATUAL_HABILIDADES.json`.
8. Rode `tools/validate_skills.py`.
