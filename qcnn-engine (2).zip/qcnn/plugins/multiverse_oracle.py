import re
import math
from typing import Dict, Any, List, Optional
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class MultiverseOraclePlugin(BaseQcnnPlugin):
    """
    Módulo 14: Sistema Multi-V (Oráculo Analítico Multifacetado e Simulador de Realidades Paralelas).
    
    Camadas:
    1. Camada Neuro-Simbólica: Ancoragem formal em lógica de predicados e invariantes.
    2. Camada de Superposição (Efeito Observador): Matriz de probabilidades antes do colapso.
    3. Camada de Multiverso (Linhas de Tempo Decisórias): Ramificações Alpha (Expansivo),
       Beta (Resiliente), Gamma (Disruptivo) e Delta (Dialético/Filosófico).
    4. Camada Filosófica & Epistemológica: Prismas de Estoicismo, Dialética e Racionalismo.
    """

    def __init__(self):
        super().__init__()

    @property
    def plugin_id(self) -> str:
        return "multiverse_oracle"

    def _is_decision_or_scenario_query(self, prompt: str) -> bool:
        """Identifica se o prompt é uma consulta decisória, estratégica, hipotética ou cenário."""
        keywords = [
            "devo", "qual decisão", "o que acontece se", "o que aconteceria", "cenário", "cenarios",
            "simule", "simular", "escolha", "alternativas", "estratégia", "consequências",
            "e se", "melhor caminho", "analise de risco", "análise de risco", "tomada de decisão", "probabilidade",
            "ramificações", "multiverso", "projeção", "plano a ou b", "como agir",
            "oráculo", "oraculo", "previsão", "prever", "impacto futuro", "linha de tempo", "linhas de tempo"
        ]
        p_lower = prompt.lower()
        return any(k in p_lower for k in keywords)

    def generate_scenarios(self, prompt: str, risk_factor: float = 0.5, philosophy: str = "Dialética", rigor: float = 0.8) -> Dict[str, Any]:
        """
        Gera as 4 ramificações determinísticas de realidade quântico-simbólica.
        """
        clean_p = prompt.strip()
        # Hash pseudo-quântico determinístico
        p_hash = sum(ord(c) * (i + 1) for i, c in enumerate(clean_p))
        phi = 1.61803398875

        # Cálculo de probabilidades moduladas pelo Observador
        prob_alpha = min(0.95, max(0.05, 0.35 + (risk_factor - 0.5) * 0.40 + (p_hash % 7) * 0.02))
        prob_beta = min(0.95, max(0.05, 0.40 - (risk_factor - 0.5) * 0.30 + ((p_hash >> 2) % 5) * 0.02))
        prob_gamma = min(0.95, max(0.05, 0.25 + (risk_factor * 0.15) + ((p_hash >> 3) % 9) * 0.015))
        
        # Normalização de probabilidade
        total_p = prob_alpha + prob_beta + prob_gamma
        p_a = round((prob_alpha / total_p) * 100, 1)
        p_b = round((prob_beta / total_p) * 100, 1)
        p_c = round((prob_gamma / total_p) * 100, 1)

        hz_alpha = round(432.0 * phi * (1.0 + risk_factor * 0.2), 2)
        hz_beta = round(528.0 * (1.0 / phi) * (1.2 - risk_factor * 0.2), 2)
        hz_gamma = round(741.0 * phi * (0.8 + rigor * 0.3), 2)
        hz_delta = round(639.0 * phi, 2)

        # Projeções analíticas específicas
        cenario_alpha = {
            "id": "alpha",
            "nome": "Cenário Alpha (Expansivo & Arrojado)",
            "arquetipo": "Máxima Aceleração & Retorno",
            "probabilidade": f"{p_a}%",
            "frequencia_hz": hz_alpha,
            "horizonte": "Curto/Médio Prazo",
            "vetor_acao": "Alocação proativa de recursos, exploração agressiva de oportunidades e liderança pela inovação.",
            "risco_potencial": "Vulnerabilidade a choques imprevistos e volatilidade de curto prazo.",
            "impacto_simbolico": "Crescimento exponencial baseado no Princípio de Kether (Início Vital)."
        }

        cenario_beta = {
            "id": "beta",
            "nome": "Cenário Beta (Resiliente & Conservador)",
            "arquetipo": "Preservação & Alta Estabilidade",
            "probabilidade": f"{p_b}%",
            "frequencia_hz": hz_beta,
            "horizonte": "Médio/Longo Prazo",
            "vetor_acao": "Consolidação de bases, proteção de liquidez/reservas e mitigação rigorosa de incertezas.",
            "risco_potencial": "Custo de oportunidade e perda de velocidade frente a movimentos rápidos do ambiente.",
            "impacto_simbolico": "Estabilidade inquebrantável ancorada no Princípio de Gevurah (Rigor & Limite)."
        }

        cenario_gamma = {
            "id": "gamma",
            "nome": "Cenário Gamma (Disruptivo & Inovador)",
            "arquetipo": "Ruptura de Paradigma & Salto Quântico",
            "probabilidade": f"{p_c}%",
            "frequencia_hz": hz_gamma,
            "horizonte": "Longo Prazo",
            "vetor_acao": "Reestruturação do modelo convencional, adoção de novas tecnologias/paradigmas e convergência assimétrica.",
            "risco_potencial": "Resistência sistêmica e atrito inicial durante o período de transição.",
            "impacto_simbolico": "Transformação estrutural guiada pelo Princípio de Tiferet (Harmonia Sintética)."
        }

        # Prisma Epistemológico
        filosofia_analise = ""
        if philosophy.lower() == "estoicismo":
            filosofia_analise = "<strong>Prisma Estoico (Epicteto / Marco Aurélio):</strong> Foco estrito nas variáveis sob controle direto; aceitação serena das forças externas e máxima resiliência interna diante de qualquer resultado."
        elif philosophy.lower() == "racionalismo":
            filosofia_analise = "<strong>Prisma Racionalista (Descartes / Spinoza):</strong> Decomposição cartesiana do problema em axiomas fundamentais, dedução lógica passo a passo e recusa categórica de preconceitos intuitivos."
        elif philosophy.lower() == "pragmatismo":
            filosofia_analise = "<strong>Prisma Pragmático (William James / Peirce):</strong> Validação pelo valor da consequência prática; a melhor decisão é aquela que gera utilidade comprovável e eficiência no mundo real."
        else:
            filosofia_analise = "<strong>Prisma Dialético (Hegel / Heráclito):</strong> Síntese dinâmica entre a Tese (Expansão) e a Antítese (Conservação), gerando uma solução evoluída e imune a dogmas estáticos."

        cenario_delta = {
            "id": "delta",
            "nome": "Cenário Delta (Síntese Epistemológica)",
            "arquetipo": f"Filtro Filosófico: {philosophy}",
            "probabilidade": "Equilíbrio Áureo",
            "frequencia_hz": hz_delta,
            "horizonte": "Atemporal / Estratégico",
            "vetor_acao": filosofia_analise,
            "risco_potencial": "Excesso de reflexão (paralisia por análise) se não conjugado com ação prática.",
            "impacto_simbolico": "Clareza reflexiva e ancoragem metafísica na Árvore da Vida."
        }

        # Determina o cenário colapsado padrão de acordo com o Observador
        cenario_colapsado = cenario_alpha if risk_factor >= 0.65 else (cenario_gamma if risk_factor <= 0.35 else cenario_beta)

        return {
            "pergunta": clean_p,
            "parametros_observador": {
                "prisma_risco": risk_factor,
                "filosofia": philosophy,
                "rigor_logico": rigor
            },
            "colapso_primario": cenario_colapsado,
            "cenarios": [cenario_alpha, cenario_beta, cenario_gamma, cenario_delta],
            "nodos_grafo": [
                {"id": "ROOT", "label": "Consulta (Superposição)", "tipo": "observador", "prob": "100%"},
                {"id": "ALPHA", "label": "Alpha: Expansão", "tipo": "expansivo", "prob": f"{p_a}%", "hz": hz_alpha},
                {"id": "BETA", "label": "Beta: Resiliência", "tipo": "conservador", "prob": f"{p_b}%", "hz": hz_beta},
                {"id": "GAMMA", "label": "Gamma: Ruptura", "tipo": "disruptivo", "prob": f"{p_c}%", "hz": hz_gamma},
                {"id": "DELTA", "label": f"Delta: {philosophy}", "tipo": "filosofico", "prob": "Síntese", "hz": hz_delta}
            ],
            "arestas_grafo": [
                {"from": "ROOT", "to": "ALPHA", "peso": p_a / 100.0},
                {"from": "ROOT", "to": "BETA", "peso": p_b / 100.0},
                {"from": "ROOT", "to": "GAMMA", "peso": p_c / 100.0},
                {"from": "ROOT", "to": "DELTA", "peso": 1.0}
            ]
        }

    def _render_html_output(self, data: Dict[str, Any]) -> str:
        """Renderiza a resposta em HTML estruturado com cards interativos de multiverso."""
        colapso = data["colapso_primario"]
        params = data["parametros_observador"]
        
        cards_html = []
        for c in data["cenarios"]:
            ativo_classe = "border: 2px solid #ffd700; background: rgba(255, 215, 0, 0.08);" if c["id"] == colapso["id"] else "border: 1px solid rgba(0, 240, 255, 0.2); background: rgba(0, 15, 30, 0.5);"
            cards_html.append(f"""
<div style="margin-top: 10px; padding: 12px; border-radius: 8px; {ativo_classe}">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <strong style="color: #00f0ff; font-size: 0.95em;">{c['nome']}</strong>
        <span style="font-size: 0.8em; padding: 2px 8px; border-radius: 4px; background: rgba(0, 240, 255, 0.15); color: #ffd700;">Prob: {c['probabilidade']} | {c['frequencia_hz']} Hz</span>
    </div>
    <div style="font-size: 0.85em; color: #a0c0d0; margin-top: 4px;"><strong>Arquétipo:</strong> {c['arquetipo']}</div>
    <div style="font-size: 0.85em; color: #e0f0ff; margin-top: 6px;"><strong>Vetor de Ação:</strong> {c['vetor_acao']}</div>
    <div style="font-size: 0.80em; color: #ff8080; margin-top: 4px;"><strong>Risco / Ponto de Atenção:</strong> {c['risco_potencial']}</div>
</div>
""")

        html = f"""🏛️ [ORÁCULO ANALÍTICO MULTI-V: SIMULADOR DE REALIDADES]
<br><br><strong>Consulta do Observador:</strong> <em>"{data['pergunta']}"</em>
<br><strong>Parâmetros do Observador:</strong> Prisma Risco: <code>{params['prisma_risco']:.2f}</code> | Filosofia: <code>{params['filosofia']}</code> | Rigor: <code>{params['rigor_logico']:.2f}</code>
<br><br>⚡ <strong>COLAPSO DE SUPERPOSIÇÃO ATIVO:</strong> <span style="color: #ffd700;">{colapso['nome']} ({colapso['arquetipo']})</span>
<br><br><strong>Ramificações Quântico-Simbólicas em Paralelo:</strong>
{''.join(cards_html)}
<br><div style="font-size: 0.80em; color: #7090a0; margin-top: 8px; border-top: 1px dashed rgba(0,240,255,0.2); padding-top: 6px;">
✨ <em>Dica: Use os controles deslizantes do Painel do Observador ou clique nos nós do grafo para colapsar a função de onda em outra linha de tempo em tempo real.</em>
</div>"""
        return html

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt = context.prompt.strip()

        # Verifica se já há uma resposta de cálculo exato ou comando direto prioritário
        if context.custom_response:
            return context

        # Verifica se a consulta solicita análise, cenário ou tomada de decisão
        if self._is_decision_or_scenario_query(prompt):
            risk = float(context.metadata.get("prisma_risco", 0.5))
            philosophy = str(context.metadata.get("filosofia", "Dialética"))
            rigor = float(context.metadata.get("rigor_logico", 0.8))

            multiverse_data = self.generate_scenarios(prompt, risk_factor=risk, philosophy=philosophy, rigor=rigor)
            
            context.custom_response = self._render_html_output(multiverse_data)
            context.metadata["multiverse_data"] = multiverse_data
            context.metadata["oracle_engine"] = "Multi-V"
            context.final_state = "11 (Superposição Multiverso Colapsada)"
            context.total_frequency_hz = multiverse_data["colapso_primario"]["frequencia_hz"]

        return context
