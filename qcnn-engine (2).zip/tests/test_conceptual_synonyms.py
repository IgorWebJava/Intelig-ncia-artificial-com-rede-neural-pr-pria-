import unittest
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.conceptual_dialogue import ConceptualDialoguePlugin
from qcnn.plugins.fractal_grammar import FractalGrammarPlugin

class TestConceptualSynonyms(unittest.TestCase):
    def setUp(self):
        self.plugin = ConceptualDialoguePlugin(pasta_conhecimento="./conhecimento_local")
        self.grammar = FractalGrammarPlugin()

    def test_synonym_resolution_quantum(self):
        # "mecanica das matrizes" deve mapear para "fisica quantica"
        ctx = QcnnExecutionContext(prompt="Explique a mecanica das matrizes")
        ctx = self.plugin.execute(ctx)
        self.assertIn("fisica quantica", ctx.metadata.get("active_concepts", []))
        self.assertIn("escala fundamental", ctx.custom_response)

    def test_synonym_resolution_relativity_einstein(self):
        # "einstein" e "espaco tempo" devem ativar "relatividade"
        ctx = QcnnExecutionContext(prompt="Qual o impacto da dilatacao temporal segundo einstein?")
        ctx = self.plugin.execute(ctx)
        self.assertIn("relatividade", ctx.metadata.get("active_concepts", []))

    def test_multi_concept_fractal_synthesis(self):
        ctx = QcnnExecutionContext(prompt="Como a fisica quantica e a relatividade se relacionam?")
        ctx = self.plugin.execute(ctx)
        ctx = self.grammar.execute(ctx)
        self.assertIn("fisica quantica", ctx.metadata.get("active_concepts", []))
        self.assertIn("relatividade", ctx.metadata.get("active_concepts", []))
        self.assertIn("Síntese Gramatical Fractal", ctx.custom_response)

    def test_autonomous_persistence_and_offline_retrieval(self):
        import os
        termo_teste = "termodinamica_teste"
        conteudo_teste = "A termodinâmica estuda as relações entre calor, trabalho mecânico e outras formas de energia."
        self.plugin._persistir_conhecimento_local(termo_teste, conteudo_teste)
        
        # Agora busca deve encontrar localmente
        res = self.plugin._varrer_arquivo_local(termo_teste)
        self.assertIsNotNone(res)
        self.assertIn("calor, trabalho mecânico", res)
        
        # Limpa arquivo de teste
        for pasta in [self.plugin.pasta_conhecimento, "./conhecimento_local"]:
            p = os.path.join(pasta, f"{termo_teste}.txt")
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass

if __name__ == "__main__":
    unittest.main()
