#!/usr/bin/env python3
"""Deterministic first-party context-pointer corpus for LocalNet v0.5.

The pointer specialist is not a world-knowledge model. It learns how to locate
an exact answer span inside evidence that has already been selected as relevant.
Version 0.5 keeps twenty-five relation families and deliberately varies answer
position (leading, middle and trailing) while preserving disjoint entity/value
holdouts and held-out question phrasings.
"""
from __future__ import annotations

import random
import string

SEED = 404
TRAIN_ENTITIES = 700
GOLD_ENTITIES = 80

COLORS = [
    "azul", "verde", "amarelo", "vermelho", "violeta", "laranja",
    "cinza", "branco", "preto", "turquesa", "magenta", "dourado",
]
OWNERS = ["Ana", "Bruno", "Caio", "Dora", "Eva", "Fábio", "Gabi", "Hugo", "Iara", "João", "Lia", "Mauro"]
STATUSES = ["ativo", "pausado", "em revisão", "aprovado", "arquivado", "em validação", "operacional", "bloqueado"]
MATERIALS = ["alumínio", "cobre", "aço inoxidável", "vidro", "cerâmica", "policarbonato", "titânio", "madeira"]
LANGUAGES = ["português", "inglês", "espanhol", "francês", "alemão", "italiano", "japonês", "coreano"]
LOCATIONS = ["Recife", "Campinas", "Curitiba", "Salvador", "Belém", "Manaus", "Fortaleza", "Goiânia", "Lisboa", "Porto"]
AUTHORS = ["Marina Alves", "Rafael Lima", "Clara Souza", "Diego Rocha", "Helena Costa", "Paulo Nunes", "Laura Dias", "Igor Melo"]
ORGS = ["Equipe Aurora", "Laboratório Delta", "Núcleo Horizonte", "Grupo Prisma", "Unidade Atlas", "Centro Íris"]
CAPITALS = ["Luminara", "Valedouro", "Serena", "Monteluz", "Porto Claro", "Nova Íris", "Alvorada", "Ribeira"]
MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]

LICENSES = ["MIT", "Apache-2.0", "BSD-3-Clause", "MPL-2.0", "ISC", "LGPL-3.0"]
PROTOCOLS = ["HTTP/2", "HTTP/3", "MQTT", "WebSocket", "gRPC", "TLS 1.3", "QUIC"]
MANUFACTURERS = ["Fábrica Atlas", "Indústria Boreal", "Laboratório Íris", "Oficina Delta", "Núcleo Prisma", "Centro Aurora"]
PRIORITIES = ["baixa", "média", "alta", "crítica"]
REGIONS = ["sa-east-1", "us-east-2", "eu-west-3", "ap-south-1", "ca-central-1", "af-south-1"]

TRAIN_Q = {
    "code": ["Qual é o código de {e}?", "Informe o código de {e}.", "Que código pertence a {e}?"],
    "color": ["Qual é a cor de {e}?", "Informe a cor de {e}.", "Que cor foi atribuída a {e}?"],
    "temp": ["Qual é a temperatura de {e}?", "Informe a temperatura de {e}.", "Que temperatura pertence a {e}?"],
    "owner": ["Quem é o responsável por {e}?", "Informe o responsável por {e}.", "Quem responde por {e}?"],
    "status": ["Qual é o status de {e}?", "Informe o estado de {e}.", "Em que status está {e}?"],
    "version": ["Qual é a versão de {e}?", "Informe a versão registrada de {e}.", "Que versão está associada a {e}?"],
    "material": ["Qual é o material de {e}?", "De que material é feito {e}?", "Informe o material registrado de {e}."],
    "language": ["Qual é o idioma de {e}?", "Em que idioma está {e}?", "Informe o idioma registrado para {e}."],
    "date": ["Qual é a data de {e}?", "Quando ocorre {e}?", "Informe a data registrada para {e}."],
    "location": ["Onde fica {e}?", "Qual é a localização de {e}?", "Informe onde {e} está localizado."],
    "capacity": ["Qual é a capacidade de {e}?", "Informe a capacidade de {e}.", "Que capacidade está registrada para {e}?"],
    "weight": ["Qual é o peso de {e}?", "Quanto pesa {e}?", "Informe o peso registrado de {e}."],
    "length": ["Qual é o comprimento de {e}?", "Quanto mede {e}?", "Informe o comprimento registrado de {e}."],
    "count": ["Quantas unidades há em {e}?", "Qual é a quantidade de {e}?", "Informe a contagem de {e}."],
    "author": ["Quem é o autor de {e}?", "Quem escreveu {e}?", "Informe a autoria de {e}."],
    "capital": ["Qual é a capital de {e}?", "Informe a capital de {e}.", "Que cidade é a capital de {e}?"],
    "organization": ["Qual organização mantém {e}?", "Quem mantém {e}?", "Informe a organização responsável por {e}."],
    "port": ["Qual é a porta de rede de {e}?", "Em qual porta {e} atende?", "Informe a porta usada por {e}."],
    "license": ["Qual é a licença de {e}?", "Sob qual licença {e} é distribuído?", "Informe a licença registrada de {e}."],
    "latency": ["Qual é a latência de {e}?", "Quanto tempo de resposta {e} apresenta?", "Informe a latência medida de {e}."],
    "protocol": ["Qual protocolo {e} utiliza?", "Por qual protocolo {e} se comunica?", "Informe o protocolo de {e}."],
    "manufacturer": ["Quem fabrica {e}?", "Qual é o fabricante de {e}?", "Informe quem produziu {e}."],
    "priority": ["Qual é a prioridade de {e}?", "Em que nível de prioridade está {e}?", "Informe a prioridade registrada de {e}."],
    "region": ["Em qual região {e} está implantado?", "Qual é a região de implantação de {e}?", "Informe a região de {e}."],
    "checksum": ["Qual é o checksum de {e}?", "Informe o hash de integridade de {e}.", "Que checksum está registrado para {e}?"],
}

POSITION_LABEL = {
    "code": "código", "color": "cor", "temp": "temperatura", "owner": "responsável",
    "status": "status", "version": "versão", "material": "material", "language": "idioma",
    "date": "data", "location": "localização", "capacity": "capacidade", "weight": "peso",
    "length": "comprimento", "count": "quantidade", "author": "autoria", "capital": "capital",
    "organization": "organização responsável", "port": "porta de rede", "license": "licença",
    "latency": "latência", "protocol": "protocolo", "manufacturer": "fabricante",
    "priority": "prioridade", "region": "região de implantação", "checksum": "checksum",
}


GOLD_Q = {
    "code": ["Qual código está registrado para {e}?", "Diga o identificador de {e}."],
    "color": ["Que cor tem {e}?", "Qual cor consta para {e}?"],
    "temp": ["Qual temperatura consta para {e}?", "Diga a temperatura registrada de {e}."],
    "owner": ["Quem está responsável por {e}?", "Diga quem é responsável por {e}."],
    "status": ["Qual situação consta para {e}?", "Diga o estado atual de {e}."],
    "version": ["Que release consta para {e}?", "Diga a versão vigente de {e}."],
    "material": ["Qual composição material consta para {e}?", "Diga de que material {e} é feito."],
    "language": ["Que língua está registrada em {e}?", "Diga o idioma usado por {e}."],
    "date": ["Em que data está marcado {e}?", "Diga quando {e} está previsto."],
    "location": ["Em qual local está {e}?", "Diga a localização registrada de {e}."],
    "capacity": ["Quanto {e} comporta?", "Diga a capacidade registrada de {e}."],
    "weight": ["Que massa foi registrada para {e}?", "Diga quanto {e} pesa."],
    "length": ["Que medida de comprimento consta para {e}?", "Diga quanto {e} mede."],
    "count": ["Qual total de unidades consta em {e}?", "Diga a quantidade registrada de {e}."],
    "author": ["De quem é a autoria de {e}?", "Diga quem é o autor de {e}."],
    "capital": ["Qual cidade funciona como capital de {e}?", "Diga a capital registrada de {e}."],
    "organization": ["Que entidade responde por {e}?", "Diga qual organização cuida de {e}."],
    "port": ["Em qual endpoint numérico {e} está escutando?", "Diga a porta exposta por {e}."],
    "license": ["Qual termo de licenciamento rege {e}?", "Diga sob que licença está {e}."],
    "latency": ["Qual tempo de resposta foi medido em {e}?", "Diga a demora registrada de {e}."],
    "protocol": ["Que padrão de comunicação está ativo em {e}?", "Diga como {e} se comunica na rede."],
    "manufacturer": ["Qual empresa produziu {e}?", "Diga quem é o fabricante registrado de {e}."],
    "priority": ["Que nível de urgência consta para {e}?", "Diga a prioridade atribuída a {e}."],
    "region": ["Em qual zona de implantação está {e}?", "Diga a região operacional de {e}."],
    "checksum": ["Qual impressão de integridade consta para {e}?", "Diga o hash registrado de {e}."],
}


def code_for(n: int) -> str:
    letters = string.ascii_uppercase
    return letters[(n * 7) % 26] + letters[(n * 11 + 3) % 26] + f"-{1000+n:04d}"


def value_for(kind: str, n: int) -> str:
    if kind == "code": return code_for(n)
    if kind == "color": return COLORS[(n * 5) % len(COLORS)]
    if kind == "temp": return f"{5 + (n * 13) % 91} graus Celsius"
    if kind == "owner": return OWNERS[(n * 7) % len(OWNERS)]
    if kind == "status": return STATUSES[(n * 3) % len(STATUSES)]
    if kind == "version": return f"v{1 + n % 9}.{(n * 3) % 20}.{(n * 7) % 30}"
    if kind == "material": return MATERIALS[(n * 5 + 1) % len(MATERIALS)]
    if kind == "language": return LANGUAGES[(n * 3 + 2) % len(LANGUAGES)]
    if kind == "date": return f"{1 + (n * 7) % 28} de {MONTHS[(n * 5) % 12]} de {2025 + n % 4}"
    if kind == "location": return LOCATIONS[(n * 7 + 1) % len(LOCATIONS)]
    if kind == "capacity": return f"{16 + (n * 16) % 496} gigabytes"
    if kind == "weight": return f"{2 + (n * 11) % 180} quilogramas"
    if kind == "length": return f"{1 + (n * 13) % 90} metros"
    if kind == "count": return f"{1 + (n * 17) % 250} unidades"
    if kind == "author": return AUTHORS[(n * 5 + 3) % len(AUTHORS)]
    if kind == "capital": return CAPITALS[(n * 3 + 1) % len(CAPITALS)]
    if kind == "organization": return ORGS[(n * 5 + 2) % len(ORGS)]
    if kind == "port": return str(1024 + (n * 37) % 54000)
    if kind == "license": return LICENSES[(n * 5 + 1) % len(LICENSES)]
    if kind == "latency": return f"{3 + (n * 17) % 180} milissegundos"
    if kind == "protocol": return PROTOCOLS[(n * 3 + 1) % len(PROTOCOLS)]
    if kind == "manufacturer": return MANUFACTURERS[(n * 5 + 2) % len(MANUFACTURERS)]
    if kind == "priority": return PRIORITIES[(n * 3) % len(PRIORITIES)]
    if kind == "region": return REGIONS[(n * 5 + 1) % len(REGIONS)]
    if kind == "checksum": return f"{(0x9e3779b1 * (n + 17)) & 0xffffffffffff:012x}"
    raise KeyError(kind)


def sentence_for(kind: str, entity: str, value: str, variant: int) -> str:
    table = {
        "code": [f"O registro de {entity} informa o código {value}.", f"Para {entity}, o identificador válido é {value}.", f"{entity} está associado ao código {value}."],
        "color": [f"A ficha de {entity} registra a cor {value}.", f"A cor atribuída a {entity} é {value}.", f"{entity} está marcado com a cor {value}."],
        "temp": [f"A temperatura de referência de {entity} é {value}.", f"O sensor de {entity} registra {value}.", f"Para {entity}, a temperatura anotada é {value}."],
        "owner": [f"O responsável registrado por {entity} é {value}.", f"{value} é responsável pelo projeto {entity}.", f"A pessoa responsável por {entity} é {value}."],
        "status": [f"O status atual de {entity} é {value}.", f"{entity} está marcado como {value}.", f"No registro, a situação de {entity} consta como {value}."],
        "version": [f"A versão registrada de {entity} é {value}.", f"{entity} está atualmente na versão {value}.", f"O release associado a {entity} é {value}."],
        "material": [f"O material principal de {entity} é {value}.", f"{entity} é fabricado principalmente em {value}.", f"A ficha técnica de {entity} informa {value} como material."],
        "language": [f"O idioma registrado de {entity} é {value}.", f"{entity} utiliza o idioma {value}.", f"Na configuração de {entity}, a língua selecionada é {value}."],
        "date": [f"A data registrada de {entity} é {value}.", f"{entity} está programado para {value}.", f"O calendário marca {entity} em {value}."],
        "location": [f"A localização registrada de {entity} é {value}.", f"{entity} está localizado em {value}.", f"O cadastro situa {entity} em {value}."],
        "capacity": [f"A capacidade registrada de {entity} é {value}.", f"{entity} comporta {value}.", f"A ficha técnica informa capacidade de {value} para {entity}."],
        "weight": [f"O peso registrado de {entity} é {value}.", f"{entity} pesa {value}.", f"A ficha técnica de {entity} informa massa de {value}."],
        "length": [f"O comprimento registrado de {entity} é {value}.", f"{entity} mede {value}.", f"A ficha de {entity} informa comprimento de {value}."],
        "count": [f"A quantidade registrada em {entity} é {value}.", f"{entity} contém {value}.", f"O inventário de {entity} contabiliza {value}."],
        "author": [f"A autoria registrada de {entity} é de {value}.", f"{entity} foi produzido por {value}.", f"O autor indicado para {entity} é {value}."],
        "capital": [f"A capital registrada de {entity} é {value}.", f"{value} é a capital de {entity}.", f"O cadastro geográfico indica {value} como capital de {entity}."],
        "organization": [f"A organização responsável por {entity} é {value}.", f"{value} mantém {entity}.", f"{entity} é administrado por {value}."],
        "port": [f"O serviço {entity} escuta em {value}.", f"{entity} publica o endpoint TCP em {value}.", f"A configuração de {entity} define {value} como porta de atendimento."],
        "license": [f"{entity} é distribuído sob {value}.", f"O licenciamento vigente de {entity} segue {value}.", f"A ficha legal associa {entity} a {value}."],
        "latency": [f"O tempo de resposta medido para {entity} foi {value}.", f"{entity} apresentou demora de {value} no ensaio.", f"A medição de desempenho de {entity} registrou {value}."],
        "protocol": [f"A comunicação de {entity} usa {value}.", f"{entity} troca mensagens por {value}.", f"O transporte configurado para {entity} é {value}."],
        "manufacturer": [f"{entity} foi produzido por {value}.", f"A origem industrial de {entity} é {value}.", f"O cadastro de {entity} indica {value} como fabricante."],
        "priority": [f"{entity} foi classificado com prioridade {value}.", f"O nível de urgência de {entity} é {value}.", f"A fila operacional marca {entity} como prioridade {value}."],
        "region": [f"{entity} foi implantado em {value}.", f"A zona operacional de {entity} é {value}.", f"O deployment de {entity} reside em {value}."],
        "checksum": [f"A impressão de integridade de {entity} é {value}.", f"{entity} possui hash registrado {value}.", f"O verificador associa {entity} ao checksum {value}."],
    }
    base = table[kind]
    positional = [
        f"{value} é o valor registrado para {POSITION_LABEL[kind]} de {entity}.",
        f"Para {entity}, o valor {value} consta no campo de {POSITION_LABEL[kind]}.",
    ]
    variants = base + positional
    return variants[variant % len(variants)]


def build_context():
    rng = random.Random(SEED)
    train = []
    golden = []
    kinds = tuple(TRAIN_Q)
    total = TRAIN_ENTITIES + GOLD_ENTITIES
    for n in range(total):
        holdout = n >= TRAIN_ENTITIES
        entity = f"Registro-{5000+n}"
        for ki, kind in enumerate(kinds):
            value = value_for(kind, n * len(kinds) + ki)
            context = sentence_for(kind, entity, value, (n + ki) % 5)
            answer = value
            templates = GOLD_Q[kind] if holdout else TRAIN_Q[kind]
            if holdout:
                # Exactly one unseen phrasing per held-out entity/relation keeps
                # the golden set independent and easy to audit.
                template = templates[(n + ki) % len(templates)]
                golden.append({
                    "question": template.format(e=entity),
                    "context": context,
                    "answer": answer,
                    "kind": kind + "_holdout",
                })
            else:
                for template in templates:
                    train.append({
                        "question": template.format(e=entity),
                        "context": context,
                        "answer": answer,
                        "kind": kind,
                    })
    rng.shuffle(train)
    random.Random(SEED + 1).shuffle(golden)
    return train, golden


if __name__ == "__main__":
    tr, go = build_context()
    print({"train": len(tr), "gold": len(go), "kinds": len(TRAIN_Q)})
