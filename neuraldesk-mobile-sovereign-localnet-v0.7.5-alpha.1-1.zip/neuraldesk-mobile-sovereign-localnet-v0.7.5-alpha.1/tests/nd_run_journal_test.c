#include "nd_run_journal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    const char *path = "/tmp/neuraldesk-run-journal-test.ndjr";
    remove(path);
    NDRunJournal j; nd_run_journal_init(&j); char err[256];
    if (nd_run_journal_set_path(&j, path, err, sizeof(err))) return 1;
    size_t abandoned = 0u;
    if (nd_run_journal_recover(&j, &abandoned, err, sizeof(err)) || abandoned != 0u) return 1;
    uint64_t a = 0u, b = 0u;
    if (nd_run_journal_begin(&j, "MICRO", &a, err, sizeof(err))) return 1;
    if (nd_run_journal_progress(&j, a, "ROUTING", "LOCAL", err, sizeof(err))) return 1;
    if (nd_run_journal_progress(&j, a, "OUTPUT_GUARD", "KNOWLEDGE", err, sizeof(err))) return 1;
    if (nd_run_journal_end(&j, a, "COMPLETED", "KNOWLEDGE", err, sizeof(err))) return 1;
    if (nd_run_journal_begin(&j, "MOBILE", &b, err, sizeof(err))) return 1;
    if (nd_run_journal_progress(&j, b, "ROUTING", "LOCAL", err, sizeof(err))) return 1;
    if (nd_run_journal_drain(&j, b, "REQUESTED", err, sizeof(err))) return 1;
    NDRunJournal j2; nd_run_journal_init(&j2);
    if (nd_run_journal_set_path(&j2, path, err, sizeof(err))) return 1;
    if (nd_run_journal_recover(&j2, &abandoned, err, sizeof(err)) || abandoned != 1u) return 1;
    FILE *f=fopen(path,"rb"); if(!f) return 1; fseek(f,0,SEEK_END); long n=ftell(f); fclose(f); if(n<=0) return 1;
    remove(path);
    printf("RUN_JOURNAL PASS abandoned=%zu bytes=%ld progress=true drain=true raw_content_persisted=false\n", abandoned, n);
    return 0;
}
