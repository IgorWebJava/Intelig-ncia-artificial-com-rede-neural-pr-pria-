<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 122 — Preview Generation Workflow

```text
Canonical UI
+ Module CSS
→ Chromium / Playwright
→ Standard viewport
→ PNG preview
→ preview.json hashes
→ Preview Registry
→ validate_previews.py
```

HTML and CSS hashes are recorded so stale previews can be detected automatically.
