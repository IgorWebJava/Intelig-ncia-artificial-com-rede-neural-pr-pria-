<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Audit, Trace & Observability

    Skill ID: `neuraldesk.audit-observability.v1`

    ## Category

    `observability`

    ## Introduced

    `V6.8`

    ## Required development capabilities

    - `audit.trace.design.v1`
- `observability.design.v1`
- `browser.render.v1`

    ## Used by

    - `audit`
- `operations`
- `system-config`
- `all-modules`

    ## Related project artifacts

    - `modules/audit/`
- `platform/observability/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
