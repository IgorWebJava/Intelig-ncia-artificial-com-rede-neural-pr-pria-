#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/scripts/pre_generation_lessons_check.py"
KOTLINC="$(command -v kotlinc || true)"
if [[ -z "$KOTLINC" ]]; then
  echo "kotlinc não encontrado; gate Kotlin host não pode ser executado" >&2
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/CanonicalAssetStoreProbe.kt" <<'KT'
package com.neuraldesk.localnet

import java.io.ByteArrayInputStream
import java.io.File
import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("nd-asset-sync-").toFile()
    try {
        val target = File(dir, "model.ndos")
        val first = "canonical-v1".toByteArray()
        val second = "canonical-v2-with-new-bytes".toByteArray()

        CanonicalAssetStore.install(target, ByteArrayInputStream(first))
        check(target.readBytes().contentEquals(first)) { "missing -> install falhou" }

        check(target.setLastModified(1_600_000_000_000L))
        val unchangedTime = target.lastModified()
        CanonicalAssetStore.install(target, ByteArrayInputStream(first))
        check(target.readBytes().contentEquals(first)) { "same -> conteúdo mudou" }
        check(target.lastModified() == unchangedTime) { "same -> asset foi reescrito sem necessidade" }

        target.writeText("stale")
        CanonicalAssetStore.install(target, ByteArrayInputStream(second))
        check(target.readBytes().contentEquals(second)) { "stale -> replace falhou" }
        check(!File(dir, ".model.ndos.installing").exists()) { "staging residual" }
        val caps = MobileHardwareCapabilities(8192L, 8, true, MobileAbi.ARM64, gpuDetected = true, npuDetected = true)
        check(MobileProfilePolicy.route(caps).selected == HardwareProvider.CPU_C99)
        check(MobileProfilePolicy.route(caps, HardwareProvider.GPU).status == HardwareRouteStatus.PROVIDER_UNAVAILABLE)
        check(MobileProfilePolicy.route(caps, HardwareProvider.NPU).status == HardwareRouteStatus.PROVIDER_UNAVAILABLE)
        check(MobileProfilePolicy.abiFromName("arm64-v8a") == MobileAbi.ARM64)
        println("CANONICAL_ASSET_SYNC PASS missing/same/stale hardware_route_fail_closed")
    } finally {
        dir.deleteRecursively()
    }
}
KT
"$KOTLINC" \
  "$ROOT/android/app/src/main/java/com/neuraldesk/localnet/NativeEngine.kt" \
  "$ROOT/android/app/src/main/java/com/neuraldesk/localnet/MobileProfilePolicy.kt" \
  "$ROOT/android/app/src/main/java/com/neuraldesk/localnet/ContextSelector.kt" \
  "$ROOT/android/app/src/main/java/com/neuraldesk/localnet/RuntimeIdentity.kt" \
  "$ROOT/android/app/src/main/java/com/neuraldesk/localnet/CanonicalAssetStore.kt" \
  "$ROOT/android/app/src/main/java/com/neuraldesk/localnet/WebContextClient.kt" \
  "$TMP/CanonicalAssetStoreProbe.kt" \
  -include-runtime -d "$TMP/neuraldesk-kotlin-host.jar"
[[ -s "$TMP/neuraldesk-kotlin-host.jar" ]]
java -jar "$TMP/neuraldesk-kotlin-host.jar"
printf 'KOTLIN_HOST_COMPILE PASS\n'
