import time
from flask import Flask, request, jsonify, send_file
from qcnn.core.pipeline import QcnnPipeline
from qcnn.plugins.ternary_bitwise import TernaryBitwisePlugin
from qcnn.plugins.milui_expansion import MiluiExpansionPlugin
from qcnn.plugins.adjacency_filter import AdjacencyFilterPlugin
from qcnn.plugins.harmonic_frequency import HarmonicFrequencyPlugin
from qcnn.plugins.hyperdimensional_computing import HyperdimensionalComputingPlugin
from qcnn.plugins.fractal_grammar import FractalGrammarPlugin
from qcnn.plugins.continuous_ingestion import ContinuousIngestionPlugin
from qcnn.plugins.assistant_toolkit import AssistantToolkitPlugin
from qcnn.plugins.multiverse_oracle import MultiverseOraclePlugin
from qcnn.plugins.mycelium_index import MyceliumIndexPlugin
from qcnn.plugins.conceptual_dialogue import ConceptualDialoguePlugin
from qcnn.plugins.octave_regulator import OctaveRegulatorPlugin
from qcnn.plugins.organ_multiplexer import OrganMultiplexerPlugin
from qcnn.plugins.fractal_breaker import FractalBreakerPlugin
from qcnn.plugins.context_crystallizer import ContextCrystallizerPlugin
from qcnn.plugins.metacognitive_auditor import MetaCognitiveAuditorPlugin
from qcnn.plugins.self_healing_consensus import SelfHealingConsensusPlugin
from qcnn.plugins.autonomous_consolidation import AutonomousConsolidationPlugin
from qcnn.plugins.goal_driven_agent_loop import GoalDrivenAgentLoopPlugin
from qcnn.plugins.holographic_snapshot_store import HolographicSnapshotStorePlugin
from qcnn.plugins.visual_matrix import VisualMatrixPlugin
from qcnn.plugins.audio_waveform import AudioWaveformPlugin
from qcnn.plugins.code_synthesis import CodeSynthesisPlugin
from qcnn.plugins.file_manager import FileManagerPlugin
from qcnn.plugins.video_sequencer import VideoSequencerPlugin
from qcnn.plugins.telemetry_meter import TelemetryMeterPlugin

app = Flask(__name__, static_folder='.', static_url_path='')

# Instanciação do Pipeline Modular do QCNN Engine v6.0 / MULTI-V Multimodal
pipeline = QcnnPipeline()
pipeline.register_plugin(TernaryBitwisePlugin())
pipeline.register_plugin(MiluiExpansionPlugin())
pipeline.register_plugin(AdjacencyFilterPlugin())
pipeline.register_plugin(HarmonicFrequencyPlugin())
pipeline.register_plugin(HyperdimensionalComputingPlugin(dimension=10000))
pipeline.register_plugin(FractalGrammarPlugin())
pipeline.register_plugin(ContinuousIngestionPlugin(knowledge_dir="./conhecimento_local"))
pipeline.register_plugin(AssistantToolkitPlugin(storage_dir="./storage_android"))
pipeline.register_plugin(MultiverseOraclePlugin())
pipeline.register_plugin(MyceliumIndexPlugin())
pipeline.register_plugin(ConceptualDialoguePlugin(pasta_conhecimento="./conhecimento_local"))
pipeline.register_plugin(VisualMatrixPlugin())
pipeline.register_plugin(AudioWaveformPlugin())
pipeline.register_plugin(CodeSynthesisPlugin())
pipeline.register_plugin(FileManagerPlugin(base_dir="./arquivos_gerados"))
pipeline.register_plugin(VideoSequencerPlugin())
pipeline.register_plugin(OrganMultiplexerPlugin())
pipeline.register_plugin(OctaveRegulatorPlugin())
pipeline.register_plugin(FractalBreakerPlugin())
pipeline.register_plugin(ContextCrystallizerPlugin(storage_dir="./storage_android"))
pipeline.register_plugin(MetaCognitiveAuditorPlugin())
pipeline.register_plugin(SelfHealingConsensusPlugin())
pipeline.register_plugin(AutonomousConsolidationPlugin())
pipeline.register_plugin(GoalDrivenAgentLoopPlugin())
pipeline.register_plugin(HolographicSnapshotStorePlugin(db_path="./storage_android/qcnn_holographic_store.db"))
pipeline.register_plugin(TelemetryMeterPlugin())

@app.route('/')
def index():
    return send_file('interface.html')

@app.route('/colapsar', methods=['POST'])
def colapsar():
    data = request.get_json(force=True, silent=True) or {}
    prompt = data.get('prompt', '')
    if not prompt:
        return jsonify({
            'resposta': 'Prompt vazio. Envie uma semente ou pergunta.',
            'arvore': 'Alef',
            'frequencia': '121.35 Hz',
            'estado': '00 (Vácuo)',
            'latencia': '0.000ms',
            'metadata': {}
        })

    meta = {
        'prisma_risco': float(data.get('prisma_risco', 0.5)),
        'filosofia': str(data.get('filosofia', 'Dialética')),
        'rigor_logico': float(data.get('rigor_logico', 0.8))
    }

    result = pipeline.process(prompt, metadata=meta)
    return jsonify(result.to_dict())

@app.route('/status', methods=['GET'])
def status():
    return jsonify({
        'engine': 'QCNN Engine v5.0',
        'status': 'ONLINE_OFFLINE_READY',
        'plugins': pipeline.list_plugins()
    })

if __name__ == '__main__':
    print(f"[*] QCNN Engine v5.0 iniciado com os plugins: {pipeline.list_plugins()}")
    app.run(host='0.0.0.0', port=5000, debug=False)
