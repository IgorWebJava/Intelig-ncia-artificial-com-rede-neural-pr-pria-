<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Quality Governance — V7.3

## Rule

A module without its `tests/` package is incomplete.

## Ownership

The same team that owns the module owns:

- code/UI;
- contracts;
- data migrations;
- documentation;
- tests;
- compatibility matrix.

## Truthfulness

Static-template tests must not claim backend behavior is implemented.
Backend-dependent tests stay labeled `future-integration`, `future-e2e` or equivalent until the real runtime exists.

## Release evidence

Generated test reports belong in `docs/verification/` and module-local `tests/reports/`.
