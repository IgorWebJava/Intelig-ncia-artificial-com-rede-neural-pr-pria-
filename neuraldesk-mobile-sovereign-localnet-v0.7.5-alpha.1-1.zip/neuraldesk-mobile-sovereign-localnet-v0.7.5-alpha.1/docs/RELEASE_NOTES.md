# v0.7.5-alpha.1 — Historical Capability Convergence

Development candidate only. Ports the remaining superior historical mobile mechanics that have current owners: real computational/UTF-8 streaming, fail-closed hardware routing, bounded lifecycle observability, current-byte governance and deterministic gradient accumulation. No generative weights are promoted.

# Release Notes

## v0.7.4-alpha.2 — Generative Runtime & Training Candidate

- reconstrução nova sobre o ZIP final v0.7.3; alpha.1 perdida não é tratada como source;
- NDGM v3 C99 mechanics: full-forward/incremental, paged KV/COW/prefix reuse/speculative target parity;
- corpus generativo materializado com 1.342 SFT + 1.342 replay + 140 Pirá validation EVALUATION_ONLY e leakage global zero;
- NDTK v1 train-only; trainer stage-only com checkpoint/resume;
- nenhum backbone generativo promovido/ativado.

## v0.7.3-alpha.1 — Mobile Runtime Hardening

Rebase físico sobre v0.7.2 integral, preservando v0.7.1 como rollback externamente atestado. Nenhum peso neural/dataset promovido mudou. Implementa cooperative cancel/deadline, JNI single-flight/free-waits-idle, Resource Governor efetivo, assets streaming SHA-256, RAG `NDRAG001` dedup/replace/LRU/persistence, thermal bridge Android e Research Memory opt-in AES-GCM/Keystore. Mantém explícito que não existe backbone generativo promovido nem token streaming autoregressivo. Source gates/reextract/freeze ainda são obrigatórios.


## v0.7.2-alpha.1 — Offline Continuity & Deep Historical Convergence

Preserva v0.7.1 como rollback. Adiciona Adaptive Network Policy, Durable Local Task Outbox, Local Projects, Pilot/Master Kill, Model Acquisition Preflight, Benchmark Evaluation e governed checkpoint averaging. Nenhum peso neural ou dataset promovido mudou. Todas as capacidades continuam first-party-only e os recursos historicamente remotos foram reexpressos sem backend externo.

— v0.7.1-alpha.1

## Delta de convergência

Recupera Robust Intent, adiciona Semantic Core, Semantic Ranker 131.200 parâmetros, Local RAG semantic rerank, Safety, Resource Governor, Text Utilities, Reliability Journal, training checkpoint/resume, Device Lab software, Android toolchain admission, cross-target ABI e model promotion/activation separadas. Preserva todas as baselines funcionais v0.6.1/v0.6.2.

## Delta v0.6.2-alpha.1 sobre a reconstrução alpha.2

- parser matemático completo bounded: 16/16 regressões;
- planner único e compartilhado por assistant/context grounding;
- preâmbulo, distribuição por tópico e herança de entidade corrigidos;
- memória `tipo de <atributo>` grounded;
- fallback sparse KB posterior à recusa neural, endurecido contra troca de entidade fictícia;
- relação morfológica conservadora no grounding;
- estado de follow-up de um turno e políticas conversacionais transparentes;
- `nd_conversational_correctness_test`: 12/12;
- Live QA: 35/35 após hardening;
- **0 alteração** nos cinco assets canônicos, pesos neurais ou datasets promovidos;
- promoção/release continua bloqueada até `verify` + `sanitize` completos desta versão e revalidação do ZIP.

## Baseline histórica preservada — delta alpha.2 sobre v0.5

A release preserva os quatro assets v0.5 e adiciona um quinto asset não-neural: `NDOS v1` com 31 registros humanos Pirá 2.0. O fallback é subordinado à rota canônica existente.

### Implementado

- NDOS v1 / `NDOSV001`;
- UTF-8→ASCII parity Python/C;
- FNV-1a 64-bit padrão + 65.536 buckets;
- TF-IDF top-96, score+margin fail-closed;
- loader defensivo;
- integração CLI/JNI/Android asset source única;
- planner de preâmbulo tópico corrigido;
- 53/53 parity, 28/28 raw, 25/25 accepted correct, 0/25 negatives;
- holdout 3/3 raw, 2/2 accepted correct;
- 4/4 corruption rejection;
- 2/2 byte-identical rebuild.

### Identidade de reconstrução

Esta é alpha.2 porque a árvore alpha.1 descrita posteriormente não estava recuperável. Nenhum hash antigo foi fabricado/reutilizado.

### Hardening após auditoria integral

- `CanonicalAssetStore` substitui cópias Android stale por conteúdo, com staging + fsync + replace atômico;
- probe JVM permanente para missing/same/stale;
- UI/User-Agent alinhados a `RuntimeIdentity.VERSION`;
- Retriever/Pointer bloqueiam exportação quando o Golden obrigatório falha;
- `VERIFY`/`SANITIZER` emitem versão e metadata rejeita logs de release diferente;
- documentação completa sincronizada com a ordem real do `NDAssistant`;
- novo gate `verify_documentation_consistency.py` cruza manifest, assets, docs e Android.

## Estado de fechamento da auditoria

O fechamento da v0.6.1 usa evidence vinculada ao digest. `AUDIT_STATUS.json` registra o estado operacional corrente; `REPORT.json` é gerado somente quando logs e receipts de VERIFY/SANITIZER correspondem ao mesmo digest. O ZIP só é promovível após reextração em árvore vazia e repetição das mesmas fases com receipts novos e externos.

## Gate retomável vinculado aos inputs

A v0.6.1 mantém os mesmos testes, mas permite executar o fechamento em fases determinísticas quando a janela externa não comporta o agregador monolítico. Cada fase concluída gera um receipt externo à release por `scripts/verification_checkpoint.py`, contendo versão, fase e SHA-256 canônico dos inputs. A fase final exige todos os receipts da mesma versão/digest. Mudança em código, documentação, manifest, modelos ou datasets invalida automaticamente a retomada. Esse mecanismo não transforma timeout em PASS e não autoriza pular cobertura.

## Release pipeline hardening
A auditoria pré-freeze encontrou metadata de calculadora antiga (10/10) e revalidação monolítica no empacotador. A v0.6.1 corrige isso: metadata deriva o contrato atual do manifest, exige o mesmo digest nos logs/receipts e registra conversational correctness 12/12; o empacotador reexecuta as fases retomáveis no ZIP reextraído e só então pode emitir attestação externa.


## v0.6.2-alpha.1

Candidata `Dialogue Grounding & Structured Memory`. Corrige binding de memória multiatributo, falso follow-up por pronome, perda de sigla explícita no retrieval, implicação universal não suportada e ausência de resumo bounded multi-turn. Adiciona holdout 7/7 e mantém modelos/datasets sem alteração. Rollback oficial: v0.6.1-alpha.1 final SHA-256 `199a8233ed2f6fb779063ac9551f5e32762d3b43e33eb7b0b4db6bad089ad112`.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
