#!/usr/bin/env python3
from pathlib import Path
import json
import re

r = Path('.')
required = [
    'README.md', '.gitignore', 'CMakeLists.txt', 'PROJECT_MANIFEST.json',
    'memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md', 'scripts/pre_generation_lessons_check.py',
    'scripts/generate_release_metadata.py', 'scripts/package_release.py',
    'core/include/nd_assistant.h', 'core/src/nd_assistant.c',
    'core/include/nd_context_qa.h', 'core/src/nd_context_qa.c',
    'core/include/nd_context_synth.h', 'core/src/nd_context_synth.c',
    'core/include/nd_relation.h', 'core/src/nd_relation.c',
    'core/include/nd_knowledge.h', 'core/src/nd_knowledge.c',
    'core/include/nd_tools.h', 'core/src/nd_tools.c',
    'core/include/nd_planner.h', 'core/src/nd_planner.c',
    'core/include/nd_memory.h', 'core/src/nd_memory.c',
    'core/include/nd_open_knowledge.h', 'core/src/nd_open_knowledge.c', 'cli/main.c',
    'training/context_data.py', 'training/knowledge_base.py',
    'training/train_context_pointer.py', 'training/train_relation_classifier.py',
    'training/train_knowledge_retriever.py', 'training/train_release.py', 'training/materialize_datasets.py',
    'training/build_open_knowledge_shard.py', 'training/data/open_knowledge/pira_reconstruction_records_v1.jsonl',
    'android/app/src/main/cpp/neuraldesk_jni.c',
    'android/app/src/main/java/com/neuraldesk/localnet/NativeEngine.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/RuntimeIdentity.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/CanonicalAssetStore.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/MainActivity.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/WebContextClient.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/WikipediaResearchClient.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/ResearchMemoryStore.kt',
    'android/app/src/main/java/com/neuraldesk/localnet/ContextSelector.kt',
    'models/neuraldesk-knowledge-retriever-v0.5.ndkr',
    'models/neuraldesk-knowledge-v0.5.ndkb',
    'models/neuraldesk-context-pointer-v0.5.ndqa',
    'models/neuraldesk-relation-classifier-v0.5.ndrl',
    'models/neuraldesk-open-knowledge-pira-v0.6.ndos',
    'models/neuraldesk-semantic-ranker-v0.7.1.ndsr',
    'core/include/nd_network_policy.h', 'core/src/nd_network_policy.c',
    'core/include/nd_pilot.h', 'core/src/nd_pilot.c',
    'core/include/nd_model_acquisition.h', 'core/src/nd_model_acquisition.c',
    'core/include/nd_outbox.h', 'core/src/nd_outbox.c',
    'core/include/nd_project.h', 'core/src/nd_project.c',
    'core/include/nd_benchmark.h', 'core/src/nd_benchmark.c',
    'training/weight_averaging.py', 'tests/nd_execution_control_test.c',
    'tests/nd_dialogue_grounding_v062_test.c',
    'docs/CURRENT_STATE.md', 'docs/SOURCE_OF_TRUTH.md', 'docs/TRAINING.md',
    'docs/EVALUATION.md', 'docs/TRUTH_BOUNDARY.md', 'docs/CLEANUP_AUDIT.md',
    'docs/OPEN_KNOWLEDGE_SHARD.md', 'docs/RECONSTRUCTION_LINEAGE.md',
    'docs/COMPREHENSIVE_AUDIT.md', 'docs/DIALOGUE_GROUNDING_V062.md', 'docs/DOCUMENTATION_INDEX.md',
]
for x in required:
    assert (r / x).is_file(), x

for dead in [
    'training/knowledge_base_v03.py','training/train_response_policy.py','training/response_policy_data.py','training/train_evidence_reranker.py',
    'models/neuraldesk-knowledge-retriever-v0.3.ndkr','models/neuraldesk-knowledge-v0.3.ndkb','models/neuraldesk-context-pointer-v0.3.ndqa',
    'models/neuraldesk-knowledge-retriever-v0.4.ndkr','models/neuraldesk-knowledge-v0.4.ndkb','models/neuraldesk-context-pointer-v0.4.ndqa',
]:
    assert not (r / dead).exists(), f'superseded artifact present: {dead}'


assert (r/'scripts/model_authority.py').is_file(), 'canonical model authority missing'
assert not (r/'tools/model_authority.py').exists(), 'parallel model authority detected'
manifest = json.loads((r / 'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))
version = manifest['version']
assert re.fullmatch(r'0\.7\.[0-9]+-alpha\.[1-9][0-9]*', version), version
assert manifest['architecture']['knowledgeRecords'] == 201
assert manifest['architecture']['contextRelationFamilies'] == 25
assert manifest['architecture']['neuralParametersTotal'] == 674294
assert manifest['mandatoryPreGenerationRead']['path'] == 'memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md'

android = (r / 'android/app/build.gradle.kts').read_text(encoding='utf-8')
assert f'versionCode = {manifest["android"]["versionCode"]}' in android
assert f'versionName = "{version}"' in android
assert 'assets.srcDir("../../models")' in android

files = [
    p for p in r.rglob('*')
    if p.is_file() and p.suffix in {'.c', '.h', '.kt', '.py', '.kts'}
    and p.name != 'verify_project.py'
    and not any(part.startswith('build') for part in p.parts)
]
src = '\n'.join(p.read_text(errors='ignore') for p in files).lower()
bads = [
    'openai' + '.com/v1', 'anthropic' + '.com',
    'generativelanguage' + '.googleapis.com', 'api.' + 'moonshot',
    'api.' + 'openai.com', 'api.' + 'anthropic.com',
]
for bad in bads:
    assert bad not in src, bad
print('project-sovereignty-and-canonicality PASS', len(files), 'source files scanned')
