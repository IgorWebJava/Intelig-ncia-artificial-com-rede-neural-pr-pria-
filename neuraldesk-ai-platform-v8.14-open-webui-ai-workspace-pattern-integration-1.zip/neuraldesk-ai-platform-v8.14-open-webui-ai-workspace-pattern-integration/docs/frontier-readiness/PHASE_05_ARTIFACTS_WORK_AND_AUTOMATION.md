# Phase 05 — Artifacts, Long-Running Work and Automation

Status: DOCUMENTATION-ONLY


Implement task runtime, checkpoint/resume, background jobs, artifact runtime and notification delivery.

Required behaviors:
- durable task states;
- restart-safe checkpoints;
- pause/resume across conversations and projects;
- artifacts are versioned and validated;
- completed work has provenance;
- long jobs survive client disconnect;
- users can stop/cancel/reprioritize within policy.

Exit result: NeuralDesk can complete multi-step work and deliver verified files/projects rather than only responses.
