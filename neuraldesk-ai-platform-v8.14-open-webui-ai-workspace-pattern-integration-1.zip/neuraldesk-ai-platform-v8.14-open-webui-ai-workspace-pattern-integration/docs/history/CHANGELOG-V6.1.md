<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# V6.1 — Decoupled Independent Pages

- `index.html` convertido em launcher.
- `chat.html` criado.
- `training.html` criado.
- `settings.html` criado.
- `dashboard-center.html` mantido independente.
- `knowledge-center.html` mantido independente.
- `tools-center.html` mantido independente.
- Navegação entre módulos alterada para páginas reais.
- Documentação de desacoplamento adicionada.
- Continua HTML + CSS somente.
