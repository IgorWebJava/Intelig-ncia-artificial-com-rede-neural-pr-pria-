#include "nd_memory.h"

#include <stdio.h>
#include <string.h>

int main(void) {
    const char *path = "nd-memory-test.bin";
    remove(path);
    NDMemory m;
    char err[256];
    char out[1024];
    int handled = 0;
    int bad = 0;

    nd_memory_init(&m);
    if (nd_memory_set_path(&m, path, err, sizeof(err))) bad++;
    if (nd_memory_handle_command(&m, "Lembre que o código do projeto Atlas é ZX-731.",
                                 out, sizeof(out), &handled, err, sizeof(err)) || !handled) bad++;
    NDMemoryResult r;
    NDMemoryFactResult fr;
    if (nd_memory_query(&m, "Qual é o código do projeto Atlas?", &r, err, sizeof(err)) ||
        !r.found || !r.text || strstr(r.text, "ZX-731") == NULL) bad++;
    handled = 0;
    if (nd_memory_handle_command(&m,
                                 "Lembre que o robô Aurora-3 usa sensor LiDAR e é coordenado por Renata.",
                                 out, sizeof(out), &handled, err, sizeof(err)) || !handled) bad++;
    if (nd_memory_query_fact(&m, "Qual sensor o robô Aurora-3 usa?", &fr, err, sizeof(err)) ||
        !fr.found || !fr.value || strcmp(fr.value, "LiDAR") != 0) bad++;
    if (nd_memory_query_fact(&m, "Quem coordena o robô Aurora-3?", &fr, err, sizeof(err)) ||
        !fr.found || !fr.value || strcmp(fr.value, "Renata") != 0) bad++;
    nd_memory_free(&m);

    nd_memory_init(&m);
    if (nd_memory_load(&m, path, err, sizeof(err))) bad++;
    if (nd_memory_query(&m, "Qual é o código do projeto Atlas?", &r, err, sizeof(err)) ||
        !r.found || !r.text || strstr(r.text, "ZX-731") == NULL) bad++;
    if (nd_memory_query_fact(&m, "Qual sensor o robô Aurora-3 usa?", &fr, err, sizeof(err)) ||
        !fr.found || !fr.value || strcmp(fr.value, "LiDAR") != 0) bad++;
    if (nd_memory_query_fact(&m, "Quem coordena o robô Aurora-3?", &fr, err, sizeof(err)) ||
        !fr.found || !fr.value || strcmp(fr.value, "Renata") != 0) bad++;
    handled = 0;
    if (nd_memory_handle_command(&m, "Limpe a memória local", out, sizeof(out), &handled,
                                 err, sizeof(err)) || !handled || m.count != 0u) bad++;
    nd_memory_free(&m);
    remove(path);

    if (bad) {
        fprintf(stderr, "memory failures=%d\n", bad);
        return 1;
    }
    puts("memory PASS");
    return 0;
}
