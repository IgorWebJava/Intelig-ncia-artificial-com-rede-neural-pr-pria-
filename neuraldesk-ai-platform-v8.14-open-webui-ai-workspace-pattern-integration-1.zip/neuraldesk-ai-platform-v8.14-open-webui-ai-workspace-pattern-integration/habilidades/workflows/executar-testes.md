<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Executar Testes

Local por módulo:
`python modules/<module>/tests/run_module_tests.py`

Global:
`python tools/run_all_module_tests.py`

Visual:
`python tools/run_all_visual_tests.py`

Não confundir testes estruturais atuais com cenários E2E que dependem do backend futuro.
