# Artifact and Work-Product Strategy

NeuralDesk should produce usable outcomes, not only prose.

Artifact classes:
documents, code projects, websites, datasets, spreadsheets, presentations, images, reports, diagrams and packages.

Lifecycle:
draft -> validate -> version -> compare -> approve -> deliver -> archive.

Every artifact records:
project, task, inputs, agents/models/tools, sources, validations, version, checksum and delivery status.
