package com.example.engine.core

import org.json.JSONArray
import org.json.JSONObject

data class CollapseResult(
    val resposta: String,
    val arvore: String,
    val estado: String,
    val frequencia: String,
    val latencia: String,
    val metadata: Map<String, Any> = emptyMap()
) {
    fun toJson(): String {
        val jsonObj = JSONObject().apply {
            put("resposta", resposta)
            put("arvore", arvore)
            put("estado", estado)
            put("frequencia", frequencia)
            put("latencia", latencia)
            put("metadata", wrapJsonValue(metadata))
        }
        return jsonObj.toString()
    }

    companion object {
        fun wrapJsonValue(value: Any?): Any {
            return when (value) {
                null -> JSONObject.NULL
                is JSONObject, is JSONArray -> value
                is Map<*, *> -> {
                    val jobj = JSONObject()
                    for ((k, v) in value) {
                        if (k != null) {
                            jobj.put(k.toString(), wrapJsonValue(v))
                        }
                    }
                    jobj
                }
                is Iterable<*> -> {
                    val jarr = JSONArray()
                    for (item in value) {
                        jarr.put(wrapJsonValue(item))
                    }
                    jarr
                }
                is Array<*> -> {
                    val jarr = JSONArray()
                    for (item in value) {
                        jarr.put(wrapJsonValue(item))
                    }
                    jarr
                }
                is Number, is Boolean, is String -> value
                else -> value.toString()
            }
        }
    }
}
