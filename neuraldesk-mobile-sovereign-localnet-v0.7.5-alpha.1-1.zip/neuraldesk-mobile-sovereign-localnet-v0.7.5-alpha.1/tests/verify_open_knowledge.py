#!/usr/bin/env python3
from __future__ import annotations
import collections, json, math, pathlib, struct, subprocess, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from training.build_open_knowledge_shard import feature_buckets
ASSET=ROOT/'models/neuraldesk-open-knowledge-pira-v0.6.ndos'
BIN=ROOT/'build/nd_open_knowledge_batch'
VAL=ROOT/'training/data/open_knowledge/pira_reconstruction_validation_v1.jsonl'
NEG=ROOT/'training/data/open_knowledge/open_knowledge_negatives_v1.jsonl'
HOLD=ROOT/'training/data/open_knowledge/open_knowledge_holdout_v1.jsonl'

def read_asset(path:pathlib.Path):
    b=path.read_bytes(); o=0
    def take(n):
        nonlocal o
        if o+n>len(b): raise AssertionError('truncated NDOS')
        x=b[o:o+n]; o+=n; return x
    assert take(8)==b'NDOSV001'
    version,rc,buckets,ic,entries,topk,flags=struct.unpack('<IIIIIII',take(28))
    score,margin=struct.unpack('<dd',take(16))
    assert version==1 and rc==31 and buckets==65536 and flags==1
    idf={}
    last=-1
    for _ in range(ic):
        bid,w=struct.unpack('<If',take(8)); assert bid>last and bid<buckets and math.isfinite(w) and w>0; last=bid; idf[bid]=w
    recs=[]; total=0
    for _ in range(rc):
        split,il,ql,al,fc=struct.unpack('<IIIII',take(20)); (norm,)=struct.unpack('<d',take(8))
        sid=take(il).decode(); q=take(ql).decode(); a=take(al).decode(); fs=[]; last=-1
        for _ in range(fc):
            bid,w=struct.unpack('<If',take(8)); assert bid>last and bid<buckets and math.isfinite(w) and w>0; last=bid; fs.append((bid,w))
        assert split in (0,1) and fc<=topk and norm>0
        recs.append((split,sid,q,a,norm,fs)); total+=fc
    assert total==entries and o==len(b)
    return {'score':score,'margin':margin,'idf':idf,'records':recs,'buckets':buckets,'topk':topk}

def rank(asset,q):
    c=collections.Counter(feature_buckets(q)); qv={b:n*asset['idf'][b] for b,n in c.items() if b in asset['idf']}
    qn=math.sqrt(sum(w*w for w in qv.values())); scores=[]
    for i,r in enumerate(asset['records']):
        dot=sum(qv.get(b,0.0)*w for b,w in r[5]); s=dot/(qn*r[4]) if qn and dot else 0.0; scores.append((s,i))
    scores.sort(reverse=True); best,i=scores[0]; second=scores[1][0] if len(scores)>1 else 0.0; margin=max(0.0,best-second)
    return best>=asset['score'] and margin>=asset['margin'],asset['records'][i][1],best,margin

def rows(path): return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]

def run_c(qs,path=ASSET,check=True):
    p=subprocess.run([str(BIN),str(path)],input='\n'.join(qs)+'\n',text=True,capture_output=True)
    if check and p.returncode!=0: raise AssertionError(p.stderr)
    if not check: return p
    out=[]
    for line in p.stdout.splitlines():
        found,sid,score,margin=line.split('\t'); out.append((found=='1',sid,float(score),float(margin)))
    assert len(out)==len(qs); return out

asset=read_asset(ASSET); val=rows(VAL); neg=rows(NEG); hold=rows(HOLD)
all53=val+neg
cres=run_c([r['query'] for r in all53])
raw=accepted=correct=false_accept=0
for row,c in zip(all53,cres):
    py=rank(asset,row['query'])
    assert py[0]==c[0] and py[1]==c[1]
    assert abs(py[2]-c[2])<2e-6 and abs(py[3]-c[3])<2e-6
    if row['kind']=='human_paraphrase':
        raw += c[1]==row['expected_source_id']
        if c[0]: accepted+=1; correct += c[1]==row['expected_source_id']
    else:
        false_accept += int(c[0])
assert len(val)==28 and raw==28, (raw,len(val))
assert accepted==25 and correct==25, (accepted,correct)
assert len(neg)==25 and false_accept==0
# Post-implementation holdout: 3 untouched human paraphrases. Wrong accepted answers are forbidden.
hc=run_c([r['query'] for r in hold]); hraw=hacc=hcorrect=0
for row,c in zip(hold,hc):
    hraw+=c[1]==row['expected_source_id']
    if c[0]: hacc+=1; hcorrect+=c[1]==row['expected_source_id']
assert hraw==3 and hcorrect==hacc and hacc>=2
# Four independent corruption classes must fail closed.
b=bytearray(ASSET.read_bytes()); corrupt=[]
x=bytearray(b); x[0]^=0x01; corrupt.append(x)
corrupt.append(b[:-9])
x=bytearray(b); x.extend(b'X'); corrupt.append(x)
x=bytearray(b); struct.pack_into('<I',x,16,12345); corrupt.append(x)  # non-power-of-two bucket_count
for i,data in enumerate(corrupt):
    with tempfile.NamedTemporaryFile(suffix='.ndos',delete=False) as f:
        f.write(data); path=pathlib.Path(f.name)
    try:
        p=run_c(['teste'],path=path,check=False); assert p.returncode!=0, (i,p.stdout,p.stderr)
    finally: path.unlink(missing_ok=True)
report={'pythonCParity':'53/53','validationHuman':len(val),'rawTop1':raw,'accepted':accepted,'acceptedCorrect':correct,
        'negativeCalibration':len(neg),'negativeAccepted':false_accept,'holdoutHuman':len(hold),'holdoutRawTop1':hraw,
        'holdoutAccepted':hacc,'holdoutAcceptedCorrect':hcorrect,'corruptionRejected':'4/4',
        'acceptScore':asset['score'],'acceptMargin':asset['margin']}
out=ROOT/'evaluation/open_knowledge/SHARD_EVALUATION_REPORT.json'; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,sort_keys=True))
