<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: release-history -->
# Changelog — V8.10

## DeepSeek Harness Agent Runtime Architecture Integration

Documentation-only release built on V8.9.

### Added
- 12 future modules under `neural-engine/modules/11-agent-harness-runtime/`.
- 73 future capabilities, taking the blueprint to 94 modules / 391 capabilities.
- DeepSeek Harness research package with repository, architecture, runtime, durability, sandbox, subagent, compaction and benchmark analyses.
- 11 global architecture strategies for event sourcing, tool-effect durability, provider composition, compaction, subagents, invariants, schema evolution, dynamic extensions, ablation benchmarks and multidimensional sandboxing.
- Development skill `neuraldesk.deepseek-harness-architecture-research-integration.v1`.

### Strengthened existing blueprint
- capability resolution;
- agent runtime;
- tool runtime;
- approval/policy guardrails;
- checkpoint/resume;
- background jobs;
- persistence/storage;
- identity/security;
- workflow events;
- skills;
- observability/audit.

### Preserved
- Visual/UI implementation V8.2.
- 10 canonical modules.
- Neural Engine status DOCUMENTATION_ONLY / NOT_IMPLEMENTED.
- Existing automated/responsive/browser test baseline.
