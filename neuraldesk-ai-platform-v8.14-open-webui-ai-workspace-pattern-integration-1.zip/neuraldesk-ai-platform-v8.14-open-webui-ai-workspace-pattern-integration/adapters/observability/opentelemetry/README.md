<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.observability.opentelemetry

Replaceable adapter template.

Provides:
- `telemetry.emit.v1`

Domain modules must never import this adapter implementation directly.
Binding occurs through the corresponding platform gateway/registry.
