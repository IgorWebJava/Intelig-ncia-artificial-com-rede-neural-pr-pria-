#!/usr/bin/env python3
"""Deterministic minibatch/epoch trainer for Micro-v2.

Experimental and stage-only. It preserves the Micro-v2 architecture, NDGM/NDTK
formats and evaluation boundaries while changing only the learning schedule:
real minibatches, explicit rich-corpus coverage per epoch and resumable batch
cursors/permutations. It never writes models/ and never authorizes promotion.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch

# Reuse the already parity-proven Micro-v2 math/export implementation.
from train_generative_micro_v074_v2 import (
    DATA,
    PRE,
    ROOT,
    MicroV2,
    Tok,
    bindings,
    ch,
    evalv,
    export,
    loss,
    oh,
    pad,
    readj,
    sftrow,
    sha,
    th,
)

SCHEMA_CONFIG = "nd-v074-micro-v2-batch-config-v1"
SCHEMA_CHECKPOINT = "nd-v074-micro-v2-batch-checkpoint-v1"
SCHEMA_REPORT = "neuraldesk-generative-training-report-v074-alpha2-micro-v2-batch-v1"


def _seed(base: int, phase: str, epoch: int, source: str) -> int:
    material = f"{base}|{phase}|{epoch}|{source}|nd-v074-batch-permutation-v1".encode()
    return int.from_bytes(hashlib.sha256(material).digest()[:8], "little")


def permutation(n: int, base_seed: int, phase: str, epoch: int, source: str) -> list[int]:
    p = list(range(n))
    random.Random(_seed(base_seed, phase, epoch, source)).shuffle(p)
    return p


def cfg(a: argparse.Namespace, tok_path: Path, counts: dict[str, int]) -> dict[str, Any]:
    if a.pretrain_rich_per_batch + a.pretrain_context_per_batch != a.pretrain_batch_size:
        raise ValueError("pretrain source counts must equal pretrain batch size")
    if a.sft_rich_per_batch + a.sft_context_per_batch + a.sft_replay_per_batch != a.sft_batch_size:
        raise ValueError("SFT source counts must equal SFT batch size")
    if min(a.pretrain_rich_per_batch, a.sft_rich_per_batch) < 1:
        raise ValueError("every batch policy must contain rich first-party/human data")
    return {
        "schema": SCHEMA_CONFIG,
        "arch": {
            "vocab": 512,
            "dim": 224,
            "layers": 8,
            "qHeads": 7,
            "kvHeads": 1,
            "ffn": 640,
            "context": 256,
            "params": 4476640,
        },
        "seed": a.seed,
        "seqLen": a.seq_len,
        "pretrainEpochs": a.pretrain_epochs,
        "sftEpochs": a.sft_epochs,
        "pretrainLr": a.pretrain_lr,
        "sftLr": a.sft_lr,
        "weightDecay": a.weight_decay,
        "threads": a.threads,
        "gradClip": a.grad_clip,
        "trainingPolicy": {
            "version": "nd-v074-source-balanced-minibatch-epochs-v1",
            "pretrain": {
                "batchSize": a.pretrain_batch_size,
                "richPerBatch": a.pretrain_rich_per_batch,
                "contextPerBatch": a.pretrain_context_per_batch,
                "epochDefinition": "ONE_FULL_RICH_REPLAY_COVERAGE",
            },
            "sft": {
                "batchSize": a.sft_batch_size,
                "richPerBatch": a.sft_rich_per_batch,
                "contextPerBatch": a.sft_context_per_batch,
                "richReplayPerBatch": a.sft_replay_per_batch,
                "epochDefinition": "ONE_FULL_RICH_SFT_COVERAGE",
                "responseOnlySupervision": True,
                "causalReplayInSameOptimizerBatch": True,
            },
            "permutation": "SHA256_DERIVED_PYTHON_MT19937_SHUFFLE_V1",
            "validationGradientUse": False,
        },
        "debugLimits": {"rich": a.rich_limit, "context": a.context_limit},
        "effectiveCounts": counts,
        "bindings": bindings(tok_path),
    }


def causal_row(r: dict[str, Any], tok: Tok, nonce: int, n: int) -> tuple[torch.Tensor, torch.Tensor]:
    ids = [257] + tok.encode(r["text"]) + [258]
    need = n + 1
    if len(ids) > need:
        off = (nonce * 37) % (len(ids) - need + 1)
        ids = ids[off : off + need]
    if len(ids) < 2:
        ids = [257, 258]
    x, y = pad(ids[:-1], ids[1:], n)
    return x.squeeze(0), y.squeeze(0)


def _slice_cycle(p: list[int], start: int, count: int) -> list[int]:
    if not p or count < 0:
        raise ValueError("invalid permutation/count")
    return [p[(start + i) % len(p)] for i in range(count)]


def schedule_pretrain(
    rich_n: int, context_n: int, a: argparse.Namespace, epoch: int
) -> dict[str, Any]:
    return {
        "phase": "pretrain",
        "epoch": epoch,
        "richPermutation": permutation(rich_n, a.seed, "pretrain", epoch, "rich_replay"),
        "contextPermutation": permutation(context_n, a.seed, "pretrain", epoch, "context_replay"),
    }


def schedule_sft(
    rich_n: int, context_n: int, replay_n: int, a: argparse.Namespace, epoch: int
) -> dict[str, Any]:
    return {
        "phase": "sft",
        "epoch": epoch,
        "richPermutation": permutation(rich_n, a.seed, "sft", epoch, "rich_sft"),
        "contextPermutation": permutation(context_n, a.seed, "sft", epoch, "context_sft"),
        "replayPermutation": permutation(replay_n, a.seed, "sft", epoch, "rich_replay"),
    }


def pretrain_batches_per_epoch(rich_n: int, a: argparse.Namespace) -> int:
    return math.ceil(rich_n / a.pretrain_rich_per_batch)


def sft_batches_per_epoch(rich_n: int, a: argparse.Namespace) -> int:
    return math.ceil(rich_n / a.sft_rich_per_batch)


def pretrain_batch(
    rich: list[dict[str, Any]],
    context: list[dict[str, Any]],
    tok: Tok,
    a: argparse.Namespace,
    schedule: dict[str, Any],
    cursor: int,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, int]]:
    rs = cursor * a.pretrain_rich_per_batch
    cs = cursor * a.pretrain_context_per_batch
    ri = _slice_cycle(schedule["richPermutation"], rs, a.pretrain_rich_per_batch)
    ci = _slice_cycle(schedule["contextPermutation"], cs, a.pretrain_context_per_batch)
    xy = []
    for j, i in enumerate(ri):
        xy.append(causal_row(rich[i], tok, schedule["epoch"] * 1000003 + cursor * 31 + j, a.seq_len))
    for j, i in enumerate(ci):
        xy.append(causal_row(context[i], tok, schedule["epoch"] * 1000033 + cursor * 43 + j, a.seq_len))
    x = torch.stack([q[0] for q in xy])
    y = torch.stack([q[1] for q in xy])
    return x, y, {"rich": len(ri), "context": len(ci)}


def sft_batch(
    rich: list[dict[str, Any]],
    context: list[dict[str, Any]],
    replay: list[dict[str, Any]],
    tok: Tok,
    a: argparse.Namespace,
    schedule: dict[str, Any],
    cursor: int,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, int]]:
    rs = cursor * a.sft_rich_per_batch
    cs = cursor * a.sft_context_per_batch
    ps = cursor * a.sft_replay_per_batch
    ri = _slice_cycle(schedule["richPermutation"], rs, a.sft_rich_per_batch)
    ci = _slice_cycle(schedule["contextPermutation"], cs, a.sft_context_per_batch)
    pi = _slice_cycle(schedule["replayPermutation"], ps, a.sft_replay_per_batch)
    xy: list[tuple[torch.Tensor, torch.Tensor]] = []
    for j, i in enumerate(ri):
        x, y = sftrow(rich[i], tok, schedule["epoch"] * 1000003 + cursor * 31 + j, a.seq_len, False)
        xy.append((x.squeeze(0), y.squeeze(0)))
    for j, i in enumerate(ci):
        x, y = sftrow(context[i], tok, schedule["epoch"] * 1000033 + cursor * 43 + j, a.seq_len, True)
        xy.append((x.squeeze(0), y.squeeze(0)))
    for j, i in enumerate(pi):
        xy.append(causal_row(replay[i], tok, schedule["epoch"] * 1000037 + cursor * 47 + j, a.seq_len))
    x = torch.stack([q[0] for q in xy])
    y = torch.stack([q[1] for q in xy])
    return x, y, {"rich": len(ri), "context": len(ci), "richReplay": len(pi)}


def validate_schedule(s: dict[str, Any], a: argparse.Namespace, counts: dict[str, int]) -> None:
    phase = s["phase"]
    epoch = int(s["epoch"])
    if phase == "pretrain":
        expected = schedule_pretrain(counts["richReplay"], counts["contextReplay"], a, epoch)
    elif phase == "sft":
        expected = schedule_sft(counts["richSft"], counts["contextSft"], counts["richReplay"], a, epoch)
    else:
        raise ValueError("unknown checkpoint phase")
    if s != expected:
        raise ValueError("checkpoint permutation does not match deterministic epoch schedule")


def cpwrite(
    path: Path,
    model: MicroV2,
    opt: torch.optim.Optimizer,
    config: dict[str, Any],
    state: dict[str, Any],
    initial_validation: float,
    schedule: dict[str, Any],
) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = {
        "schema": SCHEMA_CHECKPOINT,
        "config": config,
        "configSha256": ch(config),
        "state": state,
        "initialValidationLoss": initial_validation,
        "schedule": schedule,
        "model": model.state_dict(),
        "optimizer": opt.state_dict(),
        "modelStateSha256": th(model.state_dict().items()),
        "optimizerStateSha256": oh(opt),
    }
    torch.save(body, path)
    side = {
        "checkpointSha256": sha(path),
        "configSha256": body["configSha256"],
        "modelStateSha256": body["modelStateSha256"],
        "optimizerStateSha256": body["optimizerStateSha256"],
        "state": state,
        "schedule": {"phase": schedule["phase"], "epoch": schedule["epoch"]},
    }
    path.with_suffix(path.suffix + ".json").write_text(json.dumps(side, indent=2, sort_keys=True) + "\n")
    return side


def cpload(
    path: Path,
    model: MicroV2,
    opt: torch.optim.Optimizer,
    config: dict[str, Any],
    a: argparse.Namespace,
    counts: dict[str, int],
) -> dict[str, Any]:
    side_path = path.with_suffix(path.suffix + ".json")
    side = json.loads(side_path.read_text())
    if sha(path) != side["checkpointSha256"]:
        raise ValueError("checkpoint SHA mismatch")
    if side["configSha256"] != ch(config):
        raise ValueError("checkpoint config binding mismatch")
    body = torch.load(path, map_location="cpu", weights_only=False)
    if body["schema"] != SCHEMA_CHECKPOINT or body["config"] != config:
        raise ValueError("checkpoint schema/config mismatch")
    validate_schedule(body["schedule"], a, counts)
    model.load_state_dict(body["model"])
    opt.load_state_dict(body["optimizer"])
    if th(model.state_dict().items()) != body["modelStateSha256"]:
        raise ValueError("model-state digest mismatch after load")
    if oh(opt) != body["optimizerStateSha256"]:
        raise ValueError("optimizer-state digest mismatch after load")
    return body


def checkpoint_name(state: dict[str, Any]) -> str:
    return (
        f"v2batch-phase-{state['phase']}-pe{state['pretrainEpoch']}-pb{state['pretrainBatchCursor']}"
        f"-se{state['sftEpoch']}-sb{state['sftBatchCursor']}-u{state['updates']}.pt"
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--checkpoint-dir", required=True)
    ap.add_argument("--resume")
    ap.add_argument("--pretrain-epochs", type=int, default=2)
    ap.add_argument("--sft-epochs", type=int, default=3)
    ap.add_argument("--run-batch-budget", type=int, default=0)
    ap.add_argument("--seq-len", type=int, default=64)
    ap.add_argument("--seed", type=int, default=7422)
    ap.add_argument("--pretrain-lr", type=float, default=3e-4)
    ap.add_argument("--sft-lr", type=float, default=8e-5)
    ap.add_argument("--weight-decay", type=float, default=0.01)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--checkpoint-every-batches", type=int, default=50)
    ap.add_argument("--pretrain-batch-size", type=int, default=10)
    ap.add_argument("--pretrain-rich-per-batch", type=int, default=7)
    ap.add_argument("--pretrain-context-per-batch", type=int, default=3)
    ap.add_argument("--sft-batch-size", type=int, default=10)
    ap.add_argument("--sft-rich-per-batch", type=int, default=8)
    ap.add_argument("--sft-context-per-batch", type=int, default=1)
    ap.add_argument("--sft-replay-per-batch", type=int, default=1)
    # Debug-only bounded source limits for the resume-equivalence gate. They are
    # part of the config hash and therefore cannot be mixed with a canonical run.
    ap.add_argument("--rich-limit", type=int, default=0)
    ap.add_argument("--context-limit", type=int, default=0)
    a = ap.parse_args()

    subprocess.run([sys.executable, str(PRE)], cwd=ROOT, check=True)
    if not (1 <= a.threads <= 8):
        raise SystemExit("threads out of bounded range")
    if min(a.pretrain_epochs, a.sft_epochs) < 0:
        raise SystemExit("epochs must be non-negative")

    torch.set_num_threads(a.threads)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.mkldnn.enabled = False
    random.seed(a.seed)
    np.random.seed(a.seed)
    torch.manual_seed(a.seed)

    tok_path = DATA / "tokenizer-v2.ndtk"
    tok = Tok(tok_path)
    rich = readj(DATA / "rich_sft.jsonl")
    context = readj(DATA / "context_sft.jsonl")
    replay = readj(DATA / "causal_replay.jsonl")
    val = readj(DATA / "pira_validation.jsonl")
    rich_replay = [r for r in replay if r.get("source") != "NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN"]
    context_replay = [r for r in replay if r.get("source") == "NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN"]

    if a.rich_limit:
        rich = rich[: a.rich_limit]
        rich_replay = rich_replay[: a.rich_limit]
    if a.context_limit:
        context = context[: a.context_limit]
        context_replay = context_replay[: a.context_limit]
    if not rich or not rich_replay or not context or not context_replay:
        raise SystemExit("effective source set is empty")

    counts = {
        "richSft": len(rich),
        "contextSft": len(context),
        "richReplay": len(rich_replay),
        "contextReplay": len(context_replay),
        "validation": len(val),
    }
    config = cfg(a, tok_path, counts)
    model = MicroV2()
    if sum(p.numel() for p in model.parameters()) != 4476640:
        raise SystemExit("Micro-v2 parameter count mismatch")
    opt = torch.optim.AdamW(model.parameters(), lr=a.pretrain_lr, weight_decay=a.weight_decay)

    state: dict[str, Any] = {
        "phase": "pretrain" if a.pretrain_epochs else "sft",
        "pretrainEpoch": 0,
        "pretrainBatchCursor": 0,
        "sftEpoch": 0,
        "sftBatchCursor": 0,
        "updates": 0,
        "richPretrainSeen": 0,
        "contextPretrainSeen": 0,
        "richSftSeen": 0,
        "contextSftSeen": 0,
        "richReplaySftSeen": 0,
    }
    initial_validation: float | None = None
    schedule = (
        schedule_pretrain(len(rich_replay), len(context_replay), a, 0)
        if state["phase"] == "pretrain"
        else schedule_sft(len(rich), len(context), len(rich_replay), a, 0)
    )

    if a.resume:
        body = cpload(Path(a.resume), model, opt, config, a, counts)
        state = body["state"]
        initial_validation = float(body["initialValidationLoss"])
        schedule = body["schedule"]
        print(
            "RESUME_V2_BATCH PASS "
            f"phase={state['phase']} preEpoch={state['pretrainEpoch']} preCursor={state['pretrainBatchCursor']} "
            f"sftEpoch={state['sftEpoch']} sftCursor={state['sftBatchCursor']} updates={state['updates']}",
            flush=True,
        )

    if initial_validation is None:
        initial_validation = evalv(model, val, tok, a.seq_len)
    print(
        f"VALIDATION_V2_BATCH baseline={initial_validation:.6f} items={len(val)} "
        f"rich={len(rich)} context={len(context)} batchSft={a.sft_batch_size}",
        flush=True,
    )

    budget = a.run_batch_budget or 10**18
    used = 0
    ckdir = Path(a.checkpoint_dir)

    while state["phase"] == "pretrain" and state["pretrainEpoch"] < a.pretrain_epochs and used < budget:
        epoch = state["pretrainEpoch"]
        if schedule["phase"] != "pretrain" or schedule["epoch"] != epoch:
            schedule = schedule_pretrain(len(rich_replay), len(context_replay), a, epoch)
        total_batches = pretrain_batches_per_epoch(len(rich_replay), a)
        cursor = state["pretrainBatchCursor"]
        if cursor >= total_batches:
            state["pretrainEpoch"] += 1
            state["pretrainBatchCursor"] = 0
            if state["pretrainEpoch"] >= a.pretrain_epochs:
                state["phase"] = "sft"
                schedule = schedule_sft(len(rich), len(context), len(rich_replay), a, state["sftEpoch"])
                break
            schedule = schedule_pretrain(len(rich_replay), len(context_replay), a, state["pretrainEpoch"])
            continue
        for group in opt.param_groups:
            group["lr"] = a.pretrain_lr
        x, y, coverage = pretrain_batch(rich_replay, context_replay, tok, a, schedule, cursor)
        opt.zero_grad(set_to_none=True)
        z = loss(model, x, y)
        z.backward()
        grad_norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), a.grad_clip).detach().item())
        opt.step()
        state["pretrainBatchCursor"] += 1
        state["updates"] += 1
        state["richPretrainSeen"] += coverage["rich"]
        state["contextPretrainSeen"] += coverage["context"]
        used += 1
        if state["updates"] == 1 or state["updates"] % 25 == 0:
            print(
                f"PRETRAIN_V2_BATCH epoch={epoch+1}/{a.pretrain_epochs} batch={cursor+1}/{total_batches} "
                f"loss={z.detach().item():.6f} gradNorm={grad_norm:.6f} richSeen={state['richPretrainSeen']}",
                flush=True,
            )
        if a.checkpoint_every_batches and state["updates"] % a.checkpoint_every_batches == 0:
            p = ckdir / checkpoint_name(state)
            side = cpwrite(p, model, opt, config, state, initial_validation, schedule)
            print(f"CHECKPOINT_V2_BATCH path={p} sha256={side['checkpointSha256']}", flush=True)

    if state["phase"] == "pretrain" and state["pretrainEpoch"] >= a.pretrain_epochs:
        state["phase"] = "sft"
        schedule = schedule_sft(len(rich), len(context), len(rich_replay), a, state["sftEpoch"])

    while state["phase"] == "sft" and state["sftEpoch"] < a.sft_epochs and used < budget:
        epoch = state["sftEpoch"]
        if schedule["phase"] != "sft" or schedule["epoch"] != epoch:
            schedule = schedule_sft(len(rich), len(context), len(rich_replay), a, epoch)
        total_batches = sft_batches_per_epoch(len(rich), a)
        cursor = state["sftBatchCursor"]
        if cursor >= total_batches:
            state["sftEpoch"] += 1
            state["sftBatchCursor"] = 0
            if state["sftEpoch"] >= a.sft_epochs:
                state["phase"] = "terminal"
                break
            schedule = schedule_sft(len(rich), len(context), len(rich_replay), a, state["sftEpoch"])
            continue
        for group in opt.param_groups:
            group["lr"] = a.sft_lr
        x, y, coverage = sft_batch(rich, context, rich_replay, tok, a, schedule, cursor)
        opt.zero_grad(set_to_none=True)
        z = loss(model, x, y)
        z.backward()
        grad_norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), a.grad_clip).detach().item())
        opt.step()
        state["sftBatchCursor"] += 1
        state["updates"] += 1
        state["richSftSeen"] += coverage["rich"]
        state["contextSftSeen"] += coverage["context"]
        state["richReplaySftSeen"] += coverage["richReplay"]
        used += 1
        if state["updates"] % 25 == 0 or state["sftBatchCursor"] == 1:
            print(
                f"SFT_V2_BATCH epoch={epoch+1}/{a.sft_epochs} batch={cursor+1}/{total_batches} "
                f"loss={z.detach().item():.6f} gradNorm={grad_norm:.6f} richSeen={state['richSftSeen']}",
                flush=True,
            )
        if a.checkpoint_every_batches and state["updates"] % a.checkpoint_every_batches == 0:
            p = ckdir / checkpoint_name(state)
            side = cpwrite(p, model, opt, config, state, initial_validation, schedule)
            print(f"CHECKPOINT_V2_BATCH path={p} sha256={side['checkpointSha256']}", flush=True)

    if state["phase"] != "terminal":
        p = ckdir / checkpoint_name(state)
        side = cpwrite(p, model, opt, config, state, initial_validation, schedule)
        print(f"PAUSED_V2_BATCH path={p} sha256={side['checkpointSha256']}", flush=True)
        return 3

    final_validation = evalv(model, val, tok, a.seq_len)
    out = Path(a.output_dir)
    fp32 = out / "staging/micro-v2-batch-fp32.ndgm"
    q8 = out / "staging/micro-v2-batch-q8.ndgm"
    q4 = out / "staging/micro-v2-batch-q4.ndgm"
    fsha = export(model, fp32, "fp32")
    q8sha = export(model, q8, "q8")
    q4sha = export(model, q4, "q4")
    report = {
        "schema": SCHEMA_REPORT,
        "status": "EXPERIMENTAL_NOT_PROMOTED",
        "config": config,
        "initialValidationLoss": initial_validation,
        "finalValidationLoss": final_validation,
        "validationItems": len(val),
        "state": state,
        "coverage": {
            "richSftUniquePerEpochTarget": len(rich),
            "richSftEpochsCompleted": state["sftEpoch"],
            "richSftExamplesPresented": state["richSftSeen"],
            "richReplayExamplesPresentedPretrain": state["richPretrainSeen"],
            "contextExamplesPresentedPretrain": state["contextPretrainSeen"],
            "contextExamplesPresentedSft": state["contextSftSeen"],
            "richReplayExamplesPresentedSft": state["richReplaySftSeen"],
        },
        "modelStateSha256": th(model.state_dict().items()),
        "optimizerStateSha256": oh(opt),
        "stagedFp32": {"path": str(fp32), "sha256": fsha, "bytes": fp32.stat().st_size},
        "stagedQ8": {"path": str(q8), "sha256": q8sha, "bytes": q8.stat().st_size},
        "stagedQ4": {"path": str(q4), "sha256": q4sha, "bytes": q4.stat().st_size},
        "promotionAuthorized": False,
    }
    out.mkdir(parents=True, exist_ok=True)
    (out / "TRAINING_REPORT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    terminal_schedule = schedule_sft(len(rich), len(context), len(rich_replay), a, max(0, a.sft_epochs - 1))
    p = ckdir / "v2batch-terminal.pt"
    cpwrite(p, model, opt, config, state, initial_validation, terminal_schedule)
    print(
        f"TRAINING_V2_BATCH_TERMINAL_NOT_PROMOTED validation={final_validation:.6f} "
        f"updates={state['updates']} richSftSeen={state['richSftSeen']} modelStateSha256={report['modelStateSha256']}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
