<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Filesystem & Artifact Management

    Skill ID: `neuraldesk.artifact-management.v1`

    ## Category

    `development`

    ## Introduced

    `V3`

    ## Required development capabilities

    - `filesystem.read.v1`
- `filesystem.write.v1`
- `filesystem.copy.v1`
- `archive.zip.create.v1`
- `diff.compare.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `/mnt/data`
- `release ZIPs`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
