<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 95 — Realtime & Cache Invalidation

Event consumers can:

- invalidate local config caches;
- rebuild effective config;
- refresh model router;
- refresh agent policies;
- refresh tool policies;
- refresh knowledge retrieval settings.

Do not use the database as a high-volume frontend polling bus.
