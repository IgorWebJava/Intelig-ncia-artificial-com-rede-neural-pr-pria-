<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.chat; current: modules/chat/docs/CONTRACTS_AND_CAPABILITIES.md -->
# Autonomous Assistant Workspace Template — Contracts & Capabilities

## Public contract set

- `contracts/openapi.yaml`
- `contracts/asyncapi.yaml`
- `contracts/config.schema.json`
- `contracts/capabilities.json`
- `contracts/permissions.json`
- `contracts/adaptive-ui.json`

## Provides

- `chat.conversation.v1`
- `chat.message.v1`
- `chat.multimodal.compose.v1`
- `chat.autonomous-assistant.surface.v1`

## Requires

- `ai.execute.v1`
- `knowledge.retrieve.v1`
- `tools.execute.v1`
- `media.asset.v1`
- `config.resolve.v1`
- `audit.write.v1`
- `ui.adaptive.v1`
- `ui.multimodal.surface.v1`
- `ui.runtime.interaction.v1`
- `ui.workspace.shell.v1`
- `ui.command_palette.v1`
- `ui.global.search.v1`
- `ui.task.center.v1`
- `ui.notification.center.v1`
- `ui.artifact.workspace.v1`
- `ui.assistant.mission-control.v1`
- `ui.project.suspension.surface.v1`
- `ui.task.plan.surface.v1`
- `ui.activity.timeline.v1`
- `ui.project.memory.surface.v1`
- `ui.assistant.mode-selector.v1`
- `ui.assistant.voice.surface.v1`
- `ui.artifact.delivery.surface.v1`
- `ui.project.checkpoint.surface.v1`
- `ui.context-lens.v1`
- `ui.provenance.v1`
- `ui.trust-layer.v1`
- `ui.density.v1`
- `ui.version-diff.v1`
- `ui.adaptive-inspector.v1`
- `ui.specialized-workspace.v1`

## UI contract

- experience: `intelligence-experience-v2`
- runtime: `workspace-runtime-v2`
- design: `neuraldesk-intelligence-design-v2`
- template scope: `ui-only`

## Compatibility

Public contracts follow N/N-1 during migrations unless explicitly waived. Capability resolution must remain valid before release.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
