<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 123 — Preview Governance

Rules:

- one canonical preview image per module;
- image is generated, not manually illustrated;
- preview reflects canonical UI source;
- module owns preview;
- preview must not be used as proof of backend functionality;
- visual changes require preview regeneration;
- preview validation is a release gate.
