#ifndef ND_RELATION_H
#define ND_RELATION_H
#include <stddef.h>
#include <stdint.h>

#define ND_RELATION_MAGIC 0x314c524eu
#define ND_RELATION_VERSION 1u
#define ND_RELATION_COUNT 25u

typedef struct {
    uint32_t magic, version, feature_dim, hidden_dim, classes, seed, reserved;
} NDRelationHeader;

typedef struct {
    NDRelationHeader h;
    float *storage;
    size_t storage_floats;
    float *w1, *b1, *w2, *b2;
} NDRelationClassifier;

typedef struct {
    uint32_t relation_id;
    float confidence;
    float margin;
    int accepted;
} NDRelationResult;

int nd_relation_load(const char *path, NDRelationClassifier *r, char *err, size_t errcap);
void nd_relation_free(NDRelationClassifier *r);
int nd_relation_infer(const NDRelationClassifier *r, const char *text, NDRelationResult *result, char *err, size_t errcap);
const char *nd_relation_name(uint32_t id);

#endif
