#include "nd_resource.h"
#include <stdio.h>

int main(void) {
    if (nd_resource_select_profile(2048ul, 8u, 1) != ND_PROFILE_MICRO) return 1;
    if (nd_resource_select_profile(8192ul, 8u, 0) != ND_PROFILE_MICRO) return 1;
    if (nd_resource_select_profile(4096ul, 6u, 1) != ND_PROFILE_MOBILE) return 1;
    if (nd_resource_select_profile(8192ul, 8u, 1) != ND_PROFILE_MOBILE_PLUS) return 1;

    NDResourcePolicy micro = nd_resource_policy(ND_PROFILE_MICRO);
    NDResourcePolicy mobile = nd_resource_policy(ND_PROFILE_MOBILE);
    NDResourcePolicy plus = nd_resource_policy(ND_PROFILE_MOBILE_PLUS);
    if (!nd_resource_admit(&micro, 100u, 1000u)) return 1;
    if (nd_resource_admit(&micro, 5000u, 1000u)) return 1;
    if (nd_resource_admit(&micro, 100u, micro.max_context_bytes + 1u)) return 1;

    if (nd_resource_effective_output_bytes(&mobile, 0u) != mobile.max_output_bytes) return 1;
    if (nd_resource_effective_output_bytes(&mobile, 5u) >= mobile.max_output_bytes) return 1;
    if (nd_resource_effective_output_bytes(&micro, 5u) < 1024u) return 1;
    if (nd_resource_effective_threads(&plus, 0u) != plus.max_threads) return 1;
    if (nd_resource_effective_threads(&plus, 5u) >= plus.max_threads) return 1;
    if (nd_resource_effective_threads(&micro, 6u) == 0u) return 1;
    if (nd_resource_effective_deadline_ms(&mobile, 0u) != mobile.deadline_ms) return 1;
    if (nd_resource_effective_deadline_ms(&mobile, 5u) >= mobile.deadline_ms) return 1;

    NDResourcePolicy invalid = mobile;
    invalid.max_threads = 0u;
    if (nd_resource_admit(&invalid, 100u, 1000u)) return 1;
    invalid = mobile;
    invalid.max_output_bytes = 0u;
    if (nd_resource_admit(&invalid, 100u, 1000u)) return 1;
    invalid = mobile;
    invalid.deadline_ms = 0u;
    if (nd_resource_admit(&invalid, 100u, 1000u)) return 1;

    puts("RESOURCE_GOVERNOR PASS profiles=3 admission_fail_closed=6 thermal_output_threads_deadline=true");
    return 0;
}
