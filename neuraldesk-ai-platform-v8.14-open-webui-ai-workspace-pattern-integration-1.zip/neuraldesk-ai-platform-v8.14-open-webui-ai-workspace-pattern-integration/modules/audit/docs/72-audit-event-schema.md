<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 72 — Audit Event Schema

## Contrato conceitual

```text
event_id
timestamp
trace_id
span_id
request_id
session_id
correlation_id
tenant_id
project_id
actor_type
actor_id
actor_name
source
module
page
action
resource_type
resource_id
before
after
status
severity
risk
approval_id
duration
tokens
cost
result
metadata
integrity_hash
previous_hash
```

## Regra

O schema deve ser consistente entre módulos para permitir correlação.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
