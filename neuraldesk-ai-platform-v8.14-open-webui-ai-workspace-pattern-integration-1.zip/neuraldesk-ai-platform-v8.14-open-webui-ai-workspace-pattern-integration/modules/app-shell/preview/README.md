<!-- neuraldesk-documentation-sync: V8.8 -->

# Module Preview — App Shell

Canonical preview:

```text
modules/app-shell/preview/page-preview.png
```

Source UI:

```text
modules/app-shell/ui/index.html
```

Standard capture profile:

```text
module-preview-v1
1600x1000
viewport capture
```

Regenerate after any meaningful visual UI change.

Command:

```text
python tools/generate_module_previews.py --module app-shell
```
