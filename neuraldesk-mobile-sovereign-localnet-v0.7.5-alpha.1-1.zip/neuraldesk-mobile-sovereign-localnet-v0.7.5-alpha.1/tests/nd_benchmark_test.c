#include "nd_benchmark.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    NDBenchmark b; nd_benchmark_init(&b);
    NDBenchmarkSample s[] = {
        {ND_PROFILE_MOBILE,ND_BENCHMARK_COMPLETED,100,20,12},
        {ND_PROFILE_MOBILE,ND_BENCHMARK_COMPLETED,120,25,10},
        {ND_PROFILE_MOBILE,ND_BENCHMARK_COMPLETED,110,22,11},
        {ND_PROFILE_MOBILE,ND_BENCHMARK_FAILED,50,10,0},
        {ND_PROFILE_MICRO,ND_BENCHMARK_COMPLETED,300,60,4}
    };
    int fail=0; for(size_t i=0;i<sizeof(s)/sizeof(s[0]);i++) fail += nd_benchmark_add(&b,&s[i])!=0;
    NDBenchmarkScorecard sc=nd_benchmark_default_scorecard();NDBenchmarkReport r;
    fail += nd_benchmark_evaluate(&b,ND_PROFILE_MOBILE,&sc,&r)!=0;
    fail += r.total!=4u || r.completed!=3u || r.failed!=1u || r.latency_p50_ms!=110.0 || r.latency_p95_ms!=120.0;
    fail += r.success_rate!=0.75 || r.within_thresholds!=0 || strcmp(r.certification,"MEASURED_NOT_CERTIFIED")!=0;
    sc.min_success_rate=0.7; fail += nd_benchmark_evaluate(&b,ND_PROFILE_MOBILE,&sc,&r)!=0 || !r.within_thresholds;
    printf("BENCHMARK_EVALUATION %s p50=%.0f p95=%.0f certification=%s\n",fail?"FAIL":"PASS",r.latency_p50_ms,r.latency_p95_ms,r.certification);
    return fail?1:0;
}
