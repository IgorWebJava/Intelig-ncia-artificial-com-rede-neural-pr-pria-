<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Gerar Nova Versão

1. Copiar última versão para novo diretório.
2. Nunca sobrescrever release anterior.
3. Aplicar mudanças.
4. Atualizar versões coerentemente.
5. Atualizar docs/memory/skills/tests.
6. Executar gates.
7. Gerar verification report.
8. Criar ZIP.
