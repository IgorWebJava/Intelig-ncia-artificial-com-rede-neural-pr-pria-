<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 75 — Console & Control Model

## Audit Query Console

Default:

```text
READ ONLY
```

Suporta conceitualmente:

```text
events
events actor.type=agent
events risk=HIGH
trace TRACE-ID
integrity today
changes version=V6.8
```

## Admin Control

Ações administrativas seguem:

```text
Request
→ Authentication
→ Authorization
→ Policy
→ Approval
→ Execute
→ Verify
→ Audit
```

O próprio Audit Center também deve ser auditado.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
