# Offline Continuity & Local Control — v0.7.2-alpha.1

Status: executable C99 owners integrated into host and Android native build.

## Recovered historical mechanics

The deep audit of Mobile Runtime v0.1-v0.63 found several executable mobile mechanics that were absent from the v0.7.1 LocalNet core. v0.7.2 reexpresses them under the current first-party-only architecture instead of restoring the old remote-provider router.

### Adaptive Network Policy

`nd_network_policy` classifies only `OFFLINE`, `CONSTRAINED`, or `NORMAL`. Automatic network work is denied while offline or constrained. Explicit user-initiated network context may override only the constrained state; offline always fails closed. No policy state authorizes an external AI backend.

### Durable Local Task Outbox

`nd_outbox` is a local task queue, not a remote-AI request queue. It provides stable idempotency keys, serial FIFO eligibility, per-project IDs, up to eight local dependencies, manual-removal dependency blocking, relink with cycle rejection, seven-day TTL, deterministic bounded exponential backoff, pause after five failures, sanitized error categories and atomic file replacement.

Profile quotas preserve the historical mobile budgets:
- Micro: 20 items / 64 KiB total / 8 KiB per item;
- Mobile: 50 / 256 KiB / 16 KiB;
- Mobile Plus: 75 / 512 KiB / 32 KiB.

### Local Projects

`nd_project` manages metadata only: the non-removable `default` workspace, create/select/rename/remove for bounded opaque IDs, and safe project-scoped storage path construction. Memory, RAG and outbox remain owned by their existing components and are isolated by caller-selected project paths/IDs rather than duplicated engines.

### Pilot / Kill Switch

`nd_pilot` retains a closed allowlist of six local capabilities and a master kill. All flags default enabled to preserve v0.7.1 behavior. The master kill is enforced by `NDAssistant` before local inference and is exposed through JNI/Kotlin. Audit is bounded to 20 administrative events and contains no prompt or response content.

### Model Acquisition Preflight

`nd_model_acquisition` estimates candidate model bytes from parameter count/bit width plus runtime overhead and evaluates resource profile, free storage and network state. It performs no download, license acceptance, remote model call or automatic activation.

### Benchmark Evaluation

`nd_benchmark` aggregates sanitized local samples into success rate and p50/p95/p99 latency/TTFT/throughput statistics. Its mandatory certification string is `MEASURED_NOT_CERTIFIED`; host measurements never become physical Android evidence.

## Non-regression boundary

These owners are additive. The active neural assets, Semantic Ranker, structured memory, Local RAG, NDOS, Safety, Resource Governor, Run Journal, model authority and fail-closed current-event behavior remain unchanged. Companion pairing, image preprocessing and historical remote-provider delivery are not ported because they are not superior/currently consumable in the sovereign mobile runtime.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
