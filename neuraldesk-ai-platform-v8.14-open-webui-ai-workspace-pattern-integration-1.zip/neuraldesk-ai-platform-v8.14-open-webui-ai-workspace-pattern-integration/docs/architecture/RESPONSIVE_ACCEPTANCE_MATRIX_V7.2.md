<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Responsive Acceptance Matrix — V7.2

Every module is validated at representative viewports:

```text
390×844     phone
768×1024    tablet
1366×768    notebook
1920×1080   desktop / Full HD TV
3840×2160   4K TV
```

Acceptance criteria:

- no unintended document-level horizontal overflow;
- navigation remains reachable;
- primary content is visible without JavaScript;
- tables/complex flows may scroll inside contained regions;
- touch targets remain usable;
- TV/keyboard focus is visible;
- multimodal previews remain constrained to viewport/container;
- Chat attachment controls remain accessible on phones.
