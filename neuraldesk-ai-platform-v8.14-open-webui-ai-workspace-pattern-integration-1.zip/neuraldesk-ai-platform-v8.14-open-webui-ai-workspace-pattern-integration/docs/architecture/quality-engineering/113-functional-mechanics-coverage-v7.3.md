<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 113 — Functional Mechanics Coverage

Each module test manifest enumerates the real mechanics expected from that module.

Source:

```text
modules/<module>/tests/test.manifest.json
modules/<module>/tests/scenarios/functional-mechanics.json
```

This prevents a module from being declared complete based only on file existence.
