#include "nd_tokenizer.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define H 64u
#define ENDIAN 0x01020304u
#define PAIRS 252u
struct NDTokenizer { unsigned char pairs[PAIRS][2]; };
static uint32_t u32le(const unsigned char *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static uint64_t u64le(const unsigned char *p){uint64_t v=0;unsigned i;for(i=0;i<8;i++)v|=(uint64_t)p[i]<<(8*i);return v;}
static uint64_t fnv(const unsigned char *p,size_t n){uint64_t h=UINT64_C(1469598103934665603);size_t i;for(i=0;i<n;i++){h^=p[i];h*=UINT64_C(1099511628211);}return h;}
int nd_tokenizer_load(const char *path,NDTokenizer **out){FILE *f;long n;unsigned char *b;NDTokenizer *t;if(!path||!out)return -1;*out=NULL;f=fopen(path,"rb");if(!f)return -1;if(fseek(f,0,SEEK_END)!=0){fclose(f);return -1;}n=ftell(f);if(n!=(long)(H+PAIRS*2u)||fseek(f,0,SEEK_SET)!=0){fclose(f);return -1;}b=malloc((size_t)n);if(!b){fclose(f);return -1;}if(fread(b,1,(size_t)n,f)!=(size_t)n){free(b);fclose(f);return -1;}fclose(f);if(memcmp(b,"NDTKV001",8)!=0||u32le(b+8)!=H||u32le(b+12)!=ENDIAN||u32le(b+16)!=ND_TOKENIZER_VOCAB||u32le(b+20)!=PAIRS||u32le(b+24)!=PAIRS*2u||fnv(b+H,PAIRS*2u)!=u64le(b+32)){free(b);return -1;}t=calloc(1,sizeof(*t));if(!t){free(b);return -1;}memcpy(t->pairs,b+H,PAIRS*2u);free(b);*out=t;return 0;}
void nd_tokenizer_free(NDTokenizer *tok){free(tok);}
size_t nd_tokenizer_vocab(const NDTokenizer *tok){return tok?ND_TOKENIZER_VOCAB:0u;}
int nd_tokenizer_encode(const NDTokenizer *tok,const unsigned char *bytes,size_t n,uint32_t *tokens,size_t cap,size_t *outn){size_t i=0,k=0;if(!tok||(!bytes&&n)||!tokens||!outn)return -1;while(i<n){int found=-1;unsigned p;if(i+1<n){for(p=0;p<PAIRS;p++){if(tok->pairs[p][0]==bytes[i]&&tok->pairs[p][1]==bytes[i+1]){found=(int)p;break;}}}if(k>=cap)return -1;if(found>=0){tokens[k++]=260u+(uint32_t)found;i+=2;}else{tokens[k++]=bytes[i++];}}*outn=k;return 0;}
int nd_tokenizer_decode(const NDTokenizer *tok,const uint32_t *tokens,size_t n,unsigned char *bytes,size_t cap,size_t *outn){size_t i,k=0;if(!tok||(!tokens&&n)||!bytes||!outn)return -1;for(i=0;i<n;i++){uint32_t t=tokens[i];if(t<256u){if(k>=cap)return -1;bytes[k++]=(unsigned char)t;}else if(t>=260u&&t<ND_TOKENIZER_VOCAB){unsigned p=t-260u;if(k+2u>cap)return -1;bytes[k++]=tok->pairs[p][0];bytes[k++]=tok->pairs[p][1];}else{return -1;}}*outn=k;return 0;}

int nd_tokenizer_decode_token_bytes(const NDTokenizer *tok,uint32_t token,unsigned char *bytes,size_t cap,size_t *outn){if(!tok||!bytes||!outn)return -1;if(token<256u){if(cap<1u)return -1;bytes[0]=(unsigned char)token;*outn=1u;return 0;}if(token>=260u&&token<ND_TOKENIZER_VOCAB){unsigned p=token-260u;if(cap<2u)return -1;bytes[0]=tok->pairs[p][0];bytes[1]=tok->pairs[p][1];*outn=2u;return 0;}return -1;}
