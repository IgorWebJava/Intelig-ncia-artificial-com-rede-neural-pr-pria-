#ifndef ND_CONTEXT_SYNTH_H
#define ND_CONTEXT_SYNTH_H

#include <stddef.h>
#include "nd_context_qa.h"
#include "nd_relation.h"

typedef struct {
    int found;
    int pointer_proposed;
    int used_pointer;
    int pointer_rejected;
    int used_relation_signal;
    size_t evidence_count;
    float best_score;
    uint32_t relation_id;
    float relation_confidence;
    size_t goal_count;
    size_t covered_goals;
} NDContextSynthesisResult;

int nd_context_synthesize_ex(const NDContextQA *qa,
                             const NDRelationClassifier *relation,
                             const char *question,
                             const char *context,
                             int rich,
                             char *out,
                             size_t outcap,
                             NDContextSynthesisResult *result,
                             char *err,
                             size_t errcap);

int nd_context_synthesize(const NDContextQA *qa,
                          const char *question,
                          const char *context,
                          int rich,
                          char *out,
                          size_t outcap,
                          NDContextSynthesisResult *result,
                          char *err,
                          size_t errcap);

#endif
