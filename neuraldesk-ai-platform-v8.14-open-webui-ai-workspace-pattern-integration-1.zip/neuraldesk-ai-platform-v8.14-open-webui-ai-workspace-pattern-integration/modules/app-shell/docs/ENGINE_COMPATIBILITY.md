<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell -->
# Engine Compatibility — App Shell

**Profile:** `cooperative-engine-bridge-v1`  
**Policy:** `preserve → extend → bridge`  
**Neural Engine:** documentation-only / not implemented.

## Purpose
This module preserves every V8.10 mechanic while adding explicit UI contracts for future Neural Engine states. No surface may imply that a documented engine capability is already executing.

## Bridge capabilities
- `ui.engine.bridge.v1`
- `ui.job.durability.v1`
- `ui.direct.command.v1`
- `ui.session.replay.v1`

## Non-regression rules
1. Existing routes, tabs, actions, contracts and provided capabilities remain valid.
2. New engine states are additive and must have fallback UI.
3. Unsupported future capabilities fail visibly; they do not silently degrade.
4. Direct user commands remain distinct from model-mediated operations where applicable.
5. All external-effect states must be representable as pending, durable-intent, completed, failed or unknown-outcome when applicable.

## Truth boundary
The Engine Bridge is a local interface representation. Backend/model/agent/tool execution is still future work.
