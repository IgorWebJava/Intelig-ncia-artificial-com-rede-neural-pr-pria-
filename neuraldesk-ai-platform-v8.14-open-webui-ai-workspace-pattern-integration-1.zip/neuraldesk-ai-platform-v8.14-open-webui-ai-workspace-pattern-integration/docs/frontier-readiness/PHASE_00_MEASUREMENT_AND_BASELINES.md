# Phase 00 — Measurement and Baselines

Status: DOCUMENTATION-ONLY


Purpose: make every later claim measurable.

Deliverables:
- canonical workload suite for Chat, RAG, agents, coding, multimodal, voice, artifacts and long-running projects;
- quality, safety, latency, cost and reliability scorecards;
- reproducible reference hardware/provider configurations;
- golden datasets and acceptance fixtures;
- baseline external frontier models;
- baseline open/self-hosted models;
- benchmark result schema and experiment registry;
- red-team baseline;
- production-like load profiles.

Exit gate:
- every priority capability has a measurable success criterion;
- baseline runs are reproducible;
- no optimization is adopted without comparison to reference.
