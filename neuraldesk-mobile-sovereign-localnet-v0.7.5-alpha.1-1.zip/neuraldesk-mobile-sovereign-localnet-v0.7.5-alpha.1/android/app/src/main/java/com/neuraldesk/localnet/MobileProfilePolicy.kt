package com.neuraldesk.localnet

enum class MobileProfile(val nativeId: Int, val deadlineMs: Long) {
    MICRO(0, 5_000L), MOBILE(1, 7_500L), MOBILE_PLUS(2, 10_000L)
}

enum class MobileAbi { ARM64, X86_64, ARM32, X86, UNKNOWN }
enum class HardwareProvider { AUTO, CPU_C99, GPU, NPU }
enum class HardwareRouteStatus { OK, PROVIDER_UNAVAILABLE, PHYSICAL_CERTIFICATION_REQUIRED }

data class MobileHardwareCapabilities(
    val ramMb: Long,
    val cores: Int,
    val is64Bit: Boolean,
    val abi: MobileAbi,
    val cpuC99ExecutorAvailable: Boolean = true,
    val gpuDetected: Boolean = false,
    val gpuExecutorAvailable: Boolean = false,
    val npuDetected: Boolean = false,
    val npuExecutorAvailable: Boolean = false,
    val physicalHardwareCertified: Boolean = false,
)

data class MobileHardwareRoute(
    val status: HardwareRouteStatus,
    val requested: HardwareProvider,
    val selected: HardwareProvider?,
    val profile: MobileProfile,
    val acceleratorDetectedButUnavailable: Boolean,
)

object MobileProfilePolicy {
    fun select(ramMb: Long, cores: Int, is64Bit: Boolean): MobileProfile {
        if (!is64Bit || ramMb < 3072L || cores < 4) return MobileProfile.MICRO
        if (ramMb >= 6144L && cores >= 8) return MobileProfile.MOBILE_PLUS
        return MobileProfile.MOBILE
    }

    fun abiFromName(name: String?): MobileAbi = when (name?.lowercase()) {
        "arm64-v8a", "aarch64" -> MobileAbi.ARM64
        "x86_64", "amd64" -> MobileAbi.X86_64
        "armeabi-v7a", "arm", "armv7" -> MobileAbi.ARM32
        "x86", "i686" -> MobileAbi.X86
        else -> MobileAbi.UNKNOWN
    }

    fun route(
        capabilities: MobileHardwareCapabilities,
        requested: HardwareProvider = HardwareProvider.AUTO,
        requirePhysicalCertification: Boolean = false,
    ): MobileHardwareRoute {
        val profile = select(capabilities.ramMb, capabilities.cores, capabilities.is64Bit)
        if (requirePhysicalCertification && !capabilities.physicalHardwareCertified) {
            return MobileHardwareRoute(
                HardwareRouteStatus.PHYSICAL_CERTIFICATION_REQUIRED,
                requested,
                null,
                profile,
                false,
            )
        }
        if (requested == HardwareProvider.AUTO || requested == HardwareProvider.CPU_C99) {
            return if (capabilities.cpuC99ExecutorAvailable) {
                MobileHardwareRoute(HardwareRouteStatus.OK, requested, HardwareProvider.CPU_C99, profile, false)
            } else {
                MobileHardwareRoute(HardwareRouteStatus.PROVIDER_UNAVAILABLE, requested, null, profile, false)
            }
        }
        if (requested == HardwareProvider.GPU) {
            return if (capabilities.gpuExecutorAvailable) {
                MobileHardwareRoute(HardwareRouteStatus.OK, requested, HardwareProvider.GPU, profile, false)
            } else {
                MobileHardwareRoute(
                    HardwareRouteStatus.PROVIDER_UNAVAILABLE,
                    requested,
                    null,
                    profile,
                    capabilities.gpuDetected,
                )
            }
        }
        return if (capabilities.npuExecutorAvailable) {
            MobileHardwareRoute(HardwareRouteStatus.OK, requested, HardwareProvider.NPU, profile, false)
        } else {
            MobileHardwareRoute(
                HardwareRouteStatus.PROVIDER_UNAVAILABLE,
                requested,
                null,
                profile,
                capabilities.npuDetected,
            )
        }
    }
}
