# Benchmark Card Template

- Benchmark ID:
- Capability:
- Scenario:
- Inputs:
- Expected output/criteria:
- Dataset/version:
- Candidate configuration:
- Baseline configuration:
- Hardware/provider:
- Warmup/repetitions:
- Quality metric:
- Latency metric:
- Throughput metric:
- Memory metric:
- Cost metric:
- Safety metric:
- Statistical summary:
- Result:
