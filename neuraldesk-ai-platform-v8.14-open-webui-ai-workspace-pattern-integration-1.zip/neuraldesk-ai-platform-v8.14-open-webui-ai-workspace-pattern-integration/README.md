# NeuralDesk AI Platform — V8.14

**Cooperative AI Workspace + Agent Platform + Coding Intelligence + Future Neural Engine Blueprint**

- UI/Architecture/Docs/Memory/Skills: V8.14
- Current resolved capabilities: 157
- Future Neural Engine: 145 modules / 757 capabilities — DOCUMENTATION ONLY
- UI↔Engine mechanics: 199
- Research sources: 59
- Non-regression: preserve → extend → bridge

V8.14 adds the provider-neutral AI Workspace Platform layer derived from Open WebUI research while preserving V8.13 and all prior semantics. Root HTML files remain compatibility redirects; canonical UIs live under `modules/<module>/ui/`.
