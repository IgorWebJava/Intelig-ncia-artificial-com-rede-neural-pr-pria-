<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 44 — Arquitetura de Páginas Independentes

## Decisão

A partir da V6.1, as áreas principais deixam de existir como abas acopladas ao `index.html`.

Cada módulo possui um documento HTML próprio:

```text
index.html
chat.html
dashboard-center.html
training.html
knowledge-center.html
tools-center.html
settings.html
```

## Papel do index.html

O `index.html` é somente um launcher opcional.

Ele:

- não contém a implementação das páginas;
- não contém os conteúdos internos das abas;
- não é necessário para abrir qualquer módulo;
- pode ser removido pelo sistema hospedeiro sem impedir o uso das demais páginas.

## Independência

Cada página:

- possui `<!doctype html>`;
- possui `<html>`, `<head>` e `<body>`;
- possui seu próprio título;
- possui sua própria navegação;
- pode ser aberta diretamente;
- pode ser incorporada individualmente ao sistema real.

## Dependência compartilhada

As páginas podem compartilhar CSS.

Isso é uma dependência de apresentação, não uma dependência de página.

Se a integração exigir isolamento total, o sistema hospedeiro pode copiar os estilos utilizados por cada módulo para arquivos CSS específicos sem alterar a estrutura HTML.

## Navegação

Links entre módulos apontam diretamente para os respectivos arquivos HTML.

Exemplo:

```text
Chat → chat.html
Dashboard → dashboard-center.html
Knowledge Studio → training.html
Knowledge Center → knowledge-center.html
Tools → tools-center.html
Settings → settings.html
```
