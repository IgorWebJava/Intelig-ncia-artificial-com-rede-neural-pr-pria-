<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Workflow — Evoluir Experiência V8+

1. Read current memory, AI handoff, module manifest, tests and preview.
2. Identify the owning module and user task.
3. Preserve the global interaction grammar: shell, workspace, inspector, drawers, command palette.
4. Apply progressive disclosure; do not expose every advanced control at once.
5. Keep ordinary text readable; micro metadata must not drop below the Design System floor.
6. Keep CSS and JavaScript runtime module-owned.
7. Do not introduce direct DB/provider SDK access in the browser.
8. Update module tests, runtime tests, docs, skills if needed.
9. Regenerate preview.
10. Run release gates and interaction tests.
