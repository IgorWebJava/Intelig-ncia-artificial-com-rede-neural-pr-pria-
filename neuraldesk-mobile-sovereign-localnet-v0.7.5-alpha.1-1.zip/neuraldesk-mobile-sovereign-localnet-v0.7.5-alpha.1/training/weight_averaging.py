#!/usr/bin/env python3
"""Governed compatible checkpoint averaging candidate builder.

This is a training utility, not a model promotion authority.
"""
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path
import numpy as np
from checkpoint_manager import load_checkpoint, save_checkpoint

ROOT=Path(__file__).resolve().parents[1]

def precheck():
    subprocess.run([sys.executable,str(ROOT/'scripts/pre_generation_lessons_check.py')],cwd=ROOT,check=True)

def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()

def average_checkpoints(paths:list[Path],expected_bindings:dict,weights:list[float]|None=None):
    if len(paths)<2: raise ValueError('at least two checkpoints required')
    loaded=[load_checkpoint(p,expected_bindings=expected_bindings) for p in paths]
    models=[x[1] for x in loaded]
    keys=sorted(models[0])
    if not keys: raise ValueError('empty checkpoint model')
    if weights is None: weights=[1.0/len(paths)]*len(paths)
    if len(weights)!=len(paths) or any(w<0 for w in weights) or not np.isfinite(weights).all(): raise ValueError('invalid averaging weights')
    total=float(sum(weights))
    if total<=0: raise ValueError('averaging weights sum must be positive')
    weights=[float(w)/total for w in weights]
    for m in models[1:]:
        if sorted(m)!=keys: raise ValueError('model key mismatch')
    out={}
    for k in keys:
        ref=np.asarray(models[0][k])
        if ref.dtype.kind not in 'fc': raise ValueError(f'non-floating model tensor: {k}')
        acc=np.zeros(ref.shape,dtype=np.float64)
        for w,m in zip(weights,models):
            a=np.asarray(m[k])
            if a.shape!=ref.shape or a.dtype!=ref.dtype: raise ValueError(f'tensor compatibility mismatch: {k}')
            acc += w*a.astype(np.float64)
        out[k]=acc.astype(ref.dtype)
    return out,weights,[x[0] for x in loaded]

def build_candidate(paths:list[Path],expected_bindings:dict,out_dir:Path,weights:list[float]|None=None):
    model,norm_weights,meta=average_checkpoints(paths,expected_bindings,weights)
    optimizer={}
    out=save_checkpoint(out_dir,phase='AVERAGING_CANDIDATE_NOT_PROMOTED',step=max(int(m['step']) for m in meta),model=model,optimizer=optimizer,bindings=expected_bindings)
    report={
      'schema':'neuraldesk-weight-averaging-candidate-v1','status':'AVERAGING_CANDIDATE_NOT_PROMOTED',
      'strategy':'WEIGHTED_CHECKPOINT_AVERAGE','sourceCheckpoints':[{'path':str(p),'sha256':sha(p)} for p in paths],
      'normalizedWeights':norm_weights,'bindings':expected_bindings,'candidatePath':str(out),'candidateSha256':sha(out),
      'promotionAuthority':'scripts/model_authority.py','qualityClaim':False,
    }
    rp=out.with_suffix('.averaging-report.json');rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return out,rp

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--bindings',type=Path,required=True);ap.add_argument('--out-dir',type=Path,required=True);ap.add_argument('checkpoints',nargs='+',type=Path);a=ap.parse_args()
    precheck();bindings=json.loads(a.bindings.read_text());out,rp=build_candidate(a.checkpoints,bindings,a.out_dir);print(f'WEIGHT_AVERAGING_CANDIDATE PASS path={out} report={rp}')
if __name__=='__main__':main()
