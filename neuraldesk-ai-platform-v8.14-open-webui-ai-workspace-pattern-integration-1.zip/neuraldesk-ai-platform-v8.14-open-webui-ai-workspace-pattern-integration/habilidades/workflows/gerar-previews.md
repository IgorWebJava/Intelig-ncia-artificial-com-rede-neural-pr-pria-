<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Gerar Previews dos Módulos

## Gerar todos

```text
python tools/generate_module_previews.py
```

## Gerar um módulo

```text
python tools/generate_module_previews.py --module chat
```

## Padrão

```text
Profile: module-preview-v1
Viewport: 1600x1000
Mode: viewport capture
Format: PNG
```

## Depois de gerar

Execute:

```text
python tools/validate_previews.py
```

Uma mudança visual significativa exige regeneração do preview do módulo.
