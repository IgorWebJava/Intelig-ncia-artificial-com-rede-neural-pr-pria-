<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.architecture -->
# Current Interface Capability Map — V8.11

Current platform capability bindings resolve **106 capabilities**. The experience runtime contributes **29 UI capabilities** under `platform.experience-runtime`.

## Experience capabilities

- `ui.adaptive-inspector.v1`
- `ui.artifact.workspace.v1`
- `ui.command_palette.v1`
- `ui.context-lens.v1`
- `ui.context.compaction.v1`
- `ui.density.v1`
- `ui.direct.command.v1`
- `ui.engine.bridge.v1`
- `ui.extension.governance.v1`
- `ui.global.search.v1`
- `ui.harness.ablation.v1`
- `ui.job.durability.v1`
- `ui.notification.center.v1`
- `ui.provenance.v1`
- `ui.runtime.interaction.v1`
- `ui.runtime.invariants.v1`
- `ui.sandbox.policy.v1`
- `ui.session.replay.v1`
- `ui.session.schema.v1`
- `ui.specialized-workspace.v1`
- `ui.subagent.federation.v1`
- `ui.task.center.v1`
- `ui.tool.effect.durability.v1`
- `ui.trust-layer.v1`
- `ui.turn.step.timeline.v1`
- `ui.unknown-outcome.v1`
- `ui.version-diff.v1`
- `ui.workflow.canvas.v1`
- `ui.workspace.shell.v1`

## Registry authority

- Provider declarations: `platform/capability-registry/platform-providers.json`
- Active bindings: `platform/capability-registry/bindings.json`
- Experience runtime capabilities: `platform/experience-runtime/capabilities.json`
- Engine bridge mapping: `platform/engine-ui-bridge/registry.json`

The UI capability layer is executable only as local template interaction. Backend/engine semantics remain future work.
