# Phase 08 — Frontier Research and Continuous Optimization

Status: DOCUMENTATION-ONLY


Research dense, MoE, long-context, hybrid sequence and multimodal architectures plus distributed training, kernels, inference serving, KV scheduling, speculative decoding, quantization and compiler paths.

Every experiment must include:
- hypothesis;
- reference baseline;
- dataset/workload;
- hardware;
- quality/safety floor;
- latency/throughput/memory/cost metrics;
- reproducibility record;
- adoption/rollback decision.

A technique becomes default only after evidence on NeuralDesk workloads.

## V8.9 omni-modal architecture tracks

The frontier architecture lab now tracks Thinker–Talker-style semantic/expression separation, dynamic-window audio encoders, temporal multimodal alignment and multi-codebook speech as research families rather than fixed implementations.
