#!/usr/bin/env python3
import json,re,unicodedata
from pathlib import Path
R=Path(__file__).resolve().parents[1]; D=R/'training/data/generative_v074'; H=R/'evaluation/generative_v074/HOLDOUT_PROBES.json'
def norm(s): return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',s).casefold()).strip()
train='\n'.join(json.loads(x).get('question',json.loads(x).get('text','')) for n in ['sft_train.jsonl','causal_replay.jsonl'] for x in (D/n).read_text(encoding='utf-8').splitlines() if x.strip())
tn=norm(train); probes=json.loads(H.read_text())['probes']; assert len(probes)==6
for p in probes:
    assert norm(p['prompt']) not in tn, p['id']
print('GENERATIVE_HOLDOUT_ISOLATION PASS probes=6 exactPromptLeakage=0')
