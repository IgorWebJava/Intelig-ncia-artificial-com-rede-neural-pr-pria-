#!/usr/bin/env python3
from pathlib import Path
import struct
p=Path('models/neuraldesk-relation-classifier-v0.5.ndrl')
b=p.read_bytes(); assert len(b)>=28
magic,version,feature_dim,hidden,classes,seed,reserved=struct.unpack_from('<7I',b,0)
assert magic==0x314c524e and version==1
assert feature_dim==2048 and hidden==64 and classes==26 and seed==507 and reserved==0
expected=feature_dim*hidden+hidden+hidden*classes+classes
assert len(b)==28+expected*4,(len(b),28+expected*4)
print('relation-model-format PASS',expected,'floats')
