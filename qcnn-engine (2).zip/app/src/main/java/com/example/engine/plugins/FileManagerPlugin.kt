package com.example.engine.plugins

import android.content.Context
import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import java.io.File

/**
 * Plugin Kotlin para Criação e Gerenciamento de Arquivos Estruturados (CSV, JSON, MD) no Android.
 */
class FileManagerPlugin(private val context: Context? = null) : IQcnnPlugin {
    override val pluginId: String = "file_manager"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        val entrada = context.prompt.trim().lowercase()

        if (entrada.contains("criar arquivo") || entrada.contains("gerar arquivo") || entrada.contains("gerar csv") || entrada.contains("gerar json") || entrada.contains("salvar arquivo")) {
            val (nome, conteudo, formato) = gerarConteudo(entrada, context)
            val path = salvarArquivo(nome, conteudo)

            context.metadata["arquivo_gerado"] = path
            context.metadata["formato_arquivo"] = formato
            context.metadata["modulo_arquivo"] = pluginId

            if (entrada.contains("criar arquivo") || entrada.contains("gerar arquivo") || entrada.contains("gerar csv") || entrada.contains("gerar json")) {
                context.customResponse = "📁 **[Multi-V File Manager]** Arquivo Estruturado Gerado com Sucesso!\n\n- **Arquivo:** `$nome`\n- **Formato:** `${formato.uppercase()}`\n- **Caminho:** `$path`\n\n```$formato\n$conteudo\n```\n\n✨ *Persistência local concluída com integridade.*"
            }
        }
        return context
    }

    private fun gerarConteudo(prompt: String, ctx: QcnnExecutionContext): Triple<String, String, String> {
        return when {
            prompt.contains("csv") || prompt.contains("tabela") -> {
                val csv = "id,parametro,valor,unidade\n1,Frequencia,${String.format("%.2f", ctx.totalFrequencyHz)},Hz\n2,Estado,${ctx.finalState},Status\n3,C_Score,1.00,Metacognicao"
                Triple("metricas_engine.csv", csv, "csv")
            }
            prompt.contains("json") -> {
                val json = "{\n  \"motor\": \"Multi-V Android v6.0\",\n  \"frequencia_hz\": ${ctx.totalFrequencyHz},\n  \"estado\": \"${ctx.finalState}\",\n  \"c_score\": 1.0\n}"
                Triple("relatorio_android.json", json, "json")
            }
            else -> {
                val md = "# 📋 Relatório de Execução Android Multi-V\n\n- Frequência: ${String.format("%.2f", ctx.totalFrequencyHz)} Hz\n- Estado: ${ctx.finalState}\n- Validação: Epistêmica 100%"
                Triple("relatorio.md", md, "markdown")
            }
        }
    }

    private fun salvarArquivo(nome: String, conteudo: String): String {
        return try {
            val dir = context?.filesDir ?: File("./arquivos_gerados")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, nome)
            file.writeText(conteudo)
            file.absolutePath
        } catch (e: Exception) {
            nome
        }
    }
}
