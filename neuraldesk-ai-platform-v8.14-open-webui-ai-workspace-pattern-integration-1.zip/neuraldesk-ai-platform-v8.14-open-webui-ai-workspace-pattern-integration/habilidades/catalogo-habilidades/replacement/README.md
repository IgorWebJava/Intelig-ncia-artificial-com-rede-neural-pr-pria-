<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Module / Model Replacement & Compatibility

    Skill ID: `neuraldesk.module-model-replacement.v1`

    ## Category

    `architecture-release`

    ## Introduced

    `V7.0`

    ## Required development capabilities

    - `module.architecture.design.v1`
- `ai.model-replacement.design.v1`
- `test.scenario.design.v1`
- `audit.trace.design.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/<module>/compatibility/`
- `docs/architecture/MODULE_MODEL_REPLACEMENT_V7.1.md`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
