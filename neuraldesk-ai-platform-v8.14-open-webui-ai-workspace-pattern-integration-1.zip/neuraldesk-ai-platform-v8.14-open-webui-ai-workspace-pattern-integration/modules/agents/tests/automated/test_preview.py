import sys, unittest, json, struct
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class PreviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestContext(__file__)
        cls.preview = cls.ctx.manifest.get("preview", {})

    def test_preview_declared(self):
        self.assertEqual(self.preview.get("profile"), "module-preview-v1")
        self.assertEqual(self.preview.get("ownership"), "module")

    def test_preview_files_exist(self):
        self.assertTrue((self.ctx.module_root / self.preview["image"]).exists())
        self.assertTrue((self.ctx.module_root / self.preview["metadata"]).exists())

    def test_preview_is_png_and_matches_viewport(self):
        p = self.ctx.module_root / self.preview["image"]
        b = p.read_bytes()
        self.assertEqual(b[:8], b"\x89PNG\r\n\x1a\n")
        width, height = struct.unpack(">II", b[16:24])
        self.assertEqual(width, self.preview["viewport"]["width"])
        self.assertEqual(height, self.preview["viewport"]["height"])
        self.assertGreater(len(b), 10000)

    def test_preview_metadata_matches_module(self):
        md = json.loads((self.ctx.module_root / self.preview["metadata"]).read_text(encoding="utf-8"))
        self.assertEqual(md["module_id"], self.ctx.manifest["module_id"])
        self.assertEqual(md["module_version"], self.ctx.manifest["version"])
        self.assertEqual(md["image"], self.preview["image"])
        self.assertEqual(md["source_ui"], self.ctx.manifest["canonical_ui"])

if __name__ == "__main__":
    unittest.main()
