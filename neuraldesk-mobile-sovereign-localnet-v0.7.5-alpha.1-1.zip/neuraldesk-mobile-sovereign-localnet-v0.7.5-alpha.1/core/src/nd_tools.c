#include "nd_tools.h"

#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void seterr(char *e, size_t n, const char *fmt, ...) {
    if (!e || !n) return;
    va_list a;
    va_start(a, fmt);
    vsnprintf(e, n, fmt, a);
    va_end(a);
}

static unsigned char lo(unsigned char x) {
    return (x >= 'A' && x <= 'Z') ? (unsigned char)(x + 32) : x;
}

static int contains_ci(const char *s, const char *needle) {
    size_t n = strlen(needle);
    if (!n) return 1;
    for (; *s; s++) {
        size_t i = 0;
        while (i < n && s[i] && lo((unsigned char)s[i]) == lo((unsigned char)needle[i])) i++;
        if (i == n) return 1;
    }
    return 0;
}

static size_t numbers(const char *s, double *v, size_t cap) {
    size_t k = 0;
    const char *p = s;
    while (*p && k < cap) {
        while (*p && !isdigit((unsigned char)*p) && *p != '.' && *p != ',') p++;
        if (!*p) break;
        char *end = NULL;
        double x = strtod(p, &end);
        if (end == p) {
            p++;
            continue;
        }
        if (*end == ',' && isdigit((unsigned char)end[1])) {
            char tmp[96];
            size_t z = 0;
            const char *q = p;
            while (*q && z + 1u < sizeof(tmp) &&
                   (isdigit((unsigned char)*q) || *q == ',' || *q == '.')) {
                tmp[z++] = (*q == ',') ? '.' : *q;
                q++;
            }
            tmp[z] = 0;
            char *e2 = NULL;
            x = strtod(tmp, &e2);
            if (e2 && *e2 == 0) end = (char *)q;
        }
        v[k++] = x;
        p = end;
    }
    return k;
}

static const char *op_symbol(const char *op) {
    if (strcmp(op, "add") == 0) return "+";
    if (strcmp(op, "sub") == 0) return "−";
    if (strcmp(op, "mul") == 0) return "×";
    if (strcmp(op, "div") == 0) return "÷";
    if (strcmp(op, "pow") == 0) return "^";
    return "";
}

static int emit(char *out, size_t cap, const char *fmt, ...) {
    va_list a;
    va_start(a, fmt);
    int w = vsnprintf(out, cap, fmt, a);
    va_end(a);
    return (w < 0 || (size_t)w >= cap) ? -1 : 0;
}

typedef struct {
    const char *s;
    size_t pos;
    size_t len;
    int error;
    int division_by_zero;
} ExprParser;

static void expr_skip_ws(ExprParser *p) {
    while (p->pos < p->len && isspace((unsigned char)p->s[p->pos])) p->pos++;
}

static int expr_peek(ExprParser *p) {
    expr_skip_ws(p);
    return p->pos < p->len ? (unsigned char)p->s[p->pos] : 0;
}

static int expr_take(ExprParser *p, char c) {
    expr_skip_ws(p);
    if (p->pos < p->len && p->s[p->pos] == c) {
        p->pos++;
        return 1;
    }
    return 0;
}

static double expr_parse_expression(ExprParser *p);

static double expr_parse_primary(ExprParser *p) {
    expr_skip_ws(p);
    if (expr_take(p, '(')) {
        double v = expr_parse_expression(p);
        if (!expr_take(p, ')')) p->error = 1;
        return v;
    }
    if (p->pos >= p->len || (!isdigit((unsigned char)p->s[p->pos]) && p->s[p->pos] != '.')) {
        p->error = 1;
        return 0.0;
    }
    char *end = NULL;
    double v = strtod(p->s + p->pos, &end);
    if (!end || end == p->s + p->pos) {
        p->error = 1;
        return 0.0;
    }
    p->pos = (size_t)(end - p->s);
    return v;
}

static double expr_parse_unary(ExprParser *p) {
    if (expr_take(p, '+')) return expr_parse_unary(p);
    if (expr_take(p, '-')) return -expr_parse_unary(p);
    return expr_parse_primary(p);
}

static double expr_parse_power(ExprParser *p) {
    double left = expr_parse_unary(p);
    if (p->error) return 0.0;
    if (expr_take(p, '^')) {
        double right = expr_parse_power(p);
        double v = pow(left, right);
        if (!isfinite(v)) p->error = 1;
        return v;
    }
    return left;
}

static double expr_parse_term(ExprParser *p) {
    double v = expr_parse_power(p);
    while (!p->error) {
        int c = expr_peek(p);
        if (c != '*' && c != '/') break;
        p->pos++;
        double rhs = expr_parse_power(p);
        if (p->error) return 0.0;
        if (c == '*') {
            v *= rhs;
        } else {
            if (fabs(rhs) < 1e-15) {
                p->division_by_zero = 1;
                p->error = 1;
                return 0.0;
            }
            v /= rhs;
        }
        if (!isfinite(v)) p->error = 1;
    }
    return v;
}

static double expr_parse_expression(ExprParser *p) {
    double v = expr_parse_term(p);
    while (!p->error) {
        int c = expr_peek(p);
        if (c != '+' && c != '-') break;
        p->pos++;
        double rhs = expr_parse_term(p);
        if (p->error) return 0.0;
        v = c == '+' ? v + rhs : v - rhs;
        if (!isfinite(v)) p->error = 1;
    }
    return v;
}

static int is_utf8_op(const char *p, const char *op) {
    size_t n = strlen(op);
    return strncmp(p, op, n) == 0;
}

static int extract_symbolic_expression(const char *q, char *expr, size_t cap,
                                       size_t *number_count, size_t *binary_ops) {
    size_t used = 0u;
    size_t nums = 0u;
    size_t ops = 0u;
    int in_number = 0;
    for (const char *p = q; *p;) {
        unsigned char c = (unsigned char)*p;
        if (isdigit(c)) {
            if (!in_number) nums++;
            in_number = 1;
            if (used + 1u >= cap) return -1;
            expr[used++] = *p++;
            continue;
        }
        if ((c == '.' || c == ',') && in_number && isdigit((unsigned char)p[1])) {
            if (used + 1u >= cap) return -1;
            expr[used++] = c == ',' ? '.' : (char)c;
            p++;
            continue;
        }
        in_number = 0;
        if (is_utf8_op(p, "×")) {
            if (used + 1u >= cap) return -1;
            expr[used++] = '*';
            ops++;
            p += strlen("×");
            continue;
        }
        if (is_utf8_op(p, "÷")) {
            if (used + 1u >= cap) return -1;
            expr[used++] = '/';
            ops++;
            p += strlen("÷");
            continue;
        }
        if (is_utf8_op(p, "−")) {
            if (used + 1u >= cap) return -1;
            expr[used++] = '-';
            ops++;
            p += strlen("−");
            continue;
        }
        if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^') {
            if (used + 1u >= cap) return -1;
            expr[used++] = (char)c;
            ops++;
            p++;
            continue;
        }
        if (c == '(' || c == ')') {
            if (used + 1u >= cap) return -1;
            expr[used++] = (char)c;
            p++;
            continue;
        }
        if (isspace(c)) {
            if (used && used + 1u < cap && expr[used - 1u] != ' ') expr[used++] = ' ';
        }
        p++;
    }
    while (used && expr[used - 1u] == ' ') used--;
    expr[used] = 0;
    if (number_count) *number_count = nums;
    if (binary_ops) *binary_ops = ops;
    return 0;
}

static int try_symbolic_expression(const char *q, int rich, char *out, size_t cap,
                                   NDCalculatorResult *r, char *e, size_t ec) {
    char expr[512];
    size_t nums = 0u, ops = 0u;
    if (extract_symbolic_expression(q, expr, sizeof(expr), &nums, &ops)) {
        seterr(e, ec, "calculator expression exceeds bounds");
        return -1;
    }
    if (nums < 2u || ops == 0u) return 0;

    ExprParser p = {expr, 0u, strlen(expr), 0, 0};
    double value = expr_parse_expression(&p);
    expr_skip_ws(&p);
    NDCalculatorResult rr;
    memset(&rr, 0, sizeof(rr));
    rr.matched = 1;
    strncpy(rr.operation, "expression", sizeof(rr.operation) - 1u);
    rr.operation[sizeof(rr.operation) - 1u] = 0;

    if (p.error || p.pos != p.len || !isfinite(value)) {
        if (p.division_by_zero) {
            if (emit(out, cap, "Não é possível dividir por zero.")) {
                seterr(e, ec, "calculator answer buffer too small");
                return -1;
            }
        } else {
            if (emit(out, cap, "Não consegui avaliar a expressão matemática com segurança.")) {
                seterr(e, ec, "calculator answer buffer too small");
                return -1;
            }
        }
        if (r) *r = rr;
        return 1;
    }

    rr.ok = 1;
    rr.value = value;
    char z[64];
    snprintf(z, sizeof(z), "%.12g", value);
    if (!rich) {
        if (emit(out, cap, "%s.", z)) {
            seterr(e, ec, "calculator answer buffer too small");
            return -1;
        }
    } else if (emit(out, cap,
                    "O resultado da expressão é %s. O cálculo completo foi avaliado localmente com precedência e parênteses pela ferramenta matemática determinística.",
                    z)) {
        seterr(e, ec, "calculator answer buffer too small");
        return -1;
    }
    if (r) *r = rr;
    return 1;
}

int nd_calculator_try(const char *q, int rich, char *out, size_t cap,
                      NDCalculatorResult *r, char *e, size_t ec) {
    if (!q || !out || !cap) {
        seterr(e, ec, "invalid calculator input");
        return -1;
    }
    NDCalculatorResult rr;
    memset(&rr, 0, sizeof(rr));
    double n[4];
    size_t nc = numbers(q, n, 4);
    const char *op = NULL;

    if ((contains_ci(q, "raiz quadrada") || contains_ci(q, "sqrt")) && nc >= 1u) op = "sqrt";
    else if (((contains_ci(q, "porcentagem") || contains_ci(q, "percentual") ||
               contains_ci(q, "que porcentagem") || contains_ci(q, "qual porcentagem")) &&
              nc >= 2u && (contains_ci(q, " de ") || contains_ci(q, " em "))) ||
             (contains_ci(q, "quantos por cento") && nc >= 2u &&
              (contains_ci(q, " em ") || contains_ci(q, " de ")))) op = "ratio_pct";
    else if ((contains_ci(q, "por cento de") || (strchr(q, '%') && contains_ci(q, " de "))) && nc >= 2u) op = "pct";
    else if ((contains_ci(q, "elevado a") || contains_ci(q, "potência") || contains_ci(q, "potencia")) && nc >= 2u) op = "pow";
    else {
        int symbolic = try_symbolic_expression(q, rich, out, cap, r, e, ec);
        if (symbolic != 0) return symbolic;
    }

    if (!op) {
        if ((contains_ci(q, " vezes ") || contains_ci(q, "multiplic")) && nc >= 2u) op = "mul";
        else if ((contains_ci(q, " dividido ") || contains_ci(q, "dividir ") || contains_ci(q, "divisão")) && nc >= 2u) op = "div";
        else if (contains_ci(q, " mais ") && nc >= 2u) op = "add";
        else if (contains_ci(q, " menos ") && nc >= 2u) op = "sub";
    }

    if (!op) {
        out[0] = 0;
        if (r) *r = rr;
        return 0;
    }
    rr.matched = 1;
    strncpy(rr.operation, op, sizeof(rr.operation) - 1u);
    rr.operation[sizeof(rr.operation) - 1u] = 0;

    double value = 0.0;
    if (strcmp(op, "sqrt") == 0) {
        if (n[0] < 0.0) {
            if (emit(out, cap, "Não é possível calcular uma raiz quadrada real de um número negativo.")) goto small;
            if (r) *r = rr;
            return 1;
        }
        value = sqrt(n[0]);
    } else if (strcmp(op, "pct") == 0) {
        value = n[0] * n[1] / 100.0;
    } else if (strcmp(op, "ratio_pct") == 0) {
        if (fabs(n[1]) < 1e-15) {
            if (emit(out, cap, "Não é possível calcular porcentagem com total zero.")) goto small;
            if (r) *r = rr;
            return 1;
        }
        value = n[0] * 100.0 / n[1];
    } else if (strcmp(op, "pow") == 0) {
        value = pow(n[0], n[1]);
        if (!isfinite(value)) {
            if (emit(out, cap, "O resultado da potência excede o intervalo numérico suportado.")) goto small;
            if (r) *r = rr;
            return 1;
        }
    } else if (strcmp(op, "add") == 0) value = n[0] + n[1];
    else if (strcmp(op, "sub") == 0) value = n[0] - n[1];
    else if (strcmp(op, "mul") == 0) value = n[0] * n[1];
    else {
        if (fabs(n[1]) < 1e-15) {
            if (emit(out, cap, "Não é possível dividir por zero.")) goto small;
            if (r) *r = rr;
            return 1;
        }
        value = n[0] / n[1];
    }

    rr.ok = 1;
    rr.value = value;
    char a[64], b[64], z[64];
    snprintf(a, sizeof(a), "%.12g", n[0]);
    snprintf(b, sizeof(b), "%.12g", nc >= 2u ? n[1] : 0.0);
    snprintf(z, sizeof(z), "%.12g", value);

    if (!rich) {
        if (emit(out, cap, "%s.", z)) goto small;
    } else if (strcmp(op, "sqrt") == 0) {
        if (emit(out, cap, "A raiz quadrada de %s é %s. O resultado foi calculado localmente pela ferramenta matemática determinística.", a, z)) goto small;
    } else if (strcmp(op, "pct") == 0) {
        if (emit(out, cap, "%s%% de %s = %s. O resultado foi calculado localmente pela ferramenta matemática determinística.", a, b, z)) goto small;
    } else if (strcmp(op, "ratio_pct") == 0) {
        if (emit(out, cap, "%s de %s corresponde a %s%%. O resultado foi calculado localmente pela ferramenta matemática determinística.", a, b, z)) goto small;
    } else {
        if (emit(out, cap, "%s %s %s = %s. O resultado foi calculado localmente pela ferramenta matemática determinística.", a, op_symbol(op), b, z)) goto small;
    }
    if (r) *r = rr;
    return 1;

small:
    seterr(e, ec, "calculator answer buffer too small");
    return -1;
}
