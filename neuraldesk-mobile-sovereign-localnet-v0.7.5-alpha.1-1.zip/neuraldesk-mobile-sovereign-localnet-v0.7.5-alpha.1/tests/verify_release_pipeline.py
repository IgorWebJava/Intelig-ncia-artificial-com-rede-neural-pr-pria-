#!/usr/bin/env python3
"""Static/structural contract for the current LocalNet release evidence and package verification."""
from pathlib import Path
import json

root = Path('.')
manifest = json.loads((root/'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))
version = manifest['version']
assert manifest['verificationPolicy']['verifyMarker'] == f'VERIFY PASS version={version}'
assert manifest['verificationPolicy']['sanitizerMarker'] == f'SANITIZER PASS version={version}'
assert manifest['evaluation']['calculator'] == '16/16'
assert manifest['evaluation']['conversationalCorrectness'] == '12/12'
assert manifest['evaluation']['dialogueGrounding'] == '7/7'
assert manifest['evaluation']['robustIntentV063Recovery'] == '11/11'
assert manifest['evaluation']['semanticRanker'].startswith('746/749')

assert manifest['evaluation']['networkPolicy'].startswith('PASS')
assert manifest['evaluation']['pilotControl'].startswith('PASS')
assert manifest['evaluation']['durableOutbox'].startswith('PASS')
assert manifest['evaluation']['localProjects'].startswith('PASS')
assert manifest['evaluation']['modelAcquisition'].startswith('PASS')
assert manifest['evaluation']['benchmarkEvaluation'].startswith('PASS')
assert manifest['evaluation']['weightAveraging'].startswith('PASS')
assert manifest['evaluation']['offlineContinuity'].startswith('PASS')
assert manifest['verificationPolicy']['resumablePhases'] is True
assert manifest['verificationPolicy']['finalZipMustBeReextractedAndVerified'] is True

generator = (root/'scripts/generate_release_metadata.py').read_text(encoding='utf-8')
package = (root/'scripts/package_release.py').read_text(encoding='utf-8')
assert "evaluation['calculator']" in generator
assert "evaluation['conversationalCorrectness']" in generator
assert "evaluation['dialogueGrounding']" in generator
assert 'verificationInputDigestSha256' in generator
assert 'require_external_receipts' in generator
assert "unseen_rows = ptr.get('unseen_rows')" in generator
assert 'unseen ratio mismatch' in generator
assert "'calculator':'10/10'" not in generator.replace(' ', '')
assert 'VERIFY_PHASES' in package and 'SANITIZE_PHASES' in package
assert 'ND_VERIFY_PHASE' in package and 'ND_SANITIZE_PHASE' in package
assert 'ND_VERIFY_STATE_DIR' in package
assert 'extracted input digest mismatch' in package
assert 'write_attestation' in package
assert "'verify': 'VERIFY PASS'" in package
assert "'sanitize': 'SANITIZER PASS'" in package
assert "suite.upper()" not in package
assert 'unknown phased suite' in package
assert "for phase in phases:" in package
assert "run_phase(root, suite, phase" in package

verify = (root/'scripts/verify.sh').read_text(encoding='utf-8')
sanitize = (root/'scripts/verify_sanitize.sh').read_text(encoding='utf-8')
assert 'nd_dialogue_grounding_v062_test' in verify
assert 'nd_robust_intent_v063_recovery_test' in verify
assert 'nd_historical_convergence_test' in verify
assert 'verify_semantic_ranker.py' in verify
assert 'verify_model_authority.py' in verify
assert 'nd_dialogue_grounding_v062_test' in sanitize
assert 'nd_robust_intent_v063_recovery_test' in sanitize
assert 'nd_historical_convergence_test' in sanitize
assert 'nd_execution_control_test' in verify
assert 'nd_execution_control_test' in sanitize


assert 'verify_weight_averaging.py' in verify
for name in ['nd_network_policy_test','nd_pilot_test','nd_model_acquisition_test','nd_outbox_test','nd_project_test','nd_benchmark_test','nd_offline_continuity_test']:
    assert name in verify, name
    assert name in sanitize, name
print('release-pipeline-contract PASS version/digest/receipts/phased-reextract/attestation/offline-continuity')
