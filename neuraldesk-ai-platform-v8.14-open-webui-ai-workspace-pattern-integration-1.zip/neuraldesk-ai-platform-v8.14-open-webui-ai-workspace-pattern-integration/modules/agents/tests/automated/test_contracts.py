import sys, unittest, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestContext(__file__)

    def test_declared_contract_files_exist(self):
        for name, rel in self.ctx.manifest["contracts"].items():
            with self.subTest(contract=name):
                self.assertTrue((self.ctx.module_root / rel).exists(), rel)

    def test_contract_spec_versions(self):
        openapi = (self.ctx.module_root / self.ctx.manifest["contracts"]["openapi"]).read_text(encoding="utf-8")
        asyncapi = (self.ctx.module_root / self.ctx.manifest["contracts"]["asyncapi"]).read_text(encoding="utf-8")
        self.assertIn("openapi: 3.2.0", openapi)
        self.assertIn("asyncapi: 3.1.0", asyncapi)

    def test_json_contracts_are_valid(self):
        for key in ["config_schema","capabilities","permissions","adaptive_ui"]:
            rel = self.ctx.manifest["contracts"][key]
            with self.subTest(contract=key):
                json.loads((self.ctx.module_root / rel).read_text(encoding="utf-8"))

    def test_capability_contract_matches_manifest(self):
        caps = json.loads((self.ctx.module_root / self.ctx.manifest["contracts"]["capabilities"]).read_text(encoding="utf-8"))
        self.assertEqual(sorted(caps["provides"]), sorted(self.ctx.manifest["provides_capabilities"]))
        self.assertEqual(sorted(caps["requires"]), sorted(self.ctx.manifest["requires_capabilities"]))

    def test_required_capabilities_resolve(self):
        bindings = json.loads((self.ctx.project_root / "platform/capability-registry/bindings.json").read_text(encoding="utf-8"))["bindings"]
        for cap in self.ctx.manifest["requires_capabilities"]:
            with self.subTest(capability=cap):
                self.assertIn(cap, bindings)

if __name__ == "__main__":
    unittest.main()
