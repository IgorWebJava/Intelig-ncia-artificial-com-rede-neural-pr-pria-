<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent Project Model

Projects are shared platform entities. The Agent Studio binds agents to a `project_id` but does not create a duplicate project datastore. Project roles: Owner, Admin, Builder, Reviewer, Operator, Viewer.
