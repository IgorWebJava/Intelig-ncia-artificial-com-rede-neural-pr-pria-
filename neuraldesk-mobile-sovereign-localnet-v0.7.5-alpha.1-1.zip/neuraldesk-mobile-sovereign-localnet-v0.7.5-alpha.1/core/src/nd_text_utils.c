#include "nd_text_utils.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

#define ND_SENT_MAX 128u
#define ND_WORD_MAX 128u
#define ND_WORD_BYTES 48u

typedef struct { size_t start; size_t end; unsigned score; } Sentence;
typedef struct { char word[ND_WORD_BYTES]; unsigned count; } WordCount;

static unsigned char lo(unsigned char c) {
    return (c >= 'A' && c <= 'Z') ? (unsigned char)(c + ('a' - 'A')) : c;
}

static int stopword(const char *w) {
    static const char *sw[] = {"para","com","sem","uma","uns","umas","que","qual","quais","quem","como","por","porque","sobre","este","esta","isso","esse","essa","dos","das","do","da","de","em","no","na","nos","nas","ao","aos","e","ou","o","a","os","as","um","é","são","ser","foi","mais","muito","muita","também","tambem"};
    for (size_t i = 0u; i < sizeof(sw)/sizeof(sw[0]); i++) if (strcmp(w, sw[i]) == 0) return 1;
    return 0;
}

static size_t collect_words(const char *text, WordCount *wc, size_t cap) {
    size_t n = strlen(text), i = 0u, count = 0u;
    while (i < n) {
        while (i < n && !(isalnum((unsigned char)text[i]) || (unsigned char)text[i] >= 128u)) i++;
        size_t j = i;
        while (j < n && (isalnum((unsigned char)text[j]) || text[j]=='-' || (unsigned char)text[j]>=128u)) j++;
        if (j > i && j - i >= 3u && j - i < ND_WORD_BYTES) {
            char w[ND_WORD_BYTES];
            size_t z = j - i;
            for (size_t k=0u;k<z;k++) w[k]=(char)lo((unsigned char)text[i+k]);
            w[z]=0;
            if (!stopword(w)) {
                size_t k=0u;
                for (;k<count;k++) if (strcmp(wc[k].word,w)==0) { wc[k].count++; break; }
                if (k==count && count<cap) { memcpy(wc[count].word,w,z+1u); wc[count].count=1u; count++; }
            }
        }
        i = j > i ? j : i + 1u;
    }
    return count;
}

static size_t split_sentences(const char *text, Sentence *s, size_t cap) {
    size_t n=strlen(text), start=0u, count=0u;
    while (start<n && count<cap) {
        while (start<n && isspace((unsigned char)text[start])) start++;
        if (start>=n) break;
        size_t i=start;
        while (i<n) { unsigned char c=(unsigned char)text[i++]; if (c=='.'||c=='!'||c=='?'||c=='\n') break; }
        size_t end=i;
        while (end>start && isspace((unsigned char)text[end-1u])) end--;
        if (end>start) { s[count].start=start; s[count].end=end; s[count].score=0u; count++; }
        start=i;
    }
    return count;
}

int nd_text_summary_extractive(const char *text, unsigned max_sentences, char *out, size_t cap) {
    if (!text || !out || cap==0u || max_sentences==0u) return -1;
    Sentence s[ND_SENT_MAX];
    WordCount wc[ND_WORD_MAX];
    memset(wc,0,sizeof(wc));
    size_t sn=split_sentences(text,s,ND_SENT_MAX);
    size_t wn=collect_words(text,wc,ND_WORD_MAX);
    if (!sn) { out[0]=0; return 0; }
    for (size_t i=0u;i<sn;i++) {
        char tmp[1024]; size_t len=s[i].end-s[i].start; if (len>=sizeof(tmp)) len=sizeof(tmp)-1u;
        memcpy(tmp,text+s[i].start,len); tmp[len]=0;
        WordCount sw[64]; memset(sw,0,sizeof(sw)); size_t own=collect_words(tmp,sw,64u);
        unsigned score=0u;
        for (size_t a=0u;a<own;a++) for (size_t b=0u;b<wn;b++) if (strcmp(sw[a].word,wc[b].word)==0) score += wc[b].count;
        s[i].score=score;
    }
    size_t chosen[16]; size_t cn=0u; if (max_sentences>16u) max_sentences=16u;
    while (cn<max_sentences && cn<sn) {
        size_t best=(size_t)-1; unsigned bs=0u;
        for (size_t i=0u;i<sn;i++) {
            int used=0; for (size_t j=0u;j<cn;j++) if (chosen[j]==i) used=1;
            if (!used && (best==(size_t)-1 || s[i].score>bs)) { best=i; bs=s[i].score; }
        }
        if (best == (size_t)-1) {
            break;
        }
        chosen[cn++] = best;
    }
    for (size_t i=1u;i<cn;i++) { size_t v=chosen[i],j=i; while(j>0u&&chosen[j-1u]>v){chosen[j]=chosen[j-1u];j--;} chosen[j]=v; }
    size_t used=0u; out[0]=0;
    for (size_t i=0u;i<cn;i++) {
        size_t len=s[chosen[i]].end-s[chosen[i]].start;
        if (used+len+2u>cap) return -1;
        if (i) out[used++]=' ';
        memcpy(out+used,text+s[chosen[i]].start,len); used+=len; out[used]=0;
    }
    return (int)cn;
}

int nd_text_keywords(const char *text, unsigned max_keywords, char *out, size_t cap) {
    if (!text || !out || !cap || !max_keywords) return -1;
    WordCount wc[ND_WORD_MAX]; memset(wc,0,sizeof(wc)); size_t wn=collect_words(text,wc,ND_WORD_MAX);
    for (size_t i=1u;i<wn;i++) { WordCount v=wc[i]; size_t j=i; while(j>0u && (wc[j-1u].count<v.count || (wc[j-1u].count==v.count && strcmp(wc[j-1u].word,v.word)>0))){wc[j]=wc[j-1u];j--;} wc[j]=v; }
    if (max_keywords>wn) max_keywords=(unsigned)wn;
    size_t used=0u; out[0]=0;
    for (unsigned i=0u;i<max_keywords;i++) {
        size_t len=strlen(wc[i].word); size_t extra=len+(i?2u:0u);
        if (used+extra+1u>cap) return -1;
        if (i) { out[used++]=','; out[used++]=' '; }
        memcpy(out+used,wc[i].word,len); used+=len; out[used]=0;
    }
    return (int)max_keywords;
}
