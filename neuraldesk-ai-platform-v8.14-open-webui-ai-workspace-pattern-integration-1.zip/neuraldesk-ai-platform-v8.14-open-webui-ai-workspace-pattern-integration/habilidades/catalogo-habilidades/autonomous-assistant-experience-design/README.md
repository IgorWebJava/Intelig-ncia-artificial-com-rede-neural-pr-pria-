<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Autonomous Assistant Experience Template Design

Skill ID: `neuraldesk.autonomous-assistant-experience-design.v1`

## Purpose
Design the NeuralDesk interface so it can represent a future high-level autonomous assistant without implementing the autonomous engine.

## Hard boundary

```text
IMPLEMENTED NOW
= HTML/CSS + module-owned JavaScript for local UI states

NOT IMPLEMENTED NOW
= planner/orchestrator/backend/agent execution/tool execution/web execution/persistent memory/background runtime/live microphone capture
```

## Required surfaces
Mission Control, project state, task plan, activity timeline, agents/tools visibility, Artifact Workspace, project context/memory, checkpoints, assistant modes and multimodal composer.
