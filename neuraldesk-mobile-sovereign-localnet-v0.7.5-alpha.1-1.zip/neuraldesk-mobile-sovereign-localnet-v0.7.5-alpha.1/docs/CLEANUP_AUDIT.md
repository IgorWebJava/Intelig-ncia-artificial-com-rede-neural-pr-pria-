# Cleanup Audit — v0.7.4-alpha.2

## Delta de higiene v0.7.3

`build/`, `build-dev/` e `build-sanitize/` são transitórios e devem ser removidos antes de metadata/ZIP. O arquivo RAG `.ndrag`, memória Android criptografada, Keystore e caches `filesDir` são estado de runtime do dispositivo e **não** pertencem à árvore distribuída.


## Mantido

- quatro assets canônicos v0.5;
- um único asset NDOS v0.6;
- fontes/training data mínimos necessários para reconstruir e auditar o NDOS;
- planner, synthesis, candidate acceptance, ferramentas, memória, CLI, JNI/Android, testes e documentação.

## Proibido na release

- `.ndsh` histórico;
- assets v0.4;
- builds/caches/checkpoints;
- duplicação manual em `android/app/src/main/assets`;
- campos automáticos Pirá no shard;
- arquivos de experimentos/rejected;
- evidence `FINAL_*`, `REPORT.json`, inventário ou checksums de versão anterior no freeze corrente.

`tests/verify_cleanliness.py` exige exatamente cinco arquivos em `models/`. `scripts/clean.sh` é executado antes de inventário e ZIP.

O empacotador exige árvore limpa, checksums atuais e reextração. `generate_release_metadata.py` exige logs finais vinculados à versão do manifest antes de escrever evidence nova.

## v0.6.1 candidata

Os novos arquivos permanentes são código/gates canônicos; builds, logs parciais e memory files de teste não podem permanecer no ZIP. O fechamento ainda deve executar `clean -> verify -> sanitize -> clean final -> metadata -> zip -> reextract -> verify`.

## Verificação do pacote reextraído
O ZIP final é reextraído em diretório vazio; seu digest de inputs deve ser idêntico ao da árvore fonte. VERIFY e SANITIZER são repetidos por fases com `ND_VERIFY_STATE_DIR` fora da árvore extraída. Após os testes, builds/caches são removidos e `SHA256SUMS` precisa continuar válido. A autorização final existe apenas na attestação externa do ZIP.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

