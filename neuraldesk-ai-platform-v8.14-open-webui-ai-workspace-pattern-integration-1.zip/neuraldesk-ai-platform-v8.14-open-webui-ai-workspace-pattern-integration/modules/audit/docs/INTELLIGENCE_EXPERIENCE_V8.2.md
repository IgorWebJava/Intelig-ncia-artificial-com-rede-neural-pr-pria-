<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.audit; current: modules/audit/docs/INTELLIGENCE_EXPERIENCE_V8.2.md -->
# Intelligence Experience V8.2 — audit

Profile: `intelligence-experience-v2`.

This module owns its V8.2 specialized mechanic and local runtime. Universal Context Lens, Provenance, Trust Layer, density modes and adaptive inspector patterns are template-only UI concepts.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
