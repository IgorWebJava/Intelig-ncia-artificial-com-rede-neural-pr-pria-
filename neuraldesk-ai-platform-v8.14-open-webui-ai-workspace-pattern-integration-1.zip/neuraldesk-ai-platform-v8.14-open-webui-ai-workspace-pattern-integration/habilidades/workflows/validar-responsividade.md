<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Validar Responsividade

Testar:
- 390×844
- 768×1024
- 1366×768
- 1920×1080
- 3840×2160

Verificar:
- overflow;
- conteúdo padrão visível;
- touch;
- focus-visible;
- TV/remote;
- reduced motion;
- multimodal assets.
