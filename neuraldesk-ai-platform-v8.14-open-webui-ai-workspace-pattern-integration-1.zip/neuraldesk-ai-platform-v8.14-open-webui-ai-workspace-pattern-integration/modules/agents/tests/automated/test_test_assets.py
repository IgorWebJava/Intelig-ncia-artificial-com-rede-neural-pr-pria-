import sys, unittest, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class TestAssetsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestContext(__file__)

    def test_scenario_files_are_valid_and_nonempty(self):
        for rel in self.ctx.test_manifest["scenario_files"]:
            with self.subTest(file=rel):
                data = self.ctx.json_file(rel)
                self.assertTrue(data["scenarios"])
                ids = [x["id"] for x in data["scenarios"]]
                self.assertEqual(len(ids), len(set(ids)))

    def test_fixtures_are_valid_json(self):
        for rel in self.ctx.test_manifest["fixture_files"]:
            with self.subTest(file=rel):
                self.ctx.json_file(rel)

    def test_functional_mechanics_have_coverage_mapping(self):
        data = self.ctx.json_file("scenarios/functional-mechanics.json")
        self.assertEqual(len(data["scenarios"]), len(self.ctx.test_manifest["functional_mechanics"]))
        for scenario in data["scenarios"]:
            self.assertTrue(scenario["expected"])
            self.assertIn(scenario["execution"], ["automated-static","browser-visual","future-e2e","future-integration"])

if __name__ == "__main__":
    unittest.main()
