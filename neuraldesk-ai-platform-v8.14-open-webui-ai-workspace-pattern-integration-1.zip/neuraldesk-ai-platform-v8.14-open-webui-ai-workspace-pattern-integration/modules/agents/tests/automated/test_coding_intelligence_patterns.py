import sys, unittest, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class CodingIntelligencePatternTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.ctx=TestContext(__file__)
    def test_v813_marker(self): self.assertIn('id="coding-pattern-v813"', self.ctx.html)
    def test_truth_boundary(self): self.assertIn('coding engine not connected', self.ctx.normalized_html.lower())
    def test_manifest_profile(self): self.assertEqual(self.ctx.manifest.get('ui_surface',{}).get('coding_intelligence_pattern_profile'),'coding-intelligence-patterns-v1')
    def test_research_doc(self): self.assertTrue((self.ctx.project_root/'neural-engine/research/claw-code-2026/README.md').exists())
    def test_non_regression_profile(self): self.assertEqual(self.ctx.manifest.get('engine_compatibility',{}).get('coding_intelligence_profile'),'coding-intelligence-patterns-v1')
if __name__=='__main__': unittest.main()
