# Architecture/Research Decision Template

- Decision ID:
- Date:
- Capability:
- Problem:
- Candidate options:
- Reference baseline:
- Evidence:
- Quality impact:
- Performance impact:
- Cost impact:
- Safety/security impact:
- Compatibility impact:
- Decision:
- Rollback:
- Follow-up benchmark:
