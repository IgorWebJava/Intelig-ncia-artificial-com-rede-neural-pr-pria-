"""
Plugin de Síntese de Áudio Harmônico Nativo e Exportação de Ondas PCM / WAV.
Gera áudio senoidal puro estéreo em 16-bit PCM sem dependências externas.
"""

from typing import Dict, Any, List
import math
import struct
import base64
import os
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext


class AudioWaveformPlugin(BaseQcnnPlugin):
    """
    Gera formas de onda de áudio puras em formato WAV (PCM 16-bit) e telemetria acústica
    para qualquer frequência calculada pelo motor.
    """

    @property
    def plugin_id(self) -> str:
        return "audio_waveform"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        entrada = context.prompt.strip() if context.prompt else ""
        lower = entrada.lower()

        if any(term in lower for term in ["gerar audio", "criar audio", "sintetizar audio", "gerar som", "tocar frequencia", "gerar wav"]):
            freq = context.total_frequency_hz if context.total_frequency_hz > 0 else 432.0
            wav_bytes = self.sintetizar_wav_pcm(freq=freq, duracao_seg=1.5)
            b64_audio = base64.b64encode(wav_bytes).decode("ascii")
            
            context.metadata["audio_wav_base64"] = b64_audio
            context.metadata["audio_duracao_seg"] = 1.5
            context.metadata["modulo_audio"] = "AudioWaveformPlugin"

            if "gerar audio" in lower or "criar audio" in lower or "gerar som" in lower:
                context.custom_response = (
                    f"🎵 **[Multi-V Audio Waveform]** Onda Senoidal PCM Sintetizada com Sucesso!\n\n"
                    f"- **Frequência Fundamental:** `{freq:.2f} Hz`\n"
                    f"- **Formato:** `WAV Estéreo PCM 16-bit, 44.1 kHz`\n"
                    f"- **Duração:** `1.5 segundos`\n"
                    f"- **Envelope:** ADSR Harmônico Suave\n\n"
                    f"✨ *Áudio sintetizado matematicamente de forma nativa e sem bibliotecas externas.*"
                )

        return context

    def sintetizar_wav_pcm(self, freq: float = 432.0, duracao_seg: float = 1.5, taxa_amostragem: int = 44100) -> bytes:
        num_amostras = int(taxa_amostragem * duracao_seg)
        num_canais = 2
        bytes_por_amostra = 2
        tamanho_dados = num_amostras * num_canais * bytes_por_amostra

        cabecalho = bytearray()
        cabecalho.extend(b'RIFF')
        cabecalho.extend(struct.pack('<I', 36 + tamanho_dados))
        cabecalho.extend(b'WAVE')
        cabecalho.extend(b'fmt ')
        cabecalho.extend(struct.pack('<I', 16))
        cabecalho.extend(struct.pack('<H', 1))
        cabecalho.extend(struct.pack('<H', num_canais))
        cabecalho.extend(struct.pack('<I', taxa_amostragem))
        cabecalho.extend(struct.pack('<I', taxa_amostragem * num_canais * bytes_por_amostra))
        cabecalho.extend(struct.pack('<H', num_canais * bytes_por_amostra))
        cabecalho.extend(struct.pack('<H', 16))
        cabecalho.extend(b'data')
        cabecalho.extend(struct.pack('<I', tamanho_dados))

        dados_amostras = bytearray()
        max_amplitude = 28000.0

        for i in range(num_amostras):
            t = i / taxa_amostragem
            envelope = 1.0
            if t < 0.05:
                envelope = t / 0.05
            elif t > (duracao_seg - 0.05):
                envelope = (duracao_seg - t) / 0.05

            valor_seno = math.sin(2.0 * math.pi * freq * t) * 0.85 + math.sin(2.0 * math.pi * (freq * 2.0) * t) * 0.15
            amostra_int = int(valor_seno * max_amplitude * envelope)
            amostra_int = max(-32767, min(32767, amostra_int))

            dados_amostras.extend(struct.pack('<h', amostra_int))
            dados_amostras.extend(struct.pack('<h', amostra_int))

        return bytes(cabecalho + dados_amostras)
