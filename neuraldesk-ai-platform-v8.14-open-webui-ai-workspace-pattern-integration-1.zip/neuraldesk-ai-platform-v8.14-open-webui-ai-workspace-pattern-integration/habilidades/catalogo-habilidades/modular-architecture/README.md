<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Arquitetura Modular Contract-First

    Skill ID: `neuraldesk.modular-architecture.v1`

    ## Category

    `architecture`

    ## Introduced

    `V7.0`

    ## Required development capabilities

    - `module.architecture.design.v1`
- `module.manifest.author.v1`
- `capability.registry.manage.v1`
- `contract.registry.manage.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/`
- `platform/module-registry/`
- `platform/capability-registry/`
- `platform/contract-registry/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
