# Cost and Performance Strategy

Measure:
TTFT, inter-token latency, end-to-end latency, throughput, concurrency, GPU/CPU memory, KV-cache efficiency, token usage, tool latency, storage/network cost and cost per successful task.

Optimization rule:
never trade away quality/safety invisibly.

Use workload-specific SLOs rather than one universal "fast" target.
