<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Alterar Módulo Existente

1. Identificar módulo proprietário.
2. Ler manifest, contracts, ownership, docs e tests.
3. Ler `development_requirements`.
4. Classificar mudança: UI / contract / data / AI / security / tooling.
5. Evitar breaking changes; se inevitável, versionar contrato.
6. Atualizar implementação somente dentro do boundary.
7. Atualizar testes/cenários.
8. Atualizar docs.
9. Atualizar memória/habilidades se mudança estrutural.
10. Rodar gates.
