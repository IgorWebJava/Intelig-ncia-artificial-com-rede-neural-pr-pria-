#!/usr/bin/env python3
"""Deterministic stage-only Micro-v2 trainer. Never writes models/."""
from __future__ import annotations
import argparse,hashlib,json,math,random,struct,subprocess,sys
from pathlib import Path
from typing import Any
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'training/data/generative_v074_v2'; PRE=ROOT/'scripts/pre_generation_lessons_check.py'
V=512; D=224; L=8; QH=7; KVH=1; HD=32; KVD=32; FF=640; MAX_CTX=256; PARAMS=4476640; HEADER=128
class Tok:
 def __init__(self,p):
  b=p.read_bytes(); assert len(b)==568 and b[:8]==b'NDTKV001'; self.pairs=[tuple(b[64+i*2:66+i*2]) for i in range(252)]; self.map={p:260+i for i,p in enumerate(self.pairs)}
 def encode(self,s):
  b=s.encode();o=[];i=0
  while i<len(b):
   if i+1<len(b) and (b[i],b[i+1]) in self.map:o.append(self.map[(b[i],b[i+1])]);i+=2
   else:o.append(b[i]);i+=1
  return o
class RMS(nn.Module):
 def __init__(self,n):super().__init__();self.weight=nn.Parameter(torch.ones(n))
 def forward(self,x):return x*torch.rsqrt(x.pow(2).mean(-1,keepdim=True)+1e-5)*self.weight
def rope(x):
 B,T,H,N=x.shape;pos=torch.arange(T,dtype=x.dtype,device=x.device);dims=torch.arange(0,N,2,dtype=x.dtype,device=x.device);ang=pos[:,None]/torch.pow(torch.tensor(10000.,dtype=x.dtype,device=x.device),dims[None,:]/N);c=ang.cos()[None,:,None,:];s=ang.sin()[None,:,None,:];e=x[...,0::2];o=x[...,1::2];y=torch.empty_like(x);y[...,0::2]=e*c-o*s;y[...,1::2]=e*s+o*c;return y
class Block(nn.Module):
 def __init__(self):
  super().__init__();self.r1=RMS(D);self.wq=nn.Linear(D,D,bias=False);self.wk=nn.Linear(D,KVD,bias=False);self.wv=nn.Linear(D,KVD,bias=False);self.wo=nn.Linear(D,D,bias=False);self.r2=RMS(D);self.w1=nn.Linear(D,FF,bias=False);self.w2=nn.Linear(FF,D,bias=False);self.w3=nn.Linear(D,FF,bias=False)
 def forward(self,x):
  B,T,_=x.shape;n=self.r1(x);q=rope(self.wq(n).view(B,T,QH,HD)).transpose(1,2);k=rope(self.wk(n).view(B,T,KVH,HD)).repeat_interleave(QH//KVH,2).transpose(1,2);v=self.wv(n).view(B,T,KVH,HD).repeat_interleave(QH//KVH,2).transpose(1,2);scores=(q@k.transpose(-2,-1))/math.sqrt(HD);mask=torch.ones(T,T,dtype=torch.bool,device=x.device).tril();a=torch.softmax(scores.masked_fill(~mask,-torch.inf),-1)@v;x=x+self.wo(a.transpose(1,2).contiguous().view(B,T,D));n=self.r2(x);return x+self.w2(F.silu(self.w1(n))*self.w3(n))
class MicroV2(nn.Module):
 def __init__(self):super().__init__();self.embedding=nn.Embedding(V,D);self.blocks=nn.ModuleList([Block() for _ in range(L)]);self.final_rms=RMS(D);self.apply(self._init)
 @staticmethod
 def _init(m):
  if isinstance(m,(nn.Linear,nn.Embedding)):nn.init.normal_(m.weight,0,.02)
 def forward(self,ids):
  x=self.embedding(ids)
  for b in self.blocks:x=b(x)
  return F.linear(self.final_rms(x),self.embedding.weight)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()]
def ch(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def th(sd):
 h=hashlib.sha256()
 for n,t in sorted(sd,key=lambda x:x[0]):a=t.detach().cpu().contiguous().numpy();h.update(n.encode()+a.tobytes())
 return h.hexdigest()
def oh(opt):
 b=opt.state_dict();h=hashlib.sha256();h.update(repr(b['param_groups']).encode())
 for pid,st in sorted(b['state'].items()):
  h.update(str(pid).encode())
  for k,v in sorted(st.items()):h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes() if torch.is_tensor(v) else repr(v).encode())
 return h.hexdigest()
def bindings(tok):return {n:sha(DATA/n) for n in ['rich_sft.jsonl','context_sft.jsonl','causal_replay.jsonl','pira_validation.jsonl','PROVENANCE.json']}|{'tokenizer':sha(tok)}
def cfg(a,tok):return {'schema':'nd-v074-micro-v2-config-v1','arch':{'vocab':V,'dim':D,'layers':L,'qHeads':QH,'kvHeads':KVH,'ffn':FF,'context':MAX_CTX,'params':PARAMS},'seed':a.seed,'seqLen':a.seq_len,'pretrainSteps':a.pretrain_steps,'sftSteps':a.sft_steps,'pretrainLr':a.pretrain_lr,'sftLr':a.sft_lr,'weightDecay':a.weight_decay,'threads':a.threads,'mixture':{'pretrain':'70_RICH_30_CONTEXT','sft':'80_RICH_10_CONTEXT_10_RICH_REPLAY'},'bindings':bindings(tok)}
def cpwrite(p,m,o,c,pre,sft,phase,iv):
 p.parent.mkdir(parents=True,exist_ok=True);b={'schema':'nd-v074-micro-v2-checkpoint-v1','config':c,'configSha256':ch(c),'pretrainDone':pre,'sftDone':sft,'phase':phase,'initialValidationLoss':iv,'model':m.state_dict(),'optimizer':o.state_dict(),'modelStateSha256':th(m.state_dict().items()),'optimizerStateSha256':oh(o)};torch.save(b,p);side={'checkpointSha256':sha(p),'configSha256':b['configSha256'],'modelStateSha256':b['modelStateSha256'],'optimizerStateSha256':b['optimizerStateSha256'],'phase':phase,'pretrainDone':pre,'sftDone':sft};p.with_suffix(p.suffix+'.json').write_text(json.dumps(side,indent=2,sort_keys=True)+'\n');return side
def cpload(p,m,o,c):
 side=json.loads(p.with_suffix(p.suffix+'.json').read_text());assert sha(p)==side['checkpointSha256'] and side['configSha256']==ch(c);b=torch.load(p,map_location='cpu',weights_only=False);assert b['config']==c;m.load_state_dict(b['model']);o.load_state_dict(b['optimizer']);assert th(m.state_dict().items())==b['modelStateSha256'] and oh(o)==b['optimizerStateSha256'];return b
def pad(ids,y,n):
 ids=ids[:n];y=y[:n];return torch.tensor(ids+[256]*(n-len(ids)))[None,:],torch.tensor(y+[-100]*(n-len(y)))[None,:]
def causal(rows,tok,step,n):
 r=rows[(step*9973+17)%len(rows)];ids=[257]+tok.encode(r['text'])+[258];need=n+1
 if len(ids)>need:off=(step*37)%(len(ids)-need+1);ids=ids[off:off+need]
 if len(ids)<2:ids=[257,258]
 return pad(ids[:-1],ids[1:],n)
def sftrow(r,tok,step,n,context=False):
 q=('Contexto: '+r['context']+'\nPergunta: '+r['question']) if context else r['question'];ans=tok.encode(r['response'])+[258];prompt=[257]+tok.encode(q)+[259];maxp=max(2,n-min(24,len(ans)));prompt=prompt[-maxp:];ids=(prompt+ans)[:n+1];x=ids[:-1];start=max(0,len(prompt)-1);y=[-100 if i<start else t for i,t in enumerate(ids[1:])];return pad(x,y,n)
def loss(m,x,y):return F.cross_entropy(m(x).reshape(-1,V),y.reshape(-1),ignore_index=-100)
def evalv(m,rows,tok,n):
 m.eval();z=[]
 with torch.no_grad():
  for i,r in enumerate(rows):x,y=sftrow({'question':r['question'],'response':r['answer']},tok,i,n);z.append(float(loss(m,x,y)))
 m.train();return sum(z)/len(z)
def flat(m):
 a=[m.embedding.weight.detach().cpu().numpy().astype('<f4').ravel()]
 for b in m.blocks:
  for x in (b.r1.weight,b.wq.weight,b.wk.weight,b.wv.weight,b.wo.weight,b.r2.weight,b.w1.weight,b.w2.weight,b.w3.weight):a.append(x.detach().cpu().numpy().astype('<f4').ravel())
 a.append(m.final_rms.weight.detach().cpu().numpy().astype('<f4').ravel());o=np.concatenate(a);assert o.size==PARAMS;return o
def fnv(b):
 h=1469598103934665603
 for x in b:h=((h^x)*1099511628211)&0xffffffffffffffff
 return h
def export(m,p,fmt):
 w=flat(m);block=sc=0
 if fmt=='fp32':payload=w.tobytes();code=1;db=len(payload)
 else:
  block=64;lim=127 if fmt=='q8' else 7;nblocks=(len(w)+block-1)//block;padn=nblocks*block
  padded=np.zeros(padn,dtype=np.float32);padded[:len(w)]=w
  mat=padded.reshape(nblocks,block);mx=np.max(np.abs(mat),axis=1).astype(np.float32);scale32=np.where(mx>0.0,mx/np.float32(lim),np.float32(1.0)).astype(np.float32)
  q=np.clip(np.rint(mat/scale32[:,None]),-lim,lim).astype(np.int16).reshape(-1)[:len(w)]
  if fmt=='q8':data=q.astype(np.int8).tobytes();code=2
  else:
   if len(q)&1:q=np.concatenate([q,np.zeros(1,dtype=np.int16)])
   lo=(q[0::2]+8).astype(np.uint8)&15;hi=((q[1::2]+8).astype(np.uint8)&15)<<4;data=(lo|hi).tobytes();code=3
  scales=scale32.astype('<f4');payload=data+scales.tobytes();db=len(data);sc=len(scales)
 h=bytearray(HEADER);h[:8]=b'NDGMV004';vals=[HEADER,0x01020304,code,V,D,L,QH,KVH,FF,MAX_CTX,PARAMS,len(payload)]
 for i,v in enumerate(vals):struct.pack_into('<I',h,8+4*i,v)
 struct.pack_into('<I',h,60,block);struct.pack_into('<Q',h,64,fnv(payload));struct.pack_into('<I',h,72,sc);struct.pack_into('<I',h,76,db);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(h+payload);return sha(p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',required=True);ap.add_argument('--checkpoint-dir',required=True);ap.add_argument('--resume');ap.add_argument('--pretrain-steps',type=int,default=2500);ap.add_argument('--sft-steps',type=int,default=2500);ap.add_argument('--run-step-budget',type=int,default=0);ap.add_argument('--seq-len',type=int,default=96);ap.add_argument('--seed',type=int,default=7422);ap.add_argument('--pretrain-lr',type=float,default=3e-4);ap.add_argument('--sft-lr',type=float,default=8e-5);ap.add_argument('--weight-decay',type=float,default=.01);ap.add_argument('--threads',type=int,default=4);ap.add_argument('--checkpoint-every',type=int,default=100);a=ap.parse_args();subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
 
 if a.threads<1 or a.threads>8:raise SystemExit('threads out of bounded range')
 torch.set_num_threads(a.threads);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.backends.mkldnn.enabled=False;random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
 tokp=DATA/'tokenizer-v2.ndtk';tok=Tok(tokp);c=cfg(a,tokp);rich=readj(DATA/'rich_sft.jsonl');ctx=readj(DATA/'context_sft.jsonl');replay=readj(DATA/'causal_replay.jsonl');rich_replay=[r for r in replay if r.get('source')!='NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN'];context_replay=[r for r in replay if r.get('source')=='NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN'];val=readj(DATA/'pira_validation.jsonl');m=MicroV2();assert sum(p.numel() for p in m.parameters())==PARAMS;o=torch.optim.AdamW(m.parameters(),lr=a.pretrain_lr,weight_decay=a.weight_decay);pre=sf=0;phase='pretrain';iv=None
 if a.resume:b=cpload(Path(a.resume),m,o,c);pre=b['pretrainDone'];sf=b['sftDone'];phase=b['phase'];iv=b['initialValidationLoss'];print(f'RESUME_V2 PASS phase={phase} pretrainDone={pre} sftDone={sf}',flush=True)
 if iv is None:iv=evalv(m,val,tok,a.seq_len)
 print(f'VALIDATION_V2 baseline={iv:.6f} items={len(val)}',flush=True);budget=a.run_step_budget or 10**18;used=0
 while pre<a.pretrain_steps and used<budget:
  for g in o.param_groups:g['lr']=a.pretrain_lr
  src=rich_replay if (pre%10)<7 else context_replay; x,y=causal(src,tok,pre,a.seq_len);o.zero_grad(set_to_none=True);z=loss(m,x,y);z.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.0);o.step();pre+=1;used+=1;phase='pretrain'
  if pre==1 or pre%50==0 or pre==a.pretrain_steps:print(f'PRETRAIN_V2 step={pre}/{a.pretrain_steps} loss={z.detach().item():.6f}',flush=True)
  if a.checkpoint_every and pre%a.checkpoint_every==0 and pre<a.pretrain_steps:cpwrite(Path(a.checkpoint_dir)/f'v2-pre{pre}-sft{sf}.pt',m,o,c,pre,sf,phase,iv)
 if pre>=a.pretrain_steps:phase='sft'
 while pre>=a.pretrain_steps and sf<a.sft_steps and used<budget:
  for g in o.param_groups:g['lr']=a.sft_lr
  sel=sf%10
  if sel<8:x,y=sftrow(rich[(sf*9967+23)%len(rich)],tok,sf,a.seq_len,False)
  elif sel==8:x,y=sftrow(ctx[(sf*9949+31)%len(ctx)],tok,sf,a.seq_len,True)
  else:x,y=causal(rich_replay,tok,a.pretrain_steps+sf,a.seq_len)
  o.zero_grad(set_to_none=True);z=loss(m,x,y);z.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.0);o.step();sf+=1;used+=1;phase='sft'
  if sf==1 or sf%50==0 or sf==a.sft_steps:print(f'SFT_V2 step={sf}/{a.sft_steps} loss={z.detach().item():.6f}',flush=True)
  if a.checkpoint_every and sf%a.checkpoint_every==0 and sf<a.sft_steps:cpwrite(Path(a.checkpoint_dir)/f'v2-pre{pre}-sft{sf}.pt',m,o,c,pre,sf,phase,iv)
 if pre<a.pretrain_steps or sf<a.sft_steps:
  p=Path(a.checkpoint_dir)/f'v2-pre{pre}-sft{sf}.pt';side=cpwrite(p,m,o,c,pre,sf,phase,iv);print(f'PAUSED_V2 path={p} sha256={side["checkpointSha256"]}',flush=True);return 3
 fv=evalv(m,val,tok,a.seq_len);out=Path(a.output_dir);f=out/'staging/micro-v2-fp32.ndgm';q8=out/'staging/micro-v2-q8.ndgm';q4=out/'staging/micro-v2-q4.ndgm';fs=export(m,f,'fp32');s8=export(m,q8,'q8');s4=export(m,q4,'q4');rep={'schema':'neuraldesk-generative-training-report-v074-alpha2-micro-v2-v1','status':'EXPERIMENTAL_NOT_PROMOTED','config':c,'initialValidationLoss':iv,'finalValidationLoss':fv,'validationItems':len(val),'modelStateSha256':th(m.state_dict().items()),'optimizerStateSha256':oh(o),'stagedFp32':{'path':str(f),'sha256':fs,'bytes':f.stat().st_size},'stagedQ8':{'path':str(q8),'sha256':s8,'bytes':q8.stat().st_size},'stagedQ4':{'path':str(q4),'sha256':s4,'bytes':q4.stat().st_size},'promotionAuthorized':False};out.mkdir(parents=True,exist_ok=True);(out/'TRAINING_REPORT.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');cpwrite(Path(a.checkpoint_dir)/f'v2-terminal-pre{pre}-sft{sf}.pt',m,o,c,pre,sf,'terminal',iv);print(f'TRAINING_V2_TERMINAL_NOT_PROMOTED validation={fv:.6f} modelStateSha256={rep["modelStateSha256"]}',flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
