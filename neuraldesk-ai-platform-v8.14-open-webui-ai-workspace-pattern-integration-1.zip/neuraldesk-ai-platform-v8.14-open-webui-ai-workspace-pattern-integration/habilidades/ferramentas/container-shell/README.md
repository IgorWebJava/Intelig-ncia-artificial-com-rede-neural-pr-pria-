<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Filesystem / Shell Environment

    Tool ID: `tool.container-shell`

    ## Role in NeuralDesk development

    Inspect project trees, read files, run validators and compare artifacts.

    ## Current implementations

    - `container`
- `POSIX shell utilities`

    ## Capabilities provided

    - `shell.execute.v1`
- `filesystem.read.v1`
- `filesystem.search.v1`
- `diff.compare.v1`

    ## Constraints

    - Use non-destructive commands by default.
- Never overwrite the latest release without creating a new version.

    ## Portable alternatives

    - workspace filesystem API
- shell runner
- artifact workspace

    ## Rule

    The capability is more important than the tool name. A future AI may replace this tool if it provides equivalent capabilities and passes the relevant quality gates.
