> **Status atual (2026-08-25):** `v0.7.5-alpha.1 / NOT_PROMOTED`. Rollback final permanece `v0.7.3-alpha.1`. Esta candidata nasce da árvore integral corrente v0.7.4-alpha.2 e incorpora somente capacidades historicamente superiores que ainda faltavam, sem ativar pesos generativos rejeitados.

## Delta v0.7.5 — convergência histórica profunda

- computational token streaming real no `nd_generative`, com KV persistente, chunked prefill, backpressure, cancellation/deadline e paridade com greedy;
- adaptador de **delta UTF-8** no mesmo owner tokenizer/generative, incluindo multibyte real;
- hardware capability/provider routing em C99 + Kotlin: RAM/cores/ABI e GPU/NPU fail-closed sem executor;
- Run Journal com eventos sanitizados `PROGRESS`/`DRAIN`, preservando recovery de `ABANDONED` e zero prompt/output bruto;
- governança atual de sources/rights/derivatives/PII/reference-only, 2.563 rich + 52.500 context + 55.063 replay + 140 validation e leakage 0;
- hashes/contagens v0.63 preservados como evidence, mas **Golden 250 não importado** porque os bytes brutos não foram recuperados;
- Data-Scale trainer com gradient accumulation `8×8 => effective batch 64`, checkpoint somente em optimizer boundary e resume byte-identical comprovado.

Auditoria completa: `docs/HISTORICAL_CAPABILITY_CONVERGENCE_V075.md`. Mecânicas: `docs/STREAMING_HARDWARE_GOVERNANCE_V075.md`.

**Truth boundary:** generative model promoted=false; assistant generative activated=false; GPU/NPU executor=false; APK/AAB/ART/device físico=false; speedup físico não alegado.

# NeuralDesk Mobile Sovereign LocalNet v0.7.5-alpha.1 — Historical Capability Convergence Candidate

> **Status atual (2026-08-25):** `NOT_PROMOTED`. Rollback final: `v0.7.3-alpha.1`. Antes de qualquer alteração, ler integralmente `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md`.

## Estado novo — diálogo independente antes da próxima etapa

Foi executada uma sessão contínua de **30 turnos ChatGPT ↔ NeuralDesk** sobre o assistant canônico ativo, com transcript bruto e metadata preservados em `evaluation/dialogue_v074/`. Resultado UTF-8 natural: **16 PASS / 4 PARTIAL / 10 FAIL**; nenhum peso foi atualizado por esse diálogo. Itens FAIL/PARTIAL foram materializados somente como `REFERENCE_ONLY_NOT_TRAINED_IN_THIS_RELEASE`; qualquer correção futura exige novo holdout pós-correção.

O backbone experimental permanece **Micro v3 / NDGM v5, 11.229.760 parâmetros**, stage-only e desativado no assistant. Estado resumível atual: pretraining **350/367 batches**, checkpoint SHA-256 `c1f6745b896386e76243749ce1d2a3eea0278215411b472170df0ec6df224b24`. O checkpoint não é um modelo promovido.

---

# NeuralDesk Mobile Sovereign LocalNet v0.7.4-alpha.2 — Mobile Runtime Hardening

A v0.7.3 é uma candidata mobile-first rebasada sobre a árvore integral v0.7.2. Ela preserva os **674.294 parâmetros neurais** e todos os datasets/weights promovidos sem alteração, e endurece a execução em aparelho: lifecycle JNI single-flight, cancelamento/deadline cooperativos, Resource Governor efetivo, assets por streaming SHA-256, Local RAG persistente/LRU e memória de pesquisa Android opt-in criptografada.

**Truth boundary:** nenhum backbone generativo foi promovido; o callback atual do assistant não é token streaming autoregressivo; Pirá full continua inativo; APK/AAB/ART/device físico, GPU/NPU, speedup, bateria e thermal benchmark real continuam não comprovados. A candidata só pode virar release depois de VERIFY + SANITIZER + ZIP reextraído + attestação externa.

Documentação normativa do delta: `docs/MOBILE_RUNTIME_HARDENING_V073.md`.

## Delta v0.6.2 — Dialogue Grounding & Structured Memory

A v0.6.2 foi criada a partir do ZIP final reproduzível v0.6.1-alpha.1 (rollback SHA-256 `199a8233ed2f6fb779063ac9551f5e32762d3b43e33eb7b0b4db6bad089ad112`). Nenhum dos cinco assets neurais foi alterado. A evolução corrige falhas de diálogo observadas fora dos Golden: memória multiatributo agora usa índice derivado `sujeito -> relação -> valor`; o assistant mantém histórico volátil bounded de 8 turnos; follow-up é bloqueado quando há nova âncora explícita; implicações universais sem evidência são recusadas; e retrieval neural com sigla precisa preservar a sigla como token integral antes de ser aceito.

Novo holdout pós-implementação: **7/7** (`nd_dialogue_grounding_v062_test`), além do gate herdado **12/12** de conversational correctness. Os pesos permanecem 543.094 parâmetros; não houve treinamento online nem novo checkpoint.

## O que existe de verdade

A arquitetura neural v0.5 foi preservada integralmente:

1. **Knowledge Retriever neural** — 275.338 parâmetros; 201 registros internos + unknown.
2. **Knowledge Base `.ndkb`** — 201 registros first-party auditáveis.
3. **Relation Classifier neural** — 132.826 parâmetros; 25 relações + unknown.
4. **Context Pointer neural** — 134.930 parâmetros; proponente de spans com candidate acceptance.
5. **Open Knowledge Shard `.ndos` v1** — 31 registros humanos em português reconstruídos de Pirá 2.0, indexados localmente por TF-IDF esparso com FNV-1a 64-bit em buckets fixos; **0 parâmetros neurais**.

O runtime C99 mantém planner, grounding contextual, calculadora, memória persistente, composição multiobjetivo e incerteza explícita. O shard aberto é um **fallback posterior** ao conhecimento interno: nunca substitui contexto fornecido, ferramenta exata, memória explícita ou uma resposta interna aceita.

## Delta material da v0.6.2-alpha.1 — Conversational Correctness & Semantic Planning

A v0.6.1 não retreina os 543.094 parâmetros neurais e não altera os cinco assets canônicos. O ganho é de **correção comportamental e orquestração**, medido em perguntas pós-implementação que falhavam na alpha.2:

- parser matemático bounded com precedência, parênteses, `+ - * / ^` e operadores UTF-8 `× ÷ −`;
- um único planner canônico compartilhado por assistant e grounding contextual;
- proteção de preâmbulo para coordenações nominais como `fases 1 e 2`;
- expansão distributiva de dois tópicos quando a pergunta pede `cada técnica/abordagem/método`;
- herança de entidade entre subobjetivos somente quando semanticamente necessária;
- binding de memória para `tipo de <atributo>` quando a relação neural conhecida recusa;
- fallback sparse da KB **somente após recusa neural**, com score+margin e proteção contra substituição de entidade;
- suporte morfológico conservador no grounding (`responsável` ↔ `responsabilidade`);
- estado conversacional bounded de um turno anterior para follow-ups curtos;
- políticas determinísticas transparentes para saudação/capacidades e comparação universal absoluta;
- novo gate pós-implementação `nd_conversational_correctness_test`: **12/12**;
- calculadora permanente ampliada para **16/16** e Live QA preservado em **35/35**.

### Baseline NDOS preservada da reconstrução alpha.2

- formato binário `NDOS v1`, magic `NDOSV001`;
- normalização determinística UTF-8 português/Latin-1 → ASCII em Python e C;
- FNV-1a 64-bit padrão (`offset basis 14695981039346656037`) → **65.536 buckets** fixos;
- word unigram/bigram + char n-grams 3..5;
- TF-IDF esparso, `topK=96`, cosine similarity;
- gate fail-closed duplo: `score >= 0.33` e `margin >= 0.08`;
- loader C valida magic, versão, bucket count power-of-two, IDF ordenado, features, normas, limites, contagens e bytes extras;
- paridade Python↔C sobre positivos e negativos;
- integração opcional no mesmo `NDAssistant` usado por CLI e JNI Android;
- planner corrigido para tratar preâmbulo tópico/de propósito como um único objetivo, por exemplo `Para estimar ... calor sensíveis e latentes, qual método ...?`;
- reprodução do `.ndos` 2× byte-idêntica ao asset canônico.

## Resultados executados na árvore

| Gate | Resultado |
|---|---:|
| Open-shard Python↔C | **53/53** |
| Validação humana raw top-1 | **28/28** |
| Validação humana aceita | **25/25 corretas; 0 erradas** |
| Negativos de calibração | **0/25 aceitos** |
| Holdout humano pós-implementação raw | **3/3** |
| Holdout humano aceito | **2/2 corretas; 0 erradas** |
| Corrupções `.ndos` | **4/4 rejeitadas** |
| Reprodução `.ndos` | **2/2 byte-identical** |
| Assistant open-shard | **PASS** |
| Planner regressão científica | **PASS** |
| Multiobjetivo herdado | **320/320** antes do freeze final; reexecutado por `verify.sh` |
| JNI host `-Werror` | reexecutado por `verify.sh` |
| Kotlin host subset | reexecutado por `verify.sh` |

Os gates completos herdados da v0.5 continuam obrigatórios e são reexecutados por `scripts/verify.sh` antes do freeze.

Como o agregador monolítico excedeu repetidamente a janela operacional sem erro funcional, v0.6.1 adiciona execução **retomável por fases**. `scripts/verification_checkpoint.py` grava receipts somente fora da árvore distribuída e os vincula à versão do manifest + SHA-256 canônico dos inputs. `ND_VERIFY_PHASE=checkpoint|static|build|models|behavior|integration|final` e `ND_SANITIZE_PHASE=build|runtime|final` não reduzem cobertura; qualquer alteração nos inputs invalida a retomada. Timeout nunca conta como PASS.

## Asset NDOS

`models/neuraldesk-open-knowledge-pira-v0.6.ndos`

- formato: `NDOS v1` / `NDOSV001`;
- registros: **31**;
- tamanho: **68.177 bytes**;
- SHA-256: `b4967b52e02daf3dea5833ee5f7df63ecbf4edc3bf88d95b7f407423f44419c7`;
- dados: perguntas/respostas humanas em português, subset reconstruído de Pirá 2.0;
- licença do dataset: **CC BY 4.0**;
- test split: **não usado**;
- campos/paráfrases automáticas: **não usados no shard**;
- paráfrases humanas: usadas somente para avaliação.

Os quatro assets v0.5 permanecem byte-idênticos e seus hashes canônicos não mudam.

## Ordem canônica de resposta

```text
pergunta
  -> planner / subobjetivos
  -> contexto fornecido + grounding
  -> ferramenta local exata, quando aplicável
  -> memória explícita local
  -> retriever neural + KB first-party
  -> fallback sparse na mesma KB, somente se o neural recusar e score+margin/entity guard aceitarem
  -> shard aberto humano local, somente se o conhecimento interno recusar
  -> incerteza explícita
  -> composição dos objetivos cobertos
```

## Exemplo CLI

```bash
./build/ndassistant \
  models/neuraldesk-knowledge-retriever-v0.5.ndkr \
  models/neuraldesk-knowledge-v0.5.ndkb \
  models/neuraldesk-context-pointer-v0.5.ndqa \
  models/neuraldesk-relation-classifier-v0.5.ndrl \
  "Para estimar fluxos ar-mar de calor sensíveis e latentes, qual método é utilizado?" \
  "" 1 - \
  models/neuraldesk-open-knowledge-pira-v0.6.ndos
```

Resposta esperada pelo fallback local: `O método de covariância turbulenta.`

## Build e gates

```bash
./scripts/build_host.sh
./scripts/verify.sh
./scripts/verify_sanitize.sh
```

Antes de interpretar a release, leia `docs/CURRENT_STATE.md`, `docs/OPEN_KNOWLEDGE_SHARD.md`, `docs/RECONSTRUCTION_LINEAGE.md` e `docs/TRUTH_BOUNDARY.md`.
