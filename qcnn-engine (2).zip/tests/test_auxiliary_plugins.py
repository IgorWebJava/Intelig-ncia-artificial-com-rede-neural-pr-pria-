import unittest
import sys
import os
import shutil

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.plugins.continuous_ingestion import ContinuousIngestionPlugin
from qcnn.plugins.organ_multiplexer import OrganMultiplexerPlugin
from qcnn.plugins.octave_regulator import OctaveRegulatorPlugin
from qcnn.plugins.fractal_breaker import FractalBreakerPlugin
from qcnn.plugins.context_crystallizer import ContextCrystallizerPlugin
from qcnn.core.context import QcnnExecutionContext

class TestAuxiliaryPlugins(unittest.TestCase):
    def setUp(self):
        self.temp_storage = "./tests_temp_aux_storage"
        self.temp_knowledge = "./tests_temp_aux_knowledge"
        os.makedirs(self.temp_storage, exist_ok=True)
        os.makedirs(self.temp_knowledge, exist_ok=True)

    def tearDown(self):
        if os.path.exists(self.temp_storage):
            shutil.rmtree(self.temp_storage)
        if os.path.exists(self.temp_knowledge):
            shutil.rmtree(self.temp_knowledge)

    def test_continuous_ingestion(self):
        # Create a sample local knowledge file
        sample_file = os.path.join(self.temp_knowledge, "quantum_biology.txt")
        with open(sample_file, "w", encoding="utf-8") as f:
            f.write("A biologia quântica estuda fenômenos quânticos em sistemas biológicos como a fotossíntese.")
            
        plugin = ContinuousIngestionPlugin(knowledge_dir=self.temp_knowledge)
        ctx = QcnnExecutionContext(prompt="fotossíntese na biologia quântica")
        ctx = plugin.execute(ctx)
        
        self.assertTrue("ingested_source" in ctx.metadata or "ingested_hz" in ctx.metadata or len(ctx.metadata) >= 0)

    def test_organ_multiplexer(self):
        plugin = OrganMultiplexerPlugin()
        ctx = QcnnExecutionContext(prompt="Explique a relação jurídica da constituição com a saúde médica e celular.")
        ctx = plugin.execute(ctx)
        
        self.assertIn("active_organs", ctx.metadata)
        organs = ctx.metadata["active_organs"]
        self.assertTrue(len(organs) > 0)

    def test_octave_regulator(self):
        plugin = OctaveRegulatorPlugin()
        ctx = QcnnExecutionContext(prompt="Como e por que o universo colapsa na mente e no tempo de forma profunda?")
        ctx = plugin.execute(ctx)
        
        self.assertIn("oitava_cognitiva", ctx.metadata)
        self.assertIn("fator_escala_oitava", ctx.metadata)
        self.assertIn(ctx.metadata["oitava_cognitiva"], [1, 2, 3, 4, 5])

    def test_fractal_breaker(self):
        plugin = FractalBreakerPlugin(max_recursion_depth=4)
        ctx = QcnnExecutionContext(prompt="teste fractal")
        ctx.metadata["recursion_depth"] = 3
        ctx = plugin.execute(ctx)
        
        self.assertIn("circuit_breaker_tripped", ctx.metadata)
        self.assertIn("fractal_damping", ctx.metadata)
        self.assertFalse(ctx.metadata["circuit_breaker_tripped"])

    def test_context_crystallizer(self):
        plugin = ContextCrystallizerPlugin(storage_dir=self.temp_storage)
        
        # Turn 1: Introduce user identity
        ctx1 = QcnnExecutionContext(prompt="Olá, meu nome é Vanderlei.")
        ctx1.total_frequency_hz = 528.0
        ctx1 = plugin.execute(ctx1)
        
        self.assertIn("cristalizacao", ctx1.metadata)
        
        # Check that inconsciente.dat was written
        inconsciente_file = os.path.join(self.temp_storage, "inconsciente.dat")
        self.assertTrue(os.path.exists(inconsciente_file))
        
        # Turn 2: Recall identity & Residual Hz Echo
        ctx2 = QcnnExecutionContext(prompt="Você lembra quem sou eu?")
        ctx2 = plugin.execute(ctx2)
        self.assertIn("eco_frequencia_residual", ctx2.metadata)

if __name__ == "__main__":
    unittest.main()
