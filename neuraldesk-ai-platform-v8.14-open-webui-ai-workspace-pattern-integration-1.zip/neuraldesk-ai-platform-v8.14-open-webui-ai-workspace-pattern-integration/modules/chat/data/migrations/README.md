<!-- neuraldesk-documentation-sync: V8.8 -->

# Advanced AI Chat Workspace migrations

Only this module owns migrations for its private data schema.
