#ifndef ND_PROJECT_H
#define ND_PROJECT_H

#include <stddef.h>
#include <stdint.h>

#define ND_PROJECT_MAX 16u
#define ND_PROJECT_ID_BYTES 64u
#define ND_PROJECT_NAME_BYTES 61u

typedef struct {
    char id[ND_PROJECT_ID_BYTES];
    char name[ND_PROJECT_NAME_BYTES];
    uint64_t created_at_ms;
    uint64_t updated_at_ms;
} NDProject;

typedef struct {
    char path[1024];
    NDProject projects[ND_PROJECT_MAX];
    size_t count;
    size_t current_index;
} NDProjectStore;

void nd_project_store_init(NDProjectStore *store);
int nd_project_store_set_path(NDProjectStore *store, const char *path, char *err, size_t errcap);
int nd_project_store_restore(NDProjectStore *store, char *err, size_t errcap);
int nd_project_create(NDProjectStore *store, const char *id, const char *name, uint64_t now_ms,
                      char *err, size_t errcap);
int nd_project_rename(NDProjectStore *store, const char *id, const char *name, uint64_t now_ms,
                      char *err, size_t errcap);
int nd_project_select(NDProjectStore *store, const char *id, char *err, size_t errcap);
int nd_project_remove(NDProjectStore *store, const char *id, char *err, size_t errcap);
const NDProject *nd_project_current(const NDProjectStore *store);
int nd_project_storage_path(const char *base_dir, const char *project_id, const char *leaf,
                            char *out, size_t outcap);

#endif
