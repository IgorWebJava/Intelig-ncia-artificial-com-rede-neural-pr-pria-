<!-- neuraldesk-documentation-sync: V8.8 -->

# Data Ownership — neuraldesk.audit

    ## Owned data

    - `audit_events`
- `trace_index`
- `integrity_checks`
- `retention_policies`

    ## Invariant

    This module is the authoritative owner of the mutable data listed above.

    Other modules must not query or write this module's private tables directly.

    ```text
    Other Module
    → Versioned API or Versioned Event
    → neuraldesk.audit
    → Owned Data
    ```

    External references use IDs/contracts, not cross-module database foreign keys.
