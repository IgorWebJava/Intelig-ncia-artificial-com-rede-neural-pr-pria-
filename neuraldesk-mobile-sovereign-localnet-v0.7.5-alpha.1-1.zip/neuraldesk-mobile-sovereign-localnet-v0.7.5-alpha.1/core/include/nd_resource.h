#ifndef ND_RESOURCE_H
#define ND_RESOURCE_H

#include <stddef.h>

typedef enum {
    ND_PROFILE_MICRO = 0,
    ND_PROFILE_MOBILE = 1,
    ND_PROFILE_MOBILE_PLUS = 2
} NDMobileProfile;

typedef enum {
    ND_ABI_UNKNOWN = 0,
    ND_ABI_ARM64 = 1,
    ND_ABI_X86_64 = 2,
    ND_ABI_ARM32 = 3,
    ND_ABI_X86 = 4
} NDHardwareAbi;

typedef enum {
    ND_PROVIDER_AUTO = 0,
    ND_PROVIDER_CPU_C99 = 1,
    ND_PROVIDER_GPU = 2,
    ND_PROVIDER_NPU = 3
} NDHardwareProvider;

typedef enum {
    ND_ROUTE_OK = 0,
    ND_ROUTE_INVALID = 1,
    ND_ROUTE_PROVIDER_UNAVAILABLE = 2,
    ND_ROUTE_NOT_CERTIFIED = 3
} NDHardwareRouteStatus;

typedef struct {
    NDMobileProfile profile;
    size_t max_context_bytes;
    size_t max_rag_chunks;
    size_t max_output_bytes;
    unsigned max_threads;
    unsigned deadline_ms;
    unsigned thermal_backoff_percent;
} NDResourcePolicy;

typedef struct {
    unsigned long ram_mb;
    unsigned logical_cores;
    int is_64bit;
    NDHardwareAbi abi;
    int cpu_c99_executor_available;
    int gpu_detected;
    int gpu_executor_available;
    int npu_detected;
    int npu_executor_available;
    int physical_hardware_certified;
} NDHardwareCapabilities;

typedef struct {
    NDHardwareRouteStatus status;
    NDHardwareProvider requested;
    NDHardwareProvider selected;
    NDMobileProfile profile;
    NDHardwareAbi abi;
    int executor_available;
    int accelerator_detected_but_unavailable;
    int physical_hardware_certified;
    int automatic_default_switch;
} NDHardwareRoute;

NDMobileProfile nd_resource_select_profile(unsigned long ram_mb, unsigned cores, int is_64bit);
NDResourcePolicy nd_resource_policy(NDMobileProfile profile);
const char *nd_resource_profile_name(NDMobileProfile profile);
int nd_resource_admit(const NDResourcePolicy *policy, size_t question_bytes, size_t context_bytes);
size_t nd_resource_effective_output_bytes(const NDResourcePolicy *policy, unsigned thermal_status);
unsigned nd_resource_effective_threads(const NDResourcePolicy *policy, unsigned thermal_status);
unsigned nd_resource_effective_deadline_ms(const NDResourcePolicy *policy, unsigned thermal_status);

const char *nd_resource_abi_name(NDHardwareAbi abi);
const char *nd_resource_provider_name(NDHardwareProvider provider);
NDHardwareRoute nd_resource_route_hardware(const NDHardwareCapabilities *capabilities,
                                           NDHardwareProvider requested_provider,
                                           int require_physical_certification);

#endif
