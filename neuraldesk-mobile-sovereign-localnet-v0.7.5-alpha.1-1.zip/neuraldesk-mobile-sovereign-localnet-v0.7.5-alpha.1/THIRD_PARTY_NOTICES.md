# Third-Party Notices

## PyTorch

O treinamento usa PyTorch como biblioteca local de cálculo/autograd. PyTorch não faz parte do runtime C99 entregue no telefone e não é um serviço externo de inteligência artificial.

## Android toolchain

A compilação Android depende de Android SDK/NDK, Gradle, Android Gradle Plugin e Kotlin conforme os arquivos em `android/`. Esses componentes são ferramentas de desenvolvimento e não fazem parte dos modelos neurais do NeuralDesk.

## Kimi K3 in C

`FareedKhan-dev/kimi-k3-in-c` foi usado apenas como referência pública de padrões de engenharia. Veja `NOTICE_REFERENCE.md` e `docs/KIMI_K3_REFERENCE_REVIEW.md`.

## Pirá 2.0

A v0.6.2-alpha.1 redistribui um subset de 31 pares pergunta/resposta humanos em português provenientes do dataset Pirá 2.0 (`https://github.com/C4AI/Pira`) sob **CC BY 4.0**. O lineage, seleção e hashes estão em `training/data/open_knowledge/PIRA_RECONSTRUCTION_PROVENANCE.json`. O test split e campos automáticos não são usados no shard.
