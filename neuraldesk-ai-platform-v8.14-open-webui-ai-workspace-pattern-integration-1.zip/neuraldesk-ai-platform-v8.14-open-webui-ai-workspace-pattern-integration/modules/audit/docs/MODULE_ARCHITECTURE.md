<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.audit; current: modules/audit/docs/MODULE_ARCHITECTURE.md -->
# System Audit, Trace & Control Center — Module Architecture

## Boundary

`neuraldesk.audit` is independently packaged under `modules/audit/` and owns its UI, contracts, data ownership docs, tests, preview and module documentation.

## Package

```text
modules/audit/
├── module.manifest.json
├── ui/
├── contracts/
├── data/
├── compatibility/
├── tests/
├── preview/
└── docs/
```

## UI architecture

```text
HTML + module-owned CSS + module-owned JS runtime
→ intelligence-experience-v2
→ workspace-runtime-v2
→ neuraldesk-intelligence-design-v2
```

Platform Design System/Experience Runtime are source contracts/reference; executable assets travel with the module.

## Specialized mechanic

**Investigation Workspace**

## Integration rule

Modules depend on versioned public contracts/capabilities, never another module's private implementation or private tables.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
