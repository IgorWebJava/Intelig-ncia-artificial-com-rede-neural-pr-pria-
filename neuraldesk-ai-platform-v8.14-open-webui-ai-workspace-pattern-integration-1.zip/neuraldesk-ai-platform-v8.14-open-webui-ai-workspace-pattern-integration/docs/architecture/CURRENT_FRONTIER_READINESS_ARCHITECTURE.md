<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.architecture; current: docs/architecture/CURRENT_FRONTIER_READINESS_ARCHITECTURE.md -->
# Current Frontier Readiness Architecture

The frontier-readiness program originated in V8.7 and remains active in V8.11. It defines the target maturity model and dependency sequence for converting the V8.6 documentation-only Neural Engine into a future executable system.

## Maturity model

```text
D0 Documented
 -> D1 Contract-ready
 -> D2 Reference implementation
 -> D3 Integrated
 -> D4 Production-ready
 -> D5 Frontier-competitive
 -> D6 Differentiated
```

All Neural Engine modules remain documentation-only/D0 unless a later implementation release explicitly advances their maturity with executable evidence.

## Target product architecture

```text
Experience Plane
  -> Work/Project Plane
  -> Autonomous Execution Fabric
  -> AI Capability Fabric
  -> Model Portfolio
  -> Neural Research Platform
  -> Control Plane across all layers
```

## Dependency law

Autonomy cannot precede durable state, identity, authorization, observability and evaluation.

Model research cannot replace product/runtime fundamentals.

See `../frontier-readiness/END_TO_END_REFERENCE_ARCHITECTURE.md`.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
