<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/RESPONSIVE_MULTIMODAL_UI.md -->
# App Shell — Responsive & Multimodal UI

Profile: `intelligence-experience-v2` / `workspace-runtime-v2`

## Device classes

- phone — 390×844 validation baseline;
- tablet — 768×1024;
- notebook — 1366×768;
- desktop — 1920×1080;
- TV/4K — 3840×2160.

## Interaction

Touch, mouse, keyboard and remote focus; portrait/landscape; safe area; focus-visible; reduced motion; high-contrast accommodation.

## Density

Comfortable, Balanced and Dense are presentation choices. They do not change domain semantics.

## Multimodal content contract

Text, image, audio, video, document, structured data and tool results are recognized surface types. Large media uses Asset References in future production integration.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
