#!/usr/bin/env python3
from pathlib import Path
import hashlib

EXPECTED = {
    'models/neuraldesk-knowledge-retriever-v0.5.ndkr': '76a54e02dc6e815fd7786075bfbdf97c43f9845851a118b5c3db2c637edab539',
    'models/neuraldesk-knowledge-v0.5.ndkb': 'd6d6969de99195bcbed49e8b4067835bfe3e852bd12e3aca5b2210241dd70652',
    'models/neuraldesk-context-pointer-v0.5.ndqa': 'de85e66395b8c9ec590e0ed2f5dcec77b8cf2462444cecdc08a93119f02b79ef',
    'models/neuraldesk-relation-classifier-v0.5.ndrl': '45224521f7c70ad5fa7e14c52cc3a14c4cabd03856d1e5978d70ea804ff4d883',
    'models/neuraldesk-open-knowledge-pira-v0.6.ndos': 'b4967b52e02daf3dea5833ee5f7df63ecbf4edc3bf88d95b7f407423f44419c7',
}
for rel, expected in EXPECTED.items():
    got = hashlib.sha256(Path(rel).read_bytes()).hexdigest()
    assert got == expected, (rel, got, expected)
print('canonical-runtime-asset-hashes PASS', len(EXPECTED))
