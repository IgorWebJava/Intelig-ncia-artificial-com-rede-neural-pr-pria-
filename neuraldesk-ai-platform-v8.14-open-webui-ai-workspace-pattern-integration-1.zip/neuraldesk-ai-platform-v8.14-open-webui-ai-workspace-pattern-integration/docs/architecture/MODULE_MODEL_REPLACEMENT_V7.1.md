<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Module & Model Replacement — V7.1

## Module replacement

```text
Candidate registration
→ Manifest validation
→ Contract validation
→ Capability resolution
→ Contract tests
→ Data migration check
→ Shadow mode
→ Canary
→ Binding switch
→ Observability
→ Rollback window
```

## Model/provider replacement

```text
Adapter registration
→ Capability tests
→ Golden dataset
→ Quality evaluation
→ Safety evaluation
→ Tool tests
→ Multimodal tests
→ Shadow
→ Canary
→ Profile binding switch
→ Rollback readiness
```

## Key property

Consumers depend on a stable capability/contract. They do not depend on the concrete provider/module implementation.
