#!/usr/bin/env python3
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'training'))
import train_relation_classifier as tr

rows=tr.build_sets()[1]
lines=[]
for text,label,_view in rows:
    lines.append(f"{label}\t{text}\n")
p=subprocess.run([str(ROOT/'build/nd_relation_batch'),str(ROOT/'models/neuraldesk-relation-classifier-v0.5.ndrl')],
                 input=''.join(lines),text=True,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr)
assert f"{len(rows)}/{len(rows)}" in p.stdout,(len(rows),p.stdout,p.stderr)
print(f"relation-runtime-golden PASS {len(rows)}/{len(rows)}")
