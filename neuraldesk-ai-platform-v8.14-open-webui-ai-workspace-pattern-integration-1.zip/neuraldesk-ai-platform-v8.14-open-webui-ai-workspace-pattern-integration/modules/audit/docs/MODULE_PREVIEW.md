<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.audit; current: modules/audit/docs/MODULE_PREVIEW.md -->
# System Audit, Trace & Control Center — Module Preview

Canonical preview: `modules/audit/preview/page-preview.png`

Metadata: `modules/audit/preview/preview.json`

Previews are generated from canonical HTML/CSS/runtime and are visual references only. Regenerate after meaningful visual changes and validate freshness before release.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
