<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Adaptive Multimodal Responsive Architecture — V7.2

## Objective

Every canonical module UI adapts automatically across phone, tablet, notebook, desktop and television/4K without a shared runtime stylesheet.

## Canonical device matrix

```text
Compact Phone  <= 480
Phone          481–767
Tablet         768–1024
Notebook       1025–1439
Desktop        1440–1919
TV Full HD     1920–2559
TV / 4K        >= 2560
```

Breakpoints are guardrails, not fixed designs. Intrinsic layouts, `minmax`, `auto-fit`, `clamp`, overflow containment and flexible wrapping handle intermediate widths.

## Input adaptation

```text
Touch        → >=44px hit targets where appropriate
Mouse        → desktop density
Keyboard     → focus-visible
TV remote    → enlarged focus ring and large-distance controls
```

## Multimodal surface

System-wide canonical content types:

- text
- image
- audio
- video
- document
- structured_data
- tool_result

Large assets continue to use Asset References / Object Storage.

## Module isolation

The adaptive policy is common, but implementation CSS is duplicated/owned by each module to preserve replaceability.
