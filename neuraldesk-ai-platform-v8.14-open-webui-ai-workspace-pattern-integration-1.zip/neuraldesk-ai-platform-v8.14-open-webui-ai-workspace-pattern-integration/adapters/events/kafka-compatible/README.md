<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.events.kafka-compatible

    Replaceable adapter template.

    Provides:
    - `events.publish.v1`
- `events.consume.v1`

    Domain modules must never import this adapter implementation directly.
    Binding occurs through the corresponding platform gateway/registry.
