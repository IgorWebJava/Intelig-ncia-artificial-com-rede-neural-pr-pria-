#!/usr/bin/env python3
"""Train the first-party relation-conditioned neural context span pointer for LocalNet v0.5."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import struct
import subprocess
import sys
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parent))
import context_data

V = 259
PAD = 258
SEED = 3
RELATIONS = tuple(context_data.TRAIN_Q)
REL_TO_ID = {name: index for index, name in enumerate(RELATIONS)}


def require_lessons_precheck() -> None:
    root = Path(__file__).resolve().parents[1]
    subprocess.run(
        [sys.executable, str(root / "scripts" / "pre_generation_lessons_check.py")],
        cwd=root,
        check=True,
    )


class PointerQA(nn.Module):
    def __init__(self, d: int = 48, h: int = 96, radius: int = 12):
        super().__init__()
        self.d = d
        self.h = h
        self.radius = radius
        self.e = nn.Embedding(V, d)
        self.wp = nn.ModuleList([nn.Linear(d, h, bias=False) for _ in range(2 * radius + 1)])
        self.wq = nn.Linear(d, h, bias=False)
        self.rel = nn.Embedding(len(RELATIONS), h)
        self.b = nn.Parameter(torch.zeros(h))
        self.start = nn.Linear(h, 1)
        self.end = nn.Linear(h, 1)

    def forward(
        self, question: torch.Tensor, context: torch.Tensor, mask: torch.Tensor, relation: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        question_embedding = self.e(question)
        question_mask = (question != PAD).float().unsqueeze(-1)
        question_vector = (question_embedding * question_mask).sum(1) / question_mask.sum(1).clamp_min(1)

        context_embedding = self.e(context)
        batch, width, dim = context_embedding.shape
        state = self.wq(question_vector)[:, None, :] + self.rel(relation)[:, None, :] + self.b

        for index, offset in enumerate(range(-self.radius, self.radius + 1)):
            if offset < 0:
                shifted = torch.cat(
                    [
                        torch.zeros(batch, -offset, dim, device=context_embedding.device),
                        context_embedding[:, : width + offset],
                    ],
                    1,
                )
            elif offset > 0:
                shifted = torch.cat(
                    [
                        context_embedding[:, offset:],
                        torch.zeros(batch, offset, dim, device=context_embedding.device),
                    ],
                    1,
                )
            else:
                shifted = context_embedding
            state = state + self.wp[index](shifted)

        hidden = torch.tanh(state)
        start = self.start(hidden).squeeze(-1).masked_fill(~mask, -1e9)
        end = self.end(hidden).squeeze(-1).masked_fill(~mask, -1e9)
        return start, end


def relation_id(item: dict) -> int:
    kind = item.get("kind", "").removesuffix("_holdout")
    if kind not in REL_TO_ID:
        raise ValueError(f"missing/unknown relation kind: {kind!r}")
    return REL_TO_ID[kind]


def example(item: dict) -> tuple[list[int], list[int], int, int, int]:
    context = item["context"].encode("utf-8")
    question = item["question"].encode("utf-8")
    answer = item["answer"].encode("utf-8")
    start = context.find(answer)
    if start < 0:
        raise ValueError("answer not exact substring")
    return list(question), list(context), start, start + len(answer) - 1, relation_id(item)


def make_batch(items: list[dict], size: int, rng: random.Random):
    samples = [example(rng.choice(items)) for _ in range(size)]
    max_question = max(len(sample[0]) for sample in samples)
    max_context = max(len(sample[1]) for sample in samples)
    questions = []
    contexts = []
    masks = []
    starts = []
    ends = []
    relations = []

    for question, context, start, end, relation in samples:
        questions.append(question + [PAD] * (max_question - len(question)))
        contexts.append(context + [PAD] * (max_context - len(context)))
        masks.append([1] * len(context) + [0] * (max_context - len(context)))
        starts.append(start)
        ends.append(end)
        relations.append(relation)

    return (
        torch.tensor(questions),
        torch.tensor(contexts),
        torch.tensor(masks, dtype=torch.bool),
        torch.tensor(starts),
        torch.tensor(ends),
        torch.tensor(relations),
    )


def infer(model: PointerQA, item: dict) -> tuple[str, int, int, float]:
    question, context, _, _, relation = example(item)
    question_tensor = torch.tensor(question)[None]
    context_tensor = torch.tensor(context)[None]
    mask = torch.ones_like(context_tensor, dtype=torch.bool)

    with torch.no_grad():
        start_logits, end_logits = model(
            question_tensor, context_tensor, mask, torch.tensor([relation])
        )
        start_logits = start_logits[0]
        end_logits = end_logits[0]

    # Bounded joint span search. The length penalty prevents the end head from
    # selecting an unnecessarily long tail after the start head found the value.
    best = (-1e30, 0, 0)
    for start in range(len(context)):
        max_end = min(len(context) - 1, start + 159)
        offsets = torch.arange(0, max_end - start + 1, dtype=start_logits.dtype)
        values = end_logits[start : max_end + 1] + start_logits[start] - 0.05 * offsets
        relative_end = int(values.argmax())
        end = start + relative_end
        score = float(values[relative_end])
        if score > best[0]:
            best = (score, start, end)

    prediction = bytes(context[best[1] : best[2] + 1]).decode("utf-8", "replace")
    return prediction, best[1], best[2], best[0]


def evaluate(model: PointerQA, items: list[dict]) -> tuple[float, list[dict]]:
    rows = []
    ok = 0
    for item in items:
        prediction, start, end, score = infer(model, item)
        good = prediction == item["answer"]
        ok += int(good)
        rows.append(
            {
                **item,
                "prediction": prediction,
                "exact": bool(good),
                "start": start,
                "end": end,
                "score": score,
            }
        )
    return ok / len(items), rows


def export(model: PointerQA, path: str) -> None:
    with open(path, "wb") as file:
        file.write(struct.pack("<7I", 0x3151444E, 2, V, model.d, model.h, model.radius, 160))

        def put(tensor: torch.Tensor) -> None:
            raw = tensor.detach().cpu().float().contiguous().numpy().astype("<f4").tobytes()
            file.write(raw)

        put(model.e.weight)
        for window in model.wp:
            put(window.weight.T)
        put(model.wq.weight.T)
        put(model.rel.weight)
        put(model.b)
        put(model.start.weight.reshape(-1))
        put(model.start.bias)
        put(model.end.weight.reshape(-1))
        put(model.end.bias)


def main() -> None:
    require_lessons_precheck()
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=700)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--out", default="models/neuraldesk-context-pointer-v0.5.ndqa")
    args = parser.parse_args()

    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.mkldnn.enabled = False

    train, golden = context_data.build_context()
    model = PointerQA()
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=0.01)
    rng = random.Random(SEED)
    history = []

    for step in range(args.steps):
        question, context, mask, expected_start, expected_end, relation = make_batch(train, args.batch, rng)
        start_logits, end_logits = model(question, context, mask, relation)
        loss = F.cross_entropy(start_logits, expected_start) + F.cross_entropy(end_logits, expected_end)
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if step % 50 == 0 or step == args.steps - 1:
            history.append({"step": step, "loss": float(loss.detach())})
            print(f"step={step} loss={float(loss.detach()):.6f}", flush=True)

    golden_accuracy, golden_rows = evaluate(model, golden)
    unseen = [
        {"question": "Qual é o código do protótipo?", "context": "O protótipo experimental possui o código ZX-731.", "answer": "ZX-731", "kind": "code"},
        {"question": "Qual é a cor da unidade Aurora?", "context": "A unidade Aurora está marcada com a cor turquesa.", "answer": "turquesa", "kind": "color"},
        {"question": "Quem é o responsável pelo projeto Atlas?", "context": "O responsável registrado pelo projeto Atlas é Marina.", "answer": "Marina", "kind": "owner"},
        {"question": "Quem é responsável pelo projeto Atlas-77?", "context": "Marina é responsável pelo projeto Atlas-77.", "answer": "Marina", "kind": "owner"},
        {"question": "Qual é a porta do serviço?", "context": "O serviço de teste usa a porta 8443.", "answer": "8443", "kind": "port"},
        {"question": "Qual é a licença do componente?", "context": "O componente é distribuído sob a licença Apache-2.0.", "answer": "Apache-2.0", "kind": "license"},
        {"question": "Qual é a latência observada?", "context": "A latência observada foi 17 milissegundos.", "answer": "17 milissegundos", "kind": "latency"},
        {"question": "Qual protocolo está ativo?", "context": "O protocolo ativo no enlace é HTTP/3.", "answer": "HTTP/3", "kind": "protocol"},
        {"question": "Quem fabricou a unidade?", "context": "A unidade foi fabricada pela Vector Forge.", "answer": "Vector Forge", "kind": "manufacturer"},
        {"question": "Qual a prioridade da tarefa?", "context": "A tarefa está marcada com prioridade crítica.", "answer": "crítica", "kind": "priority"},
        {"question": "Em qual região está a implantação?", "context": "A implantação está localizada na região eu-west-3.", "answer": "eu-west-3", "kind": "region"},
        {"question": "Qual é o checksum do pacote?", "context": "O checksum do pacote é a1b2c3d4e5f6.", "answer": "a1b2c3d4e5f6", "kind": "checksum"},
    ]
    unseen_accuracy, unseen_rows = evaluate(model, unseen)
    if golden_accuracy < 1.0:
        raise SystemExit(f"context pointer below mandatory Golden: {golden_accuracy:.6f}")

    export(model, args.out)
    report = {
        "seed": SEED,
        "architecture": {
            "vocab": V,
            "embedding": model.d,
            "hidden": model.h,
            "radius": model.radius,
            "relation_count": len(RELATIONS),
            "max_span_bytes": 160,
        },
        "parameters": sum(p.numel() for p in model.parameters()),
        "train_samples": len(train),
        "golden_samples": len(golden),
        "golden_exact": golden_accuracy,
        "unseen_exact": unseen_accuracy,
        "history": history,
        "golden_rows": golden_rows,
        "unseen_rows": unseen_rows,
        "sha256": hashlib.sha256(Path(args.out).read_bytes()).hexdigest(),
    }
    Path("evaluation/CONTEXT_POINTER_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        "golden_exact",
        golden_accuracy,
        "unseen_exact",
        unseen_accuracy,
        "params",
        report["parameters"],
        flush=True,
    )
    for row in unseen_rows:
        print("UNSEEN", row["question"], "=>", row["prediction"], flush=True)


if __name__ == "__main__":
    main()
