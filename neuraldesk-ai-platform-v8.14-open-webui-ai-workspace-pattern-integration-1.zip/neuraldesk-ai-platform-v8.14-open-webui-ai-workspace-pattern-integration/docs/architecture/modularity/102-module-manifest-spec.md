<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 102 — Module Manifest

The manifest declares:

- module ID and version;
- canonical UI;
- route aliases;
- API/event/config namespaces;
- provides/requires capabilities;
- contracts;
- data ownership;
- compatibility policy;
- runtime isolation rules.
