<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: governance -->
# Coding Intelligence Non-Regression

All V8.13 coding additions are additive. Existing V8.12 routes, tabs, actions, Engine Bridge, AutoGPT agent-platform surfaces, contracts and root redirect aliases must remain. Future coding runtimes cannot bypass permission ceilings, sandbox/policy, durable effects, provenance or verification gates.
