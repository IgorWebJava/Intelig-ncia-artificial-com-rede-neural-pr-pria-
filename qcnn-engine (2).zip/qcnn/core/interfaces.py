from abc import ABC, abstractmethod
from typing import TYPE_CHECKING
from qcnn.core.holographic_memory import HolographicMemoryStore

if TYPE_CHECKING:
    from qcnn.core.context import QcnnExecutionContext

class BaseQcnnPlugin(ABC):
    """
    Interface base obrigatória para todos os plugins do ecossistema QCNN.
    Permite acoplamento fraco, conexão/desconexão dinâmica e memória holográfica autônoma.
    Princípio Fractal: Cada módulo possui sua própria memória independente proporcional.
    """
    def __init__(self, memory_dimension: int = 10000, memory_capacity: int = 100):
        self._enabled = True
        self._memory = HolographicMemoryStore(owner_id=self.plugin_id, dimension=memory_dimension, capacity=memory_capacity)

    @property
    @abstractmethod
    def plugin_id(self) -> str:
        """Identificador único do plugin (ex: 'milui_expansion')"""
        pass

    @property
    def memory(self) -> HolographicMemoryStore:
        """Repositório de memória holográfica independente do plugin."""
        return self._memory

    @property
    def is_enabled(self) -> bool:
        """Indica se o plugin está ativo. Pode ser sobrescrito se necessário."""
        return self._enabled

    @is_enabled.setter
    def is_enabled(self, value: bool):
        self._enabled = value

    @abstractmethod
    def execute(self, context: 'QcnnExecutionContext') -> 'QcnnExecutionContext':
        """
        Executa a etapa do plugin enriquecendo o contexto de execução.
        """
        pass
