<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.ai-handoff; current: docs/ai/AI_CHANGE_PROTOCOL.md -->
# AI Change Protocol

```text
Read current truth + module preview
→ identify owner module
→ classify change (UI / contract / data / docs / tests / skills)
→ preserve module boundary and specialized mechanic
→ modify only necessary artifacts
→ update contracts/tests/docs as needed
→ regenerate preview after visual change
→ update memory/skills for structural change
→ regenerate documentation inventory
→ run composite release gates
→ create a new version directory and ONE complete ZIP
```

Never overwrite the previous release. Never fake production AI/database/tool/agent behavior in the template.

## V8.7 frontier readiness

Before planning executable Neural Engine work, read:
- `../frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
- `../frontier-readiness/EXECUTION_ROADMAP.md`
- `../../neural-engine/registry/frontier-readiness.json`

Treat `D0`, `UI0`, parity targets and differentiation targets as documentation states, never as implemented capabilities.



## V8.10 agent-harness research
Before implementing project/session/agent/tool runtime behavior, read `neural-engine/research/deepseek-harness-2026/README.md`, the 12 modules under `neural-engine/modules/11-agent-harness-runtime/`, and the semantic durability/session evolution strategies. Preserve the documentation-only boundary until an executable-engine release is explicitly authorized.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.


## Engine ↔ UI Bridge V8.11
Before changing interface or engine docs, inspect `platform/engine-ui-bridge/registry.json` and run both non-regression/compatibility gates. Do not mark engine states executable while `neural_engine_code_status` is `NOT_IMPLEMENTED`.


## V8.11 change protocol

1. Read the V8.10 non-regression baseline.
2. Identify UI and future engine owners.
3. Preserve existing semantics.
4. Extend contracts additively/version them explicitly.
5. Update Engine↔UI bridge and traceability.
6. Update tests/previews/docs/memory/skills.
7. Run non-regression + Engine/UI compatibility + full release gates.
8. Regenerate status registry before documentation inventory.
