<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 110 — Non-Regression Rules

- module packages remain self-contained;
- module UI owns its CSS;
- no shared required UI CSS across modules;
- no direct private-table cross-module access;
- no provider SDK in domain modules;
- public contracts are versioned;
- current + previous contract supported during migrations;
- data ownership is explicit;
- module/model replacement is audited;
- memory/state must be updated with every structural evolution.
