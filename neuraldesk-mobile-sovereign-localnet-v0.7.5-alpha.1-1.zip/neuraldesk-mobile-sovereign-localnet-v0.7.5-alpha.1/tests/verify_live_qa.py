#!/usr/bin/env python3
import json
import subprocess
import tempfile
from pathlib import Path

BIN='./build/ndassistant'
R='models/neuraldesk-knowledge-retriever-v0.5.ndkr'
K='models/neuraldesk-knowledge-v0.5.ndkb'
Q='models/neuraldesk-context-pointer-v0.5.ndqa'
L='models/neuraldesk-relation-classifier-v0.5.ndrl'
CASES=[
 ('Qual é a capital do Brasil?',None,['Brasília'],'knowledge'),
 ('O que é KV cache?',None,['chaves','valores'],'knowledge'),
 ('O NeuralDesk depende de ChatGPT?',None,['Não','rede neural local'],'knowledge'),
 ('Como funciona a internet no NeuralDesk?',None,['contexto','localmente'],'knowledge'),
 ('O que é TLS?',None,['confidencialidade','integridade'],'knowledge'),
 ('O que é ABI?',None,['Application Binary Interface','binári'],'knowledge'),
 ('O que é CSV?',None,['tabulares','campos'],'knowledge'),
 ('O que é uma condição de corrida?',None,['concorrentes','estado compartilhado'],'knowledge'),
 ('O que é instruction tuning?',None,['instrução','resposta'],'knowledge'),
 ('O que são logits em uma rede neural?',None,['probabilidades','softmax'],'knowledge'),
 ('Quanto é 17 vezes 23?',None,['391'],'calculator'),
 ('Quanto é 25% de 200?',None,['50'],'calculator'),
 ('Qual é a raiz quadrada de 81?',None,['9'],'calculator'),
 ('Quanto é 2 elevado a 10?',None,['1024'],'calculator'),
 ('Qual é a capital do país fictício Noveria-999?',None,['Não sei com segurança'],'uncertain'),
 ('Qual é a senha privada que não foi fornecida?',None,['Não sei com segurança'],'uncertain'),
 ('Qual é a versão atual do projeto Atlas-77?',
  'A versão anterior do projeto Atlas-77 era v3.9.1. A versão atual do projeto Atlas-77 é v4.0.0. O status está estável.',
  ['v4.0.0'],'context'),
 ('Qual é o endereço atual do nó Lab-42?',
  'O endereço anterior do nó Lab-42 era 10.0.0.2. O endereço atual do nó Lab-42 é 192.168.1.10. O serviço está ativo.',
  ['192.168.1.10'],'context'),
 ('Qual é o código atual do projeto Atlas-77 e quem é responsável?',
  'O código atual do projeto Boreal-9 é BR-22. Otávio é responsável pelo projeto Boreal-9. O código anterior do projeto Atlas-77 era OLD-9. O código atual do projeto Atlas-77 é NX-88. Marina é responsável pelo projeto Atlas-77.',
  ['NX-88','Marina'],'composed'),
 ('Explique como o mecanismo Cache-99 reduz trabalho repetido.',
  'O mecanismo Cache-99 guarda chaves já calculadas para evitar recomputação. Isso reduz trabalho repetido durante a execução e pode diminuir a latência. A cor da interface de Cache-99 é azul. O relatório financeiro de Cache-99 foi arquivado ontem.',
  ['evitar recomputação','reduz trabalho repetido'],'context'),
 ('Quanto é 11 vezes 3 e o que é TLS?',None,['33','confidencialidade','integridade'],'composed'),
 ('Qual é o status atual do projeto Atlas-77, quanto é 9 vezes 9, o que é JSON?',
  'O status anterior do projeto Atlas-77 era suspenso. O status atual do projeto Atlas-77 está operacional.',
  ['operacional','81','formato textual'],'composed'),
 ('Qual é a capital do Brasil?',
  'Este contexto fala apenas de um protótipo chamado Aurora e não contém informação geográfica.',
  ['Brasília'],'knowledge'),
 ('Qual é o identificador atual de Atlas-900 e quando será lançado?',
  'O identificador atual de Atlas-900 é NX-8100. O status está ativo.',
  ['NX-8100','Não encontrei evidência suficiente'],'composed'),
 # v0.5 relation-assisted context families
 ('Em qual endpoint numérico Registro-9000 está escutando?',
  'Registro-9000 usa licença MIT. O serviço Registro-9000 escuta na porta 8443. Registro-9000 usa o protocolo HTTP/3.',
  ['8443'],'context'),
 ('Qual termo de licenciamento rege Registro-9001?',
  'Registro-9001 atende na porta 9443. O componente Registro-9001 é distribuído sob Apache-2.0. Sua prioridade é alta.',
  ['Apache-2.0'],'context'),
 ('Qual tempo de resposta foi medido em Registro-9002?',
  'Registro-9002 usa QUIC. A latência medida de Registro-9002 foi 17 milissegundos. A região é eu-west-3.',
  ['17 milissegundos'],'context'),
 ('Que padrão de comunicação está ativo em Registro-9003?',
  'Registro-9003 tem checksum a1b2c3d4e5f6. O protocolo ativo de Registro-9003 é MQTT. A porta é 1883.',
  ['MQTT'],'context'),
 ('Qual empresa produziu Registro-9004?',
  'Registro-9004 tem prioridade crítica. O fabricante registrado de Registro-9004 é Vector Forge. A licença é ISC.',
  ['Vector Forge'],'context'),
 ('Que nível de urgência consta para Registro-9005?',
  'Registro-9005 usa WebSocket. A prioridade de Registro-9005 é crítica. O fabricante é Centro Aurora.',
  ['crítica'],'context'),
 ('Em qual zona de implantação está Registro-9006?',
  'Registro-9006 tem prioridade alta. A região de implantação de Registro-9006 é sa-east-1. O protocolo é HTTP/2.',
  ['sa-east-1'],'context'),
 ('Qual impressão de integridade consta para Registro-9007?',
  'Registro-9007 está em eu-west-3. O checksum de Registro-9007 é deadbeef0123. A porta de rede é 7443.',
  ['deadbeef0123'],'context'),
 ('Qual é a porta de Registro-9010 e qual protocolo ele utiliza?',
  'Registro-9010 usa licença MIT. A porta de rede de Registro-9010 é 7443. O protocolo de Registro-9010 é HTTP/3. A prioridade é média.',
  ['7443','HTTP/3'],'composed'),
]

def invoke(question, context=None, memory=None):
    cmd=[BIN,R,K,Q,L,question]
    if memory is not None:
        cmd.extend([context or '', '1', str(memory)])
    elif context is not None:
        cmd.append(context)
    p=subprocess.run(cmd,text=True,capture_output=True)
    assert p.returncode==0,(question,p.stdout,p.stderr)
    return p.stdout.strip(),p.stderr.strip()

rows=[]
for question,context,need,source in CASES:
    out,meta=invoke(question,context)
    ok=all(x.lower() in out.lower() for x in need) and f'source={source}' in meta
    rows.append({'question':question,'context':context,'answer':out,'meta':meta,'pass':ok})
    assert ok,(question,out,meta,need,source)

with tempfile.TemporaryDirectory() as td:
    memory=Path(td)/'assistant.ndmem'
    out,meta=invoke('Lembre que o código local do projeto Aurora-51 é MEM-442.',memory=memory)
    ok='source=memory' in meta and memory.is_file()
    rows.append({'question':'memory-write','answer':out,'meta':meta,'pass':ok}); assert ok,(out,meta)
    out,meta=invoke('Qual é o código local do projeto Aurora-51?',memory=memory)
    ok='MEM-442' in out and 'source=memory' in meta
    rows.append({'question':'memory-read-after-reload','answer':out,'meta':meta,'pass':ok}); assert ok,(out,meta)

report={'pass':len(rows),'total':len(rows),'rows':rows}
Path('evaluation/LIVE_QA_V05.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(f"live-qa-v05 PASS {len(rows)}/{len(rows)}")
