import sys, unittest, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class ArchitectureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestContext(__file__)

    def test_manifest_identity_and_version(self):
        self.assertEqual(self.ctx.manifest["module_id"], self.ctx.test_manifest["module_id"])
        self.assertEqual(self.ctx.manifest["version"], self.ctx.test_manifest["module_version"])

    def test_canonical_ui_is_inside_module(self):
        expected_prefix = f"modules/{self.ctx.module_root.name}/ui/"
        self.assertTrue(self.ctx.manifest["canonical_ui"].startswith(expected_prefix))
        self.assertTrue(self.ctx.ui_path.exists())

    def test_required_module_assets_exist(self):
        required = [
            "module.manifest.json","README.md","contracts/openapi.yaml","contracts/asyncapi.yaml",
            "contracts/config.schema.json","contracts/capabilities.json","contracts/permissions.json",
            "contracts/adaptive-ui.json","data/ownership.md","compatibility/matrix.json"
        ]
        for rel in required:
            with self.subTest(rel=rel):
                self.assertTrue((self.ctx.module_root / rel).exists(), rel)

    def test_runtime_isolation_rules(self):
        rules = self.ctx.manifest["runtime_rules"]
        self.assertFalse(rules["direct_database_access_from_ui"])
        self.assertFalse(rules["cross_module_private_table_access"])
        self.assertFalse(rules["direct_ai_provider_sdk_dependency"])

    def test_root_alias_exists(self):
        alias = self.ctx.root_alias_path()
        self.assertIsNotNone(alias)
        self.assertTrue(alias.exists())
        alias_text = alias.read_text(encoding="utf-8", errors="ignore")
        self.assertIn(self.ctx.manifest["canonical_ui"], alias_text)

    def test_module_owned_runtime_rules(self):
        rules = self.ctx.manifest["runtime_rules"]
        self.assertTrue(rules["module_owned_javascript_only"])
        self.assertFalse(rules["shared_global_javascript_dependency"])
        self.assertTrue(rules["frontend_may_call_public_api_only"])

if __name__ == "__main__":
    unittest.main()
