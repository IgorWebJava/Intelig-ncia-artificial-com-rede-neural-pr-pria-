package com.neuraldesk.localnet

import android.app.Activity
import android.app.ActivityManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private var handle = 0L
    private val inferenceExecutor = Executors.newSingleThreadExecutor()
    private val destroyed = AtomicBoolean(false)
    private lateinit var ragFile: File

    private fun asset(name: String): File =
        assets.open(name).use { CanonicalAssetStore.install(File(filesDir, name), it) }

    private fun selectProfile(): MobileProfile {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        val ramMb = info.totalMem / (1024L * 1024L)
        val is64Bit = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
        return MobileProfilePolicy.select(ramMb, Runtime.getRuntime().availableProcessors(), is64Bit)
    }

    private fun applyThermalStatus() {
        if (handle == 0L) return
        val status = if (Build.VERSION.SDK_INT >= 29) {
            (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
        } else 0
        NativeEngine.setThermalStatus(handle, status)
    }

    private fun submitInference(task: () -> Unit) {
        if (destroyed.get() || handle == 0L) return
        NativeEngine.cancel(handle)
        inferenceExecutor.execute {
            if (destroyed.get() || handle == 0L) return@execute
            applyThermalStatus()
            task()
        }
    }

    private fun streamAnswer(question: String, context: String?, prefix: String, output: TextView): String {
        val collected = StringBuilder()
        val finalAnswer = NativeEngine.answerStream(handle, question, context, true) { chunk ->
            collected.append(chunk)
            if (!destroyed.get()) {
                val rendered = prefix + collected.toString()
                runOnUiThread { if (!destroyed.get()) output.text = rendered }
            }
        }
        if (collected.isEmpty() && finalAnswer.isNotEmpty() && !destroyed.get()) {
            runOnUiThread { if (!destroyed.get()) output.text = prefix + finalAnswer }
        }
        return if (collected.isNotEmpty()) collected.toString() else finalAnswer
    }

    private fun persistRag() {
        check(NativeEngine.ragSave(handle, ragFile.absolutePath)) { "falha ao persistir RAG local" }
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        val prompt = findViewById<EditText>(R.id.prompt)
        val url = findViewById<EditText>(R.id.url)
        val output = findViewById<TextView>(R.id.output)
        val memoryToggle = findViewById<Button>(R.id.memoryToggle)
        val memoryClear = findViewById<Button>(R.id.memoryClear)
        findViewById<TextView>(R.id.appTitle).text = "NeuralDesk LocalNet ${RuntimeIdentity.VERSION}"
        val memory = ResearchMemoryStore(this)

        val retriever = asset("neuraldesk-knowledge-retriever-v0.5.ndkr")
        val kb = asset("neuraldesk-knowledge-v0.5.ndkb")
        val qa = asset("neuraldesk-context-pointer-v0.5.ndqa")
        val relation = asset("neuraldesk-relation-classifier-v0.5.ndrl")
        val openKnowledge = asset("neuraldesk-open-knowledge-pira-v0.6.ndos")
        val semanticRanker = asset("neuraldesk-semantic-ranker-v0.7.1.ndsr")
        val explicitMemory = File(filesDir, "assistant-memory-v0.7.ndmem")
        ragFile = File(filesDir, "local-rag-v1.ndrag")
        handle = NativeEngine.load(
            retriever.absolutePath,
            kb.absolutePath,
            qa.absolutePath,
            relation.absolutePath,
            openKnowledge.absolutePath,
            semanticRanker.absolutePath,
            explicitMemory.absolutePath
        )
        require(handle != 0L) { "Falha ao carregar especialistas neurais e memória factual" }
        val profile = selectProfile()
        NativeEngine.setProfile(handle, profile)
        applyThermalStatus()
        if (ragFile.isFile && !NativeEngine.ragLoad(handle, ragFile.absolutePath)) {
            val rejected = File(filesDir, "local-rag-v1.rejected-${System.currentTimeMillis()}.ndrag")
            ragFile.renameTo(rejected)
        }
        output.text = "Perfil local: ${profile.name}"

        fun refreshMemoryButton() {
            memoryToggle.text = if (memory.isEnabled()) "Memória de pesquisa: ligada" else "Memória de pesquisa: desligada"
        }
        refreshMemoryButton()
        memoryToggle.setOnClickListener {
            runCatching { memory.setEnabled(!memory.isEnabled()) }
                .onSuccess { refreshMemoryButton() }
                .onFailure { output.text = "Erro na memória privada: ${it.message}" }
        }
        memoryClear.setOnClickListener {
            runCatching { memory.clear() }
                .onSuccess { output.text = "Memória de pesquisa local apagada." }
                .onFailure { output.text = "Erro ao apagar memória: ${it.message}" }
        }
        findViewById<Button>(R.id.cancel).setOnClickListener {
            if (handle != 0L) NativeEngine.cancel(handle)
        }

        findViewById<Button>(R.id.generate).setOnClickListener {
            val question = prompt.text.toString()
            submitInference {
                val cachedContext = memory.findRelevant(question)
                streamAnswer(question, cachedContext, "", output)
            }
        }

        findViewById<Button>(R.id.webGenerate).setOnClickListener {
            val question = prompt.text.toString()
            val requestedUrl = url.text.toString()
            submitInference {
                try {
                    val page = WebContextClient().fetch(requestedUrl)
                    if (destroyed.get()) return@submitInference
                    val selected = ContextSelector.select(question, page.text)
                    check(NativeEngine.ragAddDocument(handle, page.url, selected)) { "RAG rejeitou documento" }
                    persistRag()
                    streamAnswer(question, selected, "Fonte: ${page.url}\n\n", output)
                    memory.append(question, page.url, selected)
                } catch (ex: Exception) {
                    if (!destroyed.get()) runOnUiThread { output.text = "Erro: ${ex.message}" }
                }
            }
        }

        findViewById<Button>(R.id.autoResearch).setOnClickListener {
            val question = prompt.text.toString()
            submitInference {
                try {
                    val result = WikipediaResearchClient().research(question)
                    if (destroyed.get()) return@submitInference
                    check(NativeEngine.ragAddDocument(handle, result.sourceUrl, result.context)) { "RAG rejeitou documento" }
                    persistRag()
                    streamAnswer(question, result.context, "Fonte: ${result.title} — ${result.sourceUrl}\n\n", output)
                    memory.append(question, result.sourceUrl, result.context)
                } catch (ex: Exception) {
                    if (!destroyed.get()) runOnUiThread { output.text = "Erro: ${ex.message}" }
                }
            }
        }
    }

    override fun onDestroy() {
        destroyed.set(true)
        val current = handle
        if (current != 0L) NativeEngine.cancel(current)
        inferenceExecutor.shutdownNow()
        if (current != 0L) NativeEngine.free(current)
        handle = 0L
        super.onDestroy()
    }
}
