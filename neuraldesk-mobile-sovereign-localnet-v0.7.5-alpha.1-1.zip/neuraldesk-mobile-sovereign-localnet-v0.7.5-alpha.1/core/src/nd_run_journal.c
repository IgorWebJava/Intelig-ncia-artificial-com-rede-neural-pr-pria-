#include "nd_run_journal.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

#define NDJR_MAGIC 0x524a444eu
#define NDJR_VERSION 1u

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint64_t run_id;
    int64_t timestamp;
    char event[16];
    char status[24];
    char profile[24];
    char source[24];
} Record;

static int append_record(const char *path,const Record *r,char *err,size_t ec){FILE *f=fopen(path,"ab");if(!f){if(err&&ec)snprintf(err,ec,"cannot open run journal");return -1;}size_t n=fwrite(r,sizeof(*r),1u,f);int rc=fclose(f);if(n!=1u||rc!=0){if(err&&ec)snprintf(err,ec,"cannot write run journal");return -1;}return 0;}
void nd_run_journal_init(NDRunJournal *j){if(j){memset(j,0,sizeof(*j));j->next_id=1u;}}
int nd_run_journal_set_path(NDRunJournal *j,const char *p,char *err,size_t ec){if(!j||!p||strlen(p)>=sizeof(j->path)){if(err&&ec)snprintf(err,ec,"invalid journal path");return -1;}snprintf(j->path,sizeof(j->path),"%s",p);return 0;}
int nd_run_journal_recover(NDRunJournal *j,size_t *abandoned,char *err,size_t ec){if(!j||!j->path[0]){if(abandoned)*abandoned=0u;return 0;}FILE*f=fopen(j->path,"rb");if(!f){if(abandoned)*abandoned=0u;return 0;}uint64_t open_ids[256];size_t on=0u;Record r;uint64_t maxid=0u;while(fread(&r,sizeof(r),1u,f)==1u){if(r.magic!=NDJR_MAGIC||r.version!=NDJR_VERSION){fclose(f);if(err&&ec)snprintf(err,ec,"run journal corrupt");return -1;}if(r.run_id>maxid)maxid=r.run_id;if(strcmp(r.event,"BEGIN")==0){if(on<256u)open_ids[on++]=r.run_id;}else if(strcmp(r.event,"END")==0||strcmp(r.event,"ABANDONED")==0){for(size_t i=0u;i<on;i++)if(open_ids[i]==r.run_id){memmove(&open_ids[i],&open_ids[i+1u],(on-i-1u)*sizeof(open_ids[0]));on--;break;}}}fclose(f);j->next_id=maxid+1u;size_t n=on;for(size_t i=0u;i<n;i++){Record a;memset(&a,0,sizeof(a));a.magic=NDJR_MAGIC;a.version=NDJR_VERSION;a.run_id=open_ids[i];a.timestamp=(int64_t)time(NULL);snprintf(a.event,sizeof(a.event),"ABANDONED");snprintf(a.status,sizeof(a.status),"PROCESS_RESTART");if(append_record(j->path,&a,err,ec))return -1;}if(abandoned)*abandoned=n;return 0;}
int nd_run_journal_begin(NDRunJournal *j,const char *profile,uint64_t *id,char *err,size_t ec){if(!j||!j->path[0]){if(id)*id=0u;return 0;}Record r;memset(&r,0,sizeof(r));r.magic=NDJR_MAGIC;r.version=NDJR_VERSION;r.run_id=j->next_id++;r.timestamp=(int64_t)time(NULL);snprintf(r.event,sizeof(r.event),"BEGIN");snprintf(r.status,sizeof(r.status),"RUNNING");snprintf(r.profile,sizeof(r.profile),"%s",profile?profile:"UNKNOWN");if(append_record(j->path,&r,err,ec))return -1;if(id)*id=r.run_id;return 0;}
int nd_run_journal_progress(NDRunJournal *j,uint64_t id,const char *phase,const char *source,char *err,size_t ec){if(!j||!j->path[0]||id==0u)return 0;Record r;memset(&r,0,sizeof(r));r.magic=NDJR_MAGIC;r.version=NDJR_VERSION;r.run_id=id;r.timestamp=(int64_t)time(NULL);snprintf(r.event,sizeof(r.event),"PROGRESS");snprintf(r.status,sizeof(r.status),"%s",phase?phase:"UNKNOWN");snprintf(r.source,sizeof(r.source),"%s",source?source:"LOCAL");return append_record(j->path,&r,err,ec);}
int nd_run_journal_drain(NDRunJournal *j,uint64_t id,const char *status,char *err,size_t ec){if(!j||!j->path[0]||id==0u)return 0;Record r;memset(&r,0,sizeof(r));r.magic=NDJR_MAGIC;r.version=NDJR_VERSION;r.run_id=id;r.timestamp=(int64_t)time(NULL);snprintf(r.event,sizeof(r.event),"DRAIN");snprintf(r.status,sizeof(r.status),"%s",status?status:"REQUESTED");snprintf(r.source,sizeof(r.source),"LOCAL");return append_record(j->path,&r,err,ec);}
int nd_run_journal_end(NDRunJournal *j,uint64_t id,const char *status,const char *source,char *err,size_t ec){if(!j||!j->path[0]||id==0u)return 0;Record r;memset(&r,0,sizeof(r));r.magic=NDJR_MAGIC;r.version=NDJR_VERSION;r.run_id=id;r.timestamp=(int64_t)time(NULL);snprintf(r.event,sizeof(r.event),"END");snprintf(r.status,sizeof(r.status),"%s",status?status:"DONE");snprintf(r.source,sizeof(r.source),"%s",source?source:"UNKNOWN");return append_record(j->path,&r,err,ec);}
