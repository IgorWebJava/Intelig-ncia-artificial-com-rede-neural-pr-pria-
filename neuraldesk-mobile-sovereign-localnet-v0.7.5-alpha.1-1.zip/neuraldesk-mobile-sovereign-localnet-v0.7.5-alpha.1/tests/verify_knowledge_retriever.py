#!/usr/bin/env python3
import subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'training'))
import train_knowledge_retriever as k
_,gold=k.build_sets()
with tempfile.NamedTemporaryFile('w',encoding='utf-8',delete=False) as f:
    path=f.name
    for q,y in gold:f.write(f'{y}\t{q}\n')
try:
    p=subprocess.run([str(ROOT/'build/nd_knowledge_batch'),str(ROOT/'models/neuraldesk-knowledge-retriever-v0.5.ndkr'),str(ROOT/'models/neuraldesk-knowledge-v0.5.ndkb'),path],text=True,capture_output=True)
    print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
    if p.returncode:raise SystemExit(p.returncode)
finally:
    Path(path).unlink(missing_ok=True)
