#include "nd_context_synth.h"
#include "nd_planner.h"

#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ND_MAX_SENTENCES 256u
#define ND_MAX_TERMS 96u
#define ND_TERM_BYTES 72u
#define ND_MAX_EVIDENCE 6u
#define ND_MAX_GOALS 8u
#define ND_GOAL_BYTES 1024u

typedef struct {
    size_t start;
    size_t end;
    float score;
    int relation_match;
    uint32_t relation_id;
    float relation_confidence;
    int relation_accepted;
} Sent;

typedef struct {
    char s[ND_TERM_BYTES];
    size_t n;
} Term;

typedef struct {
    char text[ND_GOAL_BYTES];
    float best_score;
    size_t sentence_index;
    int covered;
    uint32_t relation_id;
    float relation_confidence;
    int relation_accepted;
} Goal;

static void seterr(char *e, size_t n, const char *fmt, ...) {
    if (!e || !n) return;
    va_list a;
    va_start(a, fmt);
    vsnprintf(e, n, fmt, a);
    va_end(a);
}

static int isword(unsigned char x) {
    return isalnum(x) || x == (unsigned char)'-' || x >= 128u;
}

static unsigned char lower_ascii(unsigned char x) {
    return (x >= 'A' && x <= 'Z') ? (unsigned char)(x + 32) : x;
}

static int eqterm(const Term *a, const Term *b) {
    return a->n == b->n && memcmp(a->s, b->s, a->n) == 0;
}

static int related_term(const Term *a, const Term *b) {
    if (eqterm(a, b)) return 1;
    /* Conservative morphology support for long lexical relation words.
     * Seven shared bytes covers forms such as responsável/responsabilidade
     * without weakening exact matching for short words or structured ids. */
    return a->n >= 8u && b->n >= 8u && memcmp(a->s, b->s, 7u) == 0;
}

static int stop(const Term *t) {
    static const char *sw[] = {
        "a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das",
        "em", "no", "na", "nos", "nas", "e", "ou", "que", "qual", "quais", "quem", "como",
        "por", "para", "com", "sem", "se", "me", "diga", "informe", "responda", "resposta",
        "pode", "favor", "sobre", "isto", "isso", "este", "esta", "esse", "essa", "ao", "aos",
        "à", "às", "é", "sao", "são", "projeto", "sistema"
    };
    for (size_t i = 0; i < sizeof(sw) / sizeof(sw[0]); i++) {
        size_t n = strlen(sw[i]);
        if (t->n == n && memcmp(t->s, sw[i], n) == 0) return 1;
    }
    return 0;
}

static size_t terms(const char *s, size_t n, Term *out, size_t cap) {
    size_t k = 0, i = 0;
    while (i < n && k < cap) {
        while (i < n && !isword((unsigned char)s[i])) i++;
        size_t j = i;
        while (j < n && isword((unsigned char)s[j])) j++;
        if (j > i) {
            Term t;
            size_t z = j - i;
            if (z >= ND_TERM_BYTES) z = ND_TERM_BYTES - 1u;
            for (size_t x = 0; x < z; x++) t.s[x] = (char)lower_ascii((unsigned char)s[i + x]);
            t.s[z] = 0;
            t.n = z;
            if ((z >= 2u || isdigit((unsigned char)t.s[0])) && !stop(&t)) {
                int dup = 0;
                for (size_t x = 0; x < k; x++) {
                    if (eqterm(&out[x], &t)) {
                        dup = 1;
                        break;
                    }
                }
                if (!dup) out[k++] = t;
            }
        }
        i = (j > i) ? j : i + 1u;
    }
    return k;
}

static int has_term(const Term *hay, size_t hn, const Term *needle) {
    for (size_t i = 0; i < hn; i++) {
        if (eqterm(&hay[i], needle)) return 1;
    }
    return 0;
}

static int has_related_term(const Term *hay, size_t hn, const Term *needle) {
    for (size_t i = 0; i < hn; i++) {
        if (related_term(&hay[i], needle)) return 1;
    }
    return 0;
}

static const Term *structured_anchor(const Term *qt, size_t qtc) {
    for (size_t i = 0; i < qtc; i++) {
        for (size_t j = 0; j < qt[i].n; j++) {
            unsigned char c = (unsigned char)qt[i].s[j];
            if (isdigit(c) || c == (unsigned char)'-' || c == (unsigned char)'_') return &qt[i];
        }
    }
    return NULL;
}

static int sentence_has_term(const char *context, const Sent *s, const Term *needle) {
    Term st[ND_MAX_TERMS];
    size_t sn = terms(context + s->start, s->end - s->start, st, ND_MAX_TERMS);
    return has_term(st, sn, needle);
}

static int contains_ci_n(const char *s, size_t n, const char *needle);

static int sentence_has_query_support(const char *context, const Sent *s,
                                      const Term *qt, size_t qtc,
                                      const Term *anchor) {
    Term st[ND_MAX_TERMS];
    size_t sn = terms(context + s->start, s->end - s->start, st, ND_MAX_TERMS);
    for (size_t i = 0; i < qtc; i++) {
        if (anchor && eqterm(&qt[i], anchor)) continue;
        if (has_related_term(st, sn, &qt[i])) return 1;
    }
    return 0;
}

static int sentence_declares_absence(const char *context, const Sent *s) {
    const char *p = context + s->start;
    size_t n = s->end - s->start;
    return contains_ci_n(p, n, "não informa") || contains_ci_n(p, n, "nao informa") ||
           contains_ci_n(p, n, "não há") || contains_ci_n(p, n, "nao ha") ||
           contains_ci_n(p, n, "não consta") || contains_ci_n(p, n, "nao consta") ||
           contains_ci_n(p, n, "não disponível") || contains_ci_n(p, n, "nao disponivel");
}

/*
 * Conservative discourse bridge recovered from v0.6.3.  A value sentence may
 * omit a structured entity when the immediately preceding sentence establishes
 * that entity.  The bridge is allowed only when the candidate itself carries
 * query/relation support and is not an explicit absence declaration.
 */
static int sentence_has_adjacent_anchor_bridge(const char *context, const Sent *sentences,
                                                size_t sentence_count, size_t candidate_index,
                                                const Term *anchor, const Term *qt, size_t qtc,
                                                int relation_match) {
    if (!context || !sentences || !anchor || candidate_index >= sentence_count) return 0;
    const Sent *candidate = &sentences[candidate_index];
    if (sentence_declares_absence(context, candidate)) return 0;
    if (!relation_match && !sentence_has_query_support(context, candidate, qt, qtc, anchor)) return 0;
    size_t first = candidate_index > 2u ? candidate_index - 2u : 0u;
    for (size_t i = candidate_index; i > first; i--) {
        const Sent *prev = &sentences[i - 1u];
        if (sentence_has_term(context, prev, anchor)) return 1;
    }
    return 0;
}

static int contains_ci_n(const char *s, size_t n, const char *needle) {
    size_t m = strlen(needle);
    if (!m || m > n) return 0;
    for (size_t i = 0; i + m <= n; i++) {
        size_t j = 0;
        for (; j < m; j++) {
            if (lower_ascii((unsigned char)s[i + j]) != lower_ascii((unsigned char)needle[j])) break;
        }
        if (j == m) return 1;
    }
    return 0;
}


static size_t split_sentences(const char *c, size_t n, Sent *s, size_t cap) {
    size_t k = 0, start = 0;
    while (start < n && k < cap) {
        while (start < n && isspace((unsigned char)c[start])) start++;
        if (start >= n) break;
        size_t i = start;
        while (i < n) {
            unsigned char x = (unsigned char)c[i];
            i++;
            if (x == '.' || x == '!' || x == '?' || x == '\n') {
                /* A dot inside a structured token is not a sentence boundary.
                 * Preserve versions (v4.0.0), decimal numbers (3.14) and IPv4
                 * addresses instead of silently truncating evidence. */
                if (x == '.' && i >= 2u && i < n &&
                    isalnum((unsigned char)c[i - 2u]) && isalnum((unsigned char)c[i])) {
                    continue;
                }
                while (i < n && (c[i] == '"' || c[i] == '\'' || c[i] == ')' || c[i] == ']')) i++;
                break;
            }
        }
        size_t end = i;
        while (end > start && isspace((unsigned char)c[end - 1])) end--;
        if (end > start) {
            s[k].start = start;
            s[k].end = end;
            s[k].score = 0.0f;
            s[k].relation_match = 0;
            k++;
        }
        start = i;
    }
    return k;
}

static float sentence_score(const char *q, size_t qn, const Term *qt, size_t qtc,
                            const char *c, const Sent *s) {
    Term st[ND_MAX_TERMS];
    size_t sn = terms(c + s->start, s->end - s->start, st, ND_MAX_TERMS);
    float sc = 0.0f;
    size_t matches = 0;
    for (size_t i = 0; i < qtc; i++) {
        if (has_related_term(st, sn, &qt[i])) {
            float w = 2.0f;
            int allnum = 1;
            for (size_t z = 0; z < qt[i].n; z++) {
                if (!isdigit((unsigned char)qt[i].s[z])) {
                    allnum = 0;
                    break;
                }
            }
            if (allnum) w = 3.0f;
            if (qt[i].n >= 7u) w += 0.5f;
            sc += w;
            matches++;
        }
    }
    if (matches >= 2u) sc += 0.5f * (float)(matches - 1u);

    int asks_current = contains_ci_n(q, qn, "atual") || contains_ci_n(q, qn, "agora") ||
                       contains_ci_n(q, qn, "vigente") || contains_ci_n(q, qn, "mais recente");
    int asks_old = contains_ci_n(q, qn, "anterior") || contains_ci_n(q, qn, "antes") ||
                   contains_ci_n(q, qn, "antigo");
    size_t len = s->end - s->start;
    const char *p = c + s->start;
    if (asks_current) {
        if (contains_ci_n(p, len, "atual") || contains_ci_n(p, len, "agora") ||
            contains_ci_n(p, len, "vigente") || contains_ci_n(p, len, "mais recente")) sc += 4.0f;
        if (contains_ci_n(p, len, "anterior") || contains_ci_n(p, len, "antes") ||
            contains_ci_n(p, len, "era ") || contains_ci_n(p, len, "tinha ")) sc -= 2.5f;
    }
    if (asks_old) {
        if (contains_ci_n(p, len, "anterior") || contains_ci_n(p, len, "antes") ||
            contains_ci_n(p, len, "antigo")) sc += 3.0f;
        if (contains_ci_n(p, len, "atual")) sc -= 1.5f;
    }
    return sc;
}

static int infer_sentence_relation(const NDRelationClassifier *relation,
                                   const char *context,
                                   Sent *sentence,
                                   char *err,
                                   size_t errcap) {
    sentence->relation_id = UINT32_MAX;
    sentence->relation_confidence = 0.0f;
    sentence->relation_accepted = 0;
    if (!relation) return 0;
    size_t len = sentence->end - sentence->start;
    char *text = (char *)malloc(len + 1u);
    if (!text) {
        seterr(err, errcap, "oom relation sentence");
        return -1;
    }
    memcpy(text, context + sentence->start, len);
    text[len] = 0;
    NDRelationResult sr;
    int rc = nd_relation_infer(relation, text, &sr, err, errcap);
    free(text);
    if (rc != 0) return -1;
    sentence->relation_id = sr.relation_id;
    sentence->relation_confidence = sr.confidence;
    sentence->relation_accepted = sr.accepted;
    return 0;
}

static float relation_adjustment(const Goal *goal, const Sent *sentence, int *used_signal) {
    if (!goal || !goal->relation_accepted || !sentence->relation_accepted) return 0.0f;
    *used_signal = 1;
    return sentence->relation_id == goal->relation_id ? 3.25f : -0.75f;
}

static void sort_idx(const Sent *s, size_t n, size_t *idx) {
    for (size_t i = 0; i < n; i++) idx[i] = i;
    for (size_t i = 1; i < n; i++) {
        size_t x = idx[i], j = i;
        while (j > 0 && s[idx[j - 1]].score < s[x].score) {
            idx[j] = idx[j - 1];
            j--;
        }
        idx[j] = x;
    }
}

static int append(char *out, size_t cap, size_t *used, const char *s, size_t n) {
    if (*used + n + 1u > cap) return -1;
    memcpy(out + *used, s, n);
    *used += n;
    out[*used] = 0;
    return 0;
}

static int append_cstr(char *out, size_t cap, size_t *used, const char *s) {
    return append(out, cap, used, s, strlen(s));
}

static int multi_or_explain(const char *q) {
    size_t n = strlen(q);
    return contains_ci_n(q, n, "por que") || contains_ci_n(q, n, "como ") ||
           contains_ci_n(q, n, "explique") || contains_ci_n(q, n, "resuma") ||
           contains_ci_n(q, n, "compare") || contains_ci_n(q, n, " e quem") ||
           contains_ci_n(q, n, " e qual") || contains_ci_n(q, n, " e a ") ||
           contains_ci_n(q, n, " e o ") || contains_ci_n(q, n, "quais ") ||
           contains_ci_n(q, n, "detalh");
}

static void extend_structured_direct(const char *sentence, char *direct, size_t cap) {
    if (!sentence || !direct || !direct[0] || cap < 2u) return;
    const char *hit = strstr(sentence, direct);
    if (!hit) return;
    size_t dn = strlen(direct);
    const char *p = hit + dn;
    size_t used = dn;

    /* A neural span may stop inside values such as 192.168.1.10, v4.0.0 or
     * code-like identifiers.  Extend only across characters that are already
     * present contiguously in the cited sentence.  A dot is included only
     * when followed by another token character, so terminal punctuation is
     * never fabricated into the answer. */
    while (*p && used + 1u < cap) {
        unsigned char c = (unsigned char)*p;
        int plain = isalnum(c) || c == (unsigned char)'-' || c == (unsigned char)'_';
        int join = (c == (unsigned char)'.' || c == (unsigned char)':' || c == (unsigned char)'/') &&
                   p[1] && (isalnum((unsigned char)p[1]) || p[1] == '-' || p[1] == '_');
        if (!plain && !join) break;
        direct[used++] = *p++;
    }
    direct[used] = 0;
}

static int boundary_is_word(unsigned char c) {
    return isalnum(c) || c >= 128u || c == (unsigned char)'_' || c == (unsigned char)'-';
}

static int asks_code_value(const char *question) {
    size_t n = strlen(question);
    return contains_ci_n(question, n, "código") || contains_ci_n(question, n, "codigo") ||
           contains_ci_n(question, n, "identificador");
}

static int extract_explicit_code_value(const char *sentence, char *out, size_t cap) {
    static const char *relations[] = {"código", "codigo", "identificador"};
    size_t n = strlen(sentence);
    for (size_t r = 0u; r < sizeof(relations) / sizeof(relations[0]); r++) {
        size_t rn = strlen(relations[r]);
        for (size_t pos = 0u; pos + rn < n; pos++) {
            if (!contains_ci_n(sentence + pos, rn, relations[r])) continue;
            const char *tail = sentence + pos + rn;
            const char *limit = tail;
            size_t scanned = 0u;
            while (*limit && *limit != '.' && *limit != ';' && *limit != ',' && scanned < 48u) {
                limit++;
                scanned++;
            }
            const char *value = NULL;
            for (const char *p = tail; p < limit; p++) {
                if ((p == tail || isspace((unsigned char)p[-1])) &&
                    ((p[0] == ':' && (p + 1) < limit) ||
                     ((unsigned char)p[0] == 0xc3u && (p + 2) < limit &&
                      (unsigned char)p[1] == 0xa9u && isspace((unsigned char)p[2])) ||
                     (p[0] == 'e' && (p + 1) < limit && isspace((unsigned char)p[1])))) {
                    if (p[0] == ':') value = p + 1;
                    else if ((unsigned char)p[0] == 0xc3u) value = p + 2;
                    else value = p + 1;
                    break;
                }
            }
            if (!value) continue;
            while (value < limit && isspace((unsigned char)*value)) value++;
            const char *finish = value;
            while (finish < limit && (isalnum((unsigned char)*finish) || *finish == '-' ||
                                      *finish == '_' || *finish == '.')) finish++;
            size_t z = (size_t)(finish - value);
            if (z >= 2u && z + 1u <= cap) {
                memcpy(out, value, z);
                out[z] = 0;
                return 1;
            }
        }
    }
    return 0;
}

static int candidate_has_value_shape(const char *sentence, const char *direct) {
    if (!sentence || !direct || !direct[0]) return 0;
    const char *hit = strstr(sentence, direct);
    if (!hit) return 0;
    size_t n = strlen(direct);
    if (!n) return 0;

    size_t alnum_count = 0u;
    size_t digit_count = 0u;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)direct[i];
        if (isalnum(c) || c >= 128u) alnum_count++;
        if (isdigit(c)) digit_count++;
    }
    if (!alnum_count) return 0;
    if (n == 1u && digit_count == 0u) return 0;

    if (hit > sentence && boundary_is_word((unsigned char)hit[-1]) &&
        boundary_is_word((unsigned char)direct[0])) return 0;
    const char *after = hit + n;
    if (*after && boundary_is_word((unsigned char)direct[n - 1u]) &&
        boundary_is_word((unsigned char)*after)) return 0;

    /* Conservative protection for a leading multi-token proper name.  If the
     * pointer selects only the first capitalized word and the next token also
     * starts with an uppercase byte, use the complete evidence instead of a
     * potentially truncated direct answer. */
    if (hit == sentence && isupper((unsigned char)direct[0]) && *after) {
        const char *p = after;
        while (*p && isspace((unsigned char)*p)) p++;
        if (*p && isupper((unsigned char)*p)) return 0;
    }
    return 1;
}

static int candidate_is_relation_phrase(const NDRelationClassifier *relation,
                                        const NDRelationResult *question_relation,
                                        const char *direct,
                                        int *is_relation,
                                        char *err,
                                        size_t errcap) {
    *is_relation = 0;
    if (!relation || !question_relation || !question_relation->accepted || !direct || !direct[0]) return 0;
    NDRelationResult candidate_relation;
    if (nd_relation_infer(relation, direct, &candidate_relation, err, errcap) != 0) return -1;
    if (candidate_relation.accepted &&
        candidate_relation.relation_id == question_relation->relation_id) {
        *is_relation = 1;
    }
    return 0;
}

static size_t count_words(const char *s) {
    size_t n = strlen(s), i = 0, k = 0;
    while (i < n) {
        while (i < n && !isword((unsigned char)s[i])) i++;
        if (i < n) k++;
        while (i < n && isword((unsigned char)s[i])) i++;
    }
    return k;
}

static void trim_copy(char *dst, size_t cap, const char *begin, const char *end) {
    while (begin < end && isspace((unsigned char)*begin)) begin++;
    while (end > begin && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - begin);
    if (n >= cap) n = cap - 1u;
    memcpy(dst, begin, n);
    dst[n] = 0;
}

/*
 * Decompose only explicit coordinated question goals.  This is deliberately
 * conservative: ordinary conjunctions inside noun phrases remain untouched.
 * The second goal does not need to repeat the entity name; relation words such
 * as "responsável", "cor", "data" or "versão" are sufficient to locate its
 * evidence after sentence-level retrieval has narrowed the context.
 */
static size_t split_goals(const char *q, Goal *goals, size_t cap) {
    if (!q || !*q || !cap) return 0;
    NDPlan plan;
    char planner_err[128];
    if (nd_plan_build(q, &plan, planner_err, sizeof(planner_err)) != 0 || plan.goal_count == 0u) {
        memset(goals, 0, cap * sizeof(*goals));
        trim_copy(goals[0].text, sizeof(goals[0].text), q, q + strlen(q));
        return goals[0].text[0] ? 1u : 0u;
    }
    size_t count = plan.goal_count < cap ? plan.goal_count : cap;
    memset(goals, 0, cap * sizeof(*goals));
    for (size_t i = 0; i < count; i++) {
        size_t n = strlen(plan.goals[i].text);
        if (n >= sizeof(goals[i].text)) n = sizeof(goals[i].text) - 1u;
        memcpy(goals[i].text, plan.goals[i].text, n);
        goals[i].text[n] = 0;
    }
    return count;
}

static int choose_goal_evidence(Goal *goals, size_t goal_count, const char *context,
                                Sent *sentences, size_t sentence_count,
                                const Term *fallback_anchor, int *relation_used) {
    size_t covered = 0;
    for (size_t g = 0; g < goal_count; g++) {
        Term gt[ND_MAX_TERMS];
        size_t gtc = terms(goals[g].text, strlen(goals[g].text), gt, ND_MAX_TERMS);
        float best = -INFINITY;
        size_t best_i = 0;
        if (!gtc) continue;
        const Term *goal_anchor = structured_anchor(gt, gtc);
        const Term *effective_anchor = goal_anchor ? goal_anchor : fallback_anchor;
        for (size_t i = 0; i < sentence_count; i++) {
            int rel_match = goals[g].relation_accepted && sentences[i].relation_accepted &&
                            goals[g].relation_id == sentences[i].relation_id;
            if (effective_anchor) {
                int has_anchor = sentence_has_term(context, &sentences[i], effective_anchor);
                int bridged = sentence_has_adjacent_anchor_bridge(context, sentences, sentence_count, i,
                                                                  effective_anchor, gt, gtc, rel_match);
                if (!has_anchor && !bridged) continue;
                if (!sentence_has_query_support(context, &sentences[i], gt, gtc, goal_anchor) &&
                    !rel_match) continue;
            }
            float sc = sentence_score(goals[g].text, strlen(goals[g].text), gt, gtc, context, &sentences[i]);
            sc += relation_adjustment(&goals[g], &sentences[i], relation_used);
            if (sc > best) {
                best = sc;
                best_i = i;
            }
        }
        goals[g].best_score = best;
        goals[g].sentence_index = best_i;
        goals[g].covered = best >= 2.0f ? 1 : 0;
        if (goals[g].covered) covered++;
    }
    return (int)covered;
}

static size_t unique_goal_sentences(const Goal *goals, size_t goal_count, size_t *chosen, size_t cap) {
    size_t cc = 0;
    for (size_t g = 0; g < goal_count && cc < cap; g++) {
        if (!goals[g].covered) continue;
        size_t x = goals[g].sentence_index;
        int dup = 0;
        for (size_t i = 0; i < cc; i++) {
            if (chosen[i] == x) {
                dup = 1;
                break;
            }
        }
        if (!dup) chosen[cc++] = x;
    }
    for (size_t i = 1; i < cc; i++) {
        size_t x = chosen[i], j = i;
        while (j > 0 && chosen[j - 1] > x) {
            chosen[j] = chosen[j - 1];
            j--;
        }
        chosen[j] = x;
    }
    return cc;
}

int nd_context_synthesize_ex(const NDContextQA *qa, const NDRelationClassifier *relation,
                             const char *question, const char *context, int rich,
                             char *out, size_t outcap, NDContextSynthesisResult *result,
                             char *e, size_t ec) {
    if (!question || !context || !out || !outcap) {
        seterr(e, ec, "invalid context synthesis input");
        return -1;
    }
    size_t qn = strlen(question), cn = strlen(context);
    if (!qn || !cn) {
        seterr(e, ec, "empty question/context");
        return -1;
    }
    if (qn > 4096u || cn > 65536u) {
        seterr(e, ec, "context synthesis input exceeds bounds");
        return -1;
    }

    Term qt[ND_MAX_TERMS];
    size_t qtc = terms(question, qn, qt, ND_MAX_TERMS);
    if (!qtc) {
        seterr(e, ec, "question has no meaningful terms");
        return -1;
    }

    Sent ss[ND_MAX_SENTENCES];
    size_t sn = split_sentences(context, cn, ss, ND_MAX_SENTENCES);
    if (!sn) {
        seterr(e, ec, "context has no sentences");
        return -1;
    }
    Goal goals[ND_MAX_GOALS];
    memset(goals, 0, sizeof(goals));
    size_t goal_count = split_goals(question, goals, ND_MAX_GOALS);

    NDRelationResult question_relation;
    memset(&question_relation, 0, sizeof(question_relation));
    question_relation.relation_id = UINT32_MAX;
    int relation_used = 0;
    if (relation && nd_relation_infer(relation, question, &question_relation, e, ec) != 0) return -1;
    for (size_t g = 0; relation && g < goal_count; g++) {
        NDRelationResult gr;
        if (nd_relation_infer(relation, goals[g].text, &gr, e, ec) != 0) return -1;
        goals[g].relation_id = gr.relation_id;
        goals[g].relation_confidence = gr.confidence;
        goals[g].relation_accepted = gr.accepted;
    }

    for (size_t i = 0; i < sn; i++) {
        if (infer_sentence_relation(relation, context, &ss[i], e, ec) != 0) return -1;
        ss[i].score = sentence_score(question, qn, qt, qtc, context, &ss[i]);
        if (goal_count == 1u && question_relation.accepted && ss[i].relation_accepted) {
            relation_used = 1;
            if (ss[i].relation_id == question_relation.relation_id) {
                ss[i].score += 3.25f;
                ss[i].relation_match = 1;
            } else {
                ss[i].score -= 0.75f;
            }
        }
    }

    size_t idx[ND_MAX_SENTENCES];
    sort_idx(ss, sn, idx);
    float best = ss[idx[0]].score;
    NDContextSynthesisResult rr;
    memset(&rr, 0, sizeof(rr));
    rr.best_score = best;
    rr.used_relation_signal = relation_used;
    rr.relation_id = question_relation.relation_id;
    rr.relation_confidence = question_relation.confidence;
    rr.goal_count = goal_count;
    out[0] = 0;

    if (goal_count == 1u && asks_code_value(question)) {
        const Term *code_anchor = structured_anchor(qt, qtc);
        for (size_t i = 0u; code_anchor && i < sn; i++) {
            int has_anchor = sentence_has_term(context, &ss[i], code_anchor);
            int bridged = sentence_has_adjacent_anchor_bridge(context, ss, sn, i, code_anchor, qt, qtc,
                                                              ss[i].relation_match);
            if (!has_anchor && !bridged) continue;
            size_t len = ss[i].end - ss[i].start;
            char *sentence = (char *)malloc(len + 1u);
            if (!sentence) continue;
            memcpy(sentence, context + ss[i].start, len);
            sentence[len] = 0;
            char code[256];
            int got = extract_explicit_code_value(sentence, code, sizeof(code));
            if (got) {
                int w = rich ? snprintf(out, outcap, "Resposta direta: %s\n\nEvidência no contexto: %s", code, sentence)
                             : snprintf(out, outcap, "%s", code);
                free(sentence);
                if (w < 0 || (size_t)w >= outcap) {
                    seterr(e, ec, "context code answer buffer too small");
                    return -1;
                }
                rr.found = 1;
                rr.evidence_count = 1u;
                rr.covered_goals = 1u;
                rr.best_score = ss[i].score;
                if (result) *result = rr;
                return 0;
            }
            free(sentence);
        }
    }

    size_t chosen[ND_MAX_EVIDENCE];
    size_t cc = 0;
    int decomposed = goal_count > 1u;
    if (decomposed) {
        const Term *fallback_anchor = structured_anchor(qt, qtc);
        int covered = choose_goal_evidence(goals, goal_count, context, ss, sn,
                                           fallback_anchor, &relation_used);
        rr.used_relation_signal = relation_used;
        rr.covered_goals = covered > 0 ? (size_t)covered : 0u;
        if ((size_t)covered != goal_count) {
            const char *z = "Não encontrei evidência suficiente no contexto fornecido para cobrir todos os pontos da pergunta com segurança.";
            if (strlen(z) + 1u > outcap) {
                seterr(e, ec, "context answer buffer too small");
                return -1;
            }
            strcpy(out, z);
            if (result) *result = rr;
            return 0;
        }
        cc = unique_goal_sentences(goals, goal_count, chosen, ND_MAX_EVIDENCE);
        if (!cc) {
            const char *z = "Não encontrei evidência suficiente no contexto fornecido para responder com segurança.";
            if (strlen(z) + 1u > outcap) {
                seterr(e, ec, "context answer buffer too small");
                return -1;
            }
            strcpy(out, z);
            if (result) *result = rr;
            return 0;
        }
    } else {
        rr.covered_goals = best >= 2.0f ? 1u : 0u;
        if (best < 2.0f) {
            const char *z = "Não encontrei evidência suficiente no contexto fornecido para responder com segurança.";
            if (strlen(z) + 1u > outcap) {
                seterr(e, ec, "context answer buffer too small");
                return -1;
            }
            strcpy(out, z);
            if (result) *result = rr;
            return 0;
        }
        float floor = best * 0.72f;
        if (floor < 2.0f) floor = 2.0f;
        const Term *anchor = structured_anchor(qt, qtc);
        for (size_t rank = 0; rank < sn && cc < ND_MAX_EVIDENCE; rank++) {
            size_t i = idx[rank];
            if (ss[i].score < floor) break;
            if (anchor) {
                int has_anchor = sentence_has_term(context, &ss[i], anchor);
                int bridged = sentence_has_adjacent_anchor_bridge(context, ss, sn, i, anchor, qt, qtc,
                                                                  ss[i].relation_match);
                if (!has_anchor && !bridged) continue;
                if (!sentence_has_query_support(context, &ss[i], qt, qtc, anchor) &&
                    !ss[i].relation_match) continue;
            }
            chosen[cc++] = i;
        }
        /* Explanatory questions often need a causal chain rather than a single
         * top-ranked sentence.  The primary ranking remains strict (including
         * structured anchors), then a second pass admits strongly related
         * supporting sentences at a lower threshold.  This allows a sentence
         * naming the mechanism to be combined with an adjacent consequence
         * sentence without admitting weak topical distractors. */
        if (multi_or_explain(question) && cc < ND_MAX_EVIDENCE) {
            float support_floor = best * 0.55f;
            if (support_floor < 2.75f) support_floor = 2.75f;
            for (size_t rank = 0; rank < sn && cc < ND_MAX_EVIDENCE; rank++) {
                size_t candidate = idx[rank];
                if (ss[candidate].score < support_floor) break;
                int duplicate = 0;
                for (size_t x = 0; x < cc; x++) {
                    if (chosen[x] == candidate) {
                        duplicate = 1;
                        break;
                    }
                }
                if (!duplicate) chosen[cc++] = candidate;
            }
        }
        if (!cc) {
            if (anchor) {
                const char *z = "Não encontrei evidência suficiente no contexto fornecido para responder com segurança.";
                if (strlen(z) + 1u > outcap) {
                    seterr(e, ec, "context answer buffer too small");
                    return -1;
                }
                strcpy(out, z);
                rr.covered_goals = 0u;
                if (result) *result = rr;
                return 0;
            }
            chosen[cc++] = idx[0];
        }
        for (size_t i = 1; i < cc; i++) {
            size_t x = chosen[i], j = i;
            while (j > 0 && chosen[j - 1] > x) {
                chosen[j] = chosen[j - 1];
                j--;
            }
            chosen[j] = x;
        }
    }

    rr.found = 1;
    rr.evidence_count = cc;
    int complex = decomposed || multi_or_explain(question) || cc > 1u;

    char direct[1024];
    direct[0] = 0;
    int pointer_ok = 0;
    if (qa && !complex) {
        size_t bi = idx[0], len = ss[bi].end - ss[bi].start;
        char *sentence = (char *)malloc(len + 1u);
        if (sentence) {
            memcpy(sentence, context + ss[bi].start, len);
            sentence[len] = 0;
            if (asks_code_value(question) && extract_explicit_code_value(sentence, direct, sizeof(direct))) {
                pointer_ok = 1;
            } else {
                float ps = 0.0f;
                uint32_t relation_id = question_relation.accepted ? question_relation.relation_id : UINT32_MAX;
                if (nd_context_qa_extract_relation(qa, relation_id, question, sentence,
                                                   direct, sizeof(direct), &ps, e, ec) == 0) {
                    rr.pointer_proposed = 1;
                extend_structured_direct(sentence, direct, sizeof(direct));
                size_t dl = strlen(direct), wc = count_words(direct);
                int relation_phrase = 0;
                if (candidate_is_relation_phrase(relation, &question_relation, direct,
                                                 &relation_phrase, e, ec) != 0) {
                    free(sentence);
                    return -1;
                }
                if (dl > 0u && dl <= 180u && wc <= 18u && dl < len &&
                    candidate_has_value_shape(sentence, direct) && !relation_phrase) {
                    pointer_ok = 1;
                    } else {
                        rr.pointer_rejected = 1;
                    }
                }
            }
            free(sentence);
        }
    }

    size_t used = 0;
    if (pointer_ok) {
        rr.used_pointer = 1;
        if (append_cstr(out, outcap, &used, "Resposta direta: ") ||
            append_cstr(out, outcap, &used, direct) ||
            append_cstr(out, outcap, &used, "\n\nEvidência no contexto: ")) {
            seterr(e, ec, "context answer buffer too small");
            return -1;
        }
    } else if (rich || complex) {
        const char *intro = cc > 1u ? "Com base no contexto, as evidências que cobrem a pergunta são:\n"
                                   : "Com base no contexto: ";
        if (append_cstr(out, outcap, &used, intro)) {
            seterr(e, ec, "context answer buffer too small");
            return -1;
        }
    }

    for (size_t j = 0; j < cc; j++) {
        Sent *s = &ss[chosen[j]];
        if ((rich || complex) && cc > 1u) {
            if (append_cstr(out, outcap, &used, "- ")) {
                seterr(e, ec, "context answer buffer too small");
                return -1;
            }
        }
        if (append(out, outcap, &used, context + s->start, s->end - s->start)) {
            seterr(e, ec, "context answer buffer too small");
            return -1;
        }
        if (j + 1u < cc) {
            if (append_cstr(out, outcap, &used, (rich || complex) ? "\n" : " ")) {
                seterr(e, ec, "context answer buffer too small");
                return -1;
            }
        }
    }

    if (result) *result = rr;
    return 0;
}

int nd_context_synthesize(const NDContextQA *qa, const char *question, const char *context, int rich,
                          char *out, size_t outcap, NDContextSynthesisResult *result,
                          char *e, size_t ec) {
    return nd_context_synthesize_ex(qa, NULL, question, context, rich, out, outcap, result, e, ec);
}
