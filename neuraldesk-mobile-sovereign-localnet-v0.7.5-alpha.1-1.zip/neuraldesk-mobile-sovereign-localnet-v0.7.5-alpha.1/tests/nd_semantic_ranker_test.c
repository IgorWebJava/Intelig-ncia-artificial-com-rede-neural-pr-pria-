#include "nd_semantic_ranker.h"
#include <math.h>
#include <stdio.h>
int main(int argc,char **argv){
 if(argc!=2){fprintf(stderr,"usage: %s MODEL\n",argv[0]);return 2;}
 NDSemanticRanker r;char e[256];
 if(nd_semantic_ranker_load(&r,argv[1],e,sizeof(e))){fprintf(stderr,"load: %s\n",e);return 1;}
 float good=nd_semantic_ranker_similarity(&r,"Para estimar fluxos ar-mar de calor sensíveis e latentes, qual método é utilizado?","Qual método pode ser usado para estimar os fluxos ar-mar de calor sensível e latente? O método de covariância turbulenta.");
 float bad=nd_semantic_ranker_similarity(&r,"Para estimar fluxos ar-mar de calor sensíveis e latentes, qual método é utilizado?","Quem escreveu Romeu e Julieta? William Shakespeare.");
 if(!isfinite(good)||!isfinite(bad)||good<=bad){fprintf(stderr,"semantic ranker ordering failed good=%f bad=%f\n",good,bad);nd_semantic_ranker_free(&r);return 1;}
 printf("SEMANTIC_RANKER_C PASS good=%f bad=%f margin=%f\n",good,bad,good-bad);
 nd_semantic_ranker_free(&r);return 0;
}
