package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.QcnnExecutionContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Plugin de Computação Hiperdimensional (Hyperdimensional Computing - HDC) v5.0.
 * Projeta o estado simbólico em um hipervetor ternário/bipolar de dimensão D=10.000 bits.
 * Implementa operações fundamentais de HDC: Binding (⊗), Bundling (⊕), Permutação (Π) e Similaridade de Cosseno em nanossegundos.
 */
class HyperdimensionalComputingPlugin(
    val dimension: Int = 10000
) : IQcnnPlugin {

    override val pluginId: String = "hyperdimensional_computing"
    override var isEnabled: Boolean = true

    // Dicionário de hipervetores ortogonais base por semente/conceito (determinístico)
    private val itemMemory = ConcurrentHashMap<String, IntArray>()

    init {
        for ((letra, info) in MatrizLetras.MATRIZ_22) {
            itemMemory[letra] = generateDeterministicHypervector(letra, info.gematria)
        }
    }

    fun getOrCreateVector(symbol: String): IntArray {
        return itemMemory.computeIfAbsent(symbol) {
            generateDeterministicHypervector(it, it.length)
        }
    }

    private fun generateDeterministicHypervector(symbol: String, seedModifier: Int): IntArray {
        val vec = IntArray(dimension)
        var seed = symbol.hashCode().toLong() * 31 + seedModifier * 1337L
        for (i in 0 until dimension) {
            // LCG determinístico leve e ultra-rápido
            seed = (seed * 6364136223846793005L + 1442695040888963407L)
            vec[i] = if ((seed and 1L) == 1L) 1 else -1
        }
        return vec
    }

    /**
     * Operação de Binding (⊗): Multiplicação element-wise de hipervetores bipolares.
     */
    fun bind(v1: IntArray, v2: IntArray): IntArray {
        val out = IntArray(dimension)
        for (i in 0 until dimension) {
            out[i] = v1[i] * v2[i]
        }
        return out
    }

    /**
     * Operação de Bundling (⊕): Superposição por votação majoritária.
     */
    fun bundle(vectors: List<IntArray>): IntArray {
        if (vectors.isEmpty()) return IntArray(dimension)
        val sum = IntArray(dimension)
        for (vec in vectors) {
            for (i in 0 until dimension) {
                sum[i] += vec[i]
            }
        }
        val out = IntArray(dimension)
        for (i in 0 until dimension) {
            out[i] = if (sum[i] >= 0) 1 else -1
        }
        return out
    }

    /**
     * Operação de Permutação Cíclica (Π): Rotação para preservação de ordem genealógica e sintática.
     */
    fun permute(v: IntArray, shift: Int = 1): IntArray {
        val out = IntArray(dimension)
        val s = ((shift % dimension) + dimension) % dimension
        for (i in 0 until dimension) {
            out[(i + s) % dimension] = v[i]
        }
        return out
    }

    /**
     * Medição de Similaridade de Cosseno entre Hipervetores.
     */
    fun cosineSimilarity(v1: IntArray, v2: IntArray): Double {
        var dot = 0
        for (i in 0 until dimension) {
            dot += v1[i] * v2[i]
        }
        return dot.toDouble() / dimension.toDouble()
    }

    /**
     * Distância de Hamming para vetores bipolares.
     */
    fun hammingDistance(v1: IntArray, v2: IntArray): Int {
        var diff = 0
        for (i in 0 until dimension) {
            if (v1[i] != v2[i]) diff++
        }
        return diff
    }

    /**
     * Raciocínio Analógico Hiperdimensional: D* = C ⊗ (B ⊗ A)
     */
    fun analogicalReasoning(a: String, b: String, c: String): Pair<String, Double> {
        val vA = getOrCreateVector(a)
        val vB = getOrCreateVector(b)
        val vC = getOrCreateVector(c)

        val relation = bind(vB, vA)
        val targetVec = bind(vC, relation)

        var bestSymbol = c
        var bestSim = -2.0
        for ((sym, vec) in itemMemory) {
            if (sym == a || sym == b || sym == c) continue
            val sim = cosineSimilarity(targetVec, vec)
            if (sim > bestSim) {
                bestSim = sim
                bestSymbol = sym
            }
        }
        return Pair(bestSymbol, Math.round(bestSim * 1000.0) / 1000.0)
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val targetSeed = context.targetSeed
        val baseVec = getOrCreateVector(targetSeed)

        val chainVectors = mutableListOf<IntArray>()
        chainVectors.add(baseVec)

        for ((idx, node) in context.chain.withIndex()) {
            val vec = getOrCreateVector(node)
            val permuted = permute(vec, idx + 1)
            chainVectors.add(permuted)
        }

        val compositeVector = bundle(chainVectors)

        // Calcula score de ressonância no hiper-espaço com o vetor raiz
        val resonanceScore = cosineSimilarity(compositeVector, baseVec)

        context.metadata["hdc_dimension"] = dimension
        context.metadata["hdc_resonance_score"] = (Math.round(resonanceScore * 1000.0) / 1000.0)
        context.metadata["hdc_dominant_symbol"] = targetSeed

        return context
    }
}
