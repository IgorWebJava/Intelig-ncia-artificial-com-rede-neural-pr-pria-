#ifndef ND_BENCHMARK_H
#define ND_BENCHMARK_H

#include <stddef.h>
#include "nd_resource.h"

#define ND_BENCHMARK_MAX_SAMPLES 128u

typedef enum {
    ND_BENCHMARK_COMPLETED = 0,
    ND_BENCHMARK_FAILED = 1,
    ND_BENCHMARK_INTERRUPTED = 2,
    ND_BENCHMARK_ABANDONED = 3
} NDBenchmarkStatus;

typedef struct {
    NDMobileProfile profile;
    NDBenchmarkStatus status;
    double latency_ms;
    double ttft_ms;
    double tokens_per_second;
} NDBenchmarkSample;

typedef struct {
    size_t min_samples;
    double max_p95_latency_ms;
    double max_p95_ttft_ms;
    double min_p50_tokens_per_second;
    double min_success_rate;
} NDBenchmarkScorecard;

typedef struct {
    size_t total;
    size_t completed;
    size_t failed;
    size_t interrupted;
    size_t abandoned;
    double success_rate;
    double latency_p50_ms;
    double latency_p95_ms;
    double latency_p99_ms;
    double ttft_p95_ms;
    double tokens_per_second_p50;
    int enough_samples;
    int within_thresholds;
    const char *certification;
} NDBenchmarkReport;

typedef struct {
    NDBenchmarkSample samples[ND_BENCHMARK_MAX_SAMPLES];
    size_t count;
} NDBenchmark;

void nd_benchmark_init(NDBenchmark *benchmark);
int nd_benchmark_add(NDBenchmark *benchmark, const NDBenchmarkSample *sample);
NDBenchmarkScorecard nd_benchmark_default_scorecard(void);
int nd_benchmark_evaluate(const NDBenchmark *benchmark, NDMobileProfile profile,
                          const NDBenchmarkScorecard *scorecard, NDBenchmarkReport *report);

#endif
