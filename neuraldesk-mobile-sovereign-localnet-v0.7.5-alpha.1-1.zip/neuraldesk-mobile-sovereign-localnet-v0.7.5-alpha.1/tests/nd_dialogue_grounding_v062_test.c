#include "nd_assistant.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int has(const char *s, const char *needle) {
    return s && needle && strstr(s, needle) != NULL;
}

static int need(const char *case_name, const char *out, const char *needle) {
    if (has(out, needle)) return 0;
    fprintf(stderr, "%s missing [%s] in [%s]\n", case_name, needle, out ? out : "<null>");
    return 1;
}

static int reject(const char *case_name, const char *out, const char *needle) {
    if (!has(out, needle)) return 0;
    fprintf(stderr, "%s unexpectedly contains [%s] in [%s]\n", case_name, needle, out);
    return 1;
}

int main(int argc, char **argv) {
    if (argc != 6) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION OPEN_SHARD\n", argv[0]);
        return 2;
    }

    const char *memory_path = "/tmp/neuraldesk-v062-dialogue-memory.ndm";
    remove(memory_path);
    NDAssistant a;
    NDAnswerMeta m;
    char err[256];
    char out[65536];
    int bad = 0;

    if (nd_assistant_load_ex(&a, argv[1], argv[2], argv[3], argv[4], argv[5],
                             memory_path, err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }

    if (nd_assistant_answer(&a,
                            "Lembre que o robô Aurora-3 usa sensor LiDAR e é coordenado por Renata.",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;

    if (nd_assistant_answer(&a, "Qual sensor o robô Aurora-3 usa?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("memory-sensor", out, "LiDAR");
    bad += reject("memory-sensor", out, "Resposta direta: Aurora-3 usa");

    if (nd_assistant_answer(&a, "Quem coordena o robô Aurora-3?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("memory-coordinator", out, "Renata");
    bad += reject("memory-coordinator", out, "Resposta direta: Aurora-3 usa");

    if (nd_assistant_answer(&a,
                            "Como funciona a ideia de RAG e por que separar recuperação de geração pode ser útil?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("rag-anchor", out, "Retrieval-Augmented Generation");
    bad += need("rag-anchor", out, "Separar recuperação de geração");
    bad += reject("rag-anchor", out, "O NeuralDesk usa a internet");

    if (nd_assistant_answer(&a,
                            "Se alguém disser que Transformer é sempre superior a RNN em qualquer tarefa, essa afirmação está correta?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("topic-shift", out, "depende");
    bad += reject("topic-shift", out, "internet");
    bad += reject("topic-shift", out, "Retrieval-Augmented");

    if (nd_assistant_answer(&a,
                            "Que método pode estimar as trocas de calor sensível e latente entre oceano e atmosfera?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("open-knowledge-setup", out, "covariância turbulenta");

    if (nd_assistant_answer(&a,
                            "E isso significa que qualquer método alternativo está necessariamente errado?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("non-entailment", out, "não prova");
    bad += need("non-entailment", out, "evidência");

    if (nd_assistant_answer(&a, "Resuma nossa conversa até aqui em duas frases.", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += need("bounded-summary", out, "Aurora-3");
    bad += need("bounded-summary", out, "RAG");
    bad += need("bounded-summary", out, "Transformer");
    bad += reject("bounded-summary", out, "Não sei com segurança");

    nd_assistant_free(&a);
    remove(memory_path);

    if (bad) {
        fprintf(stderr, "dialogue grounding v062 failures=%d\n", bad);
        return 1;
    }
    puts("dialogue_grounding_v062 PASS cases=7");
    return 0;
}
