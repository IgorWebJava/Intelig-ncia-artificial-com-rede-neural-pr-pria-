<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 94 — Transactional Outbox & Event Stream

Problem avoided:

```text
DB commit succeeds
but
event publish fails
```

Solution:

```text
BEGIN
  update authoritative state
  insert outbox event
COMMIT
```

A CDC/publisher later emits the event.

Event envelope should contain:

- event_id
- type
- aggregate_type
- aggregate_id
- version
- timestamp
- tenant/project scope
- trace_id
- payload
