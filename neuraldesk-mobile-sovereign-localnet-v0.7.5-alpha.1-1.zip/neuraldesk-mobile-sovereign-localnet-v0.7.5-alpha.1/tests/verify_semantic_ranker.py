#!/usr/bin/env python3
import hashlib,json,struct,subprocess
from pathlib import Path
r=Path('.')
report=json.loads((r/'evaluation/SEMANTIC_RANKER_REPORT.json').read_text())
p=r/report['asset']; data=p.read_bytes()
assert len(data)==524832==report['bytes']
assert hashlib.sha256(data).hexdigest()==report['sha256']
magic,ver,fd,ed,flags,res=struct.unpack('<8sIIIIQ',data[:32])
assert magic==b'NDSRANK1' and ver==1 and fd==1024 and ed==64 and flags==0 and res==0
assert report['parameters']==131200
assert report['combinedRatio']>=0.985
subprocess.run(['./build/nd_semantic_ranker_test',str(p)],check=True)
print(f"SEMANTIC_RANKER_VERIFY PASS {report['combinedPassed']}/{report['combinedTotal']} sha256={report['sha256']}")
