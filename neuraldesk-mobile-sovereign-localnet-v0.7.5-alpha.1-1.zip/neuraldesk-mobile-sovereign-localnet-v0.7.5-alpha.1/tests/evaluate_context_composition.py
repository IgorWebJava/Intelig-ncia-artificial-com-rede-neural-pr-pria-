#!/usr/bin/env python3
import json
import subprocess
from pathlib import Path

MODEL='models/neuraldesk-context-pointer-v0.5.ndqa'
RELATION='models/neuraldesk-relation-classifier-v0.5.ndrl'
SETS=[
 ('v03_regression','evaluation/fixtures/context_synthesis_regression.tsv',360),
 ('post_implementation_holdout','evaluation/fixtures/context_composition_holdout.tsv',640),
 ('v04_structured_text_and_distractors','evaluation/fixtures/context_v04_regression.tsv',6),
]
rows=[]
for name,path,total in SETS:
    p=subprocess.run(['./build/nd_context_batch',MODEL,path,RELATION],text=True,capture_output=True)
    assert p.returncode==0,(name,p.stdout,p.stderr)
    assert f'{total}/{total} PASS' in p.stdout,(name,p.stdout)
    rows.append({'name':name,'path':path,'passed':total,'total':total,'stdout':p.stdout.strip()})
report={'passed':sum(x['passed'] for x in rows),'total':sum(x['total'] for x in rows),'suites':rows}
Path('evaluation/CONTEXT_COMPOSITION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(f"context-composition PASS {report['passed']}/{report['total']}")
