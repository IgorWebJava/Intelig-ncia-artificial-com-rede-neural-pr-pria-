<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.preview-registry; current: docs/architecture/CURRENT_PREVIEW_REGISTRY.md -->
# Current Module Preview Registry

Every canonical module owns `preview/page-preview.png` and `preview/preview.json` under profile `module-preview-v1`. Preview metadata hashes canonical HTML/CSS/runtime so stale references can be detected. Current package contains 10 canonical previews.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
