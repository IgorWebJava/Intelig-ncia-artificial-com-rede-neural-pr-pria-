plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.neuraldesk.localnet"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.neuraldesk.localnet"
        minSdk = 26
        targetSdk = 36
        versionCode = 16
        versionName = "0.7.5-alpha.1"
        externalNativeBuild {
            cmake { cppFlags("") }
        }
    }

    // Single source of truth: runtime model assets live only in /models.
    sourceSets["main"].assets.srcDir("../../models")

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}
