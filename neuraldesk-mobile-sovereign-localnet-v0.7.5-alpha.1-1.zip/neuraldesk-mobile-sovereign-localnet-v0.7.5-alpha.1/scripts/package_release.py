#!/usr/bin/env python3
"""Create deterministic ZIP and revalidate the extracted deliverable by phased gates."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT.parent / f'{ROOT.name}.zip'
FIXED_TIME = (2026, 8, 24, 0, 0, 0)
VERIFY_PHASES = ['checkpoint','static','build','models','behavior','integration','final']
SANITIZE_PHASES = ['build','runtime','final']
PUBLIC_SUITE_MARKERS = {
    'verify': 'VERIFY PASS',
    'sanitize': 'SANITIZER PASS',
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def precheck() -> None:
    subprocess.run([sys.executable, str(ROOT/'scripts/pre_generation_lessons_check.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT/'tests/verify_cleanliness.py')], cwd=ROOT, check=True)


def digest(root: Path) -> str:
    return subprocess.check_output(
        [sys.executable, str(root/'scripts/verification_checkpoint.py'), 'digest'],
        cwd=root,
        text=True,
    ).strip()


def verify_sums(root: Path) -> None:
    sums = root/'SHA256SUMS'
    if not sums.is_file():
        raise RuntimeError('SHA256SUMS missing')
    for line in sums.read_text(encoding='utf-8').splitlines():
        expected, rel = line.split('  ', 1)
        path = root/rel
        if not path.is_file():
            raise RuntimeError(f'missing checksummed file: {rel}')
        got = sha256(path)
        if got != expected:
            raise RuntimeError(f'checksum mismatch: {rel}: {got} != {expected}')


def require_source_evidence(source_digest: str) -> tuple[str, dict]:
    manifest = json.loads((ROOT/'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))
    audit = json.loads((ROOT/'verification/AUDIT_STATUS.json').read_text(encoding='utf-8'))
    report = json.loads((ROOT/'verification/REPORT.json').read_text(encoding='utf-8'))
    version = manifest['version']
    if audit.get('sourceTreeInputDigestSha256') != source_digest:
        raise RuntimeError('AUDIT_STATUS source digest does not match current candidate')
    if report.get('verificationInputDigestSha256') != source_digest:
        raise RuntimeError('REPORT source digest does not match current candidate')
    if not audit.get('verifyMarkerObserved') or not audit.get('sanitizerMarkerObserved'):
        raise RuntimeError('source VERIFY/SANITIZER evidence is not complete')
    if report.get('version') != version or audit.get('version') != version:
        raise RuntimeError('source evidence version mismatch')
    return version, manifest


def make_zip(out: Path) -> None:
    files = sorted((p for p in ROOT.rglob('*') if p.is_file()), key=lambda p: p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            rel = Path(ROOT.name)/path.relative_to(ROOT)
            info = zipfile.ZipInfo(rel.as_posix(), FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (path.stat().st_mode & 0o777) << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(out, 'r') as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f'ZIP CRC failure: {bad}')


def run_phase(root: Path, suite: str, phase: str, state_dir: Path, log_path: Path, jobs: str) -> None:
    env = os.environ.copy()
    env['ND_VERIFY_STATE_DIR'] = str(state_dir)
    env['ND_BUILD_JOBS'] = jobs
    if suite == 'verify':
        env['ND_VERIFY_PHASE'] = phase
        cmd = ['bash', 'scripts/verify.sh']
    else:
        env['ND_SANITIZE_PHASE'] = phase
        cmd = ['bash', 'scripts/verify_sanitize.sh']
    with log_path.open('a', encoding='utf-8') as log:
        log.write(f'\n=== {suite} phase={phase} ===\n')
        log.flush()
        subprocess.run(cmd, cwd=root, env=env, check=True, stdout=log, stderr=subprocess.STDOUT)


def run_phased_suite(root: Path, suite: str, phases: list[str], state_dir: Path, log_path: Path, jobs: str) -> None:
    if log_path.exists():
        log_path.unlink()
    for phase in phases:
        run_phase(root, suite, phase, state_dir, log_path, jobs)
    text = log_path.read_text(encoding='utf-8', errors='replace')
    version = json.loads((root/'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))['version']
    try:
        public_marker = PUBLIC_SUITE_MARKERS[suite]
    except KeyError as exc:
        raise RuntimeError(f'unknown phased suite: {suite}') from exc
    marker = f'{public_marker} version={version}'
    if marker not in text:
        raise RuntimeError(f'extracted {suite} log lacks final marker {marker}')


def extract_with_modes(out: Path, target: Path) -> Path:
    with zipfile.ZipFile(out, 'r') as archive:
        archive.extractall(target)
        for info in archive.infolist():
            if info.is_dir():
                continue
            mode = (info.external_attr >> 16) & 0o777
            if mode:
                (target/info.filename).chmod(mode)
    return target/ROOT.name


def verify_extracted(out: Path, run_sanitizers: bool, jobs: str, source_digest: str) -> dict:
    with tempfile.TemporaryDirectory(prefix='nd-v062a1-package-') as td:
        target = Path(td)
        extracted = extract_with_modes(out, target)
        for rel in ['scripts/verify.sh','scripts/clean.sh','scripts/verify_sanitize.sh','scripts/verification_checkpoint.py']:
            if not os.access(extracted/rel, os.X_OK):
                raise RuntimeError(f'extracted executable mode missing: {rel}')
        verify_sums(extracted)
        extracted_digest = digest(extracted)
        if extracted_digest != source_digest:
            raise RuntimeError(f'extracted input digest mismatch: {extracted_digest} != {source_digest}')

        state_dir = target/'.verification-state'
        verify_log = target/'REEXTRACT_VERIFY.log'
        sanitize_log = target/'REEXTRACT_SANITIZER.log'
        run_phased_suite(extracted, 'verify', VERIFY_PHASES, state_dir, verify_log, jobs)
        if run_sanitizers:
            run_phased_suite(extracted, 'sanitize', SANITIZE_PHASES, state_dir, sanitize_log, jobs)

        subprocess.run(['bash','scripts/clean.sh'], cwd=extracted, check=True)
        subprocess.run([sys.executable,'tests/verify_cleanliness.py'], cwd=extracted, check=True)
        verify_sums(extracted)
        post_digest = digest(extracted)
        if post_digest != source_digest:
            raise RuntimeError(f'extracted post-test digest mismatch: {post_digest} != {source_digest}')
        return {
            'inputDigestSha256': extracted_digest,
            'postTestInputDigestSha256': post_digest,
            'verify': 'PASS',
            'sanitizer': 'PASS' if run_sanitizers else 'NOT_REQUESTED',
            'sha256SumsBeforeAndAfter': 'PASS',
            'cleanlinessAfterTests': 'PASS',
        }


def write_attestation(out: Path, version: str, source_digest: str, extracted_result: dict) -> Path:
    attestation = out.with_suffix(out.suffix + '.attestation.json')
    payload = {
        'project': 'NeuralDesk Mobile Sovereign LocalNet',
        'version': version,
        'releasePromotionAuthorized': extracted_result.get('verify') == 'PASS' and extracted_result.get('sanitizer') == 'PASS',
        'zip': {
            'path': out.name,
            'bytes': out.stat().st_size,
            'sha256': sha256(out),
            'crc': 'PASS',
            'fixedZipTimestamp': '2026-08-24T00:00:00',
        },
        'sourceInputDigestSha256': source_digest,
        'reextractedArtifact': extracted_result,
        'truthBoundary': {
            'androidPhysicalDeviceCertification': 'NOT_PERFORMED_IN_THIS_ENVIRONMENT',
            'apkAabPhysicalEvidence': 'NOT_CLAIMED',
        },
    }
    attestation.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return attestation


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=DEFAULT_OUT)
    parser.add_argument('--verify-extracted', action='store_true')
    parser.add_argument('--sanitize-extracted', action='store_true')
    parser.add_argument('--jobs', default=os.environ.get('ND_BUILD_JOBS', '2'))
    args = parser.parse_args()
    if not args.jobs.isdigit() or int(args.jobs) < 1:
        raise SystemExit('--jobs/ND_BUILD_JOBS must be a positive integer')

    precheck()
    verify_sums(ROOT)
    source_digest = digest(ROOT)
    version, _manifest = require_source_evidence(source_digest)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    if args.out.exists():
        args.out.unlink()
    make_zip(args.out)
    print(f'ZIP_CREATED {args.out} bytes={args.out.stat().st_size} sha256={sha256(args.out)}')

    if args.verify_extracted or args.sanitize_extracted:
        result = verify_extracted(
            args.out,
            run_sanitizers=args.sanitize_extracted,
            jobs=args.jobs,
            source_digest=source_digest,
        )
        if args.sanitize_extracted and result['sanitizer'] != 'PASS':
            raise RuntimeError('sanitizer was required but did not pass')
        print('ZIP_REEXTRACT_VERIFY PASS')
        attestation = write_attestation(args.out, version, source_digest, result)
        print(f'ATTESTATION_CREATED {attestation} sha256={sha256(attestation)}')


if __name__ == '__main__':
    main()
