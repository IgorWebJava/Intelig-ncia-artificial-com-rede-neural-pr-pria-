from pathlib import Path
import json, re, html as html_lib

class TestContext:
    def __init__(self, test_file):
        self.automated_dir = Path(test_file).resolve().parent
        self.tests_dir = self.automated_dir.parent
        self.module_root = self.tests_dir.parent
        self.project_root = self.module_root.parents[1]
        self.manifest = json.loads((self.module_root / "module.manifest.json").read_text(encoding="utf-8"))
        self.test_manifest = json.loads((self.tests_dir / "test.manifest.json").read_text(encoding="utf-8"))
        self.compat = json.loads((self.module_root / "compatibility" / "matrix.json").read_text(encoding="utf-8"))
        self.ui_path = self.project_root / self.manifest["canonical_ui"]
        self.html = self.ui_path.read_text(encoding="utf-8", errors="ignore")
        css_files = list((self.module_root / "ui").glob("*.css"))
        self.css_path = css_files[0] if css_files else None
        self.css = self.css_path.read_text(encoding="utf-8", errors="ignore") if self.css_path else ""
        self.normalized_html = html_lib.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", self.html))).strip()

    def json_file(self, rel):
        return json.loads((self.tests_dir / rel).read_text(encoding="utf-8"))

    def root_alias_path(self):
        aliases = self.manifest.get("route_aliases", [])
        return self.project_root / aliases[0] if aliases else None
