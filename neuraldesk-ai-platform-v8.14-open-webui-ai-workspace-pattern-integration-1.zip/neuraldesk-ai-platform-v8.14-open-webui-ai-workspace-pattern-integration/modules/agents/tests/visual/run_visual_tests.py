#!/usr/bin/env python3
from pathlib import Path
import json, re, asyncio, sys, shutil

TESTS = Path(__file__).resolve().parents[1]
MODULE = TESTS.parent
ROOT = MODULE.parents[1]
manifest = json.loads((MODULE / "module.manifest.json").read_text(encoding="utf-8"))
test_manifest = json.loads((TESTS / "test.manifest.json").read_text(encoding="utf-8"))
viewports = json.loads((TESTS / "visual" / "viewport-matrix.json").read_text(encoding="utf-8"))["viewports"]

async def main():
    try:
        from playwright.async_api import async_playwright
    except Exception as exc:
        print("SKIP: Playwright unavailable:", exc)
        return 2

    chromium = shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
    html_path = ROOT / manifest["canonical_ui"]
    css_path = next((MODULE / "ui").glob("*.css"))
    html = html_path.read_text(encoding="utf-8")
    css = css_path.read_text(encoding="utf-8")
    js = (MODULE / 'ui' / 'runtime' / 'module-runtime.js').read_text(encoding='utf-8')
    rendered = re.sub(r'<link\b[^>]*href=["\'][^"\']+\.css["\'][^>]*>', '<style>'+css+'</style>', html, flags=re.I)
    rendered = re.sub(r'<script\b[^>]*src=["\']runtime/module-runtime\.js["\'][^>]*></script>', '<script>'+js+'</script>', rendered, flags=re.I)

    errors = []
    checks = 0
    async with async_playwright() as p:
        kwargs = {"headless": True, "args": ["--no-sandbox","--disable-dev-shm-usage"]}
        if chromium:
            kwargs["executable_path"] = chromium
        browser = await p.chromium.launch(**kwargs)
        for profile, cfg in viewports.items():
            page = await browser.new_page(viewport={"width":cfg["width"],"height":cfg["height"]})
            await page.set_content(rendered, wait_until="domcontentloaded")
            await page.wait_for_timeout(25)
            metrics = await page.evaluate("""() => ({
                scrollWidth: document.documentElement.scrollWidth,
                clientWidth: document.documentElement.clientWidth,
                bodyText: document.body.innerText.trim().length
            })""")
            checks += 1
            if metrics["scrollWidth"] > metrics["clientWidth"] + 4:
                errors.append(f"{profile}: horizontal overflow")
            if metrics["bodyText"] == 0:
                errors.append(f"{profile}: empty body")

            # Validate all declared anchor/ID mechanics are present and renderable.
            for item in test_manifest["ui_assertions"]["required_ids"]:
                loc = page.locator("#" + item)
                if await loc.count() == 0:
                    errors.append(f"{profile}: missing #{item}")
                    continue
                checks += 1

            if MODULE.name == "chat" and profile == "phone":
                display = await page.locator(".composer-attachments").evaluate("(el) => getComputedStyle(el).display") if await page.locator(".composer-attachments").count() else None
                checks += 1
                if display == "none":
                    errors.append("phone: multimodal attachments hidden")

            if profile == "notebook":
                bridge_btn = page.locator('[data-action="open-engine-bridge"]').first
                checks += 1
                if await bridge_btn.count() == 0:
                    errors.append("notebook: Engine Bridge trigger missing")
                else:
                    await bridge_btn.click()
                    await page.wait_for_timeout(20)
                    overlay = page.locator('[data-overlay="engine-bridge"]')
                    checks += 1
                    if await overlay.count() == 0 or not await overlay.is_visible():
                        errors.append("notebook: Engine Bridge overlay did not open")
                    else:
                        checks += 1
                        text=(await overlay.inner_text()).lower()
                        if "documentation_only / not_implemented" not in text:
                            errors.append("notebook: Engine Bridge truth boundary missing")
                        sim=overlay.locator('[data-action="engine-simulate"]').first
                        checks += 1
                        if await sim.count():
                            await sim.click(); await page.wait_for_timeout(10)
                            status=(await overlay.locator('[data-engine-bridge-status]').inner_text()).lower()
                            if "preview" not in status:
                                errors.append("notebook: Engine Bridge local simulation status missing")
                        close=overlay.locator('[data-action="close-overlays"]').first
                        if await close.count(): await close.click(); await page.wait_for_timeout(10)
                        checks += 1
                        if await overlay.is_visible(): errors.append("notebook: Engine Bridge overlay did not close")

            await page.close()
        await browser.close()

    result = {"module":manifest["module_id"],"checks":checks,"errors":errors,"status":"fail" if errors else "pass"}
    (TESTS / "reports").mkdir(exist_ok=True)
    (TESTS / "reports" / "visual-result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"{manifest['module_id']}: visual checks={checks} errors={len(errors)}")
    for err in errors:
        print("ERROR:", err)
    return 1 if errors else 0

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
