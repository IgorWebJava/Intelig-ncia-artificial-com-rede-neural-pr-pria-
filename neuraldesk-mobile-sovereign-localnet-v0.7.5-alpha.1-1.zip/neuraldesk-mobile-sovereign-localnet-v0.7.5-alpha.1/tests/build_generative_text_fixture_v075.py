#!/usr/bin/env python3
import argparse, struct, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PRE=ROOT/'scripts/pre_generation_lessons_check.py'
V=512;D=320;L=10;K=64;F=896;PARAMS=11229760;H=128;TARGET=328
FNV_OFFSET=1469598103934665603;FNV_PRIME=1099511628211

def fnv_update(h,b):
 for x in b: h=((h^x)*FNV_PRIME)&0xffffffffffffffff
 return h

def emit_floats(f, values, h):
 for value in values:
  b=struct.pack('<f',value);f.write(b);h=fnv_update(h,b)
 return h

def zeros(f,n,h):
 chunk=struct.pack('<f',0.0)*4096
 while n:
  k=min(n,4096);b=chunk[:k*4];f.write(b);h=fnv_update(h,b);n-=k
 return h

def main():
 subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);payload=out.with_suffix('.payload.tmp')
 h=FNV_OFFSET;count=0
 with payload.open('wb') as f:
  # embedding: only TARGET has first dimension = 1, all other embeddings zero
  for t in range(V):
   vals=[0.0]*D
   if t==TARGET: vals[0]=1.0
   h=emit_floats(f,vals,h);count+=D
  for _ in range(L):
   h=emit_floats(f,[1.0]*D,h);count+=D
   for n in (D*D,K*D,K*D,D*D): h=zeros(f,n,h);count+=n
   h=emit_floats(f,[1.0]*D,h);count+=D
   for n in (F*D,D*F,F*D): h=zeros(f,n,h);count+=n
  h=emit_floats(f,[1.0]*D,h);count+=D
 if count!=PARAMS: raise SystemExit((count,PARAMS))
 payload_bytes=payload.stat().st_size
 header=bytearray(H);header[:8]=b'NDGMV005'
 vals=[H,0x01020304,1,V,D,L,10,2,F,256,PARAMS,payload_bytes]
 for i,v in enumerate(vals):struct.pack_into('<I',header,8+i*4,v)
 struct.pack_into('<f',header,56,0.0);struct.pack_into('<I',header,60,0);struct.pack_into('<Q',header,64,h);struct.pack_into('<I',header,72,0);struct.pack_into('<I',header,76,payload_bytes)
 with out.open('wb') as dst, payload.open('rb') as src:
  dst.write(header)
  for b in iter(lambda:src.read(1<<20),b''):dst.write(b)
 payload.unlink()
 print(f'TEXT_STREAM_FIXTURE PASS token={TARGET} bytes={out.stat().st_size} fnv={h:016x}')
if __name__=='__main__':main()
