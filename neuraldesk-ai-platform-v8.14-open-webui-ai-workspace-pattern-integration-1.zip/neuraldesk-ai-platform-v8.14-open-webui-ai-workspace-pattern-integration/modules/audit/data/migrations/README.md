<!-- neuraldesk-documentation-sync: V8.8 -->

# System Audit, Trace & Control Center migrations

Only this module owns migrations for its private data schema.
