#ifndef ND_SAFETY_H
#define ND_SAFETY_H

#include <stddef.h>

typedef enum {
    ND_SAFETY_ALLOW = 0,
    ND_SAFETY_BLOCK_PROMPT_INJECTION = 1,
    ND_SAFETY_BLOCK_SECRET_EXFILTRATION = 2,
    ND_SAFETY_BLOCK_EXTERNAL_AI_BYPASS = 3,
    ND_SAFETY_BLOCK_RESOURCE_ABUSE = 4,
    ND_SAFETY_BLOCK_OUTPUT_SECRET = 5
} NDSafetyDecision;

NDSafetyDecision nd_safety_prompt_check(const char *prompt);
NDSafetyDecision nd_safety_output_check(const char *output);
const char *nd_safety_reason(NDSafetyDecision decision);

#endif
