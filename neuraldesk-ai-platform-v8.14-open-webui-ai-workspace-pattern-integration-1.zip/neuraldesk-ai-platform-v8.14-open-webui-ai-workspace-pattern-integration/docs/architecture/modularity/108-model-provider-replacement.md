<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 108 — Model/Provider Replacement

Modules request profiles/capabilities instead of provider model names.

A provider/model change must pass:

- capability validation;
- golden dataset evaluation;
- safety;
- tool calling tests;
- multimodal tests;
- shadow traffic;
- canary;
- rollback readiness.
