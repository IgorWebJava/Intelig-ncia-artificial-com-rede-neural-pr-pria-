<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# OpenAPI / AsyncAPI / JSON Schema

    Skill ID: `neuraldesk.contract-engineering.v1`

    ## Category

    `contracts`

    ## Introduced

    `V7.0`

    ## Required development capabilities

    - `openapi.author.v1`
- `asyncapi.author.v1`
- `jsonschema.author-validate.v1`
- `contract.registry.manage.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/<module>/contracts/`
- `contracts/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
