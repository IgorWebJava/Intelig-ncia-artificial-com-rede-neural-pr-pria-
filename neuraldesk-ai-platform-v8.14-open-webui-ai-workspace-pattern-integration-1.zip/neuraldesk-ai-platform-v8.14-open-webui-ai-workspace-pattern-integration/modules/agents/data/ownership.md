<!-- neuraldesk-documentation-sync: V8.8 -->

# Data Ownership — neuraldesk.agents

## Owned mutable data

- `agent_definitions`
- `agent_versions`
- `agent_templates`
- `agent_skill_bindings`
- `agent_tool_bindings`
- `agent_knowledge_bindings`
- `agent_memory_policies`
- `agent_handoff_bindings`
- `agent_teams`
- `agent_team_members`
- `agent_workflows`
- `agent_tasks`
- `agent_evaluations`
- `agent_deployments`
- `agent_run_metadata`

## External references (not privately owned)

- `project_id` → Project Registry / `platform.projects`
- `tool_id` → Tool Catalog
- `knowledge_collection_id` → Knowledge module
- `model_profile_id` → AI Capability Fabric / Config
- runtime `skill_id` → Agent Skill Registry

Other modules **must not** read or write `mod_agents` private tables directly. Integration uses versioned APIs/capabilities/events.
