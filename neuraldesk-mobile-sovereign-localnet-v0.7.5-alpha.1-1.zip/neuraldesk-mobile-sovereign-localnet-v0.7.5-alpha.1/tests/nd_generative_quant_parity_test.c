#include "nd_generative.h"
#include <stdint.h>
#include <stdio.h>
static uint32_t top(const float*x){uint32_t b=0,i;for(i=1;i<ND_GEN_VOCAB;i++)if(x[i]>x[b])b=i;return b;}
int main(int argc,char**argv){NDGenerativeModel *f=NULL,*q8=NULL,*q4=NULL;unsigned ok8=0,ok4=0,i;if(argc!=4)return 2;if(nd_gen_load(argv[1],&f)||nd_gen_load(argv[2],&q8)||nd_gen_load(argv[3],&q4))return 3;for(i=0;i<20;i++){uint32_t p[2]={(uint32_t)(20+i),(uint32_t)(300+i)};float a[ND_GEN_VOCAB],b[ND_GEN_VOCAB],c[ND_GEN_VOCAB];if(nd_gen_full_forward(f,p,2,a,ND_GEN_VOCAB)||nd_gen_full_forward(q8,p,2,b,ND_GEN_VOCAB)||nd_gen_full_forward(q4,p,2,c,ND_GEN_VOCAB))return 4;if(top(a)==top(b))ok8++;if(top(a)==top(c))ok4++;}printf("GENERATIVE_QUANT_PARITY q8=%u/20 q4=%u/20 q8Floor=18 q4Floor=15\n",ok8,ok4);nd_gen_free(f);nd_gen_free(q8);nd_gen_free(q4);return(ok8>=18&&ok4>=15)?0:5;}
