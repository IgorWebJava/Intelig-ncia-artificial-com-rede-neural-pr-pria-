package com.example.engine.plugins

import android.content.Context
import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import org.json.JSONObject
import java.io.File

/**
 * Módulo 12 & 9: Gerenciador de Contexto, Cristalização de Memória e Eco Harmônico (KODEX ALEPH v12.5).
 */
class ContextCrystallizerPlugin(private val androidContext: Context) : IQcnnPlugin {
    override val pluginId: String = "context_crystallizer"
    override var isEnabled: Boolean = true

    private val ecoFrequencias = mutableListOf<Double>()
    private val memoriaCristalizada = mutableMapOf<String, String>()
    private val arquivoMemoria: File by lazy {
        File(androidContext.filesDir, "inconsciente.dat")
    }

    init {
        carregarMemoria()
    }

    private fun carregarMemoria() {
        try {
            if (arquivoMemoria.exists()) {
                val jsonStr = arquivoMemoria.readText(Charsets.UTF_8)
                val obj = JSONObject(jsonStr)
                for (k in obj.keys()) {
                    memoriaCristalizada[k.lowercase()] = obj.optString(k, "")
                }
            }
        } catch (_: Exception) { }
    }

    fun cristalizar(chave: String, valor: String) {
        memoriaCristalizada[chave.lowercase()] = valor
        try {
            val obj = JSONObject()
            for ((k, v) in memoriaCristalizada) {
                obj.put(k, v)
            }
            arquivoMemoria.writeText(obj.toString(2), Charsets.UTF_8)
        } catch (_: Exception) { }
    }

    fun atualizarEco(hz: Double) {
        if (hz > 0) {
            ecoFrequencias.add(hz)
            if (ecoFrequencias.size > 3) {
                ecoFrequencias.removeAt(0)
            }
        }
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val promptLower = context.prompt.lowercase()

        // 1. Detecção automática de nome / identidade
        val regexNome = Regex("meu nome [eé]\\s+([a-zA-ZÀ-ÿ]+)")
        val match = regexNome.find(promptLower)
        if (match != null) {
            val nome = match.groupValues[1].replaceFirstChar { it.uppercase() }
            cristalizar("nome_usuario", nome)
            context.metadata["cristalizacao"] = "Identidade registrada: $nome"
        }

        // 2. Consulta a memórias cristalizadas
        val memoriasInjetadas = mutableListOf<String>()
        for ((k, v) in memoriaCristalizada) {
            if (promptLower.contains("lembra") || promptLower.contains("quem sou") || promptLower.contains("meu nome") || promptLower.contains(k)) {
                memoriasInjetadas.add("[MEMÓRIA CRISTALIZADA: ${k.uppercase()}] = $v")
            }
        }

        // 3. Eco harmônico residual
        if (ecoFrequencias.isNotEmpty()) {
            val mediaEco = ecoFrequencias.average()
            context.metadata["eco_frequencia_residual"] = (mediaEco * 100).toInt() / 100.0
        }

        if (memoriasInjetadas.isNotEmpty()) {
            val prefixo = memoriasInjetadas.joinToString("<br>")
            if (context.customResponse.isNotEmpty()) {
                context.customResponse = "$prefixo<br><br>${context.customResponse}"
            } else {
                context.customResponse = prefixo
            }
        }

        if (context.totalFrequencyHz > 0) {
            atualizarEco(context.totalFrequencyHz)
        }

        return context
    }
}
