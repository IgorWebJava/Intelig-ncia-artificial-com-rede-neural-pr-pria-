<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Module Dependency Matrix — Current V7.5

| Module | Provides | Requires |
|---|---|---|
| `neuraldesk.agents` | `agents.catalog.v1`<br>`agents.definition.v1`<br>`agents.version.v1`<br>`agents.run.v1`<br>`agents.team.v1`<br>`agents.handoff.v1`<br>`agents.workflow.v1`<br>`agents.skill.bind.v1`<br>`agents.template.v1`<br>`agents.evaluate.v1` | `project.manage.v1`<br>`agent.skill.catalog.v1`<br>`agent.skill.create.v1`<br>`agent.skill.version.v1`<br>`ai.execute.v1`<br>`tools.catalog.v1`<br>`tools.execute.v1`<br>`knowledge.retrieve.v1`<br>`training.evaluate.v1`<br>`media.asset.v1`<br>`approval.request.v1`<br>`config.resolve.v1`<br>`audit.write.v1`<br>`telemetry.emit.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.app-shell` | `navigation.route.resolve.v1`<br>`module.launch.v1` | `module.registry.v1`<br>`capability.registry.v1`<br>`config.resolve.v1`<br>`audit.write.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.audit` | `audit.write.v1`<br>`audit.query.v1`<br>`trace.query.v1` | `telemetry.query.v1`<br>`config.resolve.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.chat` | `chat.conversation.v1`<br>`chat.message.v1`<br>`chat.multimodal.compose.v1` | `ai.execute.v1`<br>`knowledge.retrieve.v1`<br>`tools.execute.v1`<br>`media.asset.v1`<br>`config.resolve.v1`<br>`audit.write.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.knowledge` | `knowledge.retrieve.v1`<br>`knowledge.document.v1`<br>`knowledge.search.v1` | `ai.embedding.create.v1`<br>`ai.rerank.v1`<br>`media.asset.v1`<br>`config.resolve.v1`<br>`audit.write.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.operations` | `operations.readmodel.v1`<br>`observability.dashboard.v1` | `audit.query.v1`<br>`telemetry.query.v1`<br>`config.resolve.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.settings` | `preferences.user.v1` | `config.resolve.v1`<br>`audit.write.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.system-config` | `config.resolve.v1`<br>`module.registry.v1`<br>`capability.registry.v1`<br>`feature.flags.v1` | `audit.write.v1`<br>`secrets.reference.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.tools` | `tools.execute.v1`<br>`tools.catalog.v1`<br>`approval.request.v1` | `config.resolve.v1`<br>`audit.write.v1`<br>`secrets.reference.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
| `neuraldesk.training` | `training.dataset.v1`<br>`training.evaluate.v1`<br>`model.registry.v1` | `ai.execute.v1`<br>`ai.evaluate.v1`<br>`media.asset.v1`<br>`config.resolve.v1`<br>`audit.write.v1`<br>`ui.adaptive.v1`<br>`ui.multimodal.surface.v1` |
