# Neural Engine GitHub Ray-X — V8.5

## Scope
Primary-source GitHub research performed on 18 August 2026. This report informs documentation only; no engine code has been implemented.

## Research corpus
- repositories reviewed/registered: **28**
- future engine modules after synthesis: **64**
- future engine capabilities: **218**

## Strong patterns found
- serving: paged KV, continuous/in-flight batching, prefix reuse, chunked prefill, speculative decoding and disaggregated serving;
- training: FSDP/HSDP/TP/PP/CP/EP, ZeRO-style sharding, optimized attention/fused kernels and distributed checkpointing;
- architecture: dense Transformer baseline, MoE, efficient/latent/sparse attention, hybrid state-space research, multimodal fusion;
- data: large-scale filtering/dedup/provenance/multimodal curation and tokenizer efficiency;
- post-training: SFT, DPO/preference methods, GRPO/RLOO/RL tracks, PEFT/adapters and distillation;
- evaluation: benchmark diversity, product golden sets, long-context/multimodal/agent eval and red teaming.

## Architectural response
NeuralDesk does not pick one GitHub framework as its architecture. Stable capabilities own semantics; frameworks/kernels are candidate providers. `neural-engine/governance/RESEARCH_ADOPTION_GATES.md` is mandatory before future adoption.
