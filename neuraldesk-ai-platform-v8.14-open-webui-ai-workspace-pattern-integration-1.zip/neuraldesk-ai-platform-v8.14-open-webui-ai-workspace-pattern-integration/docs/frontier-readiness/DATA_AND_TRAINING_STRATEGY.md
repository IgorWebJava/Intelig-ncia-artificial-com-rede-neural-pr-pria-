# Data and Training Strategy

Future model quality depends heavily on data quality.

Program:
1. acquisition and legal provenance;
2. normalization;
3. deduplication;
4. quality filtering;
5. safety filtering;
6. contamination checks;
7. multimodal alignment;
8. dataset versioning;
9. tokenizer evaluation;
10. train/eval isolation;
11. synthetic-data governance;
12. continual refresh.

Every dataset must record source, license/permission, transformations, checksums, quality metrics and evaluation contamination status.
