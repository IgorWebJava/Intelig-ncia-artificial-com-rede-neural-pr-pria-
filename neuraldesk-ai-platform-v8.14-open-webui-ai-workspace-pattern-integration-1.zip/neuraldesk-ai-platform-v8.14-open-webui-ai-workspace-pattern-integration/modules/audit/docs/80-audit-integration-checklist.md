<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 80 — Audit Integration Checklist

## Event Platform
- [ ] event schema
- [ ] correlation IDs
- [ ] trace/span IDs
- [ ] actor identity
- [ ] resource identity
- [ ] risk/severity
- [ ] before/after
- [ ] result

## Security
- [ ] redaction
- [ ] secret filtering
- [ ] immutable store
- [ ] integrity checks
- [ ] tamper detection
- [ ] retention policy

## Console
- [ ] read-only query mode
- [ ] RBAC
- [ ] admin action workflow
- [ ] approval
- [ ] self-auditing

## Domains
- [ ] chat
- [ ] knowledge
- [ ] tools
- [ ] training
- [ ] models
- [ ] settings
- [ ] system changes

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
