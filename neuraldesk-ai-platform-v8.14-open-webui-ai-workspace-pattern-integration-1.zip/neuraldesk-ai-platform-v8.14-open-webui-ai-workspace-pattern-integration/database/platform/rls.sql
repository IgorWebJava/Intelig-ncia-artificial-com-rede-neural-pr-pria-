-- NeuralDesk V6.9 — RLS starter policies
-- Application services must set app.tenant_id / app.workspace_id / app.project_id
-- after authenticating and authorizing the request.

ALTER TABLE configuration.system_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS system_config_scope_read ON configuration.system_config;
CREATE POLICY system_config_scope_read ON configuration.system_config
FOR SELECT
USING (
    scope_type IN ('global','environment','module')
    OR (
        scope_type = 'tenant'
        AND scope_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid
    )
    OR (
        scope_type = 'workspace'
        AND scope_id = NULLIF(current_setting('app.workspace_id', true),'')::uuid
    )
    OR (
        scope_type = 'project'
        AND scope_id = NULLIF(current_setting('app.project_id', true),'')::uuid
    )
);

-- Writes should normally be performed by a dedicated application role
-- after application-layer authorization. Add role-specific write policies
-- during backend implementation rather than granting browser access.
