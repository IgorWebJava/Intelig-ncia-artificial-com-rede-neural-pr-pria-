import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class CompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestContext(__file__)

    def test_n_minus_one_policy_declared(self):
        self.assertIn("N-1", self.ctx.manifest["compatibility"]["supported_contract_policy"])

    def test_replacement_gates_complete(self):
        required = self.ctx.test_manifest["replacement"]["required_gates"]
        actual = self.ctx.compat["replacement_gates"]
        for gate in required:
            with self.subTest(gate=gate):
                self.assertIn(gate, actual)

    def test_test_suite_travels_with_module(self):
        testing = self.ctx.manifest.get("testing", {})
        self.assertEqual(testing.get("profile"), "module-quality-v2")
        self.assertEqual(testing.get("root"), "tests/")
        self.assertTrue((self.ctx.module_root / testing["runner"]).exists())

if __name__ == "__main__":
    unittest.main()
