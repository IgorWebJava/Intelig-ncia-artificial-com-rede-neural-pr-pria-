import sys, unittest, re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class SecurityDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestContext(__file__)

    def test_no_direct_database_connection_in_ui(self):
        patterns = [r"postgres(?:ql)?://", r"\bhost\s*=", r"\bpassword\s*=", r"\bdbname\s*="]
        for pattern in patterns:
            with self.subTest(pattern=pattern):
                self.assertIsNone(re.search(pattern, self.ctx.html, re.I))

    def test_no_obvious_plaintext_secret_assignments(self):
        patterns = [r"api[_-]?key\s*[:=]\s*['\"][^'\"]+", r"access[_-]?token\s*[:=]\s*['\"][^'\"]+"]
        for pattern in patterns:
            with self.subTest(pattern=pattern):
                self.assertIsNone(re.search(pattern, self.ctx.html, re.I))

    def test_data_ownership_invariant_documented(self):
        ownership = (self.ctx.module_root / "data/ownership.md").read_text(encoding="utf-8").lower()
        self.assertIn("must not", ownership)
        self.assertIn("private tables", ownership)

    def test_permissions_default_deny(self):
        perms = self.ctx.json_file("../contracts/permissions.json") if False else None
        import json
        data = json.loads((self.ctx.module_root / "contracts/permissions.json").read_text(encoding="utf-8"))
        self.assertEqual(data.get("default_policy"), "deny-unless-authorized")

if __name__ == "__main__":
    unittest.main()
