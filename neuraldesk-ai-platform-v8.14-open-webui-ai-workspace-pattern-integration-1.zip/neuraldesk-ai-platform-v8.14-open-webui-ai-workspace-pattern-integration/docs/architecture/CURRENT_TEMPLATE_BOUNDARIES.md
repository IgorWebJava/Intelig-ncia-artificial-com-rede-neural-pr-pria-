<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.governance; current: docs/architecture/CURRENT_TEMPLATE_BOUNDARIES.md -->
# Current Template Boundaries

## Implemented in browser template

HTML/CSS/module-owned JavaScript interactions, responsive behavior, visual states, local demo state, previews, tests, docs and contracts.

## Not implemented as production services

AI/model inference, real agent/tool execution, persistent project/agent memory, PostgreSQL mutations from browser, event delivery, background task infrastructure, external side effects, real deployments/canaries and continuous microphone capture.

Every module/AI handoff must preserve this distinction.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
