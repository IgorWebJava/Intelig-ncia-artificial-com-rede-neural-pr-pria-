#!/usr/bin/env python3
"""Materialize canonical training/evaluation inputs used by v0.5."""
import json
from pathlib import Path

import context_data
import train_knowledge_retriever as retriever

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "training" / "data"


def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in rows), encoding="utf-8")



def require_lessons_precheck() -> None:
    import subprocess as _sp
    import sys as _sys
    from pathlib import Path as _Path
    _root = _Path(__file__).resolve().parents[1]
    _sp.run([_sys.executable, str(_root / "scripts" / "pre_generation_lessons_check.py")], cwd=_root, check=True)

def main() -> None:
    require_lessons_precheck()
    DATA.mkdir(parents=True, exist_ok=True)
    context_train, context_golden = context_data.build_context()
    knowledge_train, knowledge_golden = retriever.build_sets()

    write_jsonl(DATA / "context_pointer_train.jsonl", context_train)
    write_jsonl(DATA / "context_pointer_golden.jsonl", context_golden)
    (DATA / "knowledge_retriever_train.tsv").write_text(
        "".join(f"{label}\t{question}\n" for question, label in knowledge_train), encoding="utf-8"
    )
    (DATA / "knowledge_retriever_golden.tsv").write_text(
        "".join(f"{label}\t{question}\n" for question, label in knowledge_golden), encoding="utf-8"
    )
    print(
        "datasets PASS "
        f"retriever={len(knowledge_train)}/{len(knowledge_golden)} "
        f"pointer={len(context_train)}/{len(context_golden)}"
    )


if __name__ == "__main__":
    main()
