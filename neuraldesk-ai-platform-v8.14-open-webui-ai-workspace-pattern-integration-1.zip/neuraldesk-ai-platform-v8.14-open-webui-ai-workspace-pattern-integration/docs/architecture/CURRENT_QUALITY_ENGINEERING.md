<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.quality-engineering; current: docs/architecture/CURRENT_QUALITY_ENGINEERING.md -->
# Current Quality Engineering

Profile: `module-quality-v2`

Module-owned quality covers architecture, contracts/capabilities, UI semantics, runtime isolation, data/security static rules, responsive/multimodal behavior, browser visual checks, preview freshness, documentation/skills synchronization and Intelligence Experience V2 surfaces.

Backend/API/database/event/AI/tool scenarios remain labeled future integration/E2E until executable services exist.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
