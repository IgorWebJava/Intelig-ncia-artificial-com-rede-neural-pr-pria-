# Dialogue Grounding & Structured Memory — v0.6.2-alpha.1

## Objetivo

A v0.6.2 corrige falhas observadas em diálogo real após o freeze da v0.6.1 sem alterar os cinco assets neurais, os 543.094 parâmetros ou os datasets promovidos. O foco é ligar corretamente entidade, relação e valor; impedir herança falsa de tópico; preservar siglas explícitas durante retrieval; e manter histórico recente bounded para follow-up/resumo auditável.

## Memória estruturada derivada

A fonte persistente continua sendo o texto first-party do arquivo NDM1. Em load e após cada escrita, o runtime reconstrói deterministicamente um índice bounded de fatos `subject -> relation -> value`. Relações implementadas nesta candidata: `sensor`, `battery`, `coordinator`, `responsible`, `code` e `version`. O texto original permanece a evidência. Fatos conflitantes para o mesmo sujeito/relação falham de forma conservadora e não são escolhidos arbitrariamente.

Exemplo validado:

- evidência persistida: `o robô Aurora-3 usa sensor LiDAR e é coordenado por Renata`;
- `Qual sensor o robô Aurora-3 usa?` -> `LiDAR`;
- `Quem coordena o robô Aurora-3?` -> `Renata`;
- o mesmo resultado deve existir após save + reload, provando reconstrução do índice a partir dos bytes persistidos.

## Estado conversacional bounded

A instância mantém no máximo **8 turnos recentes** de pergunta/resposta em memória volátil. Isso não altera pesos, não é treinamento online e não é persistido como modelo. O histórico serve para:

- resolver follow-up curto quando não há novo tópico explícito;
- bloquear herança quando aparece acrônimo/entidade nova;
- produzir resumo determinístico dos turnos realmente registrados;
- responder conservadoramente a perguntas de implicação absoluta quando a evidência anterior não sustenta exclusividade.

## Retrieval com preservação de acrônimo

Um resultado neural aceito para uma consulta contendo sigla explícita precisa preservar a mesma sigla como **token integral** na pergunta/resposta do registro candidato. Se não preservar, a aceitação neural é anulada e o fallback sparse pode tentar recuperar um registro first-party compatível. Substring interna em palavra maior nunca conta como identidade de sigla.

Esse mecanismo corrige `RAG` sendo confundido com política de internet sem alterar os pesos do Retriever.

## Planner e herança

Herança de entidade permanece necessária para fragmentos como `quando será lançado?` em uma pergunta sobre `Atlas-900`. Porém objetivos já topicalmente autossuficientes, como `por que separar recuperação de geração?`, não recebem siglas de outro objetivo apenas porque aparecem na mesma pergunta.

## Gates

- `nd_dialogue_grounding_v062_test`: **7/7** alvo da candidata;
- `nd_conversational_correctness_test`: **12/12** herdado;
- `nd_memory_test`: valida facts antes/depois de reload;
- Live QA: **35/35** precisa permanecer verde;
- VERIFY/SANITIZER continuam obrigatórios antes de freeze.

## Limites

Esta versão ainda não adiciona decoder autoregressivo generativo, atenção longa, multimodalidade treinada ou aprendizagem online dos pesos. Resumo de conversa é determinístico e bounded; não é geração livre de linguagem.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
