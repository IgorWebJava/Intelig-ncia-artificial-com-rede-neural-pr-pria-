#ifndef ND_PLANNER_H
#define ND_PLANNER_H

#include <stddef.h>

#define ND_PLAN_MAX_GOALS 8u
#define ND_PLAN_GOAL_BYTES 1024u

typedef struct {
    char text[ND_PLAN_GOAL_BYTES];
} NDPlanGoal;

typedef struct {
    size_t goal_count;
    NDPlanGoal goals[ND_PLAN_MAX_GOALS];
} NDPlan;

int nd_plan_build(const char *question, NDPlan *plan, char *err, size_t errcap);

#endif
