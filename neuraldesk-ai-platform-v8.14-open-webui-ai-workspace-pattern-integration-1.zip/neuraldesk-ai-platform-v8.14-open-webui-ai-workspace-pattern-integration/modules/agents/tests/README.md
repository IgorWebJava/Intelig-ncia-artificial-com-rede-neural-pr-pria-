<!-- neuraldesk-documentation-sync: V8.11 -->

# Tests — Agent Projects & Multi-Agent Studio

Run: `python modules/agents/tests/run_module_tests.py`

Visual: `python modules/agents/tests/visual/run_visual_tests.py`

The suite covers architecture, contracts, UI semantics, security/data boundaries, responsive/multimodal UI, compatibility, fixtures, functional mechanics and future integration/replacement scenarios.


## Engine Bridge V8.11
Non-regression, truth-boundary and bridge-marker coverage is executable through `test_engine_bridge.py` plus `scenarios/engine-ui-bridge-v811.json`.
