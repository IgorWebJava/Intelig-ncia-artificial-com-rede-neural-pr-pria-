# NeuralDesk Project Memory — V8.11

## Current version model

```text
Package: V8.11
Visual/UI: V8.11
Architecture: V8.11
Documentation/Memory/Skills: V8.11
Neural Engine blueprint: V8.11 documentation only
Neural Engine executable code: NOT IMPLEMENTED
```

## Current facts

- 10 canonical UI modules.
- 106 current resolved platform/UI capabilities.
- 94 future Neural Engine modules / 391 engine capabilities.
- 149 traced UI mechanics.
- `cooperative-engine-bridge-v1` maps all engine modules to interface ownership.
- `preserve → extend → bridge` is mandatory.
- V8.8/V8.9/V8.10 research remains preserved as historical/reference material inside the current blueprint.

## Read order

`ESTADO_ATUAL.json` → `MEMORIA_MESTRE_PROJETO.md` → `LEIA_ANTES_DE_MODIFICAR.md` → `docs/CURRENT_STATE.md` → `docs/SOURCE_OF_TRUTH.md` → `habilidades/AI_HANDOFF.md`.
