<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# KDA + Attention Residual + LatentMoE Research Track

NeuralDesk adds three independent architecture experiments inspired by Kimi K3: recurrent/delta attention (KDA family), attention-based residual aggregation and Stable LatentMoE-style sparse scaling.

They are research candidates, not defaults. Each must be compared with dense Transformer, existing efficient-attention and generic MoE baselines across quality, long context, optimization stability, communication, memory, kernel maturity and serving cost.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
