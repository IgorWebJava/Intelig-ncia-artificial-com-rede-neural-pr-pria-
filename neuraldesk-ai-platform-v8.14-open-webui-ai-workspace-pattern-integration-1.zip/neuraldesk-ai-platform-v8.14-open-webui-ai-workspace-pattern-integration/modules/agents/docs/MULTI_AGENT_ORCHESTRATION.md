<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Multi-Agent Orchestration

Supported conceptual modes: supervisor + specialists, sequential, parallel, router, handoff, hierarchical and human checkpoint. Agent-as-tool returns a result to the caller; handoff transfers control to another agent. Private chain-of-thought is never exposed.
