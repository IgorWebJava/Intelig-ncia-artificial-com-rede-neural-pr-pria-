# Frontier Program Risk Register

| Risk | Impact | Mitigation |
|---|---|---|
| Architecture overengineering | Slow delivery | Implement by dependency waves |
| Training-model ambition too early | Massive cost | External model first, own specialized models later |
| Multi-agent complexity | Cost/latency/failures | Compare to simpler baselines |
| Tool/computer-use side effects | Security loss | Policy, approval, sandbox, least privilege |
| Memory hallucination/staleness | Wrong decisions | Provenance, retention, invalidation, user controls |
| RAG source contamination | Incorrect answers | source quality/citation validation |
| Provider lock-in | Strategic dependency | capability-first adapters |
| GPU/serving cost | Economic failure | cost per successful task gates |
| Benchmark gaming | False confidence | hidden/rotating eval sets + production metrics |
| Data licensing/privacy | Legal/ethical risk | dataset provenance/governance |
| Model regression | Product damage | shadow/canary/rollback |
| Documentation drift | Implementation mismatch | current-state precedence + readiness registries |
