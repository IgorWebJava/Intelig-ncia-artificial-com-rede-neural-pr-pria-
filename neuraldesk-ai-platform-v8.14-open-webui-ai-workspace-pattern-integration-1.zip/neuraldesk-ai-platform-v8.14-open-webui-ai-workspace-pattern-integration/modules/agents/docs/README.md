<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.agents; current: modules/agents/docs/README.md -->
# Agent Projects & Multi-Agent Studio — Documentation

Canonical UI: `modules/agents/ui/agents.html`


This folder is the canonical module documentation set for `neuraldesk.agents`.

Start with:

1. `CURRENT_STATE.md`
2. `MECHANICS_AND_FUNCTIONALITY.md`
3. `AI_MODULE_HANDOFF.md`
4. `MODULE_ARCHITECTURE.md`
5. `CONTRACTS_AND_CAPABILITIES.md`
6. `DATA_OWNERSHIP_AND_CONSISTENCY.md`
7. `TESTING_AND_QUALITY.md`

Files not explicitly marked CURRENT may be detailed reference/baseline material; `CURRENT_STATE.md` and the module manifest prevail on conflicts.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
