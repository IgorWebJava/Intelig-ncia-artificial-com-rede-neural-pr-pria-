# NeuralDesk — Current State (V8.14)

## Version model
- Package/UI/Architecture/Documentation/Memory/Skills: **V8.14**
- Experience: `intelligence-experience-v2`
- Runtime: `workspace-runtime-v2`
- Cooperative bridge: `cooperative-engine-bridge-v1`
- Agent Platform: `agent-platform-patterns-v1`
- Coding Intelligence: `coding-intelligence-patterns-v1`
- AI Workspace Platform: `open-webui-ai-workspace-patterns-v1`
- Neural Engine code: **NOT_IMPLEMENTED**

## Current scope
- Canonical UI modules: 10
- Current resolved capabilities: 157
- Future Neural Engine modules: 145
- Future Engine capabilities: 757
- UI↔Engine mechanics: 199
- Development skills: 33
- Research sources: 59

## V8.14 evolution
Open WebUI research is integrated as independent NeuralDesk AI-workspace contracts: model presets/task models, multi-model conversation, incremental streaming, message queues, Notes, human+AI Channels, federated/hybrid knowledge, agentic knowledge navigation, native tool injection, isolated interaction extensions, layered access decisions, attention targets/timers, local/offline providers, connection pooling and memory embedding migration.

The release obeys **preserve → extend → bridge**. Existing V8.13 Coding Intelligence and V8.12 Agent Platform semantics are non-regression baselines.
