<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.governance; current: docs/governance/CURRENT_FRONTIER_PROGRAM_GOVERNANCE.md -->
# Current Frontier Program Governance

## Core rule

"Superior to market" is not a design label. It is an evidence status.

## Claim classes

- `PARITY-TARGET`: required competitive capability, not yet proven.
- `DIFFERENTIATION-TARGET`: intended NeuralDesk advantage, not yet proven.
- `PARITY-PROVEN`: benchmark evidence meets target.
- `DIFFERENTIATION-PROVEN`: reproducible evidence shows advantage.
- `SUPERIORITY-PROVEN`: allowed only for a defined workload/metric and never generalized beyond evidence.

## Promotion gates

Every executable candidate must pass:
correctness -> security -> quality -> reliability -> performance -> cost -> observability -> rollback.

## Complexity governance

Prefer direct model/RAG/tool/workflow before multi-agent. Prefer APIs before computer-use. Prefer external frontier models before training a huge model from scratch.

## Documentation boundary

The frontier program originated as documentation-only in V8.7 and remains a documentation/evidence program in V8.11. No executable Neural Engine capability is introduced by the program itself.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
