<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# V6.3 — CSS desacoplado por página

## Mudança estrutural

Cada página HTML agora carrega um único CSS próprio.

```text
css/
├── index.css
├── chat.css
├── dashboard-center.css
├── training.css
├── knowledge-center.css
├── tools-center.css
└── settings.css
```

## Removidos como dependências compartilhadas

- styles.css
- launch.css
- CSS global compartilhado

## Resultado

Cada página pode ser usada isoladamente com apenas:

```text
pagina.html
css/pagina.css
```

O projeto continua:

- HTML + CSS only;
- sem JavaScript;
- sem `<script>`;
- sem backend.
