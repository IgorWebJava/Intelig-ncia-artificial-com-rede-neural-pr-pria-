<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 107 — Multimodal Contract

Canonical content part types:

- text
- image
- audio
- video
- document
- structured_data
- tool_result

Large media is represented through Asset References, not inline database blobs.
