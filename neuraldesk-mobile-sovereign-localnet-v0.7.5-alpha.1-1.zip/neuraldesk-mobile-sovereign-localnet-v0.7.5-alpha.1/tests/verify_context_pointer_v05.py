#!/usr/bin/env python3
from __future__ import annotations
import json
import subprocess
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
rows=[json.loads(x) for x in (ROOT/'training/data/context_pointer_golden.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
with tempfile.NamedTemporaryFile('w',encoding='utf-8',delete=False) as f:
    path=Path(f.name)
    for row in rows:
        q=row['question'].replace('\t',' ')
        c=row['context'].replace('\t',' ')
        a=row['answer'].replace('\t',' ')
        f.write(f"{a}\t-\t{q}\t{c}\n")
try:
    p=subprocess.run([str(ROOT/'build/nd_context_batch'),
                      str(ROOT/'models/neuraldesk-context-pointer-v0.5.ndqa'),
                      str(path),
                      str(ROOT/'models/neuraldesk-relation-classifier-v0.5.ndrl')],
                     text=True,capture_output=True)
    assert p.returncode==0,(p.stdout,p.stderr)
    assert f"{len(rows)}/{len(rows)} PASS" in p.stdout,(p.stdout,p.stderr)
    print(f"context-pointer-runtime-final PASS {len(rows)}/{len(rows)}")
finally:
    path.unlink(missing_ok=True)
