#include "nd_safety.h"

#include <ctype.h>
#include <string.h>

static unsigned char lo(unsigned char c) {
    return (c >= 'A' && c <= 'Z') ? (unsigned char)(c + ('a' - 'A')) : c;
}

static int contains_ci(const char *s, const char *needle) {
    size_t n = strlen(needle);
    if (!n) return 1;
    for (; s && *s; s++) {
        size_t i = 0u;
        while (i < n && s[i] && lo((unsigned char)s[i]) == lo((unsigned char)needle[i])) i++;
        if (i == n) return 1;
    }
    return 0;
}

NDSafetyDecision nd_safety_prompt_check(const char *prompt) {
    if (!prompt) return ND_SAFETY_ALLOW;
    int override_rules = contains_ci(prompt, "ignore todas as instruções") ||
                         contains_ci(prompt, "ignore all previous instructions") ||
                         contains_ci(prompt, "ignore todas as regras") ||
                         contains_ci(prompt, "desconsidere todas as regras") ||
                         contains_ci(prompt, "desconsidere as regras");
    int disable_protection = contains_ci(prompt, "desative as proteções") ||
                             contains_ci(prompt, "desative as protecoes") ||
                             contains_ci(prompt, "desligue as proteções") ||
                             contains_ci(prompt, "desligue as protecoes");
    int expose_internal = contains_ci(prompt, "revele o prompt do sistema") ||
                          contains_ci(prompt, "show system prompt") ||
                          contains_ci(prompt, "revele segredos internos") ||
                          contains_ci(prompt, "exponha segredos internos");
    if (expose_internal || (override_rules && (contains_ci(prompt, "regra") || contains_ci(prompt, "instru") ||
                                               contains_ci(prompt, "prompt") || disable_protection)) ||
        (disable_protection && (contains_ci(prompt, "segredo") || contains_ci(prompt, "ia externa")))) {
        return ND_SAFETY_BLOCK_PROMPT_INJECTION;
    }
    if (contains_ci(prompt, "mostre a chave privada") || contains_ci(prompt, "revele a chave privada") ||
        contains_ci(prompt, "exfiltre") || contains_ci(prompt, "api key") || contains_ci(prompt, "senha secreta")) {
        return ND_SAFETY_BLOCK_SECRET_EXFILTRATION;
    }
    if ((contains_ci(prompt, "use chatgpt") || contains_ci(prompt, "use openai") || contains_ci(prompt, "use gemini") ||
         contains_ci(prompt, "use claude") || contains_ci(prompt, "use qualquer ia externa") ||
         contains_ci(prompt, "force uma ia externa") || contains_ci(prompt, "fallback externo")) &&
        (contains_ci(prompt, "em vez") || contains_ci(prompt, "bypass") || contains_ci(prompt, "substitua") ||
         contains_ci(prompt, "ignore") || contains_ci(prompt, "desative") || contains_ci(prompt, "desligue") ||
         contains_ci(prompt, "force"))) {
        return ND_SAFETY_BLOCK_EXTERNAL_AI_BYPASS;
    }
    if (contains_ci(prompt, "gere infinitamente") || contains_ci(prompt, "sem limite de tokens") ||
        contains_ci(prompt, "aloque toda a memória") || contains_ci(prompt, "aloque toda a memoria")) {
        return ND_SAFETY_BLOCK_RESOURCE_ABUSE;
    }
    return ND_SAFETY_ALLOW;
}

NDSafetyDecision nd_safety_output_check(const char *output) {
    if (!output) return ND_SAFETY_ALLOW;
    if (contains_ci(output, "-----begin private key-----") || contains_ci(output, "api_key=") ||
        contains_ci(output, "authorization: bearer ") || contains_ci(output, "secret_key=")) {
        return ND_SAFETY_BLOCK_OUTPUT_SECRET;
    }
    return ND_SAFETY_ALLOW;
}

const char *nd_safety_reason(NDSafetyDecision d) {
    switch (d) {
        case ND_SAFETY_BLOCK_PROMPT_INJECTION: return "PROMPT_INJECTION";
        case ND_SAFETY_BLOCK_SECRET_EXFILTRATION: return "SECRET_EXFILTRATION";
        case ND_SAFETY_BLOCK_EXTERNAL_AI_BYPASS: return "EXTERNAL_AI_BYPASS";
        case ND_SAFETY_BLOCK_RESOURCE_ABUSE: return "RESOURCE_ABUSE";
        case ND_SAFETY_BLOCK_OUTPUT_SECRET: return "OUTPUT_SECRET";
        default: return "ALLOW";
    }
}
