# NeuralDesk — Historical Capability Merge Audit

Status: CURRENT recovery/merge audit for the v0.7 candidate.
Date: 2026-08-24.
Policy: `NEURALDESK_FIRST_PARTY_ONLY`.

## Purpose

This audit compares recoverable NeuralDesk lineages from prior conversations and persisted release evidence by capability rather than by version number. The destination is the Sovereign LocalNet v0.7 C99/Android architecture. Older JS Mobile Runtime mechanisms are specifications/evidence only; they must be reexpressed inside the current first-party owners and may not create a parallel runtime authority.

## Lineages reviewed

1. UI/docs V6.x–V8.22: module ownership, memory/handoff, tests, previews, registries, 10 canonical modules and 145 future Neural Engine blueprints.
2. Mobile Runtime v0.34–v0.45: tensor/autograd/training, candidate promotion/quality/signing, incremental inference/KV/sampler, safety, physical-device gates and bounded serving foundations.
3. Mobile Runtime v0.46–v0.53: continuous serving, paged KV/prefix reuse/tensor batching, speculative decoding, compiler/quantization, compiled weight streaming, observability/recovery, hardware routing/lowering and host-native C executor.
4. Mobile Runtime v0.54–v0.62: mobile cross-codegen, Android shared/self-contained kernel, JNI, Java/JVM, DEX generation/host execution and official-toolchain admission gates.
5. Mobile Runtime v0.63: governed 490-record curated corpus, disjoint splits, 250-item Golden Evaluation and tokenizer bridge.
6. Sovereign LocalNet v0.5–v0.6.3: C99 assistant, neural retriever/relation/context pointer, planner, calculator, persistent/structured memory, NDOS, dialogue grounding, conflict safety and robust intent.
7. Recovered v0.7 candidate: Semantic Core, dual-encoder semantic ranker and first-party Micro generative decoder format/runtime/training path.

## Capability winners and merge decision

| Capability | Strongest recoverable lineage | Current v0.7 state before merge | Decision |
|---|---|---|---|
| Module ownership / documentation-first / release audit | V8.22 + v0.54+ | partially preserved | PRESERVE + strengthen |
| Neural semantic routing / structured memory / grounding | LocalNet v0.6.3/v0.7 | stronger than old runtime | PRESERVE |
| Open-data local retrieval | LocalNet NDOS | stronger/current | PRESERVE |
| Generative architecture | recovered v0.7 | newer than old dense reference model | PRESERVE, retrain before promotion |
| Paged KV with COW/refcount | Mobile v0.47 | contiguous KV only | PORT to C99 generative runtime |
| Prefix KV reuse | Mobile v0.47 | absent | PORT with hash/lineage bounded session cache |
| Tensor-aware multi-request batching | Mobile v0.47 | absent | DEFER until concurrent serving owner exists; do not fake batching |
| Speculative greedy verification | Mobile v0.48 | absent | PORT bounded target-verified path, `speedupClaimed=false` until physical proof |
| Compiler/quantization quality floor | Mobile v0.49 | Q8/Q4 export exists, quality gate incomplete historically | PORT quality/parity/integrity policy |
| Memory-aware weight streaming | Mobile v0.50 | full file malloc | PORT as verified mmap/on-demand OS paging + residency evidence; no direct-storage claim |
| Observability / drain / recovery | Mobile v0.51 | basic answer metadata only | PORT sanitized bounded inference telemetry/lifecycle |
| Hardware capability routing | Mobile v0.52 | Kotlin RAM-only profile | PORT CPU/RAM/ABI capability profile + fail-closed format routing |
| Native CPU execution | Mobile v0.53 | current runtime already C99 native | CURRENT IS SUPERIOR; preserve |
| Mobile cross-target ABI validation | v0.54–v0.57 | Android app CMake/JNI exists but no historical binary proof integrated | PORT build/ABI verification gates where host toolchain permits |
| JNI/Java/Kotlin boundary | v0.58–v0.59 | current Kotlin/JNI is functionally richer | CURRENT IS SUPERIOR; preserve historical negative controls |
| DEX bounded generation/execution | v0.60–v0.61 | absent from LocalNet | PORT only as optional pre-cert validation tooling, never Android ART claim |
| Official Android toolchain admission | v0.62 | absent | PORT fail-closed local artifact/toolchain admission |
| Curated corpus + 250-item Golden | v0.63 | current generative corpus is smaller/different | RECOVER governance schema/evaluator; raw v0.63 records unavailable in current workspace, so do not fabricate them |
| Multimodal contracts | v0.63 + V8 research | no trained multimodal model | PRESERVE as future metadata contracts only; do not claim multimodal training |
| Agent/tool calling / long-horizon coding | V8.10–V8.13 research/docs | not implemented | DO NOT label implemented; future first-party work only |

## Truth boundary

Porting a historical mechanism does not inherit its old PASS automatically. Every port requires fresh tests against the current C99 model/runtime and current artifact bytes. Historical physical/device claims remain exactly as originally bounded. In particular, Android ART/device, APK/AAB signing, GPU/NPU execution, physical speedup and production/public serving remain unproven until executed in the required environment.

## Merge order

1. Paged KV + prefix reuse.
2. mmap-backed verified weight loading and quantization parity policy.
3. Speculative greedy target verification.
4. Bounded observability + drain/recovery lifecycle.
5. Hardware capability/profile routing shared by C/JNI/Kotlin.
6. Android/native admission verification tooling.
7. Curated-corpus/Golden governance schema recovery without fabricating unavailable v0.63 rows.
8. Retrain generative Micro; only then quality/performance promotion.
9. Full inherited + new gates, sanitizer, deterministic package, clean re-extraction and final dialogue.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


## v0.7.2 deep pass

A segunda passagem incluiu todos os arquivos executáveis `mobile-runtime/core` da linha cumulativa v0.63 e os ZIPs/conversas iniciais. Novos ports: network policy, local durable outbox/dependencies, pilot/master kill, local-project metadata, model-acquisition preflight e benchmark evaluation. V8.20 checkpoint averaging deixou de ser documentation-only e passou a ter ferramenta executável, mas candidate-only. Image preprocessing, Artifact Manager e companion pairing permanecem deferidos; APIs OpenAI-compatible/remotas históricas permanecem proibidas.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
