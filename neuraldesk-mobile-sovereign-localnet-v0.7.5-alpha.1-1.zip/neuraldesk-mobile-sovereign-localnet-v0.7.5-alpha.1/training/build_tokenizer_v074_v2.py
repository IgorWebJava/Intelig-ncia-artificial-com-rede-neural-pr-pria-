#!/usr/bin/env python3
from __future__ import annotations
import argparse, collections, hashlib, json, struct, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; D=ROOT/'training/data/generative_v074_v2'; PRE=ROOT/'scripts/pre_generation_lessons_check.py'
MAG=b'NDTKV001'; HEADER=64; ENDIAN=0x01020304; VOCAB=512; PAIRS=252

def fnv(data):
    h=1469598103934665603
    for b in data: h=((h^b)*1099511628211)&0xffffffffffffffff
    return h

def add_bytes(counts:collections.Counter, text:str):
    b=text.encode('utf-8'); counts.update(zip(b,b[1:]))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default=str(D/'tokenizer-v2.ndtk')); a=ap.parse_args()
    subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
    rich=[json.loads(x) for x in (D/'rich_sft.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    context=[json.loads(x) for x in (D/'context_sft.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    rich_counts=collections.Counter(); context_counts=collections.Counter()
    for r in rich: add_bytes(rich_counts,r['question']+'\n'+r['response'])
    for r in context: add_bytes(context_counts,'Contexto: '+r['context']+'\nPergunta: '+r['question']+'\nResposta: '+r['response'])
    rich_total=max(1,sum(rich_counts.values())); context_total=max(1,sum(context_counts.values()))
    universe=set(rich_counts)|set(context_counts)
    scored=[(p,(rich_counts[p]/rich_total)+(context_counts[p]/context_total)) for p in universe]
    pairs=[p for p,_ in sorted(scored,key=lambda kv:(-kv[1],kv[0]))[:PAIRS]]
    if len(pairs)!=PAIRS: raise SystemExit('not enough byte pairs')
    payload=bytes(x for p in pairs for x in p)
    h=bytearray(HEADER); h[:8]=MAG
    struct.pack_into('<IIIIII',h,8,HEADER,ENDIAN,VOCAB,PAIRS,len(payload),0); struct.pack_into('<Q',h,32,fnv(payload))
    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(h+payload)
    meta={'schema':'neuraldesk-tokenizer-v1','profile':'MICRO_V2_SOURCE_BALANCED','status':'TRAINING_ASSET_NOT_MODEL_PROMOTION','vocab':VOCAB,'byteTokens':256,'specialTokens':4,'pairTokens':PAIRS,
          'fitPolicy':'SOURCE_BALANCED_NORMALIZED_BIGRAM_FREQUENCY_V1','validationFitRecords':0,'richTrainingRecords':len(rich),'contextTrainingRecords':len(context),'asset':str(out.relative_to(ROOT)),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
          'richSftSha256':hashlib.sha256((D/'rich_sft.jsonl').read_bytes()).hexdigest(),'contextSftSha256':hashlib.sha256((D/'context_sft.jsonl').read_bytes()).hexdigest()}
    (D/'TOKENIZER.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
    print(f"TOKENIZER_V2_BUILD PASS vocab={VOCAB} pairs={PAIRS} validationFit=0 rich={len(rich)} context={len(context)} bytes={out.stat().st_size} sha256={meta['sha256']}")
if __name__=='__main__': main()
