# 🧠 MEMÓRIA CENTRAL & DIRETRIZES DO PROJETO QCNN ENGINE v5.0 (NEURO-SIMBÓLICO & ESPARSO)

> **DOCUMENTO DE LEITURA OBRIGATÓRIA PARA A IA DESENVOLVEDORA**
> Toda modificação, implementação de nova capacidade ou refatoração no QCNN Engine deve obedecer rigorosamente a este guia.

---

## 🚫 1. PRINCÍPIOS FUNDAMENTAIS & RESTRIÇÕES CRÍTICAS

1. **AUTONOMIA 100% PURA (SEM IA EXTERNA / SEM GEMINI / SEM LLMs DE TERCEIROS)**:
   - Zero dependência de APIs externas de nuvem (OpenAI, Claude, Gemini, HuggingFace, etc.).
   - Processamento semântico, vetores hiperdimensionais de 10.000 bits ($D=10.000$), gramática fractal, expansão Milui e cálculo harmônico são 100% locais e determinísticos.
2. **CÓDIGO 100% REAL (SEM MOCKS / SEM SIMULAÇÕES / SEM DEMOS)**:
   - Todo algoritmo processa dados reais, grava e lê de memória e disco real (SQLite/Room/Disco local).
   - Vetorização HDC de 10.000 bits real com bitsets e operações bitwise em nanossegundos.
3. **ARQUITETURA MODULAR ORIENTADA A OBJETOS & PLUGINS**:
   - Padrão `BaseQcnnPlugin` em Python e `IQcnnPlugin` em Kotlin.
   - Todo módulo é plugável, acoplável e desacoplável sem quebrar o pipeline.

---

## 🗺️ PILARES DO PARADIGMA NEURO-SIMBÓLICO & ESPARSO

1. **Hyperdimensional Computing (HDC $D=10.000$ bits)**:
   - Vetores bipolares/binários de altíssima dimensão com operações de Binding ($\otimes$ / XOR), Bundling ($\oplus$ / Votação Majoritária) e Permutação ($\Pi$ / Shift circular) em tempo ultrarrápido (< 0.1ms).
2. **Recombinação Gramatical Fractal (N-Grams Fractais & Semântica Categorial)**:
   - Síntese de linguagem natural baseada nas relações da Árvore da Vida e dependência gramatical categorial para frases fluidas e inéditas.
3. **Ontologia Expandida Automatizada (Continuous Knowledge Distillation)**:
   - Ingestão contínua em lote de arquivos `.txt`, manuais e livros, gerando nós conceituais, frequências áureas e relações de adjacência estruturadas.
4. **Execução no Edge & IoT Quântico-Simbólico**:
   - Latência sub-milissegundo para robótica em tempo real, drones e hardware vestível com baixo consumo de memória (< 12MB RAM).
5. **Holografia Fractal & Auto-Cura de Subagentes (Self-Healing Consensus)**:
   - "O que está dentro é como o que está fora": cada módulo e subagente possui repositório de memória independente (`HolographicMemoryStore`). Falhas e alucinações são corrigidas por triangulação cruzada com as demais camadas.
