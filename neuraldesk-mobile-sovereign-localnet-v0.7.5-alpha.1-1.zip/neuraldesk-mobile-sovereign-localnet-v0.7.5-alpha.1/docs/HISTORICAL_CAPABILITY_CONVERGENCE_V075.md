# Historical Capability Convergence — NeuralDesk v0.7.5-alpha.1

**Status:** `DEVELOPMENT / NOT_PROMOTED`  
**Date:** 2026-08-25  
**Policy:** capability evidence wins over version number; no external-AI inference; no parallel runtime authority.

## Scope and method

This pass re-audited all NeuralDesk history recoverable through the app's prior-conversation context and persistent Library evidence: early Mobile Runtime lineages, Mobile Runtime v0.34–v0.63, Sovereign LocalNet v0.5–v0.7.4, V7/V8.22 architecture/research, final attestations, current C99/Kotlin code and the current training state. A capability is adopted only when its old evidence proves a property absent from the current owner and that property can be reexpressed first-party without regression.

Historical release identity is not trusted blindly. In particular, the Library contains conflicting evidence for the label `v0.63`: one lineage attests a curated-corpus/Golden release, while another normative blocker attestation says `V0_63_NOT_CREATED_NEXT_ANDROID_BOUNDARY_UNAVAILABLE`. v0.7.5 therefore consumes only capability evidence/hashes and preserves the conflict instead of inventing a chronology.

## Convergence matrix

| Lineage / capability | Strongest historical property | v0.7.5 decision |
|---|---|---|
| V6–V8.22 module ownership, docs-first, memory/handoff, tests | rigorous ownership and non-regression architecture | **PRESERVE**; current C99 owners remain authoritative |
| Early Mobile Runtime Local Projects | bounded local project metadata | **ALREADY PORTED** (`nd_project`) |
| Early durable outbox/dependencies | local durable task/dependency state | **ALREADY PORTED** (`nd_outbox`) |
| Adaptive network policy | explicit online/offline admission | **ALREADY PORTED** (`nd_network_policy`) |
| Pilot/master kill | reversible local kill policy | **ALREADY PORTED** (`nd_pilot`) |
| Model acquisition preflight | bounded local admission assessment | **ALREADY PORTED** (`nd_model_acquisition`) |
| Benchmark evaluation | measured-not-certified evidence | **ALREADY PORTED** (`nd_benchmark`) |
| v0.34–v0.40 tensor/autograd/loss/AdamW/checkpoint/promotion | real training correctness and signed authority | **CURRENT SUPERIOR/ACTIVE EQUIVALENT**: current PyTorch Micro trainers + integrity checkpoints + independent Ed25519 Model Authority |
| v0.41–v0.45 incremental KV / bounded safety / precert CPU | incremental inference correctness and fail-closed activation | **ALREADY PORTED / CURRENT STRONGER**; generative activation still false |
| v0.46 chunked prefill + token streaming + backpressure + cancel/deadline | computational streaming during decode | **PORTED NOW** into `nd_generative`: persistent KV stream session, chunked prefill, token callback, pause/resume, cancel/deadline, UTF-8 delta adapter |
| v0.47 paged KV + COW + prefix reuse | bounded incremental memory reuse | **ALREADY PORTED**; multi-request tensor batching remains deferred because no concurrent serving owner exists |
| v0.48 target-verified speculative greedy | rollback/replay and target parity | **ALREADY PORTED**, `speedupClaimed=false` |
| v0.49 quantization quality floors | independent Q8/Q4 integrity/parity | **ALREADY PORTED** with FP32 oracle and Q8/Q4 gates |
| v0.50 on-demand weight streaming/residency cache | avoid full restored weight residency | **CURRENT mmap PATH PREFERRED** for this C99 fixed model; OS paging avoids a second copied tensor cache. Explicit leased LRU remains deferred until measured residency proves it superior |
| v0.51 observability/drain/recovery | sanitized lifecycle evidence and restart recovery | **PORTED NOW/STRENGTHENED** in `nd_run_journal`: BEGIN/PROGRESS/DRAIN/END/ABANDONED, no raw prompt/output |
| v0.52 capability routing/lowering | privacy-preserving capability profile and unavailable-provider fail-closed | **PORTED NOW** in `nd_resource` + Kotlin: RAM/cores/ABI/provider, CPU_C99 only executable, GPU/NPU fail closed, optional physical-cert gate |
| v0.53 native CPU executor | native first-party execution | **CURRENT C99 IS SUPERIOR**, no second native executor |
| v0.54–v0.57 cross-target/shared kernel | deterministic ABI/cross-target proof | **ALREADY PORTED AS CURRENT CROSS-TARGET GATES**; no parallel historical kernel runtime |
| v0.58–v0.62 JNI/Java/JVM/DEX/toolchain admission | negative controls and Android boundary discipline | **CURRENT KOTLIN/JNI IS FUNCTIONALLY SUPERIOR / TOOLCHAIN GATES ALREADY PORTED**; bounded DEX runtime is not duplicated |
| v0.63 rights/provenance/splits/Golden governance | explicit source eligibility, contamination gates, epistemic separation, Golden never auto-promotes | **PORTED NOW FOR CURRENT BYTES**; raw historical 490/Golden-250 bytes not recovered, so `historicalGolden250Imported=false` |
| LocalNet v0.5–v0.7 semantic routing/grounding/memory/RAG | strongest current dialogue/grounding architecture | **PRESERVE** |
| V7.5 agent orchestration architecture | supervisor/sequential/parallel/router/human checkpoint designs | **DOCUMENTATION ONLY for current mobile runtime**; no fake agent executor |
| V8.20/V8.22 SWA/EMA/RLVR/context-funnel/microagents | research/design patterns | SWA/checkpoint averaging already candidate-only; all other patterns remain **DOCUMENTATION/EXPERIMENT ONLY** until current first-party proof |
| Qwen3-Omni / Thinker-Talker, DeepSeek Harness, AutoGPT research | multimodal/realtime/plugin/durable-agent patterns | **RESEARCH INPUT ONLY**; no trained multimodal owner, plugin engine or autonomous agent is claimed |
| Artifact Manager | historical executable artifact UX/service | **DEFER**: current model authority owns model artifacts and no current artifact UI/consumer exists |
| Image preprocessing | historical bounded image path | **DEFER** until a visual model is trained/promoted |
| Companion pairing | historical mobile↔desktop concept | **DEFER** until a current desktop companion owner exists |
| Remote provider routing | external model/provider path | **DO NOT PORT**: conflicts with sovereign first-party inference |

## New executable convergence in v0.7.5

### 1. Computational + UTF-8 streaming

`NDGenStreamSession` preserves the actual paged KV cache across calls. `nd_gen_stream_advance()` performs bounded prefill and decode work. Cancellation and deadlines are checked during both phases. Backpressure pauses after a consumed token and resumes by applying that token to the KV state before the next emission. `NDGenTextStreamSession` uses the canonical byte tokenizer and withholds partial UTF-8 until a complete valid prefix exists.

Fresh gates:
- token stream final output = synchronous greedy `8/8`;
- chunked prefill = exercised;
- backpressure pause/resume = exercised;
- cancellation in prefill and decode = exercised;
- deadline = exercised;
- multibyte UTF-8 delta = `çççç` exact.

This is a runtime-mechanics proof only. No rejected backbone is promoted and the deterministic assistant route is not silently replaced.

### 2. Hardware/provider routing

`NDHardwareCapabilities` and Kotlin `MobileHardwareCapabilities` classify bounded RAM/core/ABI/provider facts without hostname, CPU model, serial, device ID or network identifiers. `AUTO` selects only the executable first-party C99 CPU path. GPU/NPU detection never becomes support without an executor. Physical certification can be required as an independent fail-closed route gate.

### 3. Sanitized observability lifecycle

The existing Run Journal remains the sole owner and now records sanitized `PROGRESS` and `DRAIN` events in addition to BEGIN/END/ABANDONED recovery. No prompt or response text is persisted.

### 4. Current-corpus governance

`training/build_governance_v075.py` materializes a current source catalog and governance manifest from the canonical current datasets. It verifies 2,563 rich SFT rows, 52,500 contextual rows, 55,063 replay rows, 140 evaluation-only Pirá validation rows and zero normalized question leakage. The catalog distinguishes trainable vs reference-only sources and requires rights/derivative/PII policy for future ingestion.

Historical v0.63 hashes are retained as evidence only. The unavailable raw Golden 250 is not reconstructed.

### 5. Gradient accumulation

The Data-Scale trainer now supports `microbatch=8 × accumulation=8 => effective batch=64` while retaining the proven `1 rich + 7 context` microbatch and `context loss weight=0.15`. Clipping/AdamW happen once per accumulation group and checkpoints only occur on optimizer boundaries. A fresh debug campaign proved uninterrupted and pause/resume model-state, AdamW, FP32, Q8 and Q4 byte-identical.

## Explicit non-ports

No new claim is made for APK/AAB, ART/device execution, GPU/NPU kernels, physical speedup, full multimodal neural inference, autonomous agents, remote providers or production/public serving. Tensor-aware multi-request inference batching remains blocked until a real concurrent-serving owner exists. The historical Golden 250 remains blocked by missing bytes.
