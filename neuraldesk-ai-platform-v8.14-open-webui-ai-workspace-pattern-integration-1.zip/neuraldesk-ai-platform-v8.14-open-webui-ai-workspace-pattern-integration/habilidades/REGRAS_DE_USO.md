<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->

# Regras de Uso — habilidades/

1. Leia `memória/` antes de alterar o projeto.
2. Leia `habilidades/` antes de escolher ferramentas/processo.
3. Trabalhe por capability, não por nome de ferramenta.
4. Registre nova skill quando uma mudança introduzir conhecimento/processo novo e durável.
5. Registre nova ferramenta quando ela for realmente necessária ao workflow.
6. Atualize capability mapping quando uma ferramenta for substituída.
7. Não armazene secrets ou dados privados.
8. Não armazene chain-of-thought privada.
9. Não declare como “habilidade necessária” algo que não é usado pelo projeto.
10. Execute `tools/validate_skills.py` antes de concluir uma versão estrutural.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
