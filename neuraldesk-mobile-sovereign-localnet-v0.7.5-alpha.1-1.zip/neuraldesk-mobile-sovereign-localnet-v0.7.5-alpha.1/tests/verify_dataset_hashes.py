#!/usr/bin/env python3
from pathlib import Path
import hashlib

EXPECTED={
 'training/data/context_pointer_train.jsonl':('5ed8fe2b38b30ce5ea762ffa3d0065d964235213680ba6a26314662826edb421',52500),
 'training/data/context_pointer_golden.jsonl':('0ed24ec2f93505ef8922eec54934fac54a2d5aa1a797c118e2a4a26cd418d1e9',2000),
 'training/data/knowledge_retriever_train.tsv':('40252b8d35dfdf2fa61341418e68ea512fe6f82e4e20de4423bc22669e0dca4b',1830),
 'training/data/knowledge_retriever_golden.tsv':('d72a0e5f45df2102d7c9b676fd2cddf5e4e2f7569c3af795af9240c2d08d5d27',856),
 'evaluation/fixtures/context_synthesis_regression.tsv':('614014431164ee3e61d40a20deb82400f0518b9145cb2912851806e8a45e8717',360),
 'evaluation/fixtures/context_composition_holdout.tsv':('44060dd656ae9e7323ba4cf671c932e220c5c4322726922a7fa29fb9458a71bd',640),
 'evaluation/fixtures/context_v04_regression.tsv':('75e0074b3b0dae3507992868be4abbc038741f0cca96a01e8ac9656812f019e8',6),
 'evaluation/fixtures/relation_assisted_context_holdout.tsv':('a87e740e7fcd43c02f0336f76204dc3ddc239005a75be542a9baa0cd81266b67',400),
}
for rel,(sha,lines) in EXPECTED.items():
    p=Path(rel); raw=p.read_bytes(); got=hashlib.sha256(raw).hexdigest(); assert got==sha,(rel,got,sha)
    count=sum(1 for _ in p.open('rb')); assert count==lines,(rel,count,lines)
print('dataset-hashes PASS',len(EXPECTED),'artifacts')
