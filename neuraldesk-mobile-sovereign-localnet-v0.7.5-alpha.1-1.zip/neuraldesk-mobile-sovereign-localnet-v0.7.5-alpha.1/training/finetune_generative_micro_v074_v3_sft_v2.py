#!/usr/bin/env python3
"""Response-coverage-aware SFT v2 for Micro-v3.

Stage-only and NOT_PROMOTED. It consumes a fully completed Micro-v3 pretraining
checkpoint as an immutable predecessor, verifies its lineage, loads only model
weights, resets AdamW for the new SFT objective, and trains with deterministic
minibatches plus longer response supervision. It never writes models/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch

from train_generative_micro_v074_v3 import (
    DATA,
    ROOT,
    MicroV3,
    Tok,
    bindings,
    ch,
    export,
    loss,
    oh,
    pad,
    readj,
    sha,
    th,
)
from train_generative_micro_v074_v3_batch import causal_row
PRE = ROOT / 'scripts/pre_generation_lessons_check.py'

SCHEMA_CONFIG = "nd-v074-micro-v3-sft-v2-config-v1"
SCHEMA_CHECKPOINT = "nd-v074-micro-v3-sft-v2-checkpoint-v1"
SCHEMA_REPORT = "neuraldesk-generative-training-report-v074-alpha2-micro-v3-sft-v2-v1"
PREDECESSOR_SCHEMA = "nd-v074-micro-v3-batch-checkpoint-v1"


def _seed(base: int, epoch: int, source: str) -> int:
    material = f"{base}|sft-v2|{epoch}|{source}|nd-v074-sft-v2-permutation-v1".encode()
    return int.from_bytes(hashlib.sha256(material).digest()[:8], "little")


def permutation(n: int, seed: int, epoch: int, source: str) -> list[int]:
    p = list(range(n))
    random.Random(_seed(seed, epoch, source)).shuffle(p)
    return p


def _slice_cycle(p: list[int], start: int, count: int) -> list[int]:
    if not p or count < 0:
        raise ValueError("invalid permutation/count")
    return [p[(start + i) % len(p)] for i in range(count)]


def sftrow_v2(
    r: dict[str, Any], tok: Tok, n: int, prompt_cap: int, context: bool = False
) -> tuple[torch.Tensor, torch.Tensor, dict[str, int]]:
    if n < 16 or prompt_cap < 4 or prompt_cap >= n:
        raise ValueError("invalid SFT v2 sequence/prompt budget")
    q = ("Contexto: " + r["context"] + "\nPergunta: " + r["question"]) if context else r["question"]
    qids = tok.encode(q)
    # Always preserve BOS + the tail containing the actual question + SEP.
    qtail = qids[-(prompt_cap - 2) :]
    prompt = [257] + qtail + [259]
    answer = tok.encode(r["response"]) + [258]
    capacity = n + 1 - len(prompt)
    used_answer = answer[:capacity]
    ids = prompt + used_answer
    x = ids[:-1]
    start = len(prompt) - 1
    y = [-100 if i < start else t for i, t in enumerate(ids[1:])]
    x_t, y_t = pad(x, y, n)
    return x_t.squeeze(0), y_t.squeeze(0), {
        "answerTokens": len(answer),
        "supervisedAnswerTokens": len(used_answer),
        "promptTokens": len(prompt),
        "truncatedAnswerTokens": max(0, len(answer) - len(used_answer)),
    }


def packing_stats(rows: list[dict[str, Any]], tok: Tok, n: int, prompt_cap: int) -> dict[str, Any]:
    total = supervised = truncated_rows = 0
    lengths: list[int] = []
    for r in rows:
        _, _, st = sftrow_v2(r, tok, n, prompt_cap, False)
        total += st["answerTokens"]
        supervised += st["supervisedAnswerTokens"]
        truncated_rows += int(st["truncatedAnswerTokens"] > 0)
        lengths.append(st["answerTokens"])
    lengths.sort()
    return {
        "rows": len(rows),
        "answerTokensTotal": total,
        "supervisedAnswerTokens": supervised,
        "tokenCoverage": supervised / total,
        "truncatedRows": truncated_rows,
        "truncatedRowRate": truncated_rows / len(rows),
        "answerTokensMedian": lengths[len(lengths) // 2],
        "answerTokensP90": lengths[max(0, math.ceil(len(lengths) * 0.9) - 1)],
        "answerTokensMax": lengths[-1],
    }


def verify_predecessor(path: Path, expected_bindings: dict[str, str]) -> dict[str, Any]:
    side_path = path.with_suffix(path.suffix + ".json")
    if not path.is_file() or not side_path.is_file():
        raise ValueError("pretraining checkpoint or sidecar missing")
    side = json.loads(side_path.read_text(encoding="utf-8"))
    actual_sha = sha(path)
    if actual_sha != side.get("checkpointSha256"):
        raise ValueError("pretraining checkpoint SHA mismatch")
    body = torch.load(path, map_location="cpu", weights_only=False)
    if body.get("schema") != PREDECESSOR_SCHEMA:
        raise ValueError("unsupported pretraining checkpoint schema")
    if body.get("configSha256") != side.get("configSha256"):
        raise ValueError("pretraining config digest mismatch")
    config = body.get("config", {})
    if config.get("arch", {}).get("params") != 11229760:
        raise ValueError("pretraining architecture mismatch")
    if config.get("bindings") != expected_bindings:
        raise ValueError("pretraining corpus/tokenizer bindings are stale")
    state = body.get("state", {})
    rich_replay = int(config.get("effectiveCounts", {}).get("richReplay", 0))
    rich_per_batch = int(config.get("trainingPolicy", {}).get("pretrain", {}).get("richPerBatch", 0))
    expected_batches = math.ceil(rich_replay / rich_per_batch) if rich_replay and rich_per_batch else 0
    if state.get("phase") != "pretrain" or int(state.get("pretrainBatchCursor", -1)) != expected_batches:
        raise ValueError("pretraining checkpoint is not exactly at completed pretrain boundary")
    if th(body["model"].items()) != body.get("modelStateSha256"):
        raise ValueError("pretraining model-state digest mismatch")
    return {
        "checkpointSha256": actual_sha,
        "configSha256": body["configSha256"],
        "modelStateSha256": body["modelStateSha256"],
        "optimizerStateSha256": body["optimizerStateSha256"],
        "state": state,
        "model": body["model"],
    }


def cfg(a: argparse.Namespace, tok_path: Path, counts: dict[str, int], predecessor: dict[str, Any]) -> dict[str, Any]:
    if a.rich_per_batch + a.context_per_batch + a.replay_per_batch != a.batch_size:
        raise ValueError("SFT v2 source counts must equal batch size")
    return {
        "schema": SCHEMA_CONFIG,
        "arch": {
            "vocab": 512,
            "dim": 320,
            "layers": 10,
            "qHeads": 10,
            "kvHeads": 2,
            "ffn": 896,
            "context": 256,
            "params": 11229760,
        },
        "seed": a.seed,
        "epochs": a.epochs,
        "seqLen": a.seq_len,
        "promptCap": a.prompt_cap,
        "learningRate": a.lr,
        "weightDecay": a.weight_decay,
        "gradClip": a.grad_clip,
        "threads": a.threads,
        "mkldnn": bool(a.mkldnn),
        "validationBatchSize": a.validation_batch_size,
        "trainingPolicy": {
            "version": "nd-v074-response-coverage-sft-v2",
            "batchSize": a.batch_size,
            "richPerBatch": a.rich_per_batch,
            "contextPerBatch": a.context_per_batch,
            "richReplayPerBatch": a.replay_per_batch,
            "epochDefinition": "ONE_FULL_RICH_SFT_COVERAGE",
            "responseOnlySupervision": True,
            "optimizerResetAtSftBoundary": True,
            "packing": "BOS_PLUS_PROMPT_TAIL_PLUS_SEP_PLUS_RESPONSE_PREFIX_V2",
            "validationGradientUse": False,
        },
        "debugLimits": {"rich": a.rich_limit, "context": a.context_limit, "validation": a.validation_limit},
        "effectiveCounts": counts,
        "bindings": bindings(tok_path),
        "predecessor": {k: predecessor[k] for k in ("checkpointSha256", "configSha256", "modelStateSha256", "optimizerStateSha256")},
    }


def schedule(rich_n: int, context_n: int, replay_n: int, a: argparse.Namespace, epoch: int) -> dict[str, Any]:
    return {
        "epoch": epoch,
        "richPermutation": permutation(rich_n, a.seed, epoch, "rich_sft"),
        "contextPermutation": permutation(context_n, a.seed, epoch, "context_sft"),
        "replayPermutation": permutation(replay_n, a.seed, epoch, "rich_replay"),
    }


def validate_schedule(s: dict[str, Any], a: argparse.Namespace, counts: dict[str, int]) -> None:
    if s != schedule(counts["richSft"], counts["contextSft"], counts["richReplay"], a, int(s["epoch"])):
        raise ValueError("SFT v2 checkpoint permutation mismatch")


def sft_batch(
    rich: list[dict[str, Any]], context: list[dict[str, Any]], replay: list[dict[str, Any]],
    tok: Tok, a: argparse.Namespace, sched: dict[str, Any], cursor: int,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, int]]:
    rs = cursor * a.rich_per_batch
    cs = cursor * a.context_per_batch
    ps = cursor * a.replay_per_batch
    ri = _slice_cycle(sched["richPermutation"], rs, a.rich_per_batch)
    ci = _slice_cycle(sched["contextPermutation"], cs, a.context_per_batch)
    pi = _slice_cycle(sched["replayPermutation"], ps, a.replay_per_batch)
    xy: list[tuple[torch.Tensor, torch.Tensor]] = []
    answer_total = answer_supervised = 0
    for i in ri:
        x, y, st = sftrow_v2(rich[i], tok, a.seq_len, a.prompt_cap, False)
        xy.append((x, y)); answer_total += st["answerTokens"]; answer_supervised += st["supervisedAnswerTokens"]
    for i in ci:
        x, y, st = sftrow_v2(context[i], tok, a.seq_len, a.prompt_cap, True)
        xy.append((x, y)); answer_total += st["answerTokens"]; answer_supervised += st["supervisedAnswerTokens"]
    for j, i in enumerate(pi):
        xy.append(causal_row(replay[i], tok, sched["epoch"] * 1000037 + cursor * 47 + j, a.seq_len))
    return (
        torch.stack([q[0] for q in xy]),
        torch.stack([q[1] for q in xy]),
        {"rich": len(ri), "context": len(ci), "replay": len(pi), "answerTokens": answer_total, "supervisedAnswerTokens": answer_supervised},
    )


def evalv(model: MicroV3, rows: list[dict[str, Any]], tok: Tok, a: argparse.Namespace) -> float:
    model.eval(); per_example: list[float] = []
    with torch.no_grad():
        for start in range(0, len(rows), a.validation_batch_size):
            xy = []
            for r in rows[start:start + a.validation_batch_size]:
                rr = {"question": r["question"], "response": r["answer"]}
                x, y, _ = sftrow_v2(rr, tok, a.seq_len, a.prompt_cap, False)
                xy.append((x, y))
            x = torch.stack([q[0] for q in xy]); y = torch.stack([q[1] for q in xy])
            logits = model(x)
            raw = torch.nn.functional.cross_entropy(logits.reshape(-1, 512), y.reshape(-1), ignore_index=-100, reduction="none").reshape(y.shape)
            mask = y.ne(-100); sums = (raw * mask).sum(1); counts = mask.sum(1).clamp_min(1)
            per_example.extend((sums / counts).cpu().tolist())
    model.train(); return sum(per_example) / len(per_example)


def cpwrite(path: Path, model: MicroV3, opt: torch.optim.Optimizer, config: dict[str, Any], state: dict[str, Any], initial_validation: float, sched: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = {
        "schema": SCHEMA_CHECKPOINT, "config": config, "configSha256": ch(config), "state": state,
        "initialValidationLoss": initial_validation, "schedule": sched, "model": model.state_dict(), "optimizer": opt.state_dict(),
        "modelStateSha256": th(model.state_dict().items()), "optimizerStateSha256": oh(opt),
    }
    tmp = path.with_name(path.name + ".tmp"); side_tmp = path.with_suffix(path.suffix + ".json.tmp")
    for stale in (tmp, side_tmp):
        if stale.exists(): stale.unlink()
    torch.save(body, tmp)
    with tmp.open("rb+") as f: os.fsync(f.fileno())
    temp_sha = sha(tmp); os.replace(tmp, path)
    dfd = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(dfd)
    finally: os.close(dfd)
    if sha(path) != temp_sha: raise IOError("checkpoint hash changed across atomic replace")
    side = {
        "checkpointSha256": temp_sha, "configSha256": body["configSha256"], "modelStateSha256": body["modelStateSha256"],
        "optimizerStateSha256": body["optimizerStateSha256"], "state": state, "schedule": {"epoch": sched["epoch"]},
    }
    with side_tmp.open("w", encoding="utf-8") as f:
        f.write(json.dumps(side, indent=2, sort_keys=True) + "\n"); f.flush(); os.fsync(f.fileno())
    os.replace(side_tmp, path.with_suffix(path.suffix + ".json"))
    dfd = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(dfd)
    finally: os.close(dfd)
    return side


def cpload(path: Path, model: MicroV3, opt: torch.optim.Optimizer, config: dict[str, Any], a: argparse.Namespace, counts: dict[str, int]) -> dict[str, Any]:
    side = json.loads(path.with_suffix(path.suffix + ".json").read_text(encoding="utf-8"))
    if sha(path) != side["checkpointSha256"] or side["configSha256"] != ch(config):
        raise ValueError("SFT v2 checkpoint SHA/config mismatch")
    body = torch.load(path, map_location="cpu", weights_only=False)
    if body.get("schema") != SCHEMA_CHECKPOINT or body.get("config") != config:
        raise ValueError("SFT v2 checkpoint schema/config mismatch")
    validate_schedule(body["schedule"], a, counts)
    model.load_state_dict(body["model"]); opt.load_state_dict(body["optimizer"])
    if th(model.state_dict().items()) != body["modelStateSha256"] or oh(opt) != body["optimizerStateSha256"]:
        raise ValueError("SFT v2 state digest mismatch after load")
    return body


def checkpoint_name(state: dict[str, int]) -> str:
    return f"v3-sft-v2-e{state['epoch']}-b{state['batchCursor']}-u{state['updates']}.pt"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pretrain-checkpoint", required=True)
    ap.add_argument("--output-dir", required=True); ap.add_argument("--checkpoint-dir", required=True); ap.add_argument("--resume")
    ap.add_argument("--epochs", type=int, default=1); ap.add_argument("--run-batch-budget", type=int, default=0)
    ap.add_argument("--seq-len", type=int, default=128); ap.add_argument("--prompt-cap", type=int, default=48)
    ap.add_argument("--seed", type=int, default=7422); ap.add_argument("--lr", type=float, default=8e-5)
    ap.add_argument("--weight-decay", type=float, default=0.01); ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--threads", type=int, default=4); ap.add_argument("--mkldnn", action="store_true")
    ap.add_argument("--checkpoint-every-batches", type=int, default=25); ap.add_argument("--validation-batch-size", type=int, default=10)
    ap.add_argument("--batch-size", type=int, default=10); ap.add_argument("--rich-per-batch", type=int, default=8)
    ap.add_argument("--context-per-batch", type=int, default=1); ap.add_argument("--replay-per-batch", type=int, default=1)
    ap.add_argument("--rich-limit", type=int, default=0); ap.add_argument("--context-limit", type=int, default=0); ap.add_argument("--validation-limit", type=int, default=0)
    a = ap.parse_args()

    subprocess.run([sys.executable, str(PRE)], cwd=ROOT, check=True)
    if not (1 <= a.threads <= 8) or a.epochs < 1: raise SystemExit("invalid bounded training configuration")
    torch.set_num_threads(a.threads); torch.set_num_interop_threads(1); torch.use_deterministic_algorithms(True); torch.backends.mkldnn.enabled = bool(a.mkldnn)
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)

    tok_path = DATA / "tokenizer-v2.ndtk"; tok = Tok(tok_path)
    rich = readj(DATA / "rich_sft.jsonl"); context = readj(DATA / "context_sft.jsonl"); replay_all = readj(DATA / "causal_replay.jsonl"); val = readj(DATA / "pira_validation.jsonl")
    replay = [r for r in replay_all if r.get("source") != "NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN"]
    if a.rich_limit: rich = rich[:a.rich_limit]; replay = replay[:a.rich_limit]
    if a.context_limit: context = context[:a.context_limit]
    if a.validation_limit: val = val[:a.validation_limit]
    counts = {"richSft": len(rich), "contextSft": len(context), "richReplay": len(replay), "validation": len(val)}
    pred = verify_predecessor(Path(a.pretrain_checkpoint), bindings(tok_path))
    config = cfg(a, tok_path, counts, pred)
    stats = packing_stats(rich, tok, a.seq_len, a.prompt_cap)
    if stats["tokenCoverage"] < 0.80: raise SystemExit(f"SFT v2 token coverage below 80%: {stats['tokenCoverage']:.6f}")

    model = MicroV3(); model.load_state_dict(pred["model"])
    if th(model.state_dict().items()) != pred["modelStateSha256"]: raise SystemExit("predecessor load digest mismatch")
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.weight_decay)
    state: dict[str, int] = {"epoch": 0, "batchCursor": 0, "updates": 0, "richSeen": 0, "contextSeen": 0, "replaySeen": 0, "answerTokens": 0, "supervisedAnswerTokens": 0}
    sched = schedule(len(rich), len(context), len(replay), a, 0); initial_validation: float | None = None
    if a.resume:
        body = cpload(Path(a.resume), model, opt, config, a, counts); state = body["state"]; sched = body["schedule"]; initial_validation = float(body["initialValidationLoss"])
        print(f"RESUME_V3_SFT_V2 PASS epoch={state['epoch']} cursor={state['batchCursor']} updates={state['updates']}", flush=True)
    if initial_validation is None: initial_validation = evalv(model, val, tok, a)
    print(f"SFT_V2_PACKING PASS coverage={stats['tokenCoverage']:.6f} truncatedRows={stats['truncatedRows']}/{stats['rows']} median={stats['answerTokensMedian']} p90={stats['answerTokensP90']}", flush=True)
    print(f"VALIDATION_V3_SFT_V2 baseline={initial_validation:.6f} items={len(val)}", flush=True)

    budget = a.run_batch_budget or 10**18; used = 0; ckdir = Path(a.checkpoint_dir)
    total_batches = math.ceil(len(rich) / a.rich_per_batch)
    while state["epoch"] < a.epochs and used < budget:
        epoch = state["epoch"]
        if sched["epoch"] != epoch: sched = schedule(len(rich), len(context), len(replay), a, epoch)
        cursor = state["batchCursor"]
        if cursor >= total_batches:
            state["epoch"] += 1; state["batchCursor"] = 0
            if state["epoch"] >= a.epochs: break
            sched = schedule(len(rich), len(context), len(replay), a, state["epoch"]); continue
        x, y, cov = sft_batch(rich, context, replay, tok, a, sched, cursor)
        opt.zero_grad(set_to_none=True); z = loss(model, x, y); z.backward(); grad_norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), a.grad_clip).detach().item()); opt.step()
        state["batchCursor"] += 1; state["updates"] += 1; state["richSeen"] += cov["rich"]; state["contextSeen"] += cov["context"]; state["replaySeen"] += cov["replay"]
        state["answerTokens"] += cov["answerTokens"]; state["supervisedAnswerTokens"] += cov["supervisedAnswerTokens"]; used += 1
        if state["updates"] == 1 or state["updates"] % 10 == 0:
            ratio = state["supervisedAnswerTokens"] / max(1, state["answerTokens"])
            print(f"SFT_V3_V2 epoch={epoch+1}/{a.epochs} batch={cursor+1}/{total_batches} loss={z.detach().item():.6f} gradNorm={grad_norm:.6f} richSeen={state['richSeen']} responseCoverage={ratio:.6f}", flush=True)
        if a.checkpoint_every_batches and state["updates"] % a.checkpoint_every_batches == 0:
            p = ckdir / checkpoint_name(state); side = cpwrite(p, model, opt, config, state, initial_validation, sched); print(f"CHECKPOINT_V3_SFT_V2 path={p} sha256={side['checkpointSha256']}", flush=True)

    if state["epoch"] < a.epochs:
        p = ckdir / checkpoint_name(state); side = cpwrite(p, model, opt, config, state, initial_validation, sched); print(f"PAUSED_V3_SFT_V2 path={p} sha256={side['checkpointSha256']}", flush=True); return 3

    final_validation = evalv(model, val, tok, a); out = Path(a.output_dir)
    fp32 = out / "staging/micro-v3-sft-v2-fp32.ndgm"; q8 = out / "staging/micro-v3-sft-v2-q8.ndgm"; q4 = out / "staging/micro-v3-sft-v2-q4.ndgm"
    fsha = export(model, fp32, "fp32"); q8sha = export(model, q8, "q8"); q4sha = export(model, q4, "q4")
    report = {
        "schema": SCHEMA_REPORT, "status": "EXPERIMENTAL_NOT_PROMOTED", "config": config, "packingStats": stats,
        "initialValidationLoss": initial_validation, "finalValidationLoss": final_validation, "validationItems": len(val), "state": state,
        "modelStateSha256": th(model.state_dict().items()), "optimizerStateSha256": oh(opt),
        "stagedFp32": {"path": str(fp32), "sha256": fsha, "bytes": fp32.stat().st_size},
        "stagedQ8": {"path": str(q8), "sha256": q8sha, "bytes": q8.stat().st_size},
        "stagedQ4": {"path": str(q4), "sha256": q4sha, "bytes": q4.stat().st_size}, "promotionAuthorized": False,
    }
    out.mkdir(parents=True, exist_ok=True); (out / "TRAINING_REPORT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    term_sched = schedule(len(rich), len(context), len(replay), a, max(0, a.epochs - 1)); cpwrite(ckdir / "v3-sft-v2-terminal.pt", model, opt, config, state, initial_validation, term_sched)
    print(f"TRAINING_V3_SFT_V2_TERMINAL_NOT_PROMOTED validation={final_validation:.6f} updates={state['updates']} modelStateSha256={report['modelStateSha256']}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
