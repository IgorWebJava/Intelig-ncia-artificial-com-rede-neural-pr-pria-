<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 111 — Module Testing Standard V7.3

Every NeuralDesk module owns its test suite.

```text
modules/<module>/tests/
```

A test suite is part of the module replacement contract.

Required layers:

1. automated static/contract tests;
2. browser visual tests;
3. functional mechanics scenarios;
4. API/database/event future integration scenarios;
5. security/governance scenarios;
6. responsive/multimodal scenarios;
7. replacement/rollback scenarios;
8. fixtures;
9. acceptance matrix;
10. generated reports.
