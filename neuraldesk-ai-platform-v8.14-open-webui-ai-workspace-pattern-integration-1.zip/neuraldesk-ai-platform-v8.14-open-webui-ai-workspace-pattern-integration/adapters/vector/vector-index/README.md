<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.vector.vector-index

Replaceable adapter template.

Provides:
- `vector.search.v1`

Domain modules must never import this adapter implementation directly.
Binding occurs through the corresponding platform gateway/registry.
