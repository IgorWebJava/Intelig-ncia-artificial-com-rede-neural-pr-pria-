# Current AI Workspace Platform — V8.14

Profile: `open-webui-ai-workspace-patterns-v1`.

The workspace layer coordinates model presets, utility models, multi-model conversations, Notes, Channels, knowledge federation/retrieval, native tool injection, extension isolation, authorization, notifications/timers, local/offline provider experience and streaming.

## Architectural rule
`workspace intent → stable capability → authorization/policy → replaceable runtime provider`. Open WebUI is a research source, not a runtime dependency.

## Truth boundary
The UI surfaces are implemented as template contracts. Neural Engine execution remains NOT_IMPLEMENTED.
