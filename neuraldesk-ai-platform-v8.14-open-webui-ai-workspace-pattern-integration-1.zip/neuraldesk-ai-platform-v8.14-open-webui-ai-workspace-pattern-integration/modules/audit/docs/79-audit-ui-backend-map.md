<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 79 — Audit UI → Backend Map

| UI | Serviço futuro |
|---|---|
| Live Events | Event Stream |
| Audit Explorer | Audit Query Service |
| Trace Explorer | Distributed Tracing Backend |
| Agent Audit | Agent Runtime Telemetry |
| Tool Audit | Tool Gateway Audit |
| Security | Security Event Service |
| Approvals | Approval Audit Service |
| System Changes | Change Management |
| Console | Audit Query API |
| Integrity | Integrity Verification Service |
| Retention | Archive/Retention Service |
| Settings | Audit Policy Service |

Tecnologia não é imposta pelo template.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
