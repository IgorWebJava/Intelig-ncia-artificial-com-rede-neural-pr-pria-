#!/usr/bin/env python3
import argparse, math, struct
from pathlib import Path

V=512; D=320; L=10; QH=10; KVH=2; HD=32; K=64; F=896; CTX=256; PARAMS=11229760; H=128

def fnv(data: bytes) -> int:
    h=1469598103934665603
    for b in data:
        h ^= b; h=(h*1099511628211)&0xffffffffffffffff
    return h

def weights():
    w=[]
    # Embeddings: strong deterministic near-one-hot-ish code. Quantization-friendly grid.
    for t in range(V):
        for d in range(D):
            v = 0.0
            if d == (t % D): v = 0.84
            if d == ((t*7+3) % D): v += 0.28
            if d == ((t*13+11) % D): v -= 0.14
            w.append(v)
    for layer in range(L):
        w += [1.0]*D
        # Q/K/V/O identity-like maps with bounded scales
        for r in range(D):
            for c in range(D): w.append(0.14 if r==c else 0.0)
        for r in range(K):
            for c in range(D): w.append(0.14 if c==(r + layer*3)%D else 0.0)
        for r in range(K):
            for c in range(D): w.append(0.12 if c==(r + layer*5)%D else 0.0)
        for r in range(D):
            for c in range(D): w.append(0.12 if r==c else 0.0)
        w += [1.0]*D
        for r in range(F):
            for c in range(D): w.append(0.08 if c==(r% D) else 0.0)
        for r in range(D):
            for c in range(F): w.append(0.07 if c==(r % F) else 0.0)
        for r in range(F):
            for c in range(D): w.append(0.06 if c==((r*3+layer)%D) else 0.0)
    w += [1.0]*D
    assert len(w)==PARAMS, len(w)
    return w

def encode(ws, fmt):
    if fmt=='fp32':
        raw=b''.join(struct.pack('<f',x) for x in ws)
        return raw,1,0,0,len(raw)
    block=64; scales=[]; qs=[]; limit=127 if fmt=='q8' else 7
    for i in range(0,len(ws),block):
        chunk=ws[i:i+block]; mx=max(abs(x) for x in chunk) if chunk else 0.0; scale=(mx/limit) if mx>0 else 1.0; scales.append(scale); qs.extend(max(-limit,min(limit,round(x/scale))) for x in chunk)
    if fmt=='q8': data=bytes((q & 0xff) for q in qs); code=2
    else:
        out=bytearray()
        for i in range(0,len(qs),2):
            a=qs[i]+8; b=(qs[i+1]+8) if i+1<len(qs) else 8; out.append((a&15)|((b&15)<<4))
        data=bytes(out); code=3
    scale_bytes=b''.join(struct.pack('<f',x) for x in scales)
    return data+scale_bytes,code,block,len(scales),len(data)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out-dir',required=True)
    args=ap.parse_args(); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    ws=weights()
    for name in ('fp32','q8','q4'):
        payload,fmt,block,scale_count,data_bytes=encode(ws,name)
        h=bytearray(H); h[:8]=b'NDGMV005'
        vals=[H,0x01020304,fmt,V,D,L,QH,KVH,F,CTX,PARAMS,len(payload)]
        for i,v in enumerate(vals): struct.pack_into('<I',h,8+i*4,v)
        struct.pack_into('<f',h,56,0.0)
        struct.pack_into('<I',h,60,block)
        struct.pack_into('<Q',h,64,fnv(payload))
        struct.pack_into('<I',h,72,scale_count)
        struct.pack_into('<I',h,76,data_bytes)
        path=out/f'fixture-{name}.ndgm'; path.write_bytes(h+payload)
        print(name,path,len(h)+len(payload),f'fnv={fnv(payload):016x}',f'block={block}',f'scales={scale_count}')
if __name__=='__main__': main()
