<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# PostgreSQL & Data Ownership

    Skill ID: `neuraldesk.data-platform.v1`

    ## Category

    `data`

    ## Introduced

    `V6.9`

    ## Required development capabilities

    - `sql.postgresql.design.v1`
- `data.ownership.design.v1`
- `security.threat-model.v1`

    ## Used by

    - `chat`
- `training`
- `knowledge`
- `tools`
- `settings`
- `audit`
- `system-config`

    ## Related project artifacts

    - `database/`
- `modules/<module>/data/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
