<!-- neuraldesk-documentation-sync: V8.8 -->

# Acceptance Matrix — System Audit, Trace & Control Center

Module: `neuraldesk.audit`

| Area | Test asset | Executable now | Release expectation |
|---|---|---:|---|
| Architecture | automated/test_architecture.py | Yes | PASS |
| Contracts & capabilities | automated/test_contracts.py | Yes | PASS |
| UI semantics | automated/test_ui_semantics.py | Yes | PASS |
| Security & data boundary | automated/test_security_data.py | Yes | PASS |
| Responsive & multimodal | automated/test_responsive_multimodal.py | Yes | PASS |
| Compatibility | automated/test_compatibility.py | Yes | PASS |
| Test assets integrity | automated/test_test_assets.py | Yes | PASS |
| Browser visual | visual/run_visual_tests.py | Yes, with Playwright | PASS |
| Functional mechanics | scenarios/functional-mechanics.json | Mixed | Specified / PASS where executable |
| API/DB/Event integration | scenarios/integration-e2e.json | Backend required | Must pass before production backend release |
| Security governance | scenarios/security-governance.json | Mixed | Must pass before production backend release |
| Replacement/rollback | scenarios/replacement-resilience.json | Runtime required | Must pass before module replacement |