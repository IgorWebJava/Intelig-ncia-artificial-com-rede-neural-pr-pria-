import math
from typing import Dict, Any
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class OctaveRegulatorPlugin(BaseQcnnPlugin):
    """
    Módulo 4: Regulador de Oitavas e Zoom Cognitivo Recursivo (KODEX ALEPH v12.5).
    Mede a densidade e complexidade do prompt para modular a profundidade cognitiva (Oitavas 1 a 5)
    e escalar o cálculo harmônico.
    """
    def __init__(self):
        self._enabled = True
        self.palavras_chave_complexidade = [
            "como", "por que", "porque", "explique", "analise", "descreva",
            "detalhe", "compare", "relacione", "fundamento", "profundo"
        ]

    @property
    def plugin_id(self) -> str:
        return "octave_regulator"

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @is_enabled.setter
    def is_enabled(self, value: bool):
        self._enabled = value

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt_lower = context.prompt.lower()
        palavras = prompt_lower.split()
        num_palavras = len(palavras)

        # Cálculo da Oitava Cognitiva baseada no observador (Prompt)
        oitava = 1
        matches = sum(1 for kw in self.palavras_chave_complexidade if kw in prompt_lower)
        if matches > 0:
            oitava += min(2, matches)
        if num_palavras > 8:
            oitava += 1
        if num_palavras > 15:
            oitava += 1

        oitava = min(5, max(1, oitava))
        context.metadata["oitava_cognitiva"] = oitava

        # Modulação de ressonância pela oitava (escala áurea 1.618)
        fator_escala = math.pow(1.61803398875, (oitava - 1) * 0.5)
        context.metadata["fator_escala_oitava"] = round(fator_escala, 4)

        if context.total_frequency_hz > 0:
            context.total_frequency_hz = round(context.total_frequency_hz * fator_escala, 2)

        return context
