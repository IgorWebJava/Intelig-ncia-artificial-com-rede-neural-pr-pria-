<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# AI Multimodal Platform — V7.1

## Principle

No domain module calls an AI provider SDK directly.

```text
Chat / Training / Knowledge / Agents
→ AI Capability Fabric
→ Model Router
→ Provider Adapter
→ Model
```

## Capability families

```text
ai.text.generate.v1
ai.vision.understand.v1
ai.audio.transcribe.v1
ai.audio.synthesize.v1
ai.image.generate.v1
ai.image.understand.v1
ai.video.understand.v1
ai.embedding.create.v1
ai.rerank.v1
ai.structured_output.v1
ai.tool_calling.v1
ai.realtime.v1
ai.evaluate.v1
```

## Canonical request

The common request schema supports:

- text
- image
- audio
- video
- document
- structured data
- tool result

Providers translate this canonical envelope through adapters.

## Model replacement

Modules ask for a profile/capability set such as `reasoning`, `research`, `agent` or `multimodal`.
The router binds that profile to the currently approved adapter/model.

Provider/model replacement therefore does not require changes inside consuming modules.
