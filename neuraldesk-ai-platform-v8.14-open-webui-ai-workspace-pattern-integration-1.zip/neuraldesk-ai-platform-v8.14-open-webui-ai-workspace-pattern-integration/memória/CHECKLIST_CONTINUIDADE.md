# Checklist de Continuidade — V8.7

- [ ] Ler `ESTADO_ATUAL.json`.
- [ ] Ler `docs/CURRENT_STATE.md` e `SOURCE_OF_TRUTH.md`.
- [ ] Identificar módulo(s) de interface afetados.
- [ ] Identificar módulo(s) Neural Engine responsáveis.
- [ ] Preservar truth boundary UI vs engine.
- [ ] Atualizar contracts/registries/traceability quando aplicável.
- [ ] Atualizar docs atuais dos módulos afetados.
- [ ] Atualizar AI handoff, memória e skills.
- [ ] Atualizar inventário documental.
- [ ] Executar todos os release gates.
- [ ] Regenerar preview se houver mudança visual.
- [ ] Criar nova versão sem sobrescrever anterior.
- [ ] Entregar um único ZIP completo.


## Frontier readiness

- [ ] Read `docs/frontier-readiness/MASTER_EVOLUTION_PROMPT.md`.
- [ ] Determine owner engine module and wave P00–P08.
- [ ] Read module `FRONTIER_READINESS.md`.
- [ ] Establish baseline and acceptance benchmark.
- [ ] Do not label target capability implemented without executable evidence.
- [ ] Do not label NeuralDesk superior without reproducible evidence.

## V8.8 — Kimi K3 Engineering Research Integration

Research from `FareedKhan-dev/kimi-k3-in-c`, the official `MoonshotAI/Kimi-K3` repository and the Kimi K3 technical report was integrated as provider-agnostic documentation. The Neural Engine remains non-executable. Key additions: memory-aware weight streaming, expert-weight cache, strict model artifact validation, deterministic/reference parity, KDA, Attention Residuals, Stable LatentMoE, expert balance training and long-horizon agentic RL.

## V8.9 — Omni-Modal Continuity Checks

- [ ] Read `neural-engine/research/qwen3-omni-2026/`.
- [ ] Preserve semantic/expression separation.
- [ ] Validate backend modality matrix before claims.
- [ ] Keep Qwen mechanisms provider-agnostic.
- [ ] Do not claim published Qwen latency/benchmarks as NeuralDesk results.


## V8.11 — Cooperative Non-Regression
Interface and Neural Engine documentation now evolve together. Preserve V8.10 semantics, extend capabilities additively, and bridge every future engine module to an interface owner. Engine remains NOT_IMPLEMENTED.


## V8.13 Coding Intelligence continuity
- [ ] Read `neural-engine/research/claw-code-2026/README.md`.
- [ ] Read `docs/architecture/CURRENT_CODING_INTELLIGENCE.md`.
- [ ] Preserve the V8.12 non-regression baseline.
- [ ] Never widen workspace/shell/file permissions from model text.
- [ ] Require Task Packet + Green Contract + bounded recovery for future coding workloops.
- [ ] Keep root aliases as redirects.

## V8.14 additions
- Preserve `open-webui-ai-workspace-patterns-v1` and V8.13 semantic baseline.
- Re-verify Open WebUI license/release before future implementation.
- Never adopt legacy Pipelines as a new dependency.
- Isolate extensions and enforce access at every server boundary.
