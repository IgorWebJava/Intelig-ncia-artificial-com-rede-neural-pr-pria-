<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.cache.redis-compatible

Replaceable adapter template.

Provides:
- `cache.keyvalue.v1`

Domain modules must never import this adapter implementation directly.
Binding occurs through the corresponding platform gateway/registry.
