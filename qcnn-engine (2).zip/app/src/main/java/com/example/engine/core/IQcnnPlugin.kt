package com.example.engine.core

import java.util.Locale

interface IQcnnPlugin {
    val pluginId: String
    var isEnabled: Boolean

    fun execute(context: QcnnExecutionContext): QcnnExecutionContext
}

data class QcnnExecutionContext(
    val prompt: String,
    var targetSeed: String = "Alef",
    val chain: MutableList<String> = mutableListOf(),
    var totalFrequencyHz: Double = 0.0,
    var finalState: String = "00 (Vácuo / Superposição)",
    var latencyMs: Double = 0.0,
    val activeNodes: MutableMap<String, NoTernario> = mutableMapOf(),
    val metadata: MutableMap<String, Any> = mutableMapOf(),
    var customResponse: String = ""
) {
    fun toCollapseResult(): CollapseResult {
        val arvoreStr = if (chain.isNotEmpty()) chain.joinToString(" → ") else targetSeed
        val respostaTexto = if (customResponse.isNotEmpty()) {
            customResponse
        } else {
            "Sinal interpretado com sucesso pelo Núcleo 3. A semente '$targetSeed' disparou " +
                    "um pulso de ressonância harmônica. O filtro de adjacência semântica impediu a " +
                    "dissonância e estabilizou a seguinte árvore de manifestação real: $arvoreStr."
        }

        return CollapseResult(
            resposta = respostaTexto,
            arvore = arvoreStr,
            estado = finalState,
            frequencia = String.format(Locale.US, "%.2f Hz", totalFrequencyHz),
            latencia = String.format(Locale.US, "%.3fms", latencyMs.coerceAtLeast(0.005)),
            metadata = metadata.toMap()
        )
    }
}
