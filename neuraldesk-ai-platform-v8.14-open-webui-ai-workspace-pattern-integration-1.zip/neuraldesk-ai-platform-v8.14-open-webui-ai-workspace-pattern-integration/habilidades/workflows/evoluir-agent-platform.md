<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Evoluir Agent Platform

1. Read memória/ + habilidades/.
2. Read `modules/agents/` manifest/contracts/ownership/docs/tests.
3. Classify change: agent definition, runtime skill, project, tool binding, knowledge, model, team, workflow, run, evaluation, lifecycle or policy.
4. Reuse existing capabilities; never duplicate Tool/Knowledge/Training/Project data.
5. Version public contracts/events when breaking.
6. Preserve AI provider isolation and data ownership.
7. Update Agent Studio UI, tests, docs, Audit/Operations/System Config integration if needed.
8. Update memory/skills.
9. Run all release gates + visual tests.
