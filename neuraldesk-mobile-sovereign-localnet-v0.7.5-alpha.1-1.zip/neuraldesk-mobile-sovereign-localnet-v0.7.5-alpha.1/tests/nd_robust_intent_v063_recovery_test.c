#include "nd_assistant.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int has(const char *s, const char *needle) {
    return s && needle && strstr(s, needle) != NULL;
}

static int need(const char *name, const char *out, const char *needle) {
    if (has(out, needle)) return 0;
    fprintf(stderr, "%s missing [%s] in [%s]\n", name, needle, out ? out : "<null>");
    return 1;
}

static int reject(const char *name, const char *out, const char *needle) {
    if (!has(out, needle)) return 0;
    fprintf(stderr, "%s unexpectedly contains [%s] in [%s]\n", name, needle, out);
    return 1;
}

static int meta_bounded(const char *name, const NDAnswerMeta *m) {
    if (isfinite(m->confidence) && isfinite(m->margin) &&
        m->confidence >= 0.0f && m->confidence <= 1.0f &&
        m->margin >= 0.0f && m->margin <= 1.0f) return 0;
    fprintf(stderr, "%s public metadata out of [0,1]: confidence=%f margin=%f\n",
            name, m->confidence, m->margin);
    return 1;
}

int main(int argc, char **argv) {
    if (argc != 6) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION OPEN_SHARD\n", argv[0]);
        return 2;
    }
    const char *memory_path = "/tmp/neuraldesk-v063-recovery-memory.ndm";
    remove(memory_path);
    NDAssistant a;
    NDAnswerMeta m;
    char err[256];
    char out[65536];
    int bad = 0;
    int cases = 0;

    if (nd_assistant_load_ex(&a, argv[1], argv[2], argv[3], argv[4], argv[5],
                             memory_path, err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }

#define ASK(NAME, Q, C) do { \
        memset(&m, 0, sizeof(m)); \
        if (nd_assistant_answer(&a, (Q), (C), 1, out, sizeof(out), &m, err, sizeof(err))) { \
            fprintf(stderr, NAME " runtime error: %s\n", err); \
            bad++; \
        } \
        bad += meta_bounded(NAME, &m); \
        cases++; \
    } while (0)

    ASK("capabilities", "O que você consegue fazer localmente?", NULL);
    bad += need("capabilities", out, "local");
    bad += need("capabilities", out, "RAG");

    ASK("inference", "O que acontece durante a inferência de uma rede neural?", NULL);
    bad += need("inference", out, "inferência");
    bad += reject("inference", out, "internet");

    ASK("owner-bridge", "Quem é responsável pelo projeto Delta-8?",
        "O projeto Delta-8 está em fase piloto. A engenheira responsável é Bianca.");
    bad += need("owner-bridge", out, "Bianca");
    bad += reject("owner-bridge", out, "Resposta direta: Delta-8");

    ASK("memory-write-a", "Lembre que o projeto Vega-77 é coordenado por Lara.", NULL);
    ASK("memory-write-b", "Lembre também que o projeto Vega-77 é coordenado por Bruno.", NULL);
    ASK("memory-conflict", "Quem coordena o projeto Vega-77?", NULL);
    bad += need("memory-conflict", out, "conflit");
    bad += reject("memory-conflict", out, "Resposta direta: Lara");
    bad += reject("memory-conflict", out, "Resposta direta: Bruno");
    cases -= 2; /* writes are setup, not independent contract cases */

    ASK("rag-acronym", "O que a sigla RAG quer dizer?", NULL);
    bad += need("rag-acronym", out, "Retrieval-Augmented Generation");
    bad += reject("rag-acronym", out, "internet");

    ASK("quant-kv", "Quantização e KV cache são a mesma coisa?", NULL);
    bad += need("quant-kv", out, "Quantização");
    bad += need("quant-kv", out, "KV cache");

    ASK("quant-universal", "INT4 sempre preserva exatamente a qualidade FP32?", NULL);
    bad += need("quant-universal", out, "Não");
    bad += need("quant-universal", out, "degrad");

    ASK("non-entailment", "Se uma técnica pode ser usada, isso prova que todas as alternativas estão erradas?", NULL);
    bad += need("non-entailment", out, "não prova");

    ASK("dynamic-event", "Quem venceu a Copa do Brasil de 2026?", NULL);
    bad += need("dynamic-event", out, "temporal");
    bad += reject("dynamic-event", out, "campeão é");

    ASK("summary", "Resuma os últimos oito turnos da nossa conversa.", NULL);
    bad += reject("summary", out, "Não sei com segurança");
    bad += need("summary", out, "RAG");

    ASK("metadata", "Qual é a capital do país fictício Ventúria-908?", NULL);
    bad += need("metadata", out, "Não sei com segurança");

#undef ASK
    nd_assistant_free(&a);
    remove(memory_path);
    if (bad) {
        fprintf(stderr, "robust intent v063 recovery failures=%d cases=%d\n", bad, cases);
        return 1;
    }
    if (cases != 11) {
        fprintf(stderr, "robust intent v063 recovery case-count=%d expected=11\n", cases);
        return 1;
    }
    puts("robust_intent_v063_recovery PASS cases=11");
    return 0;
}
