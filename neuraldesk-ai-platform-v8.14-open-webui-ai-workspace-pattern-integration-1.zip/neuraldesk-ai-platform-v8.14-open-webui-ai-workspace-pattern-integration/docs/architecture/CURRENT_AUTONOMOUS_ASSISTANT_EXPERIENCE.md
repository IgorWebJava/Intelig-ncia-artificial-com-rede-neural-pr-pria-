<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.chat; current: docs/architecture/CURRENT_AUTONOMOUS_ASSISTANT_EXPERIENCE.md -->
# Current Autonomous Assistant Experience Template

Profile: `autonomous-assistant-experience-v1`  
Scope: `template-ui-only`

Chat visually represents Mission Control, Plan/Tasks, Activity, Context/Memory, Checkpoints, project pause/resume, modes, multimodal composer and Artifact Workspace. Local JS may switch/demo interface states only. No autonomous planner/orchestrator, real agents/tools/web execution, persistent memory, background task engine or continuous microphone capture is implemented.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
