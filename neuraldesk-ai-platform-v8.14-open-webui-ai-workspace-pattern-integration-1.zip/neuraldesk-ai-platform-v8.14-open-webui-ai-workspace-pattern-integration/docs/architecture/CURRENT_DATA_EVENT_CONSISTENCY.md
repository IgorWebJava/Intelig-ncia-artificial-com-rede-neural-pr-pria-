<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.data; current: docs/architecture/CURRENT_DATA_EVENT_CONSISTENCY.md -->
# Current Data & Event Consistency

PostgreSQL is relational persistent SSOT. Every mutable dataset has one authoritative owner. Cross-module integration uses public APIs/events; distributed durable changes use state + Transactional Outbox in the same transaction followed by event publication to idempotent consumers.

Current browser template does not connect directly to databases.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
