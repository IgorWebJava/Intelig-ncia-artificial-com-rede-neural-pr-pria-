#!/usr/bin/env python3
from pathlib import Path
import hashlib,tempfile
import numpy as np
import sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'training'))
from checkpoint_manager import save_checkpoint,load_checkpoint

def run(w,m,start,end):
 for step in range(start,end):
  g=(w*0.125 + (step+1)*0.001).astype(np.float64); m=0.9*m+g; w=w-0.01*m
 return w,m
bind={'architecture':'fixture-v1','corpusSha256':hashlib.sha256(b'corpus-v1').hexdigest(),'tokenizerSha256':hashlib.sha256(b'tok-v1').hexdigest(),'configSha256':hashlib.sha256(b'cfg-v1').hexdigest()}
w0=np.arange(16,dtype=np.float64).reshape(4,4)/17.0;m0=np.zeros_like(w0)
full_w,full_m=run(w0.copy(),m0.copy(),0,40)
with tempfile.TemporaryDirectory() as td:
 d=Path(td); w,m=run(w0.copy(),m0.copy(),0,17); p=save_checkpoint(d,phase='train',step=17,model={'w':w},optimizer={'m':m},bindings=bind)
 meta,model,opt=load_checkpoint(p,expected_bindings=bind); assert meta['step']==17
 rw,rm=run(model['w'],opt['m'],17,40); assert np.array_equal(rw,full_w) and np.array_equal(rm,full_m)
 bad=dict(bind);bad['configSha256']='0'*64
 try:load_checkpoint(p,expected_bindings=bad);raise AssertionError('drift accepted')
 except ValueError:pass
 data=bytearray(p.read_bytes());data[len(data)//2]^=1;p.write_bytes(data)
 try:load_checkpoint(p,expected_bindings=bind);raise AssertionError('tamper accepted')
 except ValueError:pass
print('TRAINING_CHECKPOINT PASS uninterrupted_equals_resume=true drift_rejected=true tamper_rejected=true transient_only=true')
