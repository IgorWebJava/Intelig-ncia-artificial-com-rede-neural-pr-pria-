<!-- neuraldesk-documentation-sync: V8.11 -->

# Test Plan — App Shell

## Objective

Prove that `neuraldesk.app-shell` can evolve, integrate and be replaced without violating NeuralDesk architecture.

## Test pyramid

```text
Static / contract tests        — run now
Browser visual tests           — run now with Playwright
Integration / API / DB tests   — run when backend exists
Event / distributed tests      — run when event platform exists
AI / agent / tool E2E tests    — run when runtime exists
Replacement / canary tests     — run before switching production binding
```

## Functional mechanics in scope

- Launch registered modules from the App Shell
- Resolve legacy route aliases to canonical module UI
- Expose all principal modules in navigation
- Respect feature/module availability supplied by Module Registry
- Preserve adaptive layout across device profiles
- Preserve keyboard/remote focus visibility
- Remain functional when a module binding is replaced

## Device coverage

```text
Phone      390x844
Tablet     768x1024
Notebook   1366x768
Desktop/TV 1920x1080
TV/4K      3840x2160
```

## Release rule

This test package is owned by the module and must travel with it.


## Engine Bridge V8.11
Non-regression, truth-boundary and bridge-marker coverage is executable through `test_engine_bridge.py` plus `scenarios/engine-ui-bridge-v811.json`.
