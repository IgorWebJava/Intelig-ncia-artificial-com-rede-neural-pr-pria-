import sys, unittest, re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class UIRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx=TestContext(__file__); cls.rt=cls.ctx.module_root/'ui'/'runtime'/'module-runtime.js'; cls.js=cls.rt.read_text(encoding='utf-8')
    def test_runtime_manifest(self):
        rt=self.ctx.manifest.get('ui_runtime',{}); self.assertEqual(rt.get('profile'),'workspace-runtime-v2'); self.assertTrue(rt.get('module_owned')); self.assertFalse(rt.get('shared_global_runtime_dependency')); self.assertFalse(rt.get('backend_calls_in_template'))
    def test_runtime_entrypoint_exists(self): self.assertTrue(self.rt.exists()); self.assertGreater(len(self.js),2000)
    def test_core_interactions_present(self):
        for token in ['open-command','open-create','open-tasks','open-notifications','data-tab','data-filter-input','keydown','Escape']:
            with self.subTest(token=token): self.assertIn(token,self.js)
    def test_runtime_has_no_provider_or_database_sdk(self):
        for pattern in [r'postgres(?:ql)?://',r'openai\.',r'anthropic\.',r'google\.generative',r'api[_-]?key\s*=']:
            with self.subTest(pattern=pattern): self.assertIsNone(re.search(pattern,self.js,re.I))
    def test_runtime_does_not_fetch_backend_in_template(self):
        self.assertNotRegex(self.js,r'\bfetch\s*\('); self.assertNotRegex(self.js,r'XMLHttpRequest|WebSocket\s*\(')
if __name__=='__main__': unittest.main()
