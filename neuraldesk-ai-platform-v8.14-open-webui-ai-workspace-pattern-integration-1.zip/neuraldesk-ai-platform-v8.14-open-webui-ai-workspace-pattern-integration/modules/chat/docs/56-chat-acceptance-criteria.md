<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 56 — Critérios de Aceitação da V6.4

- [x] Chat possui layout de 3 áreas.
- [x] Sidebar possui projects/recent/pinned.
- [x] Header possui model/mode/sources.
- [x] Composer suporta visual multimodal.
- [x] Mensagens suportam attachments.
- [x] AI message possui citations.
- [x] Existe Agent Activity.
- [x] Existe Tool Call.
- [x] Existe Human Approval.
- [x] Existe Research Progress.
- [x] Existe Artifact.
- [x] Existe Context Inspector.
- [x] Existe Project Memory visual.
- [x] Existe Context Usage.
- [x] Existe Prompt Library.
- [x] Existe empty/new chat state.
- [x] Existe branch visual.
- [x] Existe processing/stop state.
- [x] Responsivo.
- [x] HTML + CSS only.
- [x] 0 JavaScript.
- [x] `modules/chat/ui/chat.html` carrega somente `modules/chat/ui/chat.css`.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
