<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Assistant Persistent Memory / Personal Context

    Tool ID: `tool.project-memory-service`

    ## Role in NeuralDesk development

    Remember durable user/project continuity across conversations.

    ## Current implementations

    - `bio memory`
- `personal_context`

    ## Capabilities provided

    - `project.memory.read.v1`
- `project.memory.update.v1`

    ## Constraints

    - Project portability must never depend only on assistant memory.
- The file-based memória/ and habilidades/ folders remain the portable source of truth.

    ## Portable alternatives

    - project knowledge base
- repository memory files
- team wiki

    ## Rule

    The capability is more important than the tool name. A future AI may replace this tool if it provides equivalent capabilities and passes the relevant quality gates.
