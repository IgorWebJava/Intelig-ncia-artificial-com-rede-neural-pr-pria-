#include "nd_context_qa.h"

#include <float.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void seterr(char *e, size_t n, const char *fmt, ...) {
    if (!e || !n) return;
    va_list a;
    va_start(a, fmt);
    vsnprintf(e, n, fmt, a);
    va_end(a);
}

static int mul_ok(size_t a, size_t b, size_t *o) {
    if (a && b > SIZE_MAX / a) return 0;
    *o = a * b;
    return 1;
}

size_t nd_context_qa_expected_floats(const NDContextQAHeader *h) {
    size_t v = h->vocab_size, d = h->embedding_dim, z = h->hidden_dim;
    size_t w = (size_t)2u * h->radius + 1u;
    size_t total = v * d + w * d * z + d * z + z + z + 1u + z + 1u;
    if (h->version == ND_QA_VERSION) total += (size_t)ND_RELATION_COUNT * z;
    return total;
}

void nd_context_qa_free(NDContextQA *q) {
    if (!q) return;
    free(q->storage);
    memset(q, 0, sizeof(*q));
}

int nd_context_qa_load(const char *path, NDContextQA *q, char *e, size_t ec) {
    if (!path || !q) {
        seterr(e, ec, "invalid qa arguments");
        return -1;
    }
    memset(q, 0, sizeof(*q));
    FILE *f = fopen(path, "rb");
    if (!f) {
        seterr(e, ec, "cannot open qa model");
        return -1;
    }
    if (fread(&q->h, sizeof(q->h), 1, f) != 1) {
        seterr(e, ec, "short qa header");
        fclose(f);
        return -1;
    }
    NDContextQAHeader *h = &q->h;
    if (h->magic != ND_QA_MAGIC ||
        (h->version != ND_QA_VERSION_V1 && h->version != ND_QA_VERSION) ||
        h->vocab_size != 259u || !h->embedding_dim || !h->hidden_dim ||
        h->radius > 64u || !h->max_span_bytes || h->max_span_bytes > 4096u) {
        seterr(e, ec, "invalid qa header");
        fclose(f);
        return -1;
    }
    q->storage_floats = nd_context_qa_expected_floats(h);
    size_t bytes;
    if (!mul_ok(q->storage_floats, sizeof(float), &bytes)) {
        seterr(e, ec, "qa model too large");
        fclose(f);
        return -1;
    }
    q->storage = malloc(bytes);
    if (!q->storage) {
        seterr(e, ec, "oom qa weights");
        fclose(f);
        return -1;
    }
    if (fread(q->storage, sizeof(float), q->storage_floats, f) != q->storage_floats) {
        seterr(e, ec, "truncated qa weights");
        nd_context_qa_free(q);
        fclose(f);
        return -1;
    }
    if (fgetc(f) != EOF) {
        seterr(e, ec, "trailing qa bytes rejected");
        nd_context_qa_free(q);
        fclose(f);
        return -1;
    }
    fclose(f);

    float *p = q->storage;
    size_t v = h->vocab_size, d = h->embedding_dim, z = h->hidden_dim;
    size_t w = (size_t)2u * h->radius + 1u;
    q->embedding = p;
    p += v * d;
    q->window = p;
    p += w * d * z;
    q->wq = p;
    p += d * z;
    if (h->version == ND_QA_VERSION) {
        q->relation_embedding = p;
        p += (size_t)ND_RELATION_COUNT * z;
    }
    q->bias = p;
    p += z;
    q->w_start = p;
    p += z;
    q->b_start = *p++;
    q->w_end = p;
    p += z;
    q->b_end = *p++;
    if ((size_t)(p - q->storage) != q->storage_floats) {
        seterr(e, ec, "qa layout mismatch");
        nd_context_qa_free(q);
        return -1;
    }
    return 0;
}

static void project_add(float *out, const float *x, const float *w, size_t d, size_t h) {
    for (size_t i = 0; i < d; i++) {
        float xi = x[i];
        const float *row = w + i * h;
        for (size_t j = 0; j < h; j++) out[j] += xi * row[j];
    }
}

static float dot(const float *a, const float *b, size_t n) {
    double s = 0.0;
    for (size_t i = 0; i < n; i++) s += (double)a[i] * b[i];
    return (float)s;
}

static void align_utf8(const unsigned char *c, size_t n, size_t *s, size_t *e) {
    while (*s > 0 && (c[*s] & 0xc0u) == 0x80u) (*s)--;
    while (*e + 1u < n && (c[*e + 1u] & 0xc0u) == 0x80u) (*e)++;
}

int nd_context_qa_extract_relation(const NDContextQA *q, uint32_t relation_id,
                                   const char *question, const char *context,
                                   char *out, size_t outcap, float *score,
                                   char *e, size_t ec) {
    if (!q || !question || !context || !out || !outcap) {
        seterr(e, ec, "invalid qa input");
        return -1;
    }
    size_t qn = strlen(question), cn = strlen(context);
    if (!qn || !cn) {
        seterr(e, ec, "empty question/context");
        return -1;
    }
    if (qn > 2048u || cn > 8192u) {
        seterr(e, ec, "qa input exceeds bounded limits");
        return -1;
    }
    size_t d = q->h.embedding_dim, h = q->h.hidden_dim, r = q->h.radius;
    float *qavg = calloc(d, sizeof(float));
    float *qproj = calloc(h, sizeof(float));
    float *hid = malloc(h * sizeof(float));
    float *sl = malloc(cn * sizeof(float));
    float *el = malloc(cn * sizeof(float));
    if (!qavg || !qproj || !hid || !sl || !el) {
        free(qavg); free(qproj); free(hid); free(sl); free(el);
        seterr(e, ec, "oom qa workspace");
        return -1;
    }
    const unsigned char *qb = (const unsigned char *)question;
    const unsigned char *cb = (const unsigned char *)context;
    for (size_t i = 0; i < qn; i++) {
        const float *x = q->embedding + (size_t)qb[i] * d;
        for (size_t j = 0; j < d; j++) qavg[j] += x[j];
    }
    for (size_t j = 0; j < d; j++) qavg[j] /= (float)qn;
    project_add(qproj, qavg, q->wq, d, h);
    if (q->relation_embedding && relation_id < ND_RELATION_COUNT) {
        const float *re = q->relation_embedding + (size_t)relation_id * h;
        for (size_t j = 0; j < h; j++) qproj[j] += re[j];
    }

    for (size_t pos = 0; pos < cn; pos++) {
        for (size_t j = 0; j < h; j++) hid[j] = q->bias[j] + qproj[j];
        for (int off = -(int)r; off <= (int)r; off++) {
            long src = (long)pos + off;
            if (src < 0 || (size_t)src >= cn) continue;
            size_t wi = (size_t)(off + (int)r);
            const float *x = q->embedding + (size_t)cb[src] * d;
            const float *w = q->window + wi * d * h;
            project_add(hid, x, w, d, h);
        }
        for (size_t j = 0; j < h; j++) hid[j] = tanhf(hid[j]);
        sl[pos] = dot(hid, q->w_start, h) + q->b_start;
        el[pos] = dot(hid, q->w_end, h) + q->b_end;
    }

    size_t si = 0, ei = 0;
    float best = -FLT_MAX;
    for (size_t s = 0; s < cn; s++) {
        size_t maxe = s + q->h.max_span_bytes - 1u;
        if (maxe >= cn) maxe = cn - 1u;
        for (size_t en = s; en <= maxe; en++) {
            float z = sl[s] + el[en] - 0.05f * (float)(en - s);
            if (z > best) {
                best = z;
                si = s;
                ei = en;
            }
        }
    }
    align_utf8(cb, cn, &si, &ei);
    size_t n = ei - si + 1u;
    if (n + 1u > outcap) {
        free(qavg); free(qproj); free(hid); free(sl); free(el);
        seterr(e, ec, "qa answer buffer too small");
        return -1;
    }
    memcpy(out, context + si, n);
    out[n] = 0;
    if (score) *score = best;
    free(qavg); free(qproj); free(hid); free(sl); free(el);
    return 0;
}

int nd_context_qa_extract(const NDContextQA *q, const char *question, const char *context,
                          char *out, size_t outcap, float *score, char *e, size_t ec) {
    return nd_context_qa_extract_relation(q, UINT32_MAX, question, context,
                                          out, outcap, score, e, ec);
}
