#!/usr/bin/env python3
"""Train LocalNet v0.5 shared neural relation classifier.

The same model classifies relation families in both user questions and candidate
evidence sentences.  Grounding remains factorized: this network supplies only a
relation signal; entity, temporal and coverage constraints remain separate.
"""
from __future__ import annotations
import argparse, hashlib, json, random, re, struct, subprocess, sys
from pathlib import Path
import torch
import torch.nn as nn
import torch.nn.functional as F
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context_data import TRAIN_Q, build_context

SEED=507
MAGIC=0x314C524E  # NRL1
VERSION=1
FEAT=2048
HIDDEN=64
RELATIONS=tuple(TRAIN_Q.keys())
UNKNOWN=len(RELATIONS)
RELATION_CUES = {
    "code": ("código", "codigo", "identificador"),
    "color": ("cor",),
    "temp": ("temperatura", "graus celsius", "sensor"),
    "owner": ("responsável", "responsavel", "quem responde por"),
    "status": ("status", "situação", "situacao", "estado atual"),
    "version": ("versão", "versao", "release"),
    "material": ("material", "composição material", "composicao material"),
    "language": ("idioma", "língua", "lingua"),
    "date": ("data", "quando ocorre", "quando está", "quando esta", "calendário", "calendario"),
    "location": ("localização", "localizacao", "onde fica", "em qual local"),
    "capacity": ("capacidade", "comporta"),
    "weight": ("peso", "pesa", "massa"),
    "length": ("comprimento", "quanto mede", "medida de comprimento", "mede"),
    "count": ("quantidade", "unidades", "contagem", "total de unidades"),
    "author": ("autor", "autoria", "escreveu", "quem produziu"),
    "capital": ("capital",),
    "organization": ("organização", "organizacao", "entidade responde", "cuida de", "quem mantém", "quem mantem"),
    "port": ("porta", "endpoint numérico", "endpoint numerico", "escutando"),
    "license": ("licença", "licenca", "licenciamento"),
    "latency": ("latência", "latencia", "tempo de resposta", "demora"),
    "protocol": ("protocolo", "padrão de comunicação", "padrao de comunicacao", "se comunica"),
    "manufacturer": ("fabricante", "quem fabrica", "empresa produziu", "origem industrial"),
    "priority": ("prioridade", "urgência", "urgencia"),
    "region": ("região", "regiao", "zona de implantação", "zona de implantacao"),
    "checksum": ("checksum", "hash", "impressão de integridade", "impressao de integridade"),
}
HASH_OFFSET=32
HASH_DIM=FEAT-HASH_OFFSET


def require_lessons_precheck():
    root=Path(__file__).resolve().parents[1]
    subprocess.run([sys.executable,str(root/'scripts/pre_generation_lessons_check.py')],cwd=root,check=True)

def fnv1a(data:bytes)->int:
    h=2166136261
    for b in data: h=((h^b)*16777619)&0xffffffff
    return h

def normalize(text:str)->bytes:
    raw=text.encode('utf-8'); out=bytearray(); sp=False
    for x in raw:
        if 65<=x<=90: x+=32
        if x in b' \t\r\n':
            if out and not sp: out.append(32)
            sp=True
        else: out.append(x); sp=False
    if out and out[-1]==32: out.pop()
    return bytes(out)

def isword(x:int)->bool: return 48<=x<=57 or 97<=x<=122 or x>=128 or x in (45,95,47,46)

def relation_clean(text:str)->str:
    # Entity ids and numeric values are nuisance variables for relation typing.
    t=re.sub(r'Registro-\d+', ' ENTIDADE ', text, flags=re.IGNORECASE)
    t=re.sub(r'\b\d+(?:[.:-]\d+)*\b', ' NUMERO ', t)
    return t

def features(text:str)->torch.Tensor:
    clean=relation_clean(text); lower=clean.lower()
    b=normalize(clean); v=torch.zeros(FEAT,dtype=torch.float32); words=[]; i=0
    for ri,relation in enumerate(RELATIONS):
        hits=sum(1 for cue in RELATION_CUES[relation] if cue in lower)
        if hits: v[ri]=min(3.0,float(hits))*4.0
    while i<len(b):
        while i<len(b) and not isword(b[i]): i+=1
        j=i
        while j<len(b) and isword(b[j]): j+=1
        if j>i:
            w=b[i:j]; words.append(w)
            v[HASH_OFFSET+fnv1a(b'w'+w)%HASH_DIM]+=2.0
            v[HASH_OFFSET+fnv1a(b'W'+w)%HASH_DIM]+=1.0
        i=j if j>i else i+1
    for n,p in ((3,b'3'),(4,b'4'),(5,b'5')):
        if len(b)>=n:
            for i in range(len(b)-n+1):
                g=b[i:i+n]
                if g.strip(): v[HASH_OFFSET+fnv1a(p+g)%HASH_DIM]+=0.18
    for i in range(len(words)-1): v[HASH_OFFSET+fnv1a(b'B'+words[i]+b'_'+words[i+1])%HASH_DIM]+=0.5
    z=float(v.norm())
    if z>0: v/=z
    return v

def build_sets():
    train,gold=build_context(); rel_to_id={r:i for i,r in enumerate(RELATIONS)}
    buckets={k:[] for k in RELATIONS}
    for row in train:
        buckets[row['kind']].append(row)
    tr=[]
    rng=random.Random(SEED)
    # Stratified subset: every relation sees all question/sentence variants over
    # many entity/value instances, without materializing tens of thousands of
    # redundant dense vectors.
    for k in RELATIONS:
        rows=buckets[k][:]
        rng.shuffle(rows)
        for row in rows[:90]:
            label=rel_to_id[k]
            tr.append((row['question'],label,'question'))
            tr.append((row['context'],label,'sentence'))
    go=[]; seen=set()
    for row in gold:
        k=row['kind'].removesuffix('_holdout'); label=rel_to_id[k]
        for text,view in ((row['question'],'question'),(row['context'],'sentence')):
            key=(text,label)
            if key not in seen: seen.add(key); go.append((text,label,view))
    unknown_train=[
        'Explique por que o cache reduz trabalho repetido.','Resuma o documento em três pontos.','Compare as duas arquiteturas.',
        'Como funciona uma rede neural?','Liste os riscos principais.','Qual é a capital do Brasil?','O sistema deve recusar quando não sabe.',
        'A primeira frase explica o mecanismo e a segunda descreve seu efeito.','O relatório discute segurança e desempenho sem registrar um valor estruturado.',
        'Este parágrafo é apenas contexto geral e não contém nenhum dos atributos catalogados.',
        'Explique por que validar resultados é importante para a confiabilidade.',
        'Qual é a importância de verificar uma resposta antes de publicá-la?',
        'Como a validação ajuda a encontrar erros sem consultar atributos cadastrais?',
        'A verificação independente reduz regressões e não descreve uma porta de rede.',
        'Discuta a importância da revisão e da verificação de evidências.'
    ]
    unknown_gold=[
        'Faça um resumo da explicação.','Por que a verificação é importante?','Mostre um passo a passo genérico.',
        'O texto descreve uma causa e uma consequência sem fornecer um atributo cadastral.',
        'Nenhum valor cadastral solicitado aparece nesta sentença.',
        'Por que a verificação é importante?', 'Explique a importância da verificação.',
        'Como melhorar a verificação sem falar de portas ou atributos cadastrais?'
    ]
    tr.extend((x,UNKNOWN,'unknown') for x in unknown_train for _ in range(35))
    go.extend((x,UNKNOWN,'unknown') for x in unknown_gold)
    rng.shuffle(tr); random.Random(SEED+1).shuffle(go)
    return tr,go

class Model(nn.Module):
    def __init__(self):
        super().__init__(); self.fc1=nn.Linear(FEAT,HIDDEN); self.fc2=nn.Linear(HIDDEN,len(RELATIONS)+1)
    def forward(self,x): return self.fc2(torch.tanh(self.fc1(x)))

def evaluate(model,rows):
    model.eval(); ok=0; by={'question':[0,0],'sentence':[0,0],'unknown':[0,0]}; detail=[]
    with torch.no_grad():
        for text,label,view in rows:
            p=F.softmax(model(features(text)[None]),-1)[0]; pred=int(p.argmax()); vals=torch.topk(p,2).values; good=pred==label
            ok+=int(good); by[view][0]+=int(good); by[view][1]+=1
            detail.append({'text':text,'view':view,'expected': 'unknown' if label==UNKNOWN else RELATIONS[label],
                           'predicted':'unknown' if pred==UNKNOWN else RELATIONS[pred], 'confidence':float(vals[0]),
                           'margin':float(vals[0]-vals[1]),'exact':good})
    return ok/len(rows),{k:(a/b if b else 0) for k,(a,b) in by.items()},detail

def export(model,path):
    with open(path,'wb') as f:
        f.write(struct.pack('<7I',MAGIC,VERSION,FEAT,HIDDEN,len(RELATIONS)+1,SEED,0))
        def put(t): f.write(t.detach().cpu().float().contiguous().numpy().astype('<f4').tobytes())
        put(model.fc1.weight.T); put(model.fc1.bias); put(model.fc2.weight.T); put(model.fc2.bias)

def main():
    require_lessons_precheck(); ap=argparse.ArgumentParser(); ap.add_argument('--steps',type=int,default=900); ap.add_argument('--batch',type=int,default=96)
    ap.add_argument('--out',default='models/neuraldesk-relation-classifier-v0.5.ndrl'); args=ap.parse_args()
    torch.manual_seed(SEED); torch.set_num_threads(1); torch.use_deterministic_algorithms(True); torch.backends.mkldnn.enabled=False
    tr,go=build_sets(); print({'train':len(tr),'gold':len(go),'relations':len(RELATIONS)},flush=True)
    x=torch.stack([features(t) for t,_,_ in tr]); y=torch.tensor([z for _,z,_ in tr])
    model=Model(); opt=torch.optim.AdamW(model.parameters(),lr=3e-3,weight_decay=.01); rng=random.Random(SEED); hist=[]
    for step in range(args.steps):
        ix=torch.tensor([rng.randrange(len(tr)) for _ in range(args.batch)])
        loss=F.cross_entropy(model(x[ix]),y[ix]); opt.zero_grad(); loss.backward(); opt.step()
        if step%100==0 or step==args.steps-1:
            hist.append({'step':step,'loss':float(loss.detach())}); print('relation',step,float(loss.detach()),flush=True)
    tracc,trby,_=evaluate(model,tr); goacc,goby,detail=evaluate(model,go)
    Path(args.out).parent.mkdir(parents=True,exist_ok=True); export(model,args.out)
    report={'seed':SEED,'feature_dim':FEAT,'hidden_dim':HIDDEN,'relations':list(RELATIONS),'classes':len(RELATIONS)+1,
            'parameters':sum(p.numel() for p in model.parameters()),'train_samples':len(tr),'gold_samples':len(go),
            'train_exact':tracc,'gold_exact':goacc,'gold_by_view':goby,'history':hist,
            'model_sha256':hashlib.sha256(Path(args.out).read_bytes()).hexdigest(),'gold_rows':detail}
    Path('evaluation/RELATION_CLASSIFIER_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='gold_rows'},ensure_ascii=False,indent=2))
    if goacc<0.99 or any(goby[v]<0.99 for v in ('question','sentence','unknown')): raise SystemExit('relation classifier below 99% by required view')
if __name__=='__main__': main()
