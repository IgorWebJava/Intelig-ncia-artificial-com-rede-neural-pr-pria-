# Mapa de Versões — NeuralDesk

- V8.2 — Intelligence Experience Suite (implementação visual/arquitetural atual).
- V8.3 — documentação/memória/AI handoff sincronizados.
- V8.4 — Neural Engine Blueprint Documentation inicial.
- V8.5 — Advanced Research Blueprint com pesquisa GitHub 2026, 64 módulos e 218 capabilities.
- **V8.6 — sincronização documental total de interface + Neural Engine + memória + skills; nenhuma mudança canônica de UI e nenhum engine code.**

| V8.7 | Frontier Competitive Readiness Documentation | Documentation-only roadmap P00–P08; 64 engine readiness docs + 10 interface executable-readiness docs; no canonical UI/engine code change. |

## V8.8 — Kimi K3 Engineering Pattern Integration
- Documentation-only research integration.
- Added 8 future engine modules and new engine capabilities.
- Added K3 repository x-ray, adoption matrix, benchmark/correctness/resource strategies.
- No canonical UI/runtime code changes.

## V8.9 — Qwen3-Omni Native Omni-Modal Architecture Integration

Documentation-only. 82 future Neural Engine modules, 318 engine capabilities, 35 unique primary research sources. Visual/UI remains V8.2.


## V8.10 — DeepSeek Harness Agent Runtime Architecture Integration

- Documentation-only release; canonical V8.2 interface unchanged.
- Neural Engine: 94 future modules / 391 capabilities.
- Added semantic session durability, replay, guarded tool effects, provider-federated subagents, compaction/spill, schema evolution, runtime invariants, benchmark ablation and governed dynamic extension patterns.
- No Neural Engine runtime/source implementation introduced.


## V8.11
- Package/UI/Architecture/Documentation/Memory/Skills: V8.11.
- First coordinated actual UI evolution after V8.2 while preserving existing semantics.
- Engine Bridge v1; current capabilities 106; future engine 94 modules/391 caps; 149 UI mechanics; engine NOT IMPLEMENTED.

| V8.12 | Agent Platform pattern integration: Graph IR/AutoBuild/Marketplace/Triggers/Credentials/Simulation; 107 engine modules, 474 caps, 119 current caps |

| V8.13 | Claw Code Coding Intelligence: 125 engine modules, 604 engine capabilities, 137 current capabilities, 179 UI↔Engine mechanics; Task Packet, Green Contract, recovery, coding doctor/parity and safe repo tooling readiness |

### V8.14
Open WebUI AI Workspace Pattern Integration — presets/task models, multi-model, Notes/Channels, federated/hybrid knowledge, native tool injection, extension isolation, access resolution, notifications/timers, local/offline, streaming and embedding health.
