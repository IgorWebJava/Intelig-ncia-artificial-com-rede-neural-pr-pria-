# LEIA ANTES DE MODIFICAR — NeuralDesk V8.11

## Current truth

A interface canônica atual é V8.11. O Neural Engine continua somente documentação. Não transforme mocks, Engine Bridge surfaces ou local simulations em afirmações de execução real.

## Mandatory reading

1. `memória/ESTADO_ATUAL.json`
2. `docs/CURRENT_STATE.md`
3. `docs/SOURCE_OF_TRUTH.md`
4. `docs/architecture/CURRENT_ENGINE_UI_COMPATIBILITY.md`
5. `docs/governance/NON_REGRESSION_EVOLUTION_POLICY.md`
6. `docs/ai/AI_READ_FIRST.md`
7. `habilidades/AI_HANDOFF.md`
8. module `module.manifest.json` + `docs/CURRENT_STATE.md` + `docs/ENGINE_COMPATIBILITY.md`
9. corresponding future engine module `CURRENT_STATE.md` + `INTERFACE_COMPATIBILITY.md` when applicable

## Mandatory evolution law

`preserve → extend → bridge`.

- Do not remove V8.10 route/tab/action/contract/capability semantics without an explicit migration.
- Keep root HTML aliases as compatibility redirects.
- Add new UI behavior to canonical `modules/<module>/ui/` paths.
- Keep Engine Bridge truthful: local UI only; future engine is NOT IMPLEMENTED.
- Every new engine module/capability must have an interface owner or explicit headless representation.
- Run `validate_non_regression.py` and `validate_engine_ui_compatibility.py` before release.

## Research inheritance

V8.8 Kimi K3, V8.9 Qwen3-Omni and V8.10 DeepSeek Harness documents remain valid reference/history. They do not change the V8.11 truth boundary.
