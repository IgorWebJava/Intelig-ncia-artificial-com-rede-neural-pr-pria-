package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import java.io.File
import java.util.regex.Pattern

/**
 * Módulo 13: Assistant Toolkit & Agentic Solver.
 * Ferramentas de Assistente Universal:
 * 1. Solucionador Matemático Simbólico Exato
 * 2. Planejador de Tarefas e Workflows Estruturados
 * 3. Conversor de Unidades e Grandezas Físicas
 */
class AssistantToolkitPlugin(
    private val storageDir: File? = null
) : IQcnnPlugin {

    override val pluginId: String = "assistant_toolkit"
    override var isEnabled: Boolean = true

    private fun solveMath(prompt: String): String? {
        val clean = prompt.lowercase().replace("x", "*").replace("÷", "/")

        // 15% de 800
        val pPct = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:de|of|\\*)\\s*(\\d+(?:\\.\\d+)?)")
        val mPct = pPct.matcher(clean)
        if (mPct.find()) {
            val pct = mPct.group(1)?.toDoubleOrNull() ?: return null
            val valor = mPct.group(2)?.toDoubleOrNull() ?: return null
            val res = (pct / 100.0) * valor
            return "🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> $pct% de $valor<br><strong>Resultado:</strong> <code>${String.format("%.2f", res)}</code>"
        }

        // Raiz quadrada
        val pSqrt = Pattern.compile("(?:raiz\\s*quadrada\\s*de|sqrt\\()\\s*(\\d+(?:\\.\\d+)?)")
        val mSqrt = pSqrt.matcher(clean)
        if (mSqrt.find()) {
            val n = mSqrt.group(1)?.toDoubleOrNull() ?: return null
            val res = Math.sqrt(n)
            return "🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> <code>√$n</code><br><strong>Resultado Exato:</strong> <code>$res</code>"
        }

        // Expressões aritméticas completas (ex: "Calcule 125 * 84 + 1500 / 25 - 42", "Calcular 125 * 8 + 450 / 5")
        val pExpressao = Pattern.compile("(?:calcule|quanto\\s+[ée]|resolva|calcular|resultado\\s+de)\\s*:?\\s*([0-9\\s.+\\-*/()]+)")
        val mExp = pExpressao.matcher(clean)
        if (mExp.find()) {
            val exprStr = mExp.group(1)?.trim() ?: return null
            if (exprStr.matches(Regex(".*[+\\-*/].*")) && exprStr.matches(Regex("^[0-9\\s.+\\-*/()]+$"))) {
                try {
                    val resultado = avaliarExpressaoAritmetica(exprStr)
                    val resFormat = if (resultado % 1.0 == 0.0) resultado.toLong().toString() else String.format(java.util.Locale.ROOT, "%.4f", resultado)
                    return "🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> <code>$exprStr</code><br><strong>Resultado Exato:</strong> <code>$resFormat</code>"
                } catch (_: Exception) {}
            }
        }

        return null
    }

    private fun avaliarExpressaoAritmetica(expressao: String): Double {
        val tokens = mutableListOf<String>()
        val sb = StringBuilder()
        for (ch in expressao) {
            if (ch in "+-*/()") {
                if (sb.isNotEmpty()) {
                    tokens.add(sb.toString().trim())
                    sb.clear()
                }
                tokens.add(ch.toString())
            } else if (!ch.isWhitespace()) {
                sb.append(ch)
            }
        }
        if (sb.isNotEmpty()) tokens.add(sb.toString().trim())

        // Avaliador de precedência simplificado (+, -, *, /)
        val posFixa = mutableListOf<String>()
        val operadores = java.util.ArrayDeque<String>()
        fun precedencia(op: String) = when (op) {
            "+", "-" -> 1
            "*", "/" -> 2
            else -> 0
        }

        for (token in tokens) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                posFixa.add(token)
            } else if (token == "(") {
                operadores.push(token)
            } else if (token == ")") {
                while (operadores.isNotEmpty() && operadores.peek() != "(") {
                    posFixa.add(operadores.pop())
                }
                if (operadores.isNotEmpty()) operadores.pop()
            } else if (token in listOf("+", "-", "*", "/")) {
                while (operadores.isNotEmpty() && precedencia(operadores.peek()) >= precedencia(token)) {
                    posFixa.add(operadores.pop())
                }
                operadores.push(token)
            }
        }
        while (operadores.isNotEmpty()) {
            posFixa.add(operadores.pop())
        }

        val pilha = java.util.ArrayDeque<Double>()
        for (t in posFixa) {
            val v = t.toDoubleOrNull()
            if (v != null) {
                pilha.push(v)
            } else if (t in listOf("+", "-", "*", "/") && pilha.size >= 2) {
                val b = pilha.pop()
                val a = pilha.pop()
                val r = when (t) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> if (b != 0.0) a / b else 0.0
                    else -> 0.0
                }
                pilha.push(r)
            }
        }
        return if (pilha.isNotEmpty()) pilha.pop() else 0.0
    }

    private fun planWorkflow(prompt: String): String? {
        val pPlan = Pattern.compile("(?:crie\\s+um\\s+plano|planeje|roteiro|etapas\\s+para|passo\\s+a\\s+passo\\s+para|organize\\s+um\\s+plano)\\s+(?:de\\s+)?(.+)", Pattern.CASE_INSENSITIVE)
        val mPlan = pPlan.matcher(prompt)
        if (mPlan.find()) {
            val tema = mPlan.group(1)?.trim()?.replaceFirstChar { it.uppercase() } ?: "Execução"
            return """
📋 [PLANO DE AÇÃO ESTRUTURADO DO ASSISTENTE]
<br><br><strong>Objetivo Central:</strong> <em>$tema</em>
<br><br><strong>Fases de Execução:</strong>
<br>1. <strong>Fase 1 (Fundação & Diagnóstico):</strong> Mapeamento do escopo, levantamento de requisitos e parâmetros.
<br>2. <strong>Fase 2 (Estruturação Simbólica):</strong> Modelagem das etapas e definição do fluxo de trabalho.
<br>3. <strong>Fase 3 (Execução & Convergência):</strong> Implementação prática e iteração contínua.
<br>4. <strong>Fase 4 (Validação & Cristalização):</strong> Teste final de consistência e conclusão.
            """.trimIndent()
        }
        return null
    }

    private fun convertUnits(prompt: String): String? {
        val clean = prompt.lowercase()

        // km para milhas
        val pKmMiles = Pattern.compile("(?:converta\\s+)?(\\d+(?:\\.\\d+)?)\\s*km\\s+(?:em|para)\\s*milhas?")
        val mKmMiles = pKmMiles.matcher(clean)
        if (mKmMiles.find()) {
            val v = mKmMiles.group(1)?.toDoubleOrNull() ?: return null
            val res = v * 0.621371
            return "📐 [CONVERSÃO DE UNIDADES]<br><br><code>$v km</code> = <strong>${String.format("%.2f", res)} milhas</strong>"
        }

        // milhas para km
        val pMilesKm = Pattern.compile("(?:converta\\s+)?(\\d+(?:\\.\\d+)?)\\s*milhas?\\s+(?:em|para)\\s*km")
        val mMilesKm = pMilesKm.matcher(clean)
        if (mMilesKm.find()) {
            val v = mMilesKm.group(1)?.toDoubleOrNull() ?: return null
            val res = v * 1.60934
            return "📐 [CONVERSÃO DE UNIDADES]<br><br><code>$v milhas</code> = <strong>${String.format("%.2f", res)} km</strong>"
        }

        // metros para cm
        val pMCm = Pattern.compile("(?:converta\\s+)?(\\d+(?:\\.\\d+)?)\\s*metros?\\s+(?:em|para)\\s*(?:centimetros?|cm)")
        val mMCm = pMCm.matcher(clean)
        if (mMCm.find()) {
            val v = mMCm.group(1)?.toDoubleOrNull() ?: return null
            val res = v * 100.0
            return "📐 [CONVERSÃO DE UNIDADES]<br><br><code>$v metros</code> = <strong>${String.format("%.2f", res)} cm</strong>"
        }

        // kg para libras
        val pKgLb = Pattern.compile("(?:converta\\s+)?(\\d+(?:\\.\\d+)?)\\s*kg\\s+(?:em|para)\\s*libras?")
        val mKgLb = pKgLb.matcher(clean)
        if (mKgLb.find()) {
            val v = mKgLb.group(1)?.toDoubleOrNull() ?: return null
            val res = v * 2.20462
            return "📐 [CONVERSÃO DE UNIDADES]<br><br><code>$v kg</code> = <strong>${String.format("%.2f", res)} libras</strong>"
        }

        // km/h para m/s
        val pKmh = Pattern.compile("(?:converta\\s+)?(\\d+(?:\\.\\d+)?)\\s*km/h\\s+(?:em|para)\\s*m/s")
        val mKmh = pKmh.matcher(clean)
        if (mKmh.find()) {
            val v = mKmh.group(1)?.toDoubleOrNull() ?: return null
            val res = v / 3.6
            return "📐 [CONVERSÃO DE UNIDADES]<br><br><code>$v km/h</code> = <strong>${String.format("%.3f", res)} m/s</strong>"
        }

        // celsius para fahrenheit
        val pC = Pattern.compile("(?:converta\\s+)?(\\d+(?:\\.\\d+)?)\\s*(?:°c|celsius)\\s+(?:em|para)\\s*(?:°f|fahrenheit)")
        val mC = pC.matcher(clean)
        if (mC.find()) {
            val v = mC.group(1)?.toDoubleOrNull() ?: return null
            val res = (v * 9.0 / 5.0) + 32.0
            return "📐 [CONVERSÃO DE UNIDADES]<br><br><code>$v °C</code> = <strong>${String.format("%.2f", res)} °F</strong>"
        }
        return null
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context
        val prompt = context.prompt.trim()

        val math = solveMath(prompt)
        if (math != null) {
            context.customResponse = math
            context.metadata["assistant_tool"] = "symbolic_math"
            return context
        }

        val unit = convertUnits(prompt)
        if (unit != null) {
            context.customResponse = unit
            context.metadata["assistant_tool"] = "unit_converter"
            return context
        }

        val plan = planWorkflow(prompt)
        if (plan != null) {
            context.customResponse = plan
            context.metadata["assistant_tool"] = "workflow_planner"
            return context
        }

        return context
    }
}
