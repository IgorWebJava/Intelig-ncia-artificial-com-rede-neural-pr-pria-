<!-- neuraldesk-documentation-sync: V8.11 -->

# Tests — App Shell

Canonical test root:

```text
modules/app-shell/tests/
```

## Run automated tests

```text
python modules/app-shell/tests/run_module_tests.py
```

## Run browser visual tests

```text
python modules/app-shell/tests/visual/run_visual_tests.py
```

## Structure

```text
tests/
├── test.manifest.json
├── TEST_PLAN.md
├── README.md
├── run_module_tests.py
├── automated/
├── lib/
├── fixtures/
├── scenarios/
├── visual/
├── acceptance/
└── reports/
```

`reports/` contains generated results and may be regenerated at any time.

Backend-dependent scenario files are executable specifications for the real system; they are not falsely marked as implemented behavior in the current static template.


## Engine Bridge V8.11
Non-regression, truth-boundary and bridge-marker coverage is executable through `test_engine_bridge.py` plus `scenarios/engine-ui-bridge-v811.json`.
