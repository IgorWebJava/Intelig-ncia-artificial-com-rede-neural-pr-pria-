<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.adaptive-ui; current: docs/architecture/CURRENT_RESPONSIVE_PROFILE.md -->
# Current Responsive Profile

```text
Phone      390×844
Tablet     768×1024
Notebook   1366×768
Desktop    1920×1080
TV / 4K    3840×2160
```

Current UI uses `intelligence-experience-v2` / `workspace-runtime-v2` with touch, mouse, keyboard, remote focus, safe areas, reduced motion, focus-visible, high-contrast accommodation and Comfortable/Balanced/Dense presentation modes. Functional microtext floor is governed by the Intelligence Design System.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
