#ifndef ND_PILOT_H
#define ND_PILOT_H

#include <stddef.h>
#include <stdint.h>

#define ND_PILOT_AUDIT_CAP 20u

typedef enum {
    ND_PILOT_LOCAL_INFERENCE = 0,
    ND_PILOT_IMAGE_PREPROCESSING = 1,
    ND_PILOT_DURABLE_TASKS = 2,
    ND_PILOT_LOCAL_UTILITIES = 3,
    ND_PILOT_ARTIFACT_MANAGER = 4,
    ND_PILOT_BENCHMARK_EXPORT = 5,
    ND_PILOT_FEATURE_COUNT = 6
} NDPilotFeature;

typedef struct {
    int64_t timestamp;
    unsigned action;
    int feature;
} NDPilotAuditEvent;

typedef struct {
    int master_kill;
    unsigned enabled_mask;
    NDPilotAuditEvent audit[ND_PILOT_AUDIT_CAP];
    size_t audit_count;
} NDPilotControl;

void nd_pilot_init(NDPilotControl *control);
int nd_pilot_allowed(const NDPilotControl *control, NDPilotFeature feature);
int nd_pilot_set_feature(NDPilotControl *control, NDPilotFeature feature, int enabled, int64_t timestamp);
int nd_pilot_set_master_kill(NDPilotControl *control, int enabled, int64_t timestamp);
const char *nd_pilot_feature_name(NDPilotFeature feature);

#endif
