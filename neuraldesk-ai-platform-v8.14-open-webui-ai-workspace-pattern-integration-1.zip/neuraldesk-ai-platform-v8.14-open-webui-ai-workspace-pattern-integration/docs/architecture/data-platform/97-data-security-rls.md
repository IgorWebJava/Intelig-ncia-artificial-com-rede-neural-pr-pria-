<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 97 — Data Security & Row Scope

Where shared relational tables contain tenant/project-scoped records, Row-Level Security can reinforce isolation.

Authorization is still required in application services.

RLS is defense-in-depth, not a replacement for application authorization.

Secrets are external references.
