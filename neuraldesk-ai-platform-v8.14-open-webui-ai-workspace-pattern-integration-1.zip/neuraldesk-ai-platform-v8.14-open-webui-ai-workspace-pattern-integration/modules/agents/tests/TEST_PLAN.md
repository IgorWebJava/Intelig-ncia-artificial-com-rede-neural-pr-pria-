<!-- neuraldesk-documentation-sync: V8.11 -->

# Test Plan — Agents

Validate project-agent CRUD semantics, versioning, runtime skills, tool/knowledge/model bindings, teams, handoffs, workflows, multimodal playground, evaluations, lifecycle, audit/operations integration and module replacement boundaries. Backend-dependent cases remain explicitly future E2E specifications.


## Engine Bridge V8.11
Non-regression, truth-boundary and bridge-marker coverage is executable through `test_engine_bridge.py` plus `scenarios/engine-ui-bridge-v811.json`.
