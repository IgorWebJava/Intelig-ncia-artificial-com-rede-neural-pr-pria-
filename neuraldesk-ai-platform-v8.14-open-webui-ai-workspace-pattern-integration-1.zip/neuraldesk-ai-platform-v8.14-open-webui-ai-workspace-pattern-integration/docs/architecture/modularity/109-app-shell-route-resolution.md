<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 109 — App Shell & Route Resolution

The App Shell owns navigation, not domain logic.

Logical routes resolve through Module Registry.

Legacy root HTML files are compatibility aliases only and are not canonical module pages.
