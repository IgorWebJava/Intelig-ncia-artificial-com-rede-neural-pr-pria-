<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.chat; current: modules/chat/docs/AUTONOMOUS_ASSISTANT_EXPERIENCE.md -->
# Autonomous Assistant Experience Template — Chat V8.1

## Scope

```text
IMPLEMENTED
HTML/CSS + module-owned JavaScript local interaction states

NOT IMPLEMENTED
Autonomous engine, planner, orchestrator, agent/tool execution, web execution, persistent project memory, background tasks, live microphone runtime
```

## Surfaces
- Conversation
- Mission Control
- Plan & Tasks
- Activity Timeline (safe summaries only)
- Agents & Tools visibility
- Artifact Workspace
- Project Context & Memory surface
- Checkpoints
- Project Switcher
- Assistant Mode Selector
- Multimodal Composer

## Project continuity template
Active → Pause → visual checkpoint → Paused → Resume → restored visual state.

## Privacy
The Activity surface never exposes private chain-of-thought. Continuous Voice is represented as an explicit user-controlled mode and does not activate microphone capture.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
