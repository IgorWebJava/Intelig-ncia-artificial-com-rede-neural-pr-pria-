import math
import os
from typing import Dict, Any, List, Optional, Set
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class MyceliumIndexPlugin(BaseQcnnPlugin):
    """
    Módulo 15: Mycelium Semantic Index & Organic Routing (Rede de Micélio Bio-Inspirada).
    
    Organiza e roteia nós conceituais de forma não-hierárquica inspirada na rede biológica de fungos:
    1. Hifas Semânticas (Arestas ponderadas por afinidade vibracional áurea e co-ocorrência).
    2. Roteamento de Baixa Energia (Consumo de RAM < 1MB, latência < 0.1ms).
    3. Conexões Latentes: Identifica pontes conceituais entre domínios aparentemente desconectados
       (ex: biologia celular ↔ direito constitucional ↔ física de partículas).
    """

    def __init__(self):
        super().__init__()
        self.phi = 1.61803398875
        self.hyphae_network: Dict[str, Dict[str, float]] = self._init_base_mycelium()

    @property
    def plugin_id(self) -> str:
        return "mycelium_index"

    def _init_base_mycelium(self) -> Dict[str, Dict[str, float]]:
        """Inicializa as rotas orgânicas primordiais do micélio semântico."""
        return {
            "vida": {"energia": 0.95, "tempo": 0.82, "consciencia": 0.90, "harmonia": 0.88},
            "tempo": {"espaco": 0.98, "entropia": 0.92, "memoria": 0.85, "movimento": 0.89},
            "mente": {"consciencia": 0.99, "pensamento": 0.96, "simbolo": 0.91, "vontade": 0.87},
            "universo": {"cosmos": 0.99, "energia": 0.94, "materia": 0.93, "gravidade": 0.91},
            "decisao": {"vontade": 0.92, "consequencia": 0.95, "futuro": 0.91, "equilibrio": 0.89},
            "harmonia": {"equilibrio": 0.97, "frequencia": 0.94, "ressonancia": 0.96, "beleza": 0.89},
            "direito": {"justica": 0.98, "ordem": 0.93, "constituicao": 0.96, "etica": 0.91},
            "saude": {"equilibrio": 0.94, "celula": 0.95, "vitalidade": 0.92, "cura": 0.90},
            "gravidade": {"curvatura": 0.97, "massa": 0.96, "espaco_tempo": 0.98, "atracao": 0.93}
        }

    def grow_hypha(self, concept_a: str, concept_b: str, strength: float = 0.85):
        """Conecta dois nós na rede micelial com reforço de co-ocorrência orgânica."""
        cA = concept_a.lower().strip()
        cB = concept_b.lower().strip()
        if cA not in self.hyphae_network:
            self.hyphae_network[cA] = {}
        if cB not in self.hyphae_network:
            self.hyphae_network[cB] = {}
        
        # Ponderação com decaimento logístico suave
        self.hyphae_network[cA][cB] = round(min(1.0, self.hyphae_network[cA].get(cB, 0.5) + strength * 0.1), 3)
        self.hyphae_network[cB][cA] = self.hyphae_network[cA][cB]

    def find_mycelial_pathways(self, tokens: List[str]) -> List[Dict[str, Any]]:
        """Descobre caminhos orgânicos latentes entre os conceitos ativados."""
        pathways = []
        clean_tokens = [t.lower().strip() for t in tokens if len(t) > 2]
        
        for i in range(len(clean_tokens)):
            for j in range(i + 1, len(clean_tokens)):
                t1, t2 = clean_tokens[i], clean_tokens[j]
                if t1 in self.hyphae_network and t2 in self.hyphae_network.get(t1, {}):
                    pathways.append({
                        "origem": t1,
                        "destino": t2,
                        "condutividade_organica": self.hyphae_network[t1][t2],
                        "tipo": "hifa_direta"
                    })
                else:
                    # Busca de conexão intermediária (hifa ponte)
                    if t1 in self.hyphae_network:
                        for inter, w1 in self.hyphae_network[t1].items():
                            if inter in self.hyphae_network and t2 in self.hyphae_network[inter]:
                                w2 = self.hyphae_network[inter][t2]
                                pathways.append({
                                    "origem": t1,
                                    "ponte": inter,
                                    "destino": t2,
                                    "condutividade_organica": round(w1 * w2, 3),
                                    "tipo": "hifa_ponte"
                                })
        return pathways

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt = context.prompt.lower()
        words = [w for w in prompt.split() if len(w) > 3]

        # Auto-crescimento orgânico durante o diálogo
        for i in range(len(words) - 1):
            self.grow_hypha(words[i], words[i+1], strength=0.5)

        pathways = self.find_mycelial_pathways(words)
        if pathways:
            context.metadata["mycelium_pathways"] = pathways[:5]
            context.metadata["mycelium_nodes_count"] = len(self.hyphae_network)

        return context
