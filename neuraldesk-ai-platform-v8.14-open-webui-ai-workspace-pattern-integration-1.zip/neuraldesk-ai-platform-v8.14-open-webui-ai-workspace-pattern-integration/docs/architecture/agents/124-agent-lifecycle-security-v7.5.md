<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 124 — Agent Lifecycle & Security

Draft → Sandbox → Evaluation → Safety → Staging → Production. Production versions are immutable. Least privilege, guardrails, risk-based approvals, budgets, audit and rollback are mandatory production concepts.
