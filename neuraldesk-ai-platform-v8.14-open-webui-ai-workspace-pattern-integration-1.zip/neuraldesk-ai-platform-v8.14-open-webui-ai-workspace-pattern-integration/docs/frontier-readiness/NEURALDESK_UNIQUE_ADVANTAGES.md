# NeuralDesk Unique Advantage Hypotheses

These are hypotheses to validate, not claims.

1. **AI Workspace OS**: a project-centric system integrating chat, agents, tools, knowledge, artifacts and control plane.
2. **Capability-first intelligence**: task chooses capability, not vendor.
3. **Provenance Everywhere**: trace source -> task -> agent -> tool -> model -> artifact -> version.
4. **Trust Layer**: risk/permission/reversibility visible before actions.
5. **Reversible work**: checkpoints, versions, diffs and rollback across major entities.
6. **Full lifecycle**: build/evaluate/deploy/observe/audit in one product.
7. **Hybrid intelligence**: external frontier + private local + NeuralDesk-owned models.
