# Phase 02 — Model Access, Projects, Memory and Context

Status: DOCUMENTATION-ONLY


Add model runtime/router, real conversation streaming, project runtime, Goal & Intent, Context Compiler and scoped Memory.

Required behavior:
- projects persist independently of chats;
- conversations can branch;
- model calls stream and cancel;
- context is selected/budgeted rather than blindly concatenated;
- memory has user/project/conversation/session/agent scopes;
- forget/export controls exist;
- every model request records model/profile/version/cost/latency.

Exit result: a production-capable project-aware AI chat using replaceable providers.
