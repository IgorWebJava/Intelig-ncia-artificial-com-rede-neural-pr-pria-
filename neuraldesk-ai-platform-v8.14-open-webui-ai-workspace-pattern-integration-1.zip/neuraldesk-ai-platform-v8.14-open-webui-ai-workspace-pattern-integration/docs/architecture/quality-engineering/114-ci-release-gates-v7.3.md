<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 114 — CI / Release Gates V7.3

Recommended gate order:

```text
run_all_module_tests.py
→ validate_architecture.py
→ validate_documentation.py
→ validate_responsive.py
→ validate_testing.py
→ run_all_visual_tests.py
```

For production runtime releases, also execute backend/integration/security/replacement scenarios appropriate to the changed module.
