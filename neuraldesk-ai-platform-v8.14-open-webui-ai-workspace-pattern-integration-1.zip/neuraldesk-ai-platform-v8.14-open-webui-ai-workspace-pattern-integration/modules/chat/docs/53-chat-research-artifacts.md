<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 53 — Research e Artifacts

## Research

Estados visuais:

```text
Planning
Searching sources
Reading sources
Cross-checking
Synthesizing
Writing
```

## Artifacts

A interface fica preparada para resultados como:

- document;
- report;
- spreadsheet;
- code;
- diagram;
- image;
- structured output.

O template apenas representa o artifact. O sistema real é responsável por criar, armazenar e abrir arquivos.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
