package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Módulo 14: Sistema Multi-V (Oráculo Analítico Multifacetado e Simulador de Realidades Paralelas).
 * Simula a mecânica quântica em hardware clássico:
 * 1. Superposição de Cenários (Alpha, Beta, Gamma, Delta)
 * 2. Efeito Observador paramétrico em tempo real
 * 3. Análise Epistemológica e Filosófica
 * 4. Ramificações de Linhas de Tempo Decisórias
 */
class MultiverseOraclePlugin : IQcnnPlugin {

    override val pluginId: String = "multiverse_oracle"
    override var isEnabled: Boolean = true

    private val decisionKeywords = listOf(
        "devo", "qual decisão", "o que acontece se", "o que aconteceria", "cenário", "cenarios",
        "simule", "simular", "escolha", "alternativas", "estratégia", "consequências",
        "e se", "melhor caminho", "analise de risco", "análise de risco", "tomada de decisão", "probabilidade",
        "ramificações", "multiverso", "projeção", "plano a ou b", "como agir",
        "oráculo", "oraculo", "previsão", "prever", "impacto futuro", "linha de tempo", "linhas de tempo"
    )

    private fun isDecisionOrScenarioQuery(prompt: String): Boolean {
        val p = prompt.lowercase()
        return decisionKeywords.any { p.contains(it) }
    }

    fun generateScenarios(
        prompt: String,
        riskFactor: Double = 0.5,
        philosophy: String = "Dialética",
        rigor: Double = 0.8
    ): Map<String, Any> {
        val clean = prompt.trim()
        val phi = 1.61803398875

        var pHash = 0L
        for ((idx, ch) in clean.withIndex()) {
            pHash += ch.code.toLong() * (idx + 1)
        }

        val probAlpha = (0.35 + (riskFactor - 0.5) * 0.40 + (pHash % 7) * 0.02).coerceIn(0.05, 0.95)
        val probBeta = (0.40 - (riskFactor - 0.5) * 0.30 + ((pHash shr 2) % 5) * 0.02).coerceIn(0.05, 0.95)
        val probGamma = (0.25 + (riskFactor * 0.15) + ((pHash shr 3) % 9) * 0.015).coerceIn(0.05, 0.95)

        val totalP = probAlpha + probBeta + probGamma
        val pA = String.format(Locale.US, "%.1f", (probAlpha / totalP) * 100)
        val pB = String.format(Locale.US, "%.1f", (probBeta / totalP) * 100)
        val pC = String.format(Locale.US, "%.1f", (probGamma / totalP) * 100)

        val hzAlpha = String.format(Locale.US, "%.2f", 432.0 * phi * (1.0 + riskFactor * 0.2)).toDouble()
        val hzBeta = String.format(Locale.US, "%.2f", 528.0 * (1.0 / phi) * (1.2 - riskFactor * 0.2)).toDouble()
        val hzGamma = String.format(Locale.US, "%.2f", 741.0 * phi * (0.8 + rigor * 0.3)).toDouble()
        val hzDelta = String.format(Locale.US, "%.2f", 639.0 * phi).toDouble()

        val cenarioAlpha = mapOf(
            "id" to "alpha",
            "nome" to "Cenário Alpha (Expansivo & Arrojado)",
            "arquetipo" to "Máxima Aceleração & Retorno",
            "probabilidade" to "$pA%",
            "frequencia_hz" to hzAlpha,
            "horizonte" to "Curto/Médio Prazo",
            "vetor_acao" to "Alocação proativa de recursos, exploração agressiva de oportunidades e liderança pela inovação.",
            "risco_potencial" to "Vulnerabilidade a choques imprevistos e volatilidade de curto prazo.",
            "impacto_simbolico" to "Crescimento exponencial baseado no Princípio de Kether (Início Vital)."
        )

        val cenarioBeta = mapOf(
            "id" to "beta",
            "nome" to "Cenário Beta (Resiliente & Conservador)",
            "arquetipo" to "Preservação & Alta Estabilidade",
            "probabilidade" to "$pB%",
            "frequencia_hz" to hzBeta,
            "horizonte" to "Médio/Longo Prazo",
            "vetor_acao" to "Consolidação de bases, proteção de liquidez/reservas e mitigação rigorosa de incertezas.",
            "risco_potencial" to "Custo de oportunidade e perda de velocidade frente a movimentos rápidos do ambiente.",
            "impacto_simbolico" to "Estabilidade inquebrantável ancorada no Princípio de Gevurah (Rigor & Limite)."
        )

        val cenarioGamma = mapOf(
            "id" to "gamma",
            "nome" to "Cenário Gamma (Disruptivo & Inovador)",
            "arquetipo" to "Ruptura de Paradigma & Salto Quântico",
            "probabilidade" to "$pC%",
            "frequencia_hz" to hzGamma,
            "horizonte" to "Longo Prazo",
            "vetor_acao" to "Reestruturação do modelo convencional, adoção de novas tecnologias e convergência assimétrica.",
            "risco_potencial" to "Resistência sistêmica e atrito inicial durante o período de transição.",
            "impacto_simbolico" to "Transformação estrutural guiada pelo Princípio de Tiferet (Harmonia Sintética)."
        )

        val filoAnalise = when (philosophy.lowercase()) {
            "estoicismo" -> "<strong>Prisma Estoico (Epicteto / Marco Aurélio):</strong> Foco estrito nas variáveis sob controle direto; aceitação serena das forças externas e máxima resiliência interna."
            "racionalismo" -> "<strong>Prisma Racionalista (Descartes / Spinoza):</strong> Decomposição cartesiana do problema em axiomas fundamentais, dedução lógica passo a passo e recusa de preconceitos."
            "pragmatismo" -> "<strong>Prisma Pragmático (William James / Peirce):</strong> Validação pelo valor da consequência prática; a melhor decisão é a que gera utilidade comprovável no mundo real."
            else -> "<strong>Prisma Dialético (Hegel / Heráclito):</strong> Síntese dinâmica entre Tese (Expansão) e Antítese (Conservação), gerando uma solução evoluída e imune a dogmas estáticos."
        }

        val cenarioDelta = mapOf(
            "id" to "delta",
            "nome" to "Cenário Delta (Síntese Epistemológica)",
            "arquetipo" to "Filtro Filosófico: $philosophy",
            "probabilidade" to "Equilíbrio Áureo",
            "frequencia_hz" to hzDelta,
            "horizonte" to "Atemporal / Estratégico",
            "vetor_acao" to filoAnalise,
            "risco_potencial" to "Excesso de reflexão (paralisia por análise) se não conjugado com ação prática.",
            "impacto_simbolico" to "Clareza reflexiva e ancoragem metafísica na Árvore da Vida."
        )

        val colapso = when {
            riskFactor >= 0.65 -> cenarioAlpha
            riskFactor <= 0.35 -> cenarioGamma
            else -> cenarioBeta
        }

        val cenariosList = listOf(cenarioAlpha, cenarioBeta, cenarioGamma, cenarioDelta)

        return mapOf(
            "pergunta" to clean,
            "parametros_observador" to mapOf(
                "prisma_risco" to riskFactor,
                "filosofia" to philosophy,
                "rigor_logico" to rigor
            ),
            "colapso_primario" to colapso,
            "cenarios" to cenariosList,
            "nodos_grafo" to listOf(
                mapOf("id" to "ROOT", "label" to "Consulta (Superposição)", "tipo" to "observador", "prob" to "100%"),
                mapOf("id" to "ALPHA", "label" to "Alpha: Expansão", "tipo" to "expansivo", "prob" to "$pA%", "hz" to hzAlpha),
                mapOf("id" to "BETA", "label" to "Beta: Resiliência", "tipo" to "conservador", "prob" to "$pB%", "hz" to hzBeta),
                mapOf("id" to "GAMMA", "label" to "Gamma: Ruptura", "tipo" to "disruptivo", "prob" to "$pC%", "hz" to hzGamma),
                mapOf("id" to "DELTA", "label" to "Delta: $philosophy", "tipo" to "filosofico", "prob" to "Síntese", "hz" to hzDelta)
            )
        )
    }

    private fun renderHtmlOutput(data: Map<String, Any>): String {
        @Suppress("UNCHECKED_CAST")
        val colapso = data["colapso_primario"] as Map<String, Any>
        @Suppress("UNCHECKED_CAST")
        val params = data["parametros_observador"] as Map<String, Any>
        @Suppress("UNCHECKED_CAST")
        val cenarios = data["cenarios"] as List<Map<String, Any>>

        val cards = StringBuilder()
        for (c in cenarios) {
            val isAtivo = c["id"] == colapso["id"]
            val cardStyle = if (isAtivo) {
                "border: 2px solid #ffd700; background: rgba(255, 215, 0, 0.08);"
            } else {
                "border: 1px solid rgba(0, 240, 255, 0.2); background: rgba(0, 15, 30, 0.5);"
            }

            cards.append("""
<div style="margin-top: 10px; padding: 12px; border-radius: 8px; $cardStyle">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <strong style="color: #00f0ff; font-size: 0.95em;">${c["nome"]}</strong>
        <span style="font-size: 0.8em; padding: 2px 8px; border-radius: 4px; background: rgba(0, 240, 255, 0.15); color: #ffd700;">Prob: ${c["probabilidade"]} | ${c["frequencia_hz"]} Hz</span>
    </div>
    <div style="font-size: 0.85em; color: #a0c0d0; margin-top: 4px;"><strong>Arquétipo:</strong> ${c["arquetipo"]}</div>
    <div style="font-size: 0.85em; color: #e0f0ff; margin-top: 6px;"><strong>Vetor de Ação:</strong> ${c["vetor_acao"]}</div>
    <div style="font-size: 0.80em; color: #ff8080; margin-top: 4px;"><strong>Risco / Ponto de Atenção:</strong> ${c["risco_potencial"]}</div>
</div>
            """.trimIndent())
        }

        val riscoVal = String.format(Locale.US, "%.2f", params["prisma_risco"] as Double)
        val rigorVal = String.format(Locale.US, "%.2f", params["rigor_logico"] as Double)

        return """
🏛️ [ORÁCULO ANALÍTICO MULTI-V: SIMULADOR DE REALIDADES]
<br><br><strong>Consulta do Observador:</strong> <em>"${data["pergunta"]}"</em>
<br><strong>Parâmetros do Observador:</strong> Prisma Risco: <code>$riscoVal</code> | Filosofia: <code>${params["filosofia"]}</code> | Rigor: <code>$rigorVal</code>
<br><br>⚡ <strong>COLAPSO DE SUPERPOSIÇÃO ATIVO:</strong> <span style="color: #ffd700;">${colapso["nome"]} (${colapso["arquetipo"]})</span>
<br><br><strong>Ramificações Quântico-Simbólicas em Paralelo:</strong>
$cards
<br><div style="font-size: 0.80em; color: #7090a0; margin-top: 8px; border-top: 1px dashed rgba(0,240,255,0.2); padding-top: 6px;">
✨ <em>Dica: Use os controles deslizantes do Painel do Observador ou toque nos nós de ramificação para navegar entre as realidades em tempo real.</em>
</div>
        """.trimIndent()
    }

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context
        val prompt = context.prompt.trim()

        if (context.customResponse.isNotEmpty()) return context

        if (isDecisionOrScenarioQuery(prompt)) {
            val risk = (context.metadata["prisma_risco"] as? Double) ?: 0.5
            val philosophy = (context.metadata["filosofia"] as? String) ?: "Dialética"
            val rigor = (context.metadata["rigor_logico"] as? Double) ?: 0.8

            val multiverseData = generateScenarios(prompt, risk, philosophy, rigor)
            context.customResponse = renderHtmlOutput(multiverseData)
            context.metadata["multiverse_data"] = multiverseData
            context.metadata["oracle_engine"] = "Multi-V"
            context.finalState = "11 (Superposição Multiverso Colapsada)"

            @Suppress("UNCHECKED_CAST")
            val colapso = multiverseData["colapso_primario"] as Map<String, Any>
            context.totalFrequencyHz = (colapso["frequencia_hz"] as? Double) ?: 432.0
        }

        return context
    }
}
