#include "nd_assistant.h"

#include <stdio.h>
#include <string.h>

static int has(const char *s, const char *n) { return strstr(s, n) != NULL; }

int main(int argc, char **argv) {
    if (argc != 5) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION\n", argv[0]);
        return 2;
    }
    NDAssistant a;
    char err[256], out[65536], q[2048], ctx[4096], expected[128];
    NDAnswerMeta m;
    if (nd_assistant_load(&a, argv[1], argv[2], argv[3], argv[4], err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }
    int bad = 0;
    int total = 0;

    for (int i = 0; i < 80; i++) {
        int x = 11 + i, y = 3 + (i % 17), z = x * y;
        snprintf(q, sizeof(q), "Quanto é %d vezes %d e qual é a capital do Brasil?", x, y);
        snprintf(expected, sizeof(expected), "%d", z);
        if (nd_assistant_answer(&a, q, NULL, 1, out, sizeof(out), &m, err, sizeof(err)) ||
            m.source != ND_ANSWER_COMPOSED || m.covered_goals != 2u ||
            !has(out, expected) || !has(out, "Brasília")) bad++;
        total++;
    }

    for (int i = 0; i < 80; i++) {
        snprintf(ctx, sizeof(ctx), "A versão registrada de Registro-X%d é v4.%d.%d.", i, i % 10, (i * 3) % 20);
        snprintf(q, sizeof(q), "Qual é a versão de Registro-X%d e o que é TLS?", i);
        snprintf(expected, sizeof(expected), "v4.%d.%d", i % 10, (i * 3) % 20);
        if (nd_assistant_answer(&a, q, ctx, 1, out, sizeof(out), &m, err, sizeof(err)) ||
            m.source != ND_ANSWER_COMPOSED || m.covered_goals != 2u ||
            !has(out, expected) || !has(out, "TLS")) bad++;
        total++;
    }

    for (int i = 0; i < 80; i++) {
        int x = 5 + i, y = 2 + (i % 9), z = x + y;
        snprintf(ctx, sizeof(ctx), "O registro de Registro-Y%d informa o código QA-%04d.", i, 6000 + i);
        snprintf(q, sizeof(q), "Qual é o código de Registro-Y%d e quanto é %d mais %d?", i, x, y);
        snprintf(expected, sizeof(expected), "%d", z);
        char code[64];
        snprintf(code, sizeof(code), "QA-%04d", 6000 + i);
        if (nd_assistant_answer(&a, q, ctx, 1, out, sizeof(out), &m, err, sizeof(err)) ||
            m.source != ND_ANSWER_COMPOSED || m.covered_goals != 2u ||
            !has(out, code) || !has(out, expected)) bad++;
        total++;
    }

    for (int i = 0; i < 80; i++) {
        int x = 20 + i, y = 2 + (i % 7), z = x - y;
        snprintf(ctx, sizeof(ctx), "O status atual de Registro-Z%d é operacional.", i);
        snprintf(q, sizeof(q), "Qual é o status de Registro-Z%d e quanto é %d menos %d e o que é JSON?", i, x, y);
        snprintf(expected, sizeof(expected), "%d", z);
        if (nd_assistant_answer(&a, q, ctx, 1, out, sizeof(out), &m, err, sizeof(err)) ||
            m.source != ND_ANSWER_COMPOSED || m.covered_goals != 3u ||
            !has(out, "operacional") || !has(out, expected) || !has(out, "JSON")) bad++;
        total++;
    }

    nd_assistant_free(&a);
    if (bad) {
        fprintf(stderr, "multigoal failures=%d/%d\n", bad, total);
        return 1;
    }
    printf("multigoal PASS %d/%d\n", total, total);
    return 0;
}
