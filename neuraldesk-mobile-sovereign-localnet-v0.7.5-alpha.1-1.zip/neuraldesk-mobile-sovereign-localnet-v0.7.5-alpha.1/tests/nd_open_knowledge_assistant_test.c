#include "nd_assistant.h"

#include <stdio.h>
#include <string.h>

static int contains(const char *s, const char *needle) {
    return s && needle && strstr(s, needle) != NULL;
}

int main(int argc, char **argv) {
    if (argc != 6) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION OPEN_SHARD\n", argv[0]);
        return 2;
    }
    NDAssistant a;
    NDAnswerMeta m;
    char err[256];
    char out[65536];
    if (nd_assistant_load_ex(&a, argv[1], argv[2], argv[3], argv[4], argv[5], NULL, err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }
    int bad = 0;

    if (nd_assistant_answer(&a, "Qual é a capital do Brasil?", NULL, 1, out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_KNOWLEDGE || !contains(out, "Brasília") || m.open_knowledge_hits != 0u) {
        fprintf(stderr, "internal precedence failed: %s\n", out);
        bad++;
    }

    if (nd_assistant_answer(&a, "Para estimar fluxos ar-mar de calor sensíveis e latentes, qual método é utilizado?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_OPEN_KNOWLEDGE || !contains(out, "covariância turbulenta") ||
        !contains(out, "A160") || m.open_knowledge_hits != 1u) {
        fprintf(stderr, "open knowledge validation paraphrase failed: %s\n", out);
        bad++;
    }

    const char *ctx = "A medição local informa que o valor atual do projeto Atlas-77 é CTX-551.";
    if (nd_assistant_answer(&a, "Qual é o valor atual do projeto Atlas-77?", ctx, 1,
                            out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_CONTEXT || !contains(out, "CTX-551") || m.open_knowledge_hits != 0u) {
        fprintf(stderr, "context precedence failed: %s\n", out);
        bad++;
    }

    if (nd_assistant_answer(&a, "Qual é a senha privada secreta que nunca foi fornecida?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_UNCERTAIN || m.open_knowledge_hits != 0u) {
        fprintf(stderr, "unknown fail-closed failed: %s\n", out);
        bad++;
    }

    nd_assistant_free(&a);
    if (bad) return 1;
    puts("open_knowledge_assistant PASS");
    return 0;
}
