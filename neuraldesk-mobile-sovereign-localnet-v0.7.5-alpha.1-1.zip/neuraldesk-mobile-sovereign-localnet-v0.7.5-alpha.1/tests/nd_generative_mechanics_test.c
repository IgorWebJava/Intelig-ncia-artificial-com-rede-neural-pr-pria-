#include "nd_generative.h"

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ND_MECH_QUANT_PROBES 20u

static uint32_t argmax_local(const float *x) {
    uint32_t best = 0u;
    uint32_t i;
    for (i = 1u; i < ND_GEN_VOCAB; ++i) {
        if (x[i] > x[best]) {
            best = i;
        }
    }
    return best;
}

static int parse_unsigned(const char *text, unsigned int *value) {
    char *end = NULL;
    unsigned long parsed;
    if (!text || !text[0] || !value) return -1;
    parsed = strtoul(text, &end, 10);
    if (!end || *end != '\0' || parsed > 0xfffffffful) return -1;
    *value = (unsigned int)parsed;
    return 0;
}

static int load_three(char **argv, NDGenerativeModel **fp, NDGenerativeModel **q8, NDGenerativeModel **q4) {
    if (nd_gen_load(argv[1], fp) != 0 || nd_gen_load(argv[2], q8) != 0 || nd_gen_load(argv[3], q4) != 0) {
        fprintf(stderr, "model load failed\n");
        return -1;
    }
    return 0;
}

int main(int argc, char **argv) {
    NDGenerativeModel *fp = NULL;
    NDGenerativeModel *q8 = NULL;
    NDGenerativeModel *q4 = NULL;
    uint32_t prompt[] = {259u, 81u, 117u, 97u, 110u, 116u, 105u, 122u};
    float full[ND_GEN_VOCAB];
    float inc[ND_GEN_VOCAB];
    NDGenKVCache cache;
    NDGenKVCache clone;
    float max_abs = 0.0f;
    size_t i;
    unsigned int q8_ok = 0u;
    unsigned int q4_ok = 0u;
    unsigned int quant_start = 0u;
    unsigned int quant_count = ND_MECH_QUANT_PROBES;
    uint32_t greedy[8];
    uint32_t spec[8];
    NDGenSpecStats stats;
    int run_core = 1;
    int run_quant = 1;
    int full_mode = 1;
    int cache_live = 0;
    int clone_live = 0;
    int rc = 0;

    memset(&cache, 0, sizeof(cache));
    memset(&clone, 0, sizeof(clone));
    memset(&stats, 0, sizeof(stats));

    if (argc == 5 && strcmp(argv[4], "--core") == 0) {
        run_quant = 0;
        full_mode = 0;
    } else if (argc == 7 && strcmp(argv[4], "--quant") == 0) {
        run_core = 0;
        full_mode = 0;
        if (parse_unsigned(argv[5], &quant_start) != 0 ||
            parse_unsigned(argv[6], &quant_count) != 0 ||
            quant_count == 0u || quant_start >= ND_MECH_QUANT_PROBES ||
            quant_count > ND_MECH_QUANT_PROBES - quant_start) {
            fprintf(stderr, "invalid quant slice\n");
            return 2;
        }
    } else if (argc != 4) {
        fprintf(stderr, "usage: %s FP32 Q8 Q4 [--core | --quant START COUNT]\n", argv[0]);
        return 2;
    }

    if (load_three(argv, &fp, &q8, &q4) != 0) {
        rc = 2;
        goto cleanup;
    }
    if (nd_gen_parameter_count(fp) != ND_GEN_PARAMS || !nd_gen_mmap_active(fp) ||
        nd_gen_format(fp) != ND_GEN_FP32 || nd_gen_format(q8) != ND_GEN_Q8 || nd_gen_format(q4) != ND_GEN_Q4) {
        fprintf(stderr, "header/mechanics identity failed\n");
        rc = 3;
        goto cleanup;
    }

    if (run_core) {
        if (nd_gen_full_forward(fp, prompt, sizeof(prompt) / sizeof(prompt[0]), full, ND_GEN_VOCAB) != 0) {
            rc = 4;
            goto cleanup;
        }
        nd_gen_kv_init(&cache);
        cache_live = 1;
        for (i = 0u; i < sizeof(prompt) / sizeof(prompt[0]); ++i) {
            if (nd_gen_incremental_step(fp, &cache, prompt[i], inc, ND_GEN_VOCAB) != 0) {
                rc = 5;
                goto cleanup;
            }
        }
        for (i = 0u; i < ND_GEN_VOCAB; ++i) {
            float d = fabsf(full[i] - inc[i]);
            if (d > max_abs) max_abs = d;
        }
        if (max_abs > 1.0e-5f) {
            fprintf(stderr, "oracle parity max_abs=%g\n", (double)max_abs);
            rc = 6;
            goto cleanup;
        }
        if (nd_gen_kv_clone(&cache, &clone) != 0) {
            rc = 7;
            goto cleanup;
        }
        clone_live = 1;
        if (nd_gen_kv_shared_pages(&cache, &clone) == 0u) {
            rc = 7;
            goto cleanup;
        }
        if (nd_gen_incremental_step(fp, &clone, 33u, inc, ND_GEN_VOCAB) != 0) {
            rc = 8;
            goto cleanup;
        }
        if (nd_gen_kv_shared_pages(&cache, &clone) != 0u) {
            fprintf(stderr, "COW did not detach shared tail page\n");
            rc = 9;
            goto cleanup;
        }
        nd_gen_kv_free(&clone);
        clone_live = 0;
        nd_gen_kv_free(&cache);
        cache_live = 0;

        if (nd_gen_greedy_generate(fp, prompt, 8u, greedy, 8u, 8u) != 0 ||
            nd_gen_speculative_greedy(fp, prompt, 8u, spec, 8u, 8u, 1, &stats) != 0 ||
            memcmp(greedy, spec, sizeof(greedy)) != 0 || stats.rejected == 0u || stats.rollbacks == 0u) {
            rc = 12;
            goto cleanup;
        }
    }

    if (run_quant) {
        unsigned int end = quant_start + quant_count;
        unsigned int probe;
        for (probe = quant_start; probe < end; ++probe) {
            uint32_t p[2] = {(uint32_t)(20u + probe), (uint32_t)(300u + probe)};
            float lf[ND_GEN_VOCAB];
            float l8[ND_GEN_VOCAB];
            float l4[ND_GEN_VOCAB];
            if (nd_gen_full_forward(fp, p, 2u, lf, ND_GEN_VOCAB) != 0 ||
                nd_gen_full_forward(q8, p, 2u, l8, ND_GEN_VOCAB) != 0 ||
                nd_gen_full_forward(q4, p, 2u, l4, ND_GEN_VOCAB) != 0) {
                rc = 10;
                goto cleanup;
            }
            if (argmax_local(lf) == argmax_local(l8)) q8_ok++;
            if (argmax_local(lf) == argmax_local(l4)) q4_ok++;
        }
        if (full_mode) {
            if (q8_ok < 18u || q4_ok < 15u) {
                fprintf(stderr, "quant parity q8=%u/20 q4=%u/20\n", q8_ok, q4_ok);
                rc = 11;
                goto cleanup;
            }
        } else if (q8_ok != quant_count || q4_ok != quant_count) {
            fprintf(stderr, "quant slice parity start=%u count=%u q8=%u q4=%u\n",
                    quant_start, quant_count, q8_ok, q4_ok);
            rc = 11;
            goto cleanup;
        }
    }

    if (full_mode) {
        printf("GENERATIVE_MECHANICS PASS params=%u mmap=1 oracleMaxAbs=%.9g q8=%u/20 q4=%u/20 sharedPrefix=1 cow=1 speculativeParity=8/8 rejections=%zu rollbacks=%zu speedupClaimed=false\n",
               ND_GEN_PARAMS, (double)max_abs, q8_ok, q4_ok, stats.rejected, stats.rollbacks);
    } else if (run_core) {
        printf("GENERATIVE_MECHANICS_CORE PASS params=%u mmap=1 oracleMaxAbs=%.9g sharedPrefix=1 cow=1 speculativeParity=8/8 rejections=%zu rollbacks=%zu speedupClaimed=false\n",
               ND_GEN_PARAMS, (double)max_abs, stats.rejected, stats.rollbacks);
    } else {
        printf("GENERATIVE_MECHANICS_QUANT_SLICE PASS start=%u count=%u q8=%u/%u q4=%u/%u\n",
               quant_start, quant_count, q8_ok, quant_count, q4_ok, quant_count);
    }

cleanup:
    if (clone_live) nd_gen_kv_free(&clone);
    if (cache_live) nd_gen_kv_free(&cache);
    nd_gen_free(fp);
    nd_gen_free(q8);
    nd_gen_free(q4);
    return rc;
}
