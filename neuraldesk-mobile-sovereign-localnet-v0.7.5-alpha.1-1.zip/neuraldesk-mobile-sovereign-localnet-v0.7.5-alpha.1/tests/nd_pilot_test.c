#include "nd_pilot.h"
#include <stdio.h>

int main(void) {
    NDPilotControl c;
    nd_pilot_init(&c);
    int fail = 0;
    for (int i = 0; i < ND_PILOT_FEATURE_COUNT; i++) fail += !nd_pilot_allowed(&c, (NDPilotFeature)i);
    fail += nd_pilot_set_feature(&c, ND_PILOT_DURABLE_TASKS, 0, 10) != 0;
    fail += nd_pilot_allowed(&c, ND_PILOT_DURABLE_TASKS) != 0;
    fail += nd_pilot_set_master_kill(&c, 1, 20) != 0;
    fail += nd_pilot_allowed(&c, ND_PILOT_LOCAL_INFERENCE) != 0;
    fail += nd_pilot_set_master_kill(&c, 0, 30) != 0;
    fail += !nd_pilot_allowed(&c, ND_PILOT_LOCAL_INFERENCE);
    fail += nd_pilot_allowed(&c, ND_PILOT_DURABLE_TASKS) != 0;
    fail += c.audit_count != 3u;
    printf("PILOT_CONTROL %s audit=%zu\n", fail ? "FAIL" : "PASS", c.audit_count);
    return fail ? 1 : 0;
}
