# Project License Status

Nenhuma licença pública de redistribuição é concedida por este pacote. O código e os artefatos próprios permanecem sob os direitos do proprietário do projeto, salvo componentes de terceiros sujeitos às suas próprias licenças.

Este arquivo não altera licenças de ferramentas, bibliotecas ou referências de terceiros descritas em `THIRD_PARTY_NOTICES.md`.
