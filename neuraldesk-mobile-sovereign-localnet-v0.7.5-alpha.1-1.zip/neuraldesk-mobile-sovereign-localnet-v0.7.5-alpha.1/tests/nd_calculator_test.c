#include "nd_tools.h"

#include <math.h>
#include <stdio.h>

int main(void) {
    char error[128];
    char out[512];
    struct Case { const char *q; double value; } cases[] = {
        {"Quanto é 7 vezes 8?", 56.0},
        {"Quanto é 12 mais 30?", 42.0},
        {"Quanto é 10 menos 3?", 7.0},
        {"Quanto é 9 dividido por 4?", 2.25},
        {"Calcule 2.5 + 0.5", 3.0},
        {"Quanto é 25% de 200?", 50.0},
        {"Qual é a raiz quadrada de 81?", 9.0},
        {"Quanto é 2 elevado a 10?", 1024.0},
        {"Quanto é (37 × 19) + 15?", 718.0},
        {"Calcule 2 + 3 * 4", 14.0},
        {"Calcule (2 + 3) * 4", 20.0},
        {"Quanto é 100 ÷ (5 × 4)?", 5.0},
        {"Calcule 2^3^2", 512.0}
    };

    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
        NDCalculatorResult result;
        int status = nd_calculator_try(cases[i].q, 1, out, sizeof(out),
                                       &result, error, sizeof(error));
        if (status != 1 || !result.ok || fabs(result.value - cases[i].value) > 1e-9) {
            fprintf(stderr, "FAIL %s => %s (%s)\n", cases[i].q, out, error);
            return 1;
        }
    }

    NDCalculatorResult result;
    if (nd_calculator_try("Qual é a capital do Brasil?", 1, out, sizeof(out),
                          &result, error, sizeof(error)) != 0) return 1;
    if (nd_calculator_try("Quanto é 5 dividido por 0?", 1, out, sizeof(out),
                          &result, error, sizeof(error)) != 1 || result.ok) return 1;
    if (nd_calculator_try("Calcule 10 / (3 - 3)", 1, out, sizeof(out),
                          &result, error, sizeof(error)) != 1 || result.ok) return 1;

    puts("calculator 16/16 PASS");
    return 0;
}
