<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.experience -->
# Current Intelligence Experience — V8.11

V8.11 preserves the `intelligence-experience-v2` language introduced in V8.2 and evolves it additively with `cooperative-engine-bridge-v1`.

## Stable experience mechanics

The 10 canonical modules retain their specialized workspaces: App Shell continuity/work graph, adaptive Chat + Artifact Workspace, Agent Design Studio, Knowledge Labs, Tool Marketplace/Builder/Testbench, Training Experiment Lab, Operations trace/anomaly workspace, Audit investigations, System Config Change Planner and user-level Settings.

## New cooperative layer

Every module now exposes an Engine Bridge surface that can represent future state such as session replay, turn/step lifecycle, compaction/spill, durable jobs, invariants, tool-effect durability, UNKNOWN_OUTCOME, subagent federation, sandbox policy and extension governance where relevant.

The bridge is progressive disclosure: it does not replace the module's primary workflow and does not imply an executable engine.

## Profiles

- Experience: `intelligence-experience-v2`
- Runtime: `workspace-runtime-v2`
- Design System: `neuraldesk-intelligence-design-v2`
- Engine Bridge: `cooperative-engine-bridge-v1`
- Quality: `module-quality-v2`
