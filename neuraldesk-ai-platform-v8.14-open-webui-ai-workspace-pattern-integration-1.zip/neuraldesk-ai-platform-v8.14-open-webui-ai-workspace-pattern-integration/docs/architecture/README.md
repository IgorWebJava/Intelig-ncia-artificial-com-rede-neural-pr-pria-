<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.architecture; current: docs/architecture/CURRENT_ARCHITECTURE.md -->
# Architecture Documentation

Start with current documents:

- `CURRENT_ARCHITECTURE.md`
- `CURRENT_INTELLIGENCE_EXPERIENCE.md`
- `CURRENT_EXPERIENCE_RUNTIME.md`
- `CURRENT_INTERFACE_CAPABILITY_MAP.md`
- `CURRENT_TEMPLATE_BOUNDARIES.md`
- `CURRENT_MODULE_DEPENDENCY_MATRIX.md`
- `CURRENT_AI_MULTIMODAL_PLATFORM.md`
- `CURRENT_DATA_EVENT_CONSISTENCY.md`
- `CURRENT_MODULE_MODEL_REPLACEMENT.md`
- `CURRENT_RESPONSIVE_PROFILE.md`
- `CURRENT_QUALITY_ENGINEERING.md`
- `CURRENT_SKILLS_TOOLING.md`
- `CURRENT_AGENT_PLATFORM.md`
- `CURRENT_PREVIEW_REGISTRY.md`

Versioned/numbered documents are historical or detailed reference material.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
