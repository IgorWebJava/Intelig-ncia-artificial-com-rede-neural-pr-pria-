<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->
# Workflow — Evoluir Interface + Engine sem regressão

1. Capture/read current baseline.
2. Identify UI owner + future engine owner.
3. Preserve route/action/tab/contract/capability semantics.
4. Extend capability/contract additively.
5. Update Engine Bridge + interface compatibility docs.
6. Add/extend module-owned tests and scenarios.
7. Regenerate preview for visual changes.
8. Run non-regression and Engine/UI compatibility gates.
9. Run full release gates.
10. Regenerate documentation status registry, then documentation inventory.
11. Update memory + AI handoff.
12. Package one complete ZIP.
