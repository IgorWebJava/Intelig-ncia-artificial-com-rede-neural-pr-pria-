<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Web Research / Primary Source Verification

    Tool ID: `tool.web-research`

    ## Role in NeuralDesk development

    Verify current standards, platform patterns and time-sensitive technical facts.

    ## Current implementations

    - `web.run`

    ## Capabilities provided

    - `web.research.v1`
- `source.verify.v1`

    ## Constraints

    - Prefer primary/official technical sources.
- Do not browse when project-local files are the source of truth.

    ## Portable alternatives

    - search engine + official docs access
- technical research connector

    ## Rule

    The capability is more important than the tool name. A future AI may replace this tool if it provides equivalent capabilities and passes the relevant quality gates.
