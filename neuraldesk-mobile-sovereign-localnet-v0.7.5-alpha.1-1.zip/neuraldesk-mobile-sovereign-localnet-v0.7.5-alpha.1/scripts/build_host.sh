#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/scripts/pre_generation_lessons_check.py"
JOBS="${ND_BUILD_JOBS:-2}"
[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || { echo "ND_BUILD_JOBS inválido: $JOBS" >&2; exit 2; }
cmake -S "$ROOT" -B "$ROOT/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DND_WARNINGS_AS_ERRORS=ON
cmake --build "$ROOT/build" -j"$JOBS"
