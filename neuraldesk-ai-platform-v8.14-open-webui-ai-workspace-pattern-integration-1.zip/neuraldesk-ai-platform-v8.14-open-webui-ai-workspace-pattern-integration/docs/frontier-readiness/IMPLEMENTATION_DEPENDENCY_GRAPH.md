# Implementation Dependency Graph

```text
Measurement / Eval Baseline
        |
Runtime Kernel -- Identity -- Persistence -- Config -- Observability
        |
Capability Resolution -- API/BFF
        |
Project + Conversation
        |
Model Runtime + Router
        |
Goal + Context + Memory
        |
Knowledge/RAG -- Tool + Policy
        |
Planner/Orchestrator -- Agent/Skill/Workflow
        |
Task + Checkpoint + Artifact
        |
Web Research / Multimodal / Voice / Browser
        |
Background Work / Notifications
        |
Production Control Plane
        |
Own Specialized Models
        |
Frontier Model Research
```

Dependencies are intentionally biased toward correctness and governance before autonomy.
