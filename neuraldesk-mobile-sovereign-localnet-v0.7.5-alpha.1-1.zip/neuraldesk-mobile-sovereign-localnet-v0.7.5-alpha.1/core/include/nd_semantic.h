#ifndef ND_SEMANTIC_H
#define ND_SEMANTIC_H

#include <stddef.h>

typedef enum {
    ND_INTENT_GENERAL = 0,
    ND_INTENT_ROLE_CAPABILITIES = 1,
    ND_INTENT_DEFINE_INFERENCE = 2,
    ND_INTENT_WEIGHT_UPDATE = 3,
    ND_INTENT_DEFINE_RAG = 4,
    ND_INTENT_COMPARE_QUANT_KV = 5,
    ND_INTENT_DYNAMIC_EVENT = 6,
    ND_INTENT_SUMMARY_CONTEXT = 7,
    ND_INTENT_SUMMARY_HISTORY = 8,
    ND_INTENT_CREATIVE = 9,
    ND_INTENT_PERCENTAGE = 10,
    ND_INTENT_NON_ENTAILMENT = 11,
    ND_INTENT_QUANTIZATION_SAVINGS = 12,
    ND_INTENT_COMPARE_TRANSFORMER_RNN = 13,
    ND_INTENT_KEYWORDS_CONTEXT = 14
} NDIntent;

typedef enum {
    ND_EXPECT_ANY = 0,
    ND_EXPECT_PERSON = 1,
    ND_EXPECT_CODE = 2,
    ND_EXPECT_NUMBER = 3,
    ND_EXPECT_DATE = 4,
    ND_EXPECT_MATERIAL = 5,
    ND_EXPECT_BOOLEAN = 6,
    ND_EXPECT_EXPLANATION = 7
} NDExpectedAnswerType;

typedef struct {
    NDIntent intent;
    NDExpectedAnswerType expected_type;
    unsigned sentence_limit;
    int has_temporal_scope;
    int requires_fresh_evidence;
    int is_comparison;
    int has_universal_quantifier;
    int creative;
    int percentage;
    int non_entailment;
} NDSemanticFrame;

int nd_semantic_analyze(const char *question, NDSemanticFrame *frame);
int nd_semantic_direct_answer(const NDSemanticFrame *frame,
                              const char *question,
                              char *out,
                              size_t outcap);
const char *nd_semantic_intent_name(NDIntent intent);

#endif
