#include "nd_model_acquisition.h"
#include <stdio.h>

int main(void) {
    NDResourcePolicy p = nd_resource_policy(ND_PROFILE_MOBILE);
    NDNetworkSnapshot normal = nd_network_snapshot(1, 0, 5000u);
    NDNetworkSnapshot offline = nd_network_snapshot(0, 0, 0u);
    NDModelAcquisitionReport a = nd_model_acquisition_assess(200000000u, 4u, 64000000u,
        1000000000u, 100000000u, 1, &p, &normal);
    NDModelAcquisitionReport b = nd_model_acquisition_assess(200000000u, 4u, 64000000u,
        200000000u, 100000000u, 1, &p, &normal);
    NDModelAcquisitionReport c = nd_model_acquisition_assess(200000000u, 4u, 64000000u,
        1000000000u, 100000000u, 1, &p, &offline);
    int fail = 0;
    fail += a.estimated_model_bytes != 164000000u;
    fail += a.decision != ND_MODEL_ACQUISITION_REQUIRES_CONFIRMATION;
    fail += b.decision != ND_MODEL_ACQUISITION_BLOCKED_STORAGE;
    fail += c.decision != ND_MODEL_ACQUISITION_CACHE_ONLY_OFFLINE;
    printf("MODEL_ACQUISITION %s bytes=%llu decision=%s\n", fail ? "FAIL" : "PASS",
           (unsigned long long)a.estimated_model_bytes, nd_model_acquisition_decision_name(a.decision));
    return fail ? 1 : 0;
}
