# Open Knowledge Shard — v0.7.2-alpha.1

O shard ativo permanece Pirá NDOS de **31 registros**, SHA `b4967b52...`. Um candidate histórico completo de **1.281 registros**, 1.518.756 bytes, SHA `7a35d2b6...`, é distribuído apenas como `CANDIDATE_NOT_ACTIVATED_PRECISION_GATE_PENDING`; mais recall não substitui quality/answerability gates.

## Objetivo

Adicionar conhecimento humano auditável ao runtime local sem importar um modelo externo, sem transformar recuperação em “treinamento” e sem permitir que dados abertos substituam contexto, ferramentas, memória ou conhecimento first-party já aceito.

## Formato

Arquivo canônico: `models/neuraldesk-open-knowledge-pira-v0.6.ndos`.

Header `NDOSV001` contém versão, número de registros, número de buckets, IDF buckets, sparse entries, top-k, flags e thresholds de score/margem. O loader rejeita tamanhos impossíveis, bucket count não power-of-two, IDF/features fora de ordem, NaN/Inf, contagens divergentes, truncamento e bytes extras.

## Features

1. normalização UTF-8 português/Latin-1 para ASCII lowercase;
2. word unigrams;
3. word bigrams;
4. char n-grams 3, 4 e 5 sobre texto compacto;
5. FNV-1a 64-bit padrão;
6. redução para 65.536 buckets fixos;
7. TF-IDF;
8. top-96 features por registro;
9. cosine similarity.

Aceitação é fail-closed: `score >= 0.33` **e** `margin >= 0.08`.

## Dados

O subset contém 31 pares pergunta/resposta humanos em português do Pirá 2.0, licença CC BY 4.0. O `test.csv` original não é usado. Campos automáticos não entram no shard. Paráfrases humanas separadas são apenas avaliação.

Lineage e hashes: `training/data/open_knowledge/PIRA_RECONSTRUCTION_PROVENANCE.json`.

## Métricas

- 53/53 paridade Python↔C no conjunto de 28 positivos + 25 negativos;
- positivos: 28/28 raw top-1, 25/25 aceitos corretos, 0 aceitos errados;
- negativos: 0/25 aceitos;
- holdout pós-implementação: 3/3 raw top-1 e 2/2 aceitos corretos;
- corrupções: 4/4 rejeitadas;
- rebuild: 2/2 byte-idêntico ao asset canônico.

## Fronteira semântica

NDOS é **retrieval**, não uma rede neural. O answer text vem do registro humano local selecionado. A confiança representa similaridade/isolamento do match dentro desse shard finito, não probabilidade universal de verdade.

## Asset promovido nesta reconstrução

- registros: 31;
- bytes: 68.177;
- SHA-256: `b4967b52e02daf3dea5833ee5f7df63ecbf4edc3bf88d95b7f407423f44419c7`;
- ordem de autoridade: somente depois de contexto, ferramenta exata, memória e retriever+KB internos;
- ausência de score/margem: incerteza, nunca best-effort silencioso.

## Relação com o fallback sparse v0.6.1

O fallback sparse novo não consulta o NDOS e não altera seus thresholds. Ele opera exclusivamente sobre a KB first-party interna, após recusa neural. Somente se essa rota interna inteira recusar o assistant consulta o NDOS Pirá. Assim as duas camadas não são confundidas nem contam como parâmetros neurais.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
