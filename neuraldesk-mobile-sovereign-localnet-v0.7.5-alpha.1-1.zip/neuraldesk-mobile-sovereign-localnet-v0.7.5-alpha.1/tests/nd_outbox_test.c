#include "nd_outbox.h"
#include <stdio.h>
#include <string.h>

static int corrupt_tail(const char *path) {
    FILE *f = fopen(path, "ab");
    if (!f) return -1;
    unsigned char x = 0x7fu;
    int rc = fwrite(&x, 1u, 1u, f) == 1u ? 0 : -1;
    if (fclose(f) != 0) rc = -1;
    return rc;
}

int main(void) {
    const char *path = "/tmp/neuraldesk-outbox-v072-test.ndbx";
    remove(path);
    NDOutbox o;
    nd_outbox_init(&o);
    char err[256];
    int fail = 0;
    fail += nd_outbox_configure(&o, ND_PROFILE_MOBILE, path, err, sizeof(err)) != 0;
    uint64_t parent = 0u, child = 0u;
    fail += nd_outbox_enqueue(&o, "default", "indexar documento local", NULL, 0u, 0, 1000u, &parent, err, sizeof(err)) != 0;
    uint64_t deps[1] = { parent };
    fail += nd_outbox_enqueue(&o, "default", "pesquisar contexto web autorizado", deps, 1u, 1, 1001u, &child, err, sizeof(err)) != 0;
    NDNetworkSnapshot offline = nd_network_snapshot(0, 0, 0u);
    NDNetworkSnapshot normal = nd_network_snapshot(1, 0, 5000u);
    const NDOutboxItem *next = nd_outbox_next_eligible(&o, &offline, 0, 1002u);
    fail += !next || next->id != parent;
    fail += nd_outbox_mark_sending(&o, parent, err, sizeof(err)) != 0;
    fail += nd_outbox_mark_success(&o, parent, err, sizeof(err)) != 0;
    next = nd_outbox_next_eligible(&o, &offline, 0, 1003u);
    fail += next != NULL;
    next = nd_outbox_next_eligible(&o, &normal, 0, 1003u);
    fail += !next || next->id != child;
    char idem[ND_OUTBOX_IDEMPOTENCY_BYTES];
    snprintf(idem, sizeof(idem), "%s", next ? next->idempotency_key : "");
    fail += nd_outbox_mark_sending(&o, child, err, sizeof(err)) != 0;
    for (unsigned i = 0u; i < 5u; i++) fail += nd_outbox_mark_failure(&o, child, ND_OUTBOX_ERR_NETWORK, 2000u + i * 1000u, err, sizeof(err)) != 0;
    NDOutboxSummary sum = nd_outbox_summary(&o);
    fail += sum.paused != 1u;
    fail += strcmp(o.items[0].idempotency_key, idem) != 0;
    fail += nd_outbox_remove(&o, child, err, sizeof(err)) != 0;

    uint64_t p2 = 0u, c2 = 0u, new_parent = 0u;
    fail += nd_outbox_enqueue(&o, "default", "pai removível", NULL, 0u, 0, 10000u, &p2, err, sizeof(err)) != 0;
    uint64_t d2[1] = { p2 };
    fail += nd_outbox_enqueue(&o, "default", "filho dependente", d2, 1u, 0, 10001u, &c2, err, sizeof(err)) != 0;
    fail += nd_outbox_remove(&o, p2, err, sizeof(err)) != 0;
    fail += o.count != 1u || o.items[0].id != c2 || o.items[0].state != ND_OUTBOX_BLOCKED_DEPENDENCY;
    fail += nd_outbox_enqueue(&o, "default", "novo pai", NULL, 0u, 0, 10002u, &new_parent, err, sizeof(err)) != 0;
    uint64_t d3[1] = { new_parent };
    fail += nd_outbox_relink(&o, c2, d3, 1u, 10003u, err, sizeof(err)) != 0;
    fail += o.items[0].state != ND_OUTBOX_QUEUED;
    fail += nd_outbox_mark_sending(&o, new_parent, err, sizeof(err)) != 0;
    fail += nd_outbox_mark_success(&o, new_parent, err, sizeof(err)) != 0;
    fail += o.count != 1u || o.items[0].dependency_count != 0u;
    nd_outbox_free(&o);

    NDOutbox restored;
    nd_outbox_init(&restored);
    fail += nd_outbox_configure(&restored, ND_PROFILE_MOBILE, path, err, sizeof(err)) != 0;
    fail += nd_outbox_restore(&restored, 11000u, err, sizeof(err)) != 0;
    fail += restored.count != 1u;
    nd_outbox_free(&restored);

    fail += corrupt_tail(path) != 0;
    NDOutbox corrupt;
    nd_outbox_init(&corrupt);
    fail += nd_outbox_configure(&corrupt, ND_PROFILE_MOBILE, path, err, sizeof(err)) != 0;
    fail += nd_outbox_restore(&corrupt, 12000u, err, sizeof(err)) == 0;
    nd_outbox_free(&corrupt);
    remove(path);

    NDOutbox micro;
    nd_outbox_init(&micro);
    fail += nd_outbox_configure(&micro, ND_PROFILE_MICRO, NULL, err, sizeof(err)) != 0;
    char too_big[9000];
    memset(too_big, 'x', sizeof(too_big) - 1u);
    too_big[sizeof(too_big) - 1u] = 0;
    uint64_t tmpid = 0u;
    fail += nd_outbox_enqueue(&micro, "default", too_big, NULL, 0u, 0, 1u, &tmpid, err, sizeof(err)) == 0;
    nd_outbox_free(&micro);

    printf("DURABLE_OUTBOX %s idempotency=%s negative_controls=true\n", fail ? "FAIL" : "PASS", idem);
    return fail ? 1 : 0;
}
