<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Hardware Fit & Memory Preset Strategy

Before a future self-hosted model starts, NeuralDesk should profile RAM/HBM, CPU/GPU ISA, storage capacity/bandwidth, NUMA/device topology and context-cache budget, then recommend a named execution profile.

Profiles are generated from measured hardware and model metadata rather than hard-coded marketing tiers. The system must refuse configurations that cannot safely complete initialization or expected context growth.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
