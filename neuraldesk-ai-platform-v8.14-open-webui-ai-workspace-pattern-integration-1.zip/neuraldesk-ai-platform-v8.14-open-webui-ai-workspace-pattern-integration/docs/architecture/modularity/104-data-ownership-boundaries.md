<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 104 — Data Ownership Boundaries

One authoritative owner per mutable domain dataset.

No module may directly read/write another module's private tables.

Cross-module references are IDs and public contracts, not private-schema foreign keys.
