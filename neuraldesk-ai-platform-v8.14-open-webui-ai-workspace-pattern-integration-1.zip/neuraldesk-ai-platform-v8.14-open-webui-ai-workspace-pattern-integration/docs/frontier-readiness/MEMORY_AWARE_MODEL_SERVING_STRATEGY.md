<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Memory-Aware Model Serving Strategy

Future model serving must plan RAM/HBM/storage before load. Model state is partitioned into residency classes: always-resident state, pinnable dense/trunk weights, streamable weights, sparse expert weights, recurrent state, KV/context state and temporary buffers.

The planner must predict memory, context growth, storage traffic and expected degraded mode. A lower-memory mode may be slower, but must remain semantically correct within the declared numeric/determinism policy.

Policies must be benchmark-driven. Allocate memory where it avoids the most traffic/latency; do not assume equal percentage allocations or generic LRU are optimal.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
