import sys, unittest, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext

class EngineBridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx=TestContext(__file__)
    def test_bridge_profile_declared(self):
        self.assertEqual(self.ctx.manifest.get("engine_compatibility",{}).get("profile"),"cooperative-engine-bridge-v1")
    def test_non_regression_policy_declared(self):
        self.assertEqual(self.ctx.manifest.get("engine_compatibility",{}).get("non_regression_policy"),"preserve-extend-bridge")
    def test_bridge_ui_markers_exist(self):
        for token in ["data-engine-bridge-profile=\"cooperative-engine-bridge-v1\"","data-action=\"open-engine-bridge\"","data-overlay=\"engine-bridge\""]:
            self.assertIn(token,self.ctx.html)
    def test_truth_boundary_is_visible(self):
        self.assertIn("documentation_only / not_implemented",self.ctx.normalized_html.lower())
    def test_engine_compatibility_doc_exists(self):
        self.assertTrue((self.ctx.module_root/"docs"/"ENGINE_COMPATIBILITY.md").exists())
if __name__=="__main__": unittest.main()
