<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Criar / Atualizar Documentação

- documentação específica vive com o módulo;
- documentação transversal vive em `docs/`;
- memória registra estado/decisões;
- habilidades registra método/tooling/workflow;
- evitar referências canônicas a root HTML aliases;
- executar `validate_documentation.py` e `validate_skills.py`.
