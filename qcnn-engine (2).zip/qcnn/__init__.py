"""
QCNN Package - Motor Quântico-Cabalístico Modular v4.0
"""
from qcnn.core.pipeline import QcnnPipeline
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext, CollapseResult

__all__ = [
    "QcnnPipeline",
    "BaseQcnnPlugin",
    "QcnnExecutionContext",
    "CollapseResult"
]
