<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Histórico de Habilidades

A evolução das habilidades acompanha os marcos do NeuralDesk:

- V3 — HTML/CSS artifact authoring e empacotamento.
- V4 — Knowledge/RAG interface modeling.
- V5 — Tool/MCP architecture.
- V6 — AI Operations/observability modeling.
- V6.2 — memória documental.
- V6.3 — CSS modular por página.
- V6.6 — training/evaluation/optimization architecture.
- V6.8 — audit/trace/security.
- V6.9 — Data Platform/PostgreSQL/outbox.
- V7.0 — modular architecture, contracts, capabilities, AI Fabric/adapters.
- V7.1 — documentação sincronizada e governança.
- V7.2 — responsive/multimodal/browser validation.
- V7.3 — module-owned Quality Engineering.
- V7.4 — Skills, Tools & Development Capability Registry.

- V7.5 — Agent Projects, runtime Agent Skills e Multi-Agent Orchestration.

- V7.6 — Module Preview Registry, geração automática de previews e validação de freshness por hash.
