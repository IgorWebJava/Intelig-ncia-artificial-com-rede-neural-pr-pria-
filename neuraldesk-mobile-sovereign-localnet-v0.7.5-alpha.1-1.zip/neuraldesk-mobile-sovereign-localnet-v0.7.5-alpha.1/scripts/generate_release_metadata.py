#!/usr/bin/env python3
"""Generate source-tree release evidence bound to version, digest and receipts."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LESSONS = ROOT / 'memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md'
VERIFY_LOG = ROOT / 'verification/FINAL_VERIFY.log'
SANITIZER_LOG = ROOT / 'verification/FINAL_SANITIZER.log'
AUDIT_STATUS = ROOT / 'verification/AUDIT_STATUS.json'
INVENTORY = ROOT / 'verification/INVENTORY.txt'
REPORT = ROOT / 'verification/REPORT.json'
SUMS = ROOT / 'SHA256SUMS'
CHECKPOINT = ROOT / 'scripts/verification_checkpoint.py'

MODEL_FILES = [
    ROOT/'models/neuraldesk-knowledge-retriever-v0.5.ndkr',
    ROOT/'models/neuraldesk-knowledge-v0.5.ndkb',
    ROOT/'models/neuraldesk-context-pointer-v0.5.ndqa',
    ROOT/'models/neuraldesk-relation-classifier-v0.5.ndrl',
    ROOT/'models/neuraldesk-open-knowledge-pira-v0.6.ndos',
    ROOT/'models/neuraldesk-semantic-ranker-v0.7.1.ndsr',
]
DATA_FILES = [
    ROOT/'training/data/knowledge_retriever_train.tsv',
    ROOT/'training/data/knowledge_retriever_golden.tsv',
    ROOT/'training/data/context_pointer_train.jsonl',
    ROOT/'training/data/context_pointer_golden.jsonl',
    ROOT/'evaluation/fixtures/context_synthesis_regression.tsv',
    ROOT/'evaluation/fixtures/context_composition_holdout.tsv',
    ROOT/'evaluation/fixtures/context_v04_regression.tsv',
    ROOT/'evaluation/fixtures/relation_assisted_context_holdout.tsv',
    ROOT/'training/data/open_knowledge/PIRA_RECONSTRUCTION_PROVENANCE.json',
    ROOT/'training/data/open_knowledge/pira_reconstruction_records_v1.jsonl',
    ROOT/'training/data/open_knowledge/pira_reconstruction_validation_v1.jsonl',
    ROOT/'training/data/open_knowledge/open_knowledge_negatives_v1.jsonl',
    ROOT/'training/data/open_knowledge/open_knowledge_holdout_v1.jsonl',
    ROOT/'training/data/open_knowledge/historical_full/pira_human_records_v06.jsonl',
    ROOT/'training/data/open_knowledge/historical_full/pira_human_eval_train_v06.jsonl',
    ROOT/'training/data/open_knowledge/historical_full/pira_human_eval_validation_v06.jsonl',
]
VERIFY_PHASES = ['checkpoint','static','build','models','behavior','integration']
SANITIZE_PHASES = ['build','runtime']


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def precheck() -> None:
    subprocess.run([sys.executable, str(ROOT/'scripts/pre_generation_lessons_check.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT/'tests/verify_cleanliness.py')], cwd=ROOT, check=True)


def current_digest() -> str:
    return subprocess.check_output([sys.executable, str(CHECKPOINT), 'digest'], cwd=ROOT, text=True).strip()


def require_external_receipts(suite: str, phases: list[str]) -> None:
    subprocess.run([sys.executable, str(CHECKPOINT), 'require', suite, *phases], cwd=ROOT, check=True)


def require_bound_log(path: Path, suite: str, version: str, digest: str, phases: list[str]) -> None:
    if not path.is_file():
        raise SystemExit(f'{path.relative_to(ROOT)} is missing')
    text = path.read_text(encoding='utf-8', errors='replace')
    pass_marker = f'{suite.upper()} PASS version={version}'
    if pass_marker not in text:
        raise SystemExit(f'{path.relative_to(ROOT)} lacks exact marker: {pass_marker}')
    receipt_marker = (
        rf'{suite.upper()} RECEIPTS PASS version={re.escape(version)} '
        rf'digest=([0-9a-f]{{64}}) phases={re.escape(",".join(phases))}'
    )
    match = re.search(receipt_marker, text)
    if not match:
        raise SystemExit(f'{path.relative_to(ROOT)} lacks current receipt marker for {suite}')
    if match.group(1) != digest:
        raise SystemExit(
            f'{path.relative_to(ROOT)} digest mismatch: {match.group(1)} != current {digest}'
        )


def distributed_files() -> list[Path]:
    excluded = {SUMS.resolve(), INVENTORY.resolve()}
    out: list[Path] = []
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.resolve() in excluded:
            continue
        if any(part in {'build','build-sanitize','build-werror','__pycache__'} for part in path.parts):
            continue
        out.append(path)
    return sorted(out, key=lambda p: p.relative_to(ROOT).as_posix())


def main() -> None:
    precheck()
    manifest = json.loads((ROOT/'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))
    version = manifest['version']
    digest = current_digest()

    require_external_receipts('verify', VERIFY_PHASES)
    require_external_receipts('sanitize', SANITIZE_PHASES)
    require_bound_log(VERIFY_LOG, 'verify', version, digest, VERIFY_PHASES)
    require_bound_log(SANITIZER_LOG, 'sanitizer', version, digest, SANITIZE_PHASES)

    kr = json.loads((ROOT/'evaluation/KNOWLEDGE_RETRIEVER_REPORT.json').read_text())
    ptr = json.loads((ROOT/'evaluation/CONTEXT_POINTER_REPORT.json').read_text())
    rel = json.loads((ROOT/'evaluation/RELATION_CLASSIFIER_REPORT.json').read_text())
    ctx = json.loads((ROOT/'evaluation/CONTEXT_COMPOSITION_REPORT.json').read_text())
    adv = json.loads((ROOT/'evaluation/RELATION_ASSISTED_CONTEXT_REPORT.json').read_text())
    live = json.loads((ROOT/'evaluation/LIVE_QA_V05.json').read_text())
    repro = json.loads((ROOT/'evaluation/REPRODUCIBILITY_V05.json').read_text())
    ods = json.loads((ROOT/'evaluation/open_knowledge/SHARD_BUILD_REPORT.json').read_text())
    ode = json.loads((ROOT/'evaluation/open_knowledge/SHARD_EVALUATION_REPORT.json').read_text())
    sr = json.loads((ROOT/'evaluation/SEMANTIC_RANKER_REPORT.json').read_text())
    full_pira = json.loads((ROOT/'evaluation/open_knowledge_full/BUILD_REPORT.json').read_text())

    evaluation = dict(manifest['evaluation'])
    unseen_rows = ptr.get('unseen_rows')
    if not isinstance(unseen_rows, list) or not unseen_rows:
        raise SystemExit('CONTEXT_POINTER_REPORT.json lacks concrete unseen_rows')
    unseen_total = len(unseen_rows)
    unseen_correct = sum(1 for row in unseen_rows if row.get('exact') is True)
    unseen_ratio = unseen_correct / unseen_total
    reported_ratio = ptr.get('unseen_exact')
    if not isinstance(reported_ratio, (int, float)) or abs(float(reported_ratio) - unseen_ratio) > 1e-12:
        raise SystemExit(
            f'CONTEXT_POINTER_REPORT.json unseen ratio mismatch: rows={unseen_correct}/{unseen_total} reported={reported_ratio}'
        )

    report = {
        'project': manifest['name'],
        'version': version,
        'status': 'SOURCE_TREE_RELEASE_GATES_PASS_ZIP_REEXTRACT_REQUIRED',
        'releasePromotionAuthorized': False,
        'verificationInputDigestSha256': digest,
        'lineage': {
            'developmentPredecessor': manifest['sourceBaseline']['developmentPredecessor'],
            'externalRollback': manifest['rollback'],
            'modelLineageBaseline': '0.5.0-alpha.1',
            'lastExternallyAttestedRelease': manifest['sourceBaseline']['lastExternallyAttestedRelease'],
            'lastExternallyAttestedReleaseSha256': manifest['sourceBaseline']['lastExternallyAttestedReleaseSha256'],
        },
        'mandatory_lessons': {
            'path': str(LESSONS.relative_to(ROOT)),
            'sha256': sha256(LESSONS),
            'precheck': 'PASS',
        },
        'verificationReceipts': {
            'state': 'EXTERNAL_TO_DISTRIBUTED_TREE',
            'binding': manifest['verificationPolicy']['checkpointBinding'],
            'verifyPhases': VERIFY_PHASES,
            'sanitizePhases': SANITIZE_PHASES,
            'verifyLog': str(VERIFY_LOG.relative_to(ROOT)),
            'sanitizerLog': str(SANITIZER_LOG.relative_to(ROOT)),
        },
        'models': {
            str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha256(p)}
            for p in MODEL_FILES
        },
        'datasets': {
            str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha256(p)}
            for p in DATA_FILES
        },
        'training': {
            'retriever': {'parameters': kr['parameters'], 'train': kr['train_samples'], 'golden': kr['gold_samples'], 'golden_exact': kr['gold_exact']},
            'relation': {'parameters': rel['parameters'], 'train': rel['train_samples'], 'golden': rel['gold_samples'], 'golden_exact': rel['gold_exact'], 'by_view': rel['gold_by_view']},
            'pointer': {'parameters': ptr['parameters'], 'train': ptr['train_samples'], 'golden': ptr['golden_samples'], 'golden_exact': ptr['golden_exact'], 'raw_free_probe_exact': ptr['unseen_exact']},
            'strict_reproduction': repro['results'],
            'openKnowledge': {'neuralTraining': False, 'parameters': 0, 'materialization': ods},
            'semanticRanker': {'parameters': sr['parameters'], 'trainPairs': sr['trainPairs'], 'combinedPassed': sr['combinedPassed'], 'combinedTotal': sr['combinedTotal'], 'sha256': sr['sha256']},
            'historicalPiraFullCandidate': full_pira,
            'neuralWeightsChanged': False,
            'datasetsChanged': False,
        },
        'evaluation': {
            'manifestContract': evaluation,
            'knowledge_runtime_c': evaluation['knowledgeRetriever'],
            'relation_runtime_c': evaluation['relationClassifierRuntime'],
            'pointer_runtime_c': evaluation['contextPointerGolden'],
            'candidate_acceptance': evaluation['candidateAcceptance'],
            'relation_adversarial': f"heuristic {adv['heuristic_only_passed']}/{adv['total']} -> neural {adv['relation_assisted_passed']}/{adv['total']}",
            'context_composition': f"{ctx['passed']}/{ctx['total']}",
            'multi_goal': evaluation['multiGoal'],
            'live_qa': f"{live['pass']}/{live['total']}",
            'calculator': evaluation['calculator'],
            'conversational_correctness': evaluation['conversationalCorrectness'],
            'dialogue_grounding_v062': evaluation['dialogueGrounding'],
            'robust_intent_v063_recovery': evaluation['robustIntentV063Recovery'],
            'historical_convergence_v071_preserved': evaluation['historicalConvergence'],
            'semantic_core': evaluation['semanticCore'],
            'semantic_ranker': evaluation['semanticRanker'],
            'safety_gate': evaluation['safetyGate'],
            'local_rag': evaluation['localRag'],
            'run_journal': evaluation['runJournal'],
            'training_checkpoint': evaluation['trainingCheckpoint'],
            'device_lab_software': evaluation['deviceLabSoftware'],
            'network_policy': evaluation['networkPolicy'],
            'pilot_control': evaluation['pilotControl'],
            'durable_outbox': evaluation['durableOutbox'],
            'local_projects': evaluation['localProjects'],
            'model_acquisition': evaluation['modelAcquisition'],
            'benchmark_evaluation': evaluation['benchmarkEvaluation'],
            'weight_averaging': evaluation['weightAveraging'],
            'offline_continuity': evaluation['offlineContinuity'],
            'computational_streaming': evaluation['computationalStreaming'],
            'generative_text_streaming': evaluation['generativeTextStreaming'],
            'hardware_routing': evaluation['hardwareRouting'],
            'governance_v075': evaluation['governanceV075'],
            'gradient_accumulation': evaluation['gradientAccumulation'],
            'fail_closed_legacy': evaluation['failClosed'],
            'memory': evaluation['memory'],
            'planner': evaluation['planner'],
            'assistant_orchestrator': evaluation['orchestrator'],
            'open_knowledge': ode,
            'jni_host_syntax': 'PASS',
            'kotlin_host_compile': 'PASS',
            'asan_ubsan': 'PASS',
        },
        'truth_boundary': {
            'android_physical_certification': 'NOT_PERFORMED_IN_THIS_ENVIRONMENT',
            'apk_aab_device_evidence': 'NOT_CLAIMED',
            'general_language_model': 'NOT_PRESENT_AS_APPROVED_RUNTIME',
            'open_knowledge_is_neural_model': False,
            'open_knowledge_records': manifest['architecture']['openKnowledgeRecords'],
            'open_knowledge_full_candidate_records': manifest['architecture']['openKnowledgeFullCandidateRecords'],
            'open_knowledge_full_candidate_active': False,
            'semantic_ranker_promoted_and_activated_bounded': True,
            'generative_backend_activated': False,
            'raw_pointer_free_probes': f"{unseen_correct}/{unseen_total}; final pipeline validates or falls back",
            'external_ai_backend': 'NOT_USED_FOR_INFERENCE',
            'conversation_state': manifest['architecture']['conversationState'],
        },
    }

    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    audit = {
        'project': manifest['name'],
        'version': version,
        'date': manifest['audit']['date'],
        'status': 'SOURCE_GATES_PASS_METADATA_GENERATED_ZIP_REEXTRACT_PENDING',
        'releasePromotionAuthorized': False,
        'finalZipGenerated': False,
        'sourceTreeInputDigestSha256': digest,
        'lessonsSha256': sha256(LESSONS),
        'neuralWeightsChanged': False,
        'datasetsChanged': False,
        'verifyMarkerRequired': manifest['verificationPolicy']['verifyMarker'],
        'verifyMarkerObserved': True,
        'sanitizerMarkerRequired': manifest['verificationPolicy']['sanitizerMarker'],
        'sanitizerMarkerObserved': True,
        'verifyReceiptPhases': VERIFY_PHASES,
        'sanitizeReceiptPhases': SANITIZE_PHASES,
        'calculator': evaluation['calculator'],
        'conversationalCorrectness': evaluation['conversationalCorrectness'],
        'packageState': 'REEXTRACTION_AND_FULL_PHASED_REVALIDATION_REQUIRED',
        'finalEvidenceRequiredBeforeRelease': [
            'deterministic ZIP creation from current checksummed tree',
            'ZIP CRC validation',
            'reextract to empty directory preserving executable modes',
            'input digest equality with source candidate',
            'phased VERIFY on extracted bytes with fresh external receipts',
            'phased SANITIZER on extracted bytes with fresh external receipts',
            'post-test clean + SHA256SUMS revalidation',
            'external final freeze attestation with ZIP SHA-256',
        ],
    }
    AUDIT_STATUS.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    files = distributed_files()
    total = sum(p.stat().st_size for p in files)
    lines = [
        f'NeuralDesk Mobile Sovereign LocalNet v{version} — distributed file inventory',
        'INVENTORY.txt and SHA256SUMS are intentionally not self-listed.',
        f'verification_input_digest_sha256={digest}',
        f'listed_files={len(files)} listed_bytes={total}',
        '',
    ]
    lines += [f'{p.stat().st_size:10d}  {p.relative_to(ROOT).as_posix()}' for p in files]
    INVENTORY.write_text('\n'.join(lines) + '\n', encoding='utf-8')

    checksum_files = sorted(
        [
            p for p in ROOT.rglob('*')
            if p.is_file() and p.resolve() != SUMS.resolve()
            and not any(part in {'build','build-sanitize','build-werror','__pycache__'} for part in p.parts)
        ],
        key=lambda p: p.relative_to(ROOT).as_posix(),
    )
    SUMS.write_text(
        ''.join(f'{sha256(p)}  {p.relative_to(ROOT).as_posix()}\n' for p in checksum_files),
        encoding='utf-8',
    )
    print(
        f'RELEASE_METADATA PASS version={version} digest={digest} '
        f'files={len(checksum_files)} bytes={sum(p.stat().st_size for p in checksum_files)}'
    )


if __name__ == '__main__':
    main()
