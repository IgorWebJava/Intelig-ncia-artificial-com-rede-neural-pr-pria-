import re
import math
import os
from typing import Dict, Any, Optional
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class AssistantToolkitPlugin(BaseQcnnPlugin):
    """
    Módulo 13: Assistant Toolkit & Agentic Solver.
    Combina ferramentas simbólicas determinísticas:
    1. Symbolic Math Solver (Cálculo aritmético/algébrico exato)
    2. Task & Workflow Planner (Gerador de planos e roteiros estruturados)
    3. Conversor de Unidades & Métricas Físicas
    4. Guardião de Metas e Lembretes Cristalizados
    """
    def __init__(self, storage_dir: str = "./storage_android"):
        super().__init__()
        self.storage_dir = storage_dir
        if not os.path.exists(self.storage_dir):
            try:
                os.makedirs(self.storage_dir, exist_ok=True)
            except Exception:
                pass

    @property
    def plugin_id(self) -> str:
        return "assistant_toolkit"

    def _solve_math(self, prompt: str) -> Optional[str]:
        """Extrai e calcula expressões matemáticas determinísticas com precisão absoluta."""
        clean_p = prompt.lower().replace("x", "*").replace("÷", "/")
        
        # Padrão: "calcule 15 * 34", "quanto é 250 + 450", "sqrt(144) + 10", "15% de 800"
        match_sqrt_direct = re.search(r"(?:calcule\s+)?(?:a\s+)?(?:raiz\s*quadrada\s*de|sqrt\(?)\s*(\d+(?:\.\d+)?)\)?", clean_p)
        if match_sqrt_direct:
            val = float(match_sqrt_direct.group(1))
            res = math.sqrt(val)
            return f"🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> √{val}<br><strong>Resultado Exato:</strong> <code>{res}</code>"

        match_pct = re.search(r"(\d+(?:\.\d+)?)\s*%\s*(?:de|of|\*)\s*(\d+(?:\.\d+)?)", clean_p)
        if match_pct:
            pct = float(match_pct.group(1))
            val = float(match_pct.group(2))
            res = (pct / 100.0) * val
            return f"🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> {pct}% de {val}<br><strong>Resultado:</strong> <code>{res:.4f}</code> (ou {res:.2f})"

        match_calc = re.search(r"(?:calcule|quanto\s+[ée]|resolva|calcular|resultado\s+de)\s*:?\s*([0-9\.\+\-\*\/\(\)\^\s\w]+)", clean_p)
        if match_calc:
            expr = match_calc.group(1).strip()
            # Tratamento de funções matemáticas simples
            expr_eval = expr.replace("^", "**")
            expr_eval = re.sub(r'sqrt\(([^)]+)\)', r'math.sqrt(\1)', expr_eval)
            expr_eval = re.sub(r'raiz\s*quadrada\s*de\s*(\d+(?:\.\d+)?)', r'math.sqrt(\1)', expr_eval)
            expr_eval = re.sub(r'seno\s*de\s*(\d+(?:\.\d+)?)', r'math.sin(\1)', expr_eval)
            expr_eval = re.sub(r'cosseno\s*de\s*(\d+(?:\.\d+)?)', r'math.cos(\1)', expr_eval)

            # Sanitização estrita para segurança determinística
            allowed_chars = set("0123456789.+-*/() math.sqrtsincospie,")
            if all(c in allowed_chars for c in expr_eval) and any(c in "0123456789" for c in expr_eval):
                try:
                    # Proteção contra divisão por zero direta
                    if re.search(r"/\s*0(?!\.)", expr_eval) or re.search(r"/\s*0\.0+(?!\d)", expr_eval):
                        return f"🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> <code>{expr}</code><br><strong>Indeterminação:</strong> <em>Divisão por zero não é definida na aritmética real.</em>"
                    res = eval(expr_eval, {"__builtins__": None, "math": math})
                    return f"🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> <code>{expr}</code><br><strong>Resultado Exato:</strong> <code>{res}</code>"
                except ZeroDivisionError:
                    return f"🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]<br><br><strong>Expressão:</strong> <code>{expr}</code><br><strong>Indeterminação:</strong> <em>Divisão por zero não é definida na aritmética real.</em>"
                except Exception:
                    pass
        return None

    def _plan_workflow(self, prompt: str) -> Optional[str]:
        """Gera um plano de ação ou checklist estruturado em tópicos."""
        match_plan = re.search(r"(?:crie\s+um\s+plano|planeje|roteiro|etapas\s+para|passo\s+a\s+passo\s+para|organize\s+um\s+plano)\s+(?:de\s+)?(.+)", prompt, re.IGNORECASE)
        if match_plan:
            tema = match_plan.group(1).strip().capitalize()
            return f"""📋 [PLANO DE AÇÃO ESTRUTURADO DO ASSISTENTE]
<br><br><strong>Objetivo Central:</strong> <em>{tema}</em>
<br><br><strong>Fases de Execução:</strong>
<br>1. <strong>Fase 1 (Fundação & Diagnóstico):</strong> Mapeamento do escopo, levantamento de requisitos e definição de parâmetros-chave.
<br>2. <strong>Fase 2 (Estruturação Simbólica):</strong> Modelagem das etapas, alocação de recursos e definição do fluxo de trabalho.
<br>3. <strong>Fase 3 (Execução & Convergência):</strong> Implementação prática, iteração contínua e monitoramento de métricas.
<br>4. <strong>Fase 4 (Validação & Cristalização):</strong> Teste final de consistência, documentação dos aprendizados e conclusão."""
        return None

    def _convert_units(self, prompt: str) -> Optional[str]:
        """Converte grandezas físicas e métricas com exatidão."""
        clean_p = prompt.lower()
        
        # km para milhas
        match_km_mi = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*km\s+(?:em|para)\s*milhas?", clean_p)
        if match_km_mi:
            val = float(match_km_mi.group(1))
            res = val * 0.621371
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} km</code> = <strong>{res:.2f} milhas</strong>"

        # milhas para km
        match_mi_km = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*milhas?\s+(?:em|para)\s*km", clean_p)
        if match_mi_km:
            val = float(match_mi_km.group(1))
            res = val * 1.60934
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} milhas</code> = <strong>{res:.2f} km</strong>"

        # metros para centimetros
        match_m_cm = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*metros?\s+(?:em|para)\s*(?:centimetros?|cm)", clean_p)
        if match_m_cm:
            val = float(match_m_cm.group(1))
            res = val * 100.0
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} metros</code> = <strong>{res:.2f} cm</strong>"

        # kg para libras
        match_kg_lb = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*kg\s+(?:em|para)\s*libras?", clean_p)
        if match_kg_lb:
            val = float(match_kg_lb.group(1))
            res = val * 2.20462
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} kg</code> = <strong>{res:.2f} libras</strong>"

        # km/h para m/s
        match_kmh = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*km\/h\s+(?:em|para)\s*m\/s", clean_p)
        if match_kmh:
            val = float(match_kmh.group(1))
            res = val / 3.6
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} km/h</code> = <strong>{res:.3f} m/s</strong>"
        
        # m/s para km/h
        match_ms = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*m\/s\s+(?:em|para)\s*km\/h", clean_p)
        if match_ms:
            val = float(match_ms.group(1))
            res = val * 3.6
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} m/s</code> = <strong>{res:.3f} km/h</strong>"

        # celsius para fahrenheit
        match_c = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*(?:°c|celsius)\s+(?:em|para)\s*(?:°f|fahrenheit)", clean_p)
        if match_c:
            val = float(match_c.group(1))
            res = (val * 9.0/5.0) + 32.0
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} °C</code> = <strong>{res:.2f} °F</strong>"

        # fahrenheit para celsius
        match_f = re.search(r"(?:converta\s+)?(\d+(?:\.\d+)?)\s*(?:°f|fahrenheit)\s+(?:em|para)\s*(?:°c|celsius)", clean_p)
        if match_f:
            val = float(match_f.group(1))
            res = (val - 32.0) * 5.0 / 9.0
            return f"📐 [CONVERSÃO DE UNIDADES]<br><br><code>{val} °F</code> = <strong>{res:.2f} °C</strong>"

        return None

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        prompt = context.prompt.strip()

        # 1. Tenta resolver cálculo matemático
        math_res = self._solve_math(prompt)
        if math_res:
            context.custom_response = math_res
            context.metadata["assistant_tool"] = "symbolic_math"
            return context

        # 2. Tenta conversão de unidades
        unit_res = self._convert_units(prompt)
        if unit_res:
            context.custom_response = unit_res
            context.metadata["assistant_tool"] = "unit_converter"
            return context

        # 3. Tenta gerar plano / workflow
        plan_res = self._plan_workflow(prompt)
        if plan_res:
            context.custom_response = plan_res
            context.metadata["assistant_tool"] = "workflow_planner"
            return context

        return context
