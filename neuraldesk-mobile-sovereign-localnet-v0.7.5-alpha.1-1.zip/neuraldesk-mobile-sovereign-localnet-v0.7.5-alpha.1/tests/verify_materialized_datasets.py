#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'training'))
import context_data
import train_knowledge_retriever as retriever

ctx_train,ctx_gold=context_data.build_context()
kn_train,kn_gold=retriever.build_sets()
expected={
    ROOT/'training/data/context_pointer_train.jsonl': ''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in ctx_train).encode(),
    ROOT/'training/data/context_pointer_golden.jsonl': ''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in ctx_gold).encode(),
    ROOT/'training/data/knowledge_retriever_train.tsv': ''.join(f"{label}\t{question}\n" for question,label in kn_train).encode(),
    ROOT/'training/data/knowledge_retriever_golden.tsv': ''.join(f"{label}\t{question}\n" for question,label in kn_gold).encode(),
}
for path,data in expected.items():
    got=path.read_bytes()
    assert got==data,f"stale materialized dataset: {path.relative_to(ROOT)}"
print('materialized-datasets-freshness PASS',len(expected),'artifacts')
