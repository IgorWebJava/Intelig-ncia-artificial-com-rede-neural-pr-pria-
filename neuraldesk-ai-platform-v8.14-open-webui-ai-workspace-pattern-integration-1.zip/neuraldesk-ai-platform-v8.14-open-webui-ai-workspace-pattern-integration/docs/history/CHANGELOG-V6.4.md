<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# V6.4 — Advanced AI Chat Workspace

## Arquivos visuais modificados

```text
chat.html
css/chat.css
```

## Implementado

- 3-panel AI Workspace;
- retractable sidebar via HTML/CSS;
- projects/recent/pinned;
- model router visual;
- Auto/Fast/Reasoning/Research/Agent;
- Knowledge/Web/Files/Tools;
- multimodal attachments;
- rich AI messages;
- professional citations;
- source cards;
- Agent Activity;
- Tool Call cards;
- Human Approval;
- Research Progress;
- Artifacts;
- Branch Conversation;
- Context Inspector;
- Project Memory;
- Context Usage;
- Agent status;
- available tools;
- prompt library;
- new-chat empty state;
- processing/stop state;
- responsive mobile/tablet/desktop.

## Restrições preservadas

- HTML + CSS only;
- 0 JavaScript;
- 0 `<script>`;
- 0 `@import`;
- Chat usa apenas `css/chat.css`.
