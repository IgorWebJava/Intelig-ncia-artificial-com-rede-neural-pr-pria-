<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 118 — AI Handoff

A future AI must not start by editing files blindly.

Required sequence:

```text
Memory
→ Skills/Tools registry
→ Module manifest
→ Contracts
→ Data ownership
→ Docs
→ Tests
→ Workflow
→ Change
→ Release gates
```

See `habilidades/AI_HANDOFF.md`.
