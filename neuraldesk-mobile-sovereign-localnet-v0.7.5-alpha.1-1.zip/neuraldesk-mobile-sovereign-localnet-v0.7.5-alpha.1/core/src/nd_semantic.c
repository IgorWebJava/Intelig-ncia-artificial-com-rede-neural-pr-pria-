#include "nd_semantic.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

static unsigned char lo(unsigned char c) {
    return (c >= 'A' && c <= 'Z') ? (unsigned char)(c + ('a' - 'A')) : c;
}

static const char *find_ci(const char *s, const char *needle) {
    size_t m = strlen(needle);
    if (!m) return s;
    for (; *s; s++) {
        size_t i = 0u;
        while (i < m && s[i] && lo((unsigned char)s[i]) == lo((unsigned char)needle[i])) i++;
        if (i == m) return s;
    }
    return NULL;
}

static int has(const char *s, const char *needle) {
    return s && needle && find_ci(s, needle) != NULL;
}

static unsigned parse_sentence_limit(const char *q) {
    static const struct { const char *text; unsigned value; } words[] = {
        {"uma frase", 1u}, {"1 frase", 1u}, {"duas frases", 2u}, {"2 frases", 2u},
        {"três frases", 3u}, {"tres frases", 3u}, {"3 frases", 3u},
        {"quatro frases", 4u}, {"4 frases", 4u}
    };
    for (size_t i = 0u; i < sizeof(words) / sizeof(words[0]); i++) {
        if (has(q, words[i].text)) return words[i].value;
    }
    return 0u;
}

static int dynamic_event_query(const char *q) {
    int event_result = has(q, "quem venceu") || has(q, "quem ganhou") || has(q, "vencedor") ||
                       has(q, "resultado") || has(q, "placar") || has(q, "campeão") || has(q, "campeao");
    int temporal = has(q, "hoje") || has(q, "agora") || has(q, "atual") || has(q, "2026") ||
                   has(q, "ontem") || has(q, "esta semana") || has(q, "neste mês") || has(q, "neste mes");
    return event_result && temporal;
}

int nd_semantic_analyze(const char *q, NDSemanticFrame *f) {
    if (!q || !f) return -1;
    memset(f, 0, sizeof(*f));
    f->intent = ND_INTENT_GENERAL;
    f->expected_type = ND_EXPECT_ANY;
    f->sentence_limit = parse_sentence_limit(q);

    if (has(q, "quem ") || has(q, "responsável") || has(q, "responsavel") || has(q, "líder") || has(q, "lider")) {
        f->expected_type = ND_EXPECT_PERSON;
    } else if (has(q, "código") || has(q, "codigo")) {
        f->expected_type = ND_EXPECT_CODE;
    } else if (has(q, "massa") || has(q, "peso") || has(q, "quanto") || has(q, "quantos") || has(q, "quantas")) {
        f->expected_type = ND_EXPECT_NUMBER;
    } else if (has(q, "data") || has(q, "quando")) {
        f->expected_type = ND_EXPECT_DATE;
    } else if (has(q, "material")) {
        f->expected_type = ND_EXPECT_MATERIAL;
    }

    f->has_universal_quantifier = has(q, "sempre") || has(q, "nunca") || has(q, "qualquer") ||
                                  has(q, "todo ") || has(q, "toda ") || has(q, "todos") || has(q, "todas");
    f->is_comparison = has(q, "mesma coisa") || has(q, "diferença entre") || has(q, "diferenca entre") ||
                       has(q, "compar") || has(q, " versus ") || has(q, " vs ");
    f->creative = has(q, "poema") || has(q, "história original") || has(q, "historia original") ||
                  has(q, "analogia original") || has(q, "crie ") || has(q, "escreva ");
    f->percentage = has(q, "porcent") || has(q, "percent");
    f->non_entailment = ((has(q, "prova") || has(q, "significa") || has(q, "implica")) &&
                         (has(q, "todo") || has(q, "toda") || has(q, "qualquer") ||
                          has(q, "alternativ") || has(q, "necessariamente") || has(q, "sempre"))) ||
                        (f->has_universal_quantifier && (has(q, "int4") || has(q, "quantiza")) && has(q, "fp32"));

    if ((has(q, "o que você consegue") || has(q, "o que voce consegue") || has(q, "o que você faz") ||
         has(q, "o que voce faz") || has(q, "seu principal limite") || has(q, "suas capacidades")) &&
        (has(q, "neuraldesk") || has(q, "você") || has(q, "voce") || has(q, "sistema"))) {
        f->intent = ND_INTENT_ROLE_CAPABILITIES;
        f->expected_type = ND_EXPECT_EXPLANATION;
    } else if (has(q, "pesos") && (has(q, "inferência") || has(q, "inferencia")) &&
               (has(q, "atualiz") || has(q, "aprendem") || has(q, "mudam"))) {
        f->intent = ND_INTENT_WEIGHT_UPDATE;
        f->expected_type = ND_EXPECT_BOOLEAN;
    } else if ((has(q, "quantiza") && has(q, "kv cache")) ||
               (has(q, "quantiza") && has(q, "cache kv"))) {
        f->intent = ND_INTENT_COMPARE_QUANT_KV;
        f->expected_type = ND_EXPECT_EXPLANATION;
        f->is_comparison = 1;
    } else if (has(q, "quantiza") &&
               (has(q, "econom") || has(q, "reduz") || has(q, "memória") || has(q, "memoria") ||
                has(q, "largura de banda") || has(q, "custo"))) {
        f->intent = ND_INTENT_QUANTIZATION_SAVINGS;
        f->expected_type = ND_EXPECT_EXPLANATION;
    } else if (has(q, "transformer") && has(q, "rnn") &&
               (has(q, "vantagem") || has(q, "limita") || has(q, "melhor") || has(q, "compare"))) {
        f->intent = ND_INTENT_COMPARE_TRANSFORMER_RNN;
        f->expected_type = ND_EXPECT_EXPLANATION;
        f->is_comparison = 1;
    } else if ((has(q, "o que é inferência") || has(q, "o que e inferencia") || has(q, "defina inferência") ||
                has(q, "defina inferencia") || has(q, "diferença entre treinamento") || has(q, "diferenca entre treinamento") ||
                has(q, "durante a inferência") || has(q, "durante a inferencia") ||
                has(q, "acontece na inferência") || has(q, "acontece na inferencia")) &&
               has(q, "infer")) {
        f->intent = ND_INTENT_DEFINE_INFERENCE;
        f->expected_type = ND_EXPECT_EXPLANATION;
    } else if ((has(q, "o que é rag") || has(q, "o que e rag") || has(q, "rag quer dizer") ||
                has(q, "significa rag") || has(q, "defina rag"))) {
        f->intent = ND_INTENT_DEFINE_RAG;
        f->expected_type = ND_EXPECT_EXPLANATION;
    } else if (dynamic_event_query(q)) {
        f->intent = ND_INTENT_DYNAMIC_EVENT;
        f->has_temporal_scope = 1;
        f->requires_fresh_evidence = 1;
    } else if ((has(q, "resuma") || has(q, "resumo") || has(q, "resumir") ||
                has(q, "sintetize") || has(q, "síntese") || has(q, "sintese")) &&
               (has(q, "contexto") || has(q, "texto") || has(q, "documento") || has(q, "trecho"))) {
        f->intent = ND_INTENT_SUMMARY_CONTEXT;
    } else if ((has(q, "palavras-chave") || has(q, "palavras chave") || has(q, "keywords") ||
                (has(q, "extraia") && has(q, "palavras")) || (has(q, "liste") && has(q, "palavras"))) &&
               (has(q, "texto") || has(q, "trecho") || has(q, "contexto") || has(q, "palavras"))) {
        f->intent = ND_INTENT_KEYWORDS_CONTEXT;
    } else if ((has(q, "resuma") || has(q, "resumo") || has(q, "resumir") ||
                has(q, "sintetize") || has(q, "síntese") || has(q, "sintese")) &&
               (has(q, "conversa") || has(q, "turnos") || has(q, "diálogo") || has(q, "dialogo") ||
                has(q, "histórico") || has(q, "historico") || has(q, "recentes"))) {
        f->intent = ND_INTENT_SUMMARY_HISTORY;
    } else if (f->creative) {
        f->intent = ND_INTENT_CREATIVE;
    } else if (f->percentage) {
        f->intent = ND_INTENT_PERCENTAGE;
        f->expected_type = ND_EXPECT_NUMBER;
    } else if (f->non_entailment) {
        f->intent = ND_INTENT_NON_ENTAILMENT;
        f->expected_type = ND_EXPECT_BOOLEAN;
    }
    return 0;
}

int nd_semantic_direct_answer(const NDSemanticFrame *f, const char *q, char *out, size_t cap) {
    if (!f || !out || !cap) return -1;
    const char *z = NULL;
    switch (f->intent) {
        case ND_INTENT_ROLE_CAPABILITIES:
            if (f->sentence_limit == 1u) {
                z = "Sou um sistema de IA local e auditável para contexto, memória estruturada, conhecimento local, cálculo, RAG local e respostas fail-closed; meu principal limite atual é não possuir ainda um backbone generativo promovido com linguagem geral equivalente a grandes modelos modernos.";
            } else {
                z = "Sou um sistema local e auditável: uso contexto fornecido, memória estruturada, conhecimento interno/aberto, cálculo determinístico e RAG local sem backend externo de IA. Meu principal limite atual é não possuir ainda um backbone generativo promovido capaz de linguagem aberta com a generalidade de grandes modelos modernos.";
            }
            break;
        case ND_INTENT_DEFINE_INFERENCE:
            z = "Treinamento ajusta parâmetros usando dados e uma função objetivo; validação mede generalização em dados separados; inferência usa os parâmetros já treinados para produzir uma previsão ou resposta sem, por si só, atualizar os pesos.";
            break;
        case ND_INTENT_WEIGHT_UPDATE:
            z = "Não. Na inferência normal os pesos permanecem fixos; memória explícita e estado de sessão podem mudar, mas isso não equivale a treinar ou atualizar os parâmetros neurais.";
            break;
        case ND_INTENT_DEFINE_RAG:
            z = "RAG significa Retrieval-Augmented Generation, ou geração aumentada por recuperação. Separar recuperação de geração permite buscar evidência relevante primeiro e sintetizar a resposta depois, reduzindo a necessidade de memorizar todo o conteúdo no modelo e melhorando rastreabilidade.";
            break;
        case ND_INTENT_COMPARE_QUANT_KV:
            z = "Não resolvem o mesmo problema. Quantização reduz principalmente memória, largura de banda e custo aritmético dos pesos/ativações; KV cache evita recomputar estados de atenção de tokens anteriores durante inferência autoregressiva, trocando memória por menor trabalho por token.";
            break;
        case ND_INTENT_QUANTIZATION_SAVINGS:
            z = "Durante a inferência, quantização tende a reduzir principalmente o espaço ocupado pelos pesos, a largura de banda de memória e, dependendo do kernel, o custo aritmético; o ganho real precisa ser medido porque maior compressão pode reduzir qualidade.";
            break;
        case ND_INTENT_COMPARE_TRANSFORMER_RNN:
            z = "Não existe uma arquitetura universalmente superior: a escolha depende da tarefa, dos dados, da latência, da memória e do hardware. Transformer permite paralelizar melhor o treinamento e modelar dependências longas, mas atenção pode consumir muita memória e computação em sequências longas. RNN mantém estado sequencial compacto e pode ser útil em streaming, mas sua dependência passo a passo reduz paralelismo e dificulta relações muito longas.";
            break;
        case ND_INTENT_NON_ENTAILMENT:
            if (q && (has(q, "int4") || has(q, "quantiza")) && has(q, "fp32")) {
                z = "Não. INT4 não preserva necessariamente e exatamente a qualidade FP32; quantização mais agressiva pode degradar logits, escolhas de token ou qualidade de resposta, por isso precisa de parity e quality floors medidos.";
            } else {
                z = "Não necessariamente. A evidência observada não prova a conclusão universal; seria necessária evidência adicional que compare ou cubra explicitamente todos os casos relevantes.";
            }
            break;
        default:
            return 0;
    }
    if (!z || strlen(z) + 1u > cap) return -1;
    memcpy(out, z, strlen(z) + 1u);
    return 1;
}

const char *nd_semantic_intent_name(NDIntent intent) {
    switch (intent) {
        case ND_INTENT_ROLE_CAPABILITIES: return "ROLE_CAPABILITIES";
        case ND_INTENT_DEFINE_INFERENCE: return "DEFINE_INFERENCE";
        case ND_INTENT_WEIGHT_UPDATE: return "WEIGHT_UPDATE";
        case ND_INTENT_DEFINE_RAG: return "DEFINE_RAG";
        case ND_INTENT_COMPARE_QUANT_KV: return "COMPARE_QUANT_KV";
        case ND_INTENT_DYNAMIC_EVENT: return "DYNAMIC_EVENT";
        case ND_INTENT_SUMMARY_CONTEXT: return "SUMMARY_CONTEXT";
        case ND_INTENT_SUMMARY_HISTORY: return "SUMMARY_HISTORY";
        case ND_INTENT_CREATIVE: return "CREATIVE";
        case ND_INTENT_PERCENTAGE: return "PERCENTAGE";
        case ND_INTENT_NON_ENTAILMENT: return "NON_ENTAILMENT";
        case ND_INTENT_QUANTIZATION_SAVINGS: return "QUANTIZATION_SAVINGS";
        case ND_INTENT_COMPARE_TRANSFORMER_RNN: return "COMPARE_TRANSFORMER_RNN";
        case ND_INTENT_KEYWORDS_CONTEXT: return "KEYWORDS_CONTEXT";
        default: return "GENERAL";
    }
}
