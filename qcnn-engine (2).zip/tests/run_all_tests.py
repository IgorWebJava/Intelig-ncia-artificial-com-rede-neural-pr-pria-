#!/usr/bin/env python3
"""
SUÍTE MESTRE DE TESTES DO MOTOR QCNN ENGINE v5.0 / MULTI-V
Executa todos os testes unitários, integrados e de estresse dos módulos 1 ao 16.
"""

import unittest
import sys
import os
import time

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

def run_suite():
    print("================================================================================")
    print("🧠 INICIANDO SUÍTE COMPLETA DE TESTES DO QCNN ENGINE v5.0 / MULTI-V")
    print("================================================================================\n")
    
    loader = unittest.TestLoader()
    start_dir = os.path.dirname(os.path.abspath(__file__))
    suite = loader.discover(start_dir, pattern='test_*.py')
    
    start_time = time.time()
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    duration = time.time() - start_time
    
    print("\n================================================================================")
    print(f"📊 RESUMO DE EXECUÇÃO:")
    print(f"   • Total de Testes Executados: {result.testsRun}")
    print(f"   • Sucessos: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"   • Falhas: {len(result.failures)}")
    print(f"   • Erros: {len(result.errors)}")
    print(f"   • Tempo Total: {duration:.3f}s")
    
    if result.wasSuccessful():
        print("✅ TODOS OS TESTES PASSARAM COM 100% DE APROVAÇÃO!")
        print("================================================================================")
        return 0
    else:
        print("❌ ALGUNS TESTES FALHARAM!")
        print("================================================================================")
        return 1

if __name__ == '__main__':
    sys.exit(run_suite())
