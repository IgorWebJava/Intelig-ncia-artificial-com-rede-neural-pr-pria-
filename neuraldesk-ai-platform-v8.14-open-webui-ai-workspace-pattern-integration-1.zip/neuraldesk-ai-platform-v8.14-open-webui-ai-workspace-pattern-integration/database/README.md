<!-- neuraldesk-documentation-sync: V8.8 -->

# NeuralDesk Data Platform — V7.0

The physical database may initially use one PostgreSQL cluster, but logical ownership is modular.

```text
platform / configuration / identity
mod_chat
mod_knowledge
mod_training
mod_tools
mod_audit
...
```

Rules:

- UI never connects directly to PostgreSQL.
- A module never reads/writes another module's private tables.
- Cross-module communication uses versioned APIs/events.
- Cross-module IDs are external references, not hard private-schema foreign keys.
- State + outbox event are persisted atomically when distribution is required.

Shared platform schema foundation remains in `database/platform/`.
Module-owned migrations live under `modules/<module>/data/migrations/`.
