#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
from device_lab import REQUIRED,NETWORK,LIFECYCLE,packet_hash,validate_packets
pack=[];seq=0
for k in sorted(REQUIRED-{'NETWORK','LIFECYCLE'}):
 p={'sequence':seq,'kind':k,'value':1};p['packetSha256']=packet_hash(p);pack.append(p);seq+=1
for sc in sorted(NETWORK):
 p={'sequence':seq,'kind':'NETWORK','scenario':sc,'value':1};p['packetSha256']=packet_hash(p);pack.append(p);seq+=1
for sc in sorted(LIFECYCLE):
 p={'sequence':seq,'kind':'LIFECYCLE','scenario':sc,'value':1};p['packetSha256']=packet_hash(p);pack.append(p);seq+=1
r=validate_packets(pack);assert r['ready'] and not r['physicalRunPerformed'] and not r['certified']
bad=[dict(pack[0])];bad[0]['prompt']='secret';bad[0]['packetSha256']=packet_hash(bad[0]);assert validate_packets(bad)['reason']=='PRIVACY_GUARD'
tam=[dict(pack[0])];tam[0]['value']=2;assert validate_packets(tam)['reason']=='PACKET_HASH_MISMATCH'
print(f'DEVICE_LAB PASS packets={len(pack)} matrix_complete=true privacy_guard=true physical_run=false certified=false')
