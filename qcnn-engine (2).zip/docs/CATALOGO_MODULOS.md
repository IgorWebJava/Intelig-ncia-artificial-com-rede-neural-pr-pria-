# 📦 CATÁLOGO DE MÓDULOS, CLASSES E PLUGINS REUTILIZÁVEIS (v5.0)

> **CONSULTE ANTES DE PROGRAMAR:**
> Toda e qualquer classe, função e estrutura de dados implementada está catalogada e documentada aqui.
> É estritamente proibido recriar ou duplicar qualquer lógica já existente.

---

## 🐍 1. Módulos e Plugins Python (`qcnn/`)

### 1.1 Core Engine (`qcnn/core/`)

#### **`BaseQcnnPlugin`** (`qcnn/core/interfaces.py`)
- **Tipo**: Classe Abstrata / Interface Base (`ABC`).
- **Finalidade**: Define o contrato formal que todo plugin Python deve implementar.
- **Propriedades**:
  - `plugin_id -> str`: Identificador único do plugin (ex: `"milui_expansion"`, `"conceptual_dialogue"`).
  - `is_enabled -> bool`: Flag booleana que controla se o módulo está ativo ou pausado no pipeline.
- **Métodos**:
  - `execute(context: QcnnExecutionContext) -> QcnnExecutionContext`: Executa a transformação do contexto durante a passagem pelo pipeline.

#### **`QcnnExecutionContext`** (`qcnn/core/context.py`)
- **Tipo**: Data Class / Objeto de Estado Compartilhado.
- **Finalidade**: Objeto que transita por todos os plugins carregando o estado de computação quântica.
- **Campos**:
  - `prompt: str` — Entrada original fornecida pelo usuário.
  - `target_seed: str` — Semente raiz identificada (padrão: `"Alef"`).
  - `chain: List[str]` — Lista de sementes/conceitos ativados na árvore.
  - `total_frequency_hz: float` — Frequência harmônica acumulada em Hertz.
  - `final_state: str` — Estado ternário final colapsado (`"10"`, `"01"`, `"00"`).
  - `custom_response: Optional[str]` — Resposta textual sintetizada pelo motor.
  - `metadata: Dict[str, Any]` — Dicionário extensível para telemetria e dados adicionais.

#### **`QcnnPipeline`** (`qcnn/core/pipeline.py`)
- **Tipo**: Orquestrador Central / Pipeline Dispatcher.
- **Finalidade**: Gerencia o registro, desregistro, ordenação e execução dos plugins.
- **Métodos**:
  - `register_plugin(plugin: BaseQcnnPlugin) -> None`: Registra e adiciona um plugin à fila de execução.
  - `unregister_plugin(plugin_id: str) -> None`: Remove dinamicamente um plugin do pipeline.
  - `get_plugin(plugin_id: str) -> Optional[BaseQcnnPlugin]`: Retorna a instância do plugin pelo seu ID.
  - `process(prompt: str) -> CollapseResult`: Instancia o contexto, executa a cadeia de plugins e retorna o resultado encapsulado.

#### **`CollapseResult`** (`qcnn/core/result.py`)
- **Tipo**: Modelo de Saída / DTO.
- **Campos**: `resposta: str`, `arvore: str`, `frequencia: str`, `estado: str`, `latencia: str`, `memoria_ram: str`.
- **Método**: `to_dict() -> Dict[str, Any]` — Serialização para JSON da API.

---

### 1.2 Plugins Implementados (`qcnn/plugins/`)

#### **`MATRIZ_22_LETRAS`** (`qcnn/plugins/matriz_letras.py`)
- **Tipo**: Dicionário de Constantes Fundamentais.
- **Estrutura**: Mapeia cada uma das 22 letras hebraicas para:
  - `caractere`: Glifo original (ex: `א`).
  - `valor`: Valor gemátrico tradicional (ex: `1`, `2`, `400`).
  - `hz`: Frequência harmônica áurea calculada (ex: `1.62 Hz`, `3.24 Hz`, `647.20 Hz`).
  - `milui`: Descompactação genealógica cabalística dos nomes das letras (ex: `Alef -> Lamed -> Pe`).
  - `atbash`: Par de espelhamento polar inverso.

#### **`TernaryBitwisePlugin`** (`qcnn/plugins/ternary_bitwise.py`)
- **Tipo**: Plugin de Emulação Ternária Bitwise (`plugin_id = "ternary_bitwise"`).
- **Estrutura de Flags**:
  - `bit_ativacao: bool` e `bit_inibicao: bool`
  - `00`: Vácuo / Superposição Quântica
  - `10`: Ativação Construtiva / Colapso
  - `01`: Inibição / Ruído Destrutivo
- **Métodos**: `definir_estado(valor: int)`, `obter_estado_str() -> str`, `execute(context)`.

#### **`MiluiExpansionPlugin`** (`qcnn/plugins/milui_expansion.py`)
- **Tipo**: Plugin de Descompactação Fractal (`plugin_id = "milui_expansion"`).
- **Função**: Localiza a semente raiz e descompacta sua árvore genealógica de 3 níveis de profundidade.

#### **`AdjacencyFilterPlugin`** (`qcnn/plugins/adjacency_filter.py`)
- **Tipo**: Plugin de Filtragem Gramatical e Anti-Loop (`plugin_id = "adjacency_filter"`).
- **Constante**: `TRANSICOES_PERMITIDAS: Dict[str, Set[str]]` — Grafo de arestas válidas entre as 22 letras.
- **Função**: Remove transições dissonantes e loops infinitos durante a expansão fractal.

#### **`HarmonicFrequencyPlugin`** (`qcnn/plugins/harmonic_frequency.py`)
- **Tipo**: Plugin de Frequências Áureas (`plugin_id = "harmonic_frequency"`).
- **Função**: Acumula a ressonância harmônica em Hertz de todos os nós presentes na árvore descompactada.

#### **`TelemetryMeterPlugin`** (`qcnn/plugins/telemetry_meter.py`)
- **Tipo**: Plugin de Métricas e Telemetria (`plugin_id = "telemetry_meter"`).
- **Função**: Mede latência precisa via `time.perf_counter_ns()` e consumo de memória RAM do processo via `resource`.

#### **`HyperdimensionalComputingPlugin`** (`qcnn/plugins/hyperdimensional_computing.py` & Kotlin)
- **Tipo**: Plugin de Computação Hiperdimensional e Vetores Ternários Esparsos (`plugin_id = "hyperdimensional_computing"`).
- **Dimensão**: $D = 10.000$ bits em espaço vetorial bipolar $\{-1, +1\}^D$.
- **Operações Hiperdimensionais Implementadas**:
  - `bind(v1, v2)`: Produto element-wise bipolar ($\otimes$ / XOR) para associação de papéis e conceitos.
  - `bundle(vetores)`: Superposição vetorial ($\oplus$) por votação majoritária.
  - `permute(v, shifts)`: Rotação cíclica circular ($\Pi$) para codificação de profundidade genealógica e ordem sintática.
  - `similarity(v1, v2)`: Medição exata de ressonância no hiper-espaço via similaridade de cosseno em tempo sub-milissegundo (< 0.1ms).

#### **`FractalGrammarPlugin`** (`qcnn/plugins/fractal_grammar.py` & Kotlin)
- **Tipo**: Plugin de Síntese Gramatical Fractal e Recombinação Categorial (`plugin_id = "fractal_grammar"`).
- **Função**: Constrói articulações sintáticas estruturadas e fluidas sem alucinação a partir de N-Grams Fractais e Semântica Categorial da Árvore da Vida.

#### **`ConceptualDialoguePlugin`** (`qcnn/plugins/conceptual_dialogue.py` & Kotlin)
- **Tipo**: Plugin de Diálogo Conceitual, Destilação Ontológica Contínua e Emaranhamento Web (`plugin_id = "conceptual_dialogue"`).
- **Função**: Ingestão contínua em lote de arquivos `.txt`, pré-cálculo de frequências áureas determinísticas, indexação no grafo de conceitos e busca em tempo real.
- **Tipo**: Plugin de Conversação Natural, Absorção Contínua e Emaranhamento Web (`plugin_id = "conceptual_dialogue"`).
- **Constantes**: `GRAFO_CONCEITUAL: Dict[str, Dict]`, `PASTA_CONHECIMENTO_LOCAL = "./conhecimento_local"`.
- **Funções Auxiliares**:
  - `realizar_scraping_e_sintonia(termo: str) -> Dict[str, Any]`: Busca e sintoniza arquivos `.txt` locais via vetorização na Proporção Áurea ($\phi = 1.618$).
  - `realizar_pesquisa_internet_real(termo: str) -> Dict[str, Any]`: Dispara requisições HTTP ultraleves (`urllib.request`) para obtenção de resumos públicos e phase-locking vitalício no grafo de memória RAM.

#### **`OctaveRegulatorPlugin`** (`qcnn/plugins/octave_regulator.py` & Kotlin)
- **Tipo**: Plugin Regulador de Oitavas & Zoom Cognitivo Recursivo (`plugin_id = "octave_regulator"` - Módulo 4).
- **Função**: Mede densidade e marcadores de complexidade do prompt ("como", "por que", "explique", "analise") modulando o processamento em oitavas escaláveis ($1..5$) com escala áurea $\phi^{(n-1)/2}$.

#### **`OrganMultiplexerPlugin`** (`qcnn/plugins/organ_multiplexer.py` & Kotlin)
- **Tipo**: Plugin Modo Expedidor & Bit-Mask Multiplexing de Órgãos Especializados (`plugin_id = "organ_multiplexer"` - Módulo 10).
- **Função**: Multiplexa órgãos (Direito, Medicina, Engenharia, Filosofia, Finanças, Astronomia) na memória RAM em 1 ciclo de clock via operações bitwise `0b10 << pos` com suporte a carregamento dinâmico.

#### **`ContinuousIngestionPlugin`** (`qcnn/plugins/continuous_ingestion.py` & Kotlin)
- **Tipo**: Plugin de Auto-Expansão Ontológica Contínua (`plugin_id = "continuous_ingestion"` - Pilar 1).
- **Função**: Destilação autônoma de manuais e arquivos de texto em frequências áureas ($\phi=1.618$) e entidades em tempo real.

#### **`HyperdimensionalComputingPlugin`** (`qcnn/plugins/hyperdimensional_computing.py` & Kotlin)
- **Tipo**: Plugin de Computação Hiperdimensional $D=10.000$ bits com Raciocínio Analógico ($D^* = C \otimes (B \otimes A)$) e Distância de Hamming instantânea.

#### **`FractalBreakerPlugin`** (`qcnn/plugins/fractal_breaker.py` & Kotlin)
- **Tipo**: Plugin Disjuntor Fractal & Amortecimento Exponencial (`plugin_id = "fractal_breaker"` - Módulo 8).
- **Função**: Aplica equação de atenuação exponencial $e^{-\lambda \cdot depth}$ cortando loops infinitos e blindando a RAM estática em ~12MB.

#### **`ContextCrystallizerPlugin`** (`qcnn/plugins/context_crystallizer.py` & Kotlin)
- **Tipo**: Plugin Gerenciador de Contexto, Cristalização de Memória e Eco Residual (`plugin_id = "context_crystallizer"` - Módulos 9 & 12).
- **Função**: Cristaliza fatos em `storage_android/inconsciente.dat` e retém o Eco Harmônico Residual das últimas 3 interações.

#### **`AssistantToolkitPlugin`** (`qcnn/plugins/assistant_toolkit.py` & Kotlin)
- **Tipo**: Assistente Universal Neuro-Simbólico (`plugin_id = "assistant_toolkit"` - Módulo 13).
- **Funções**: Resolvedor Aritmético Exato (`calc`), Planejador Estratégico Determinístico (`plano`) e Conversor Universal de Unidades de Medida (`conversao`).

#### **`MultiverseOraclePlugin`** (`qcnn/plugins/multiverse_oracle.py` & Kotlin)
- **Tipo**: Oráculo Analítico Multi-V e Simulador de Realidades Quânticas (`plugin_id = "multiverse_oracle"` - Módulo 14).
- **Funções**:
  - Simulação Quântica de Cenários em Hardware Clássico com 4 Linhas de Tempo Paralelas (Alpha: Expansão, Beta: Resiliência, Gamma: Ruptura, Delta: Síntese Epistêmica).
  - Modulação dinâmica por **Prisma de Risco** ($0.0 \dots 1.0$), **Oitava Filosófica** (Dialética, Estoicismo, Racionalismo, Pragmatismo) e **Rigor Lógico**.

#### **`MyceliumIndexPlugin`** (`qcnn/plugins/mycelium_index.py` & Kotlin)
- **Tipo**: Roteador Semântico Bio-Inspirado e Grafo Micelial (`plugin_id = "mycelium_index"` - Módulo 15).
- **Funções**: Roteamento semântico descentralizado não-linear com reforço orgânico de sinapses, decaimento entrópico e navegação por nutrientes conceituais.

#### **`MetaCognitiveAuditorPlugin`** (`qcnn/plugins/metacognitive_auditor.py` & Kotlin)
- **Tipo**: Auditor Meta-Cognitivo e Validador Epistêmico de Coerência (`plugin_id = "metacognitive_auditor"` - Módulo 16).
- **Funções**: Loop de auto-reflexão e avaliação epistêmica com cálculo de Certeza Simbólica ($C$-Score) e verificação de não-contradição e alinhamento áureo.

#### **`VisualMatrixPlugin`** (`qcnn/plugins/visual_matrix.py` & Kotlin)
- **Tipo**: Plugin de Síntese e Processamento Visual/Vetorial (`plugin_id = "visual_matrix"` - Módulo 17).
- **Funções**: Geração determinística de diagramas e grafos vetoriais em formato SVG dinâmico com matrizes de luminância e órbitas trigonométricas áureas.

#### **`AudioWaveformPlugin`** (`qcnn/plugins/audio_waveform.py` & Kotlin)
- **Tipo**: Plugin de Síntese de Áudio Harmônico Nativo PCM / WAV (`plugin_id = "audio_waveform"` - Módulo 18).
- **Funções**: Síntese senoidal estéreo 16-bit PCM (44.1 kHz) com envelope ADSR suave e emissão direta via `AudioTrack` no Android.

#### **`CodeSynthesisPlugin`** (`qcnn/plugins/code_synthesis.py` & Kotlin)
- **Tipo**: Plugin de Síntese e Validação de Código Multi-Linguagem (`plugin_id = "code_synthesis"` - Módulo 19).
- **Funções**: Geração tipada e determinística de código em Python, Kotlin (Android), JavaScript e SQL.

#### **`FileManagerPlugin`** (`qcnn/plugins/file_manager.py` & Kotlin)
- **Tipo**: Plugin de Gerenciamento Universal de Arquivos (`plugin_id = "file_manager"` - Módulo 20).
- **Funções**: Criação, estruturação e exportação local de relatórios em Markdown (`.md`), planilhas `CSV` e schemas `JSON`.

#### **`VideoSequencerPlugin`** (`qcnn/plugins/video_sequencer.py` & Kotlin)
- **Tipo**: Plugin de Sequenciamento Visual Dinâmico e Animações Fractais (`plugin_id = "video_sequencer"` - Módulo 21).
- **Funções**: Renderização contínua de animações vetoriais a 60 FPS com modulação temporal senoidal.

---

## 📱 2. Módulos e Plugins Kotlin / Android (`app/src/main/java/com/example/engine/`)

### 2.1 Core Engine (`com.example.engine.core`)

#### **`IQcnnPlugin`**
- **Interface**: Contrato de plugins em Kotlin com `pluginId: String`, `isEnabled: Boolean` e `execute(context: QcnnExecutionContext): QcnnExecutionContext`.

#### **`QcnnExecutionContext`**
- **Data Class**: Carrega `prompt`, `targetSeed`, `chain`, `totalFrequencyHz`, `finalState`, `latencyMs`, `customResponse` e `metadata`.

#### **`MatrizLetras`**
- **Singleton**: Tabela estática com as 22 letras hebraicas, frequências áureas, transições válidas e pares atbash.

#### **`QcnnEngine`**
- **Orquestrador Central**: Inicializa e gerencia os plugins no ciclo de vida Android, executando `processSeed(prompt: String): CollapseResult`.

---

### 2.2 Plugins Android (`com.example.engine.plugins`)

- **`NoTernario`**: Implementação em Kotlin dos nós de flags bitwise `10`, `01`, `00` (Módulo 3).
- **`MiluiExpansionPlugin`**: Descompactador fractal cabalístico das 22 letras (Módulo 1).
- **`AdjacencyFilterPlugin`**: Validador de arestas do grafo de transição gramatical (Módulo 6).
- **`HarmonicFrequencyPlugin`**: Acumulador de frequência áurea total em Hz (Módulo 7).
- **`HyperdimensionalComputingPlugin`**: Computação Hiperdimensional $D=10.000$ bits com operações de binding, bundling e similaridade vetorial.
- **`FractalGrammarPlugin`**: Síntese de linguagem natural via N-Grams Fractais e Semântica Categorial.
- **`ConceptualDialoguePlugin(context)`**: Motor de diálogo semântico com absorção offline de arquivos no storage e assets (`assets/conhecimento_local`) e requisições leves (Módulo 11).
- **`OrganMultiplexerPlugin`**: Modo Expedidor com multiplexação binária de múltiplos órgãos em tempo real (Módulo 10).
- **`OctaveRegulatorPlugin`**: Regulador de oitavas cognitivas e zoom recursivo (Módulo 4).
- **`FractalBreakerPlugin`**: Disjuntor fractal com amortecimento $e^{-\lambda}$ (Módulo 8).
- **`ContextCrystallizerPlugin(context)`**: Cristalização de memória em `inconsciente.dat` e retenção de eco de Hz (Módulo 12 & 9).
- **`AssistantToolkitPlugin(storageDir)`**: Assistente Universal Simbólico com resolvedor matemático exato, planejador de workflows e conversor de grandezas físicas (Módulo 13).
- **`ContinuousIngestionPlugin(storageDir)`**: Auto-expansão ontológica e destilação contínua em background de arquivos locais com frequência áurea (Pilar 1).
- **`MultiverseOraclePlugin`**: Simulador de Realidades Multi-V com 4 ramificações temporais (Alpha, Beta, Gamma, Delta) sob prismas de risco e filosofia (Módulo 14).
- **`MyceliumIndexPlugin`**: Roteador Semântico Micelial com pesos sinápticos orgânicos e navegação por nutrientes conceituais (Módulo 15).
- **`MetaCognitiveAuditorPlugin`**: Loop de Auditoria Meta-Cognitiva e Validação Epistêmica $C$-Score de 100% de coerência (Módulo 16).
- **`VisualMatrixPlugin`**: Renderização e síntese de grafos SVG no Android (Módulo 17).
- **`AudioWaveformPlugin(context)`**: Emissão direta de áudio PCM senoidal via `AudioTrack` nativo (Módulo 18).
- **`CodeSynthesisPlugin`**: Síntese determinística de código multi-linguagem no Android (Módulo 19).
- **`FileManagerPlugin(context)`**: Gerenciador local de arquivos CSV, JSON e MD no Android (Módulo 20).
- **`VideoSequencerPlugin`**: Sequenciamento de animações vetoriais 60 FPS (Módulo 21).
- **`SelfHealingConsensusPlugin`**: Protocolo de Auto-Cura e Consenso Holográfico Cruzado com `HolographicMemoryStore` independente por módulo (Módulo 22).
- **`HardwareTelemetryPlugin(context)`**: Coletor de métricas reais de hardware usando `ActivityManager.MemoryInfo` e `System.nanoTime()`.

---

## 🌐 3. Interface Web & Bridge (`interface.html` & `AndroidBridge`)

- **`AndroidBridge`** (`MainActivity.kt`):
  - `@JavascriptInterface processSeed(prompt: String): String`
  - `@JavascriptInterface getDeviceRamMB(): String`
- **Reconhecimento de Voz**: Web Speech API integrada (`SpeechRecognition` / `webkitSpeechRecognition`) com permissão nativa `RECORD_AUDIO`.
- **Engine Cliente JavaScript Autônoma**: Executa a decodificação fractal e ressonância localmente no navegador em modo offline absoluto sem servidor.
