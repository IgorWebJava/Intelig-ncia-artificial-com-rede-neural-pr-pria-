#include "nd_knowledge.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void trim(char *s){size_t n=strlen(s);while(n&&(s[n-1]=='\n'||s[n-1]=='\r'))s[--n]=0;}
int main(int argc,char **argv){
    if(argc!=4){fprintf(stderr,"usage: %s RETRIEVER KB TSV\n",argv[0]);return 2;}
    char e[256];NDKnowledgeBase kb;NDKnowledgeRetriever r;
    if(nd_knowledge_load(argv[2],&kb,e,sizeof(e))){fprintf(stderr,"kb: %s\n",e);return 1;}
    if(nd_retriever_load(argv[1],kb.count,&r,e,sizeof(e))){fprintf(stderr,"retriever: %s\n",e);nd_knowledge_free(&kb);return 1;}
    FILE *f=fopen(argv[3],"rb");if(!f){perror("tsv");nd_retriever_free(&r);nd_knowledge_free(&kb);return 1;}
    char line[8192];size_t total=0,ok=0,accepted_known=0,rejected_unknown=0,fail_printed=0;
    while(fgets(line,sizeof(line),f)){
        trim(line);if(!*line)continue;char *tab=strchr(line,'\t');
        if(!tab){fprintf(stderr,"bad tsv line %zu\n",total+1);fclose(f);nd_retriever_free(&r);nd_knowledge_free(&kb);return 1;}
        *tab=0;unsigned long ex=strtoul(line,NULL,10);const char *q=tab+1;NDRetrievalResult rr;
        if(nd_retriever_infer(&r,q,&rr,e,sizeof(e))){fprintf(stderr,"infer: %s\n",e);fclose(f);nd_retriever_free(&r);nd_knowledge_free(&kb);return 1;}
        int good;
        if(ex==kb.count){good=!rr.accepted;if(good)rejected_unknown++;}
        else{good=rr.accepted&&rr.class_id==(uint32_t)ex;if(good)accepted_known++;}
        ok+=good?1u:0u;total++;
        if(!good&&fail_printed<20u){fprintf(stderr,"FAIL expected=%lu got=%u accepted=%d conf=%.6f margin=%.6f q=%s\n",ex,rr.class_id,rr.accepted,rr.confidence,rr.margin,q);fail_printed++;}
    }
    if(ferror(f)){fprintf(stderr,"tsv read error\n");fclose(f);nd_retriever_free(&r);nd_knowledge_free(&kb);return 1;}
    fclose(f);printf("knowledge_c_gold %zu/%zu accepted_known=%zu rejected_unknown=%zu\n",ok,total,accepted_known,rejected_unknown);nd_retriever_free(&r);nd_knowledge_free(&kb);return ok==total?0:1;
}
