# RAG, Research and Provenance Strategy

Retrieval pipeline:
query understanding -> rewrite -> candidate retrieval -> filtering -> reranking -> context selection -> generation -> citation validation.

Research pipeline:
plan -> search -> open/read -> cross-check -> evidence graph -> synthesis -> citation validation.

Metrics:
retrieval recall, precision, citation entailment, source quality, freshness, answer correctness and unsupported-claim rate.

Every generated conclusion should be traceable to evidence where evidence exists.
