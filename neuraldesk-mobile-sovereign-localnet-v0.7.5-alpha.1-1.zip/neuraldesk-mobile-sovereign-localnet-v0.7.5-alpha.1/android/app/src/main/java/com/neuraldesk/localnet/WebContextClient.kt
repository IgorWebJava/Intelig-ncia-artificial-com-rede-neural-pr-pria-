package com.neuraldesk.localnet

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI

/**
 * Bounded HTTPS text acquisition client.
 *
 * This class does not call an AI service and does not generate answers. It
 * downloads textual evidence only after validating scheme, port and resolved
 * addresses. Every redirect is validated again before the next connection.
 */
class WebContextClient {
    data class Result(val url: String, val text: String)

    private fun requireSafe(uri: URI) {
        require(uri.scheme.equals("https", ignoreCase = true)) { "Somente HTTPS" }
        require(uri.userInfo == null) { "userinfo proibido" }
        require(uri.port == -1 || uri.port == 443) { "porta proibida" }
        val host = uri.host ?: error("host inválido")

        for (address in InetAddress.getAllByName(host)) {
            val bytes = address.address
            val uniqueLocalIpv6 = bytes.size == 16 && ((bytes[0].toInt() and 0xfe) == 0xfc)
            require(
                !address.isAnyLocalAddress &&
                    !address.isLoopbackAddress &&
                    !address.isLinkLocalAddress &&
                    !address.isSiteLocalAddress &&
                    !address.isMulticastAddress &&
                    !uniqueLocalIpv6
            ) { "destino de rede privada/local proibido" }
        }
    }

    fun fetch(raw: String, maxBytes: Int = 384 * 1024): Result {
        require(maxBytes in 1..(2 * 1024 * 1024)) { "limite de conteúdo inválido" }
        var uri = URI(raw.trim())

        repeat(4) {
            requireSafe(uri)
            val connection = (uri.toURL().openConnection() as HttpURLConnection).apply {
                connectTimeout = 7_000
                readTimeout = 9_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", RuntimeIdentity.USER_AGENT)
            }

            val code = connection.responseCode
            if (code in 300..399) {
                val location = connection.getHeaderField("Location") ?: error("redirect sem Location")
                uri = uri.resolve(location)
                connection.disconnect()
                return@repeat
            }

            require(code in 200..299) { "HTTP $code" }
            val contentType = (connection.contentType ?: "").lowercase()
            require(contentType.startsWith("text/") || contentType.startsWith("application/json")) {
                "tipo não textual"
            }
            val declared = connection.contentLengthLong
            if (declared > 0) require(declared <= maxBytes) { "conteúdo grande demais" }

            val output = ByteArrayOutputStream()
            val buffer = ByteArray(8_192)
            var total = 0
            connection.inputStream.use { input ->
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= maxBytes) { "conteúdo grande demais" }
                    output.write(buffer, 0, count)
                }
            }
            connection.disconnect()

            var text = output.toString(Charsets.UTF_8.name())
            if (contentType.startsWith("text/html")) {
                text = text
                    .replace(Regex("(?is)<script.*?</script>|<style.*?</style>|<noscript.*?</noscript>"), " ")
                    .replace(Regex("(?s)<[^>]+>"), " ")
                    .replace("&nbsp;", " ")
                    .replace("&amp;", "&")
            }
            text = text.replace(Regex("\\s+"), " ").trim()
            return Result(uri.toString(), text)
        }
        error("redirects demais")
    }
}
