<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Workflow — Evoluir Experiência V8.2

1. Preserve module ownership.
2. Choose the module-specific mechanic, not a generic dashboard.
3. Keep functional text >= 11 px.
4. Use progressive disclosure.
5. Preserve density modes and adaptive inspector behavior.
6. Include Context, Provenance, Trust and visual versioning when relevant.
7. Keep template/backend boundary explicit.
8. Update tests, docs, memory and preview.
9. Run all release gates.
