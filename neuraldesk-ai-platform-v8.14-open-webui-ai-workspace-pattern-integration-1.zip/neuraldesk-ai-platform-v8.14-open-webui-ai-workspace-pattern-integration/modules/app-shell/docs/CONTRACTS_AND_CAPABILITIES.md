<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CONTRACTS_AND_CAPABILITIES.md -->
# App Shell — Contracts & Capabilities

## Public contract set

- `contracts/openapi.yaml`
- `contracts/asyncapi.yaml`
- `contracts/config.schema.json`
- `contracts/capabilities.json`
- `contracts/permissions.json`
- `contracts/adaptive-ui.json`

## Provides

- `navigation.route.resolve.v1`
- `module.launch.v1`

## Requires

- `module.registry.v1`
- `capability.registry.v1`
- `config.resolve.v1`
- `audit.write.v1`
- `ui.adaptive.v1`
- `ui.multimodal.surface.v1`
- `ui.runtime.interaction.v1`
- `ui.workspace.shell.v1`
- `ui.command_palette.v1`
- `ui.global.search.v1`
- `ui.task.center.v1`
- `ui.notification.center.v1`
- `ui.project.suspension.surface.v1`
- `ui.project.checkpoint.surface.v1`
- `ui.assistant.mission-control.v1`
- `ui.context-lens.v1`
- `ui.provenance.v1`
- `ui.trust-layer.v1`
- `ui.density.v1`
- `ui.version-diff.v1`
- `ui.adaptive-inspector.v1`
- `ui.specialized-workspace.v1`

## UI contract

- experience: `intelligence-experience-v2`
- runtime: `workspace-runtime-v2`
- design: `neuraldesk-intelligence-design-v2`
- template scope: `ui-only`

## Compatibility

Public contracts follow N/N-1 during migrations unless explicitly waived. Capability resolution must remain valid before release.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
