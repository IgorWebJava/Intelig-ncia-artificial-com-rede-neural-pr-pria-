package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.QcnnEngine
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("QCNN Engine", appName)
  }

  @Test
  fun `qcnn engine processes alef seed properly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("Descompactar semente Alef")

    assertNotNull(result)
    assertTrue(result.resposta.contains("Alef"))
    assertTrue(result.arvore.contains("Alef"))
    assertTrue(result.frequencia.contains("Hz"))
    assertTrue(result.latencia.contains("ms"))

    val json = JSONObject(result.toJson())
    assertEquals(result.resposta, json.getString("resposta"))
    assertEquals(result.arvore, json.getString("arvore"))
  }

  @Test
  fun `qcnn engine processes lamed seed with adjacency transitions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("Colapsar fenda Lamed")

    assertNotNull(result)
    assertTrue(result.arvore.contains("Lamed"))
    assertTrue(result.estado.contains("10"))
  }

  @Test
  fun `qcnn engine supports dynamic plugin connection and disconnection`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)

    assertTrue(engine.listPluginIds().contains("adjacency_filter"))
    assertTrue(engine.listPluginIds().contains("milui_expansion"))

    val removed = engine.unregisterPlugin("adjacency_filter")
    assertNotNull(removed)
    assertEquals("adjacency_filter", removed?.pluginId)
    assertTrue(!engine.listPluginIds().contains("adjacency_filter"))

    // Re-register
    if (removed != null) {
      engine.registerPlugin(removed)
    }
    assertTrue(engine.listPluginIds().contains("adjacency_filter"))
  }

  @Test
  fun `qcnn engine processes reish and 22 letters matrix correctly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("Ativar semente Reish")

    assertNotNull(result)
    assertTrue(result.resposta.contains("Reish"))
    assertTrue(result.arvore.contains("Reish"))
    assertTrue(result.frequencia.contains("Hz"))
  }

  @Test
  fun `qcnn engine processes voice command format accurately`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("Descompactar semente de Shin")

    assertNotNull(result)
    assertTrue(result.resposta.contains("Shin"))
    assertTrue(result.arvore.contains("Shin"))
    assertEquals("10 (Ativação Construtiva)", result.estado)
  }

  @Test
  fun `qcnn engine processes conceptual natural conversation accurately`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("Como as estrelas nascem no universo?")

    assertNotNull(result)
    assertTrue(result.resposta.contains("ESTRELAS") || result.resposta.contains("UNIVERSO"))
    assertTrue(result.resposta.contains("estrelas nascem do colapso"))
    assertEquals("10 (Diálogo Colapsado)", result.estado)
    assertTrue(result.arvore.contains("estrelas") || result.arvore.contains("universo"))
  }

  @Test
  fun `qcnn engine automatically absorbs new topics from local offline storage`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("Fale sobre tecnologia")

    assertNotNull(result)
    assertTrue(result.resposta.contains("NOVO CONCEITO ABSORVIDO") || result.resposta.contains("TECNOLOGIA"))
    assertTrue(result.resposta.contains("computação biológica"))
    assertEquals("10 (Diálogo Colapsado)", result.estado)
    assertTrue(result.arvore.contains("tecnologia"))

    // Second call tests that topic is phase-locked into RAM graph with sub-millisecond retrieval
    val secondResult = engine.processSeed("Fale sobre tecnologia")
    assertNotNull(secondResult)
    assertTrue(secondResult.resposta.contains("computação biológica"))
  }

  @Test
  fun `qcnn engine executes hyperdimensional computing and fractal grammar`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)

    assertTrue(engine.listPluginIds().contains("hyperdimensional_computing"))
    assertTrue(engine.listPluginIds().contains("fractal_grammar"))

    val result = engine.processSeed("Qual a relação entre mente, tempo e universo?")
    assertNotNull(result)
    assertTrue(result.resposta.contains("UNIVERSO") || result.resposta.contains("TEMPO") || result.resposta.contains("MENTE"))
    assertTrue(result.metadata.containsKey("hdc_dimension"))
    assertEquals(2048, (result.metadata["hdc_dimension"] as? Number)?.toInt())
    assertTrue(result.metadata.containsKey("active_concepts"))
  }

  @Test
  fun `qcnn engine responds with vibrational echo when topic is unknown in vacuum`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QcnnEngine(context)
    val result = engine.processSeed("xyzqwnonexistenttheme1234567")

    assertNotNull(result)
    assertTrue(result.resposta.contains("vácuo quântico") || result.resposta.contains("vibracional"))
    assertEquals("10 (Diálogo Colapsado)", result.estado)
  }
}

