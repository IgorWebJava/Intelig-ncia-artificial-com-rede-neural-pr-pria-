#!/usr/bin/env python3
"""Exercise deterministic verification checkpoint receipts without touching release inputs."""
from __future__ import annotations
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "scripts/verification_checkpoint.py"
with tempfile.TemporaryDirectory(prefix="nd-verify-state-") as td:
    env = os.environ.copy()
    env["ND_VERIFY_STATE_DIR"] = td
    digest1 = subprocess.check_output([sys.executable, str(TOOL), "digest"], cwd=ROOT, env=env, text=True).strip()
    assert len(digest1) == 64, digest1
    excluded_probe = ROOT / "build" / "checkpoint-digest-excluded-probe.bin"
    excluded_probe.parent.mkdir(parents=True, exist_ok=True)
    excluded_probe.write_bytes(b"excluded-build-content-must-not-change-input-digest")
    try:
        digest3 = subprocess.check_output([sys.executable, str(TOOL), "digest"], cwd=ROOT, env=env, text=True).strip()
        assert digest3 == digest1, (digest1, digest3)
    finally:
        excluded_probe.unlink(missing_ok=True)
    subprocess.run([sys.executable, str(TOOL), "mark", "verify", "unit"], cwd=ROOT, env=env, check=True, stdout=subprocess.DEVNULL)
    receipts = list(Path(td).rglob("unit.json"))
    assert len(receipts) == 1, receipts
    data = json.loads(receipts[0].read_text(encoding="utf-8"))
    data["inputDigestSha256"] = "0" * 64
    receipts[0].write_text(json.dumps(data), encoding="utf-8")
    bad = subprocess.run([sys.executable, str(TOOL), "require", "verify", "unit"], cwd=ROOT, env=env, text=True, capture_output=True)
    assert bad.returncode != 0, (bad.stdout, bad.stderr)
    subprocess.run([sys.executable, str(TOOL), "reset", "verify"], cwd=ROOT, env=env, check=True, stdout=subprocess.DEVNULL)
print("verification-checkpoint PASS deterministic-digest receipt-require tamper-reject reset")
