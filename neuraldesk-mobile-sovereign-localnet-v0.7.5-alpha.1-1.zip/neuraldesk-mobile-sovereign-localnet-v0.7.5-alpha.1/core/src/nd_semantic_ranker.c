#include "nd_semantic_ranker.h"

#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char magic[8];
    uint32_t version;
    uint32_t fdim;
    uint32_t edim;
    uint32_t flags;
    uint64_t reserved;
} NDSemanticRankerHeader;

static void seterr(char *err, size_t errcap, const char *msg) {
    if (err && errcap) {
        snprintf(err, errcap, "%s", msg);
        err[errcap - 1u] = 0;
    }
}

static uint64_t fnv1a64(const unsigned char *p, size_t n) {
    uint64_t h = UINT64_C(14695981039346656037);
    for (size_t i = 0; i < n; i++) {
        h ^= p[i];
        h *= UINT64_C(1099511628211);
    }
    return h;
}

static size_t normalize_ascii(const char *src, char *dst, size_t cap) {
    size_t n = 0;
    int spaced = 1;
    if (!src || !dst || cap < 2u) return 0u;
    for (const unsigned char *p = (const unsigned char *)src; *p && n + 1u < cap; p++) {
        unsigned char c = *p;
        if (c < 128u && isalnum(c)) {
            dst[n++] = (char)tolower(c);
            spaced = 0;
        } else if (c == (unsigned char)'-' || c == (unsigned char)'_') {
            dst[n++] = (char)c;
            spaced = 0;
        } else if (!spaced && n) {
            dst[n++] = ' ';
            spaced = 1;
        }
    }
    if (n && dst[n - 1u] == ' ') n--;
    dst[n] = 0;
    return n;
}

static void add_hash(float *v, const char *prefix, const char *text, float weight) {
    char buf[512];
    int n = snprintf(buf, sizeof(buf), "%s%s", prefix, text);
    if (n <= 0 || (size_t)n >= sizeof(buf)) return;
    size_t bucket = (size_t)(fnv1a64((const unsigned char *)buf, (size_t)n) &
                             (ND_SEMANTIC_FEATURE_DIM - 1u));
    v[bucket] += weight;
}

static size_t split_tokens(char *text, char **tokens, size_t cap) {
    size_t count = 0;
    char *p = text;
    while (*p && count < cap) {
        while (*p == ' ') p++;
        if (!*p) break;
        tokens[count++] = p;
        while (*p && *p != ' ') p++;
        if (*p == ' ') *p++ = 0;
    }
    return count;
}

static void build_features(const char *text, float v[ND_SEMANTIC_FEATURE_DIM]) {
    memset(v, 0, ND_SEMANTIC_FEATURE_DIM * sizeof(float));
    char normalized[4096];
    normalize_ascii(text, normalized, sizeof(normalized));

    char token_text[4096];
    snprintf(token_text, sizeof(token_text), "%s", normalized);
    char *tokens[256];
    size_t token_count = split_tokens(token_text, tokens, 256u);
    for (size_t i = 0; i < token_count; i++) {
        add_hash(v, "w:", tokens[i], 1.0f);
        if (i + 1u < token_count) {
            char bigram[512];
            int n = snprintf(bigram, sizeof(bigram), "%s_%s", tokens[i], tokens[i + 1u]);
            if (n > 0 && (size_t)n < sizeof(bigram)) add_hash(v, "b:", bigram, 0.75f);
        }
    }

    char compact[4096];
    size_t compact_count = 0;
    for (size_t i = 0; normalized[i] && compact_count + 1u < sizeof(compact); i++) {
        if (normalized[i] != ' ') compact[compact_count++] = normalized[i];
    }
    compact[compact_count] = 0;
    for (size_t k = 3u; k <= 5u; k++) {
        for (size_t i = 0; i + k <= compact_count; i++) {
            char gram[8];
            memcpy(gram, compact + i, k);
            gram[k] = 0;
            add_hash(v, "c:", gram, 0.18f);
        }
    }

    double sumsq = 0.0;
    for (size_t i = 0; i < ND_SEMANTIC_FEATURE_DIM; i++) {
        sumsq += (double)v[i] * (double)v[i];
    }
    if (sumsq > 0.0) {
        float inv = (float)(1.0 / sqrt(sumsq));
        for (size_t i = 0; i < ND_SEMANTIC_FEATURE_DIM; i++) v[i] *= inv;
    }
}

static int embed(const float *weights, const float *bias, const char *text,
                 float out[ND_SEMANTIC_EMBED_DIM]) {
    float x[ND_SEMANTIC_FEATURE_DIM];
    build_features(text, x);
    double sumsq = 0.0;
    for (size_t e = 0; e < ND_SEMANTIC_EMBED_DIM; e++) {
        double z = bias[e];
        const float *row = weights + e * ND_SEMANTIC_FEATURE_DIM;
        for (size_t i = 0; i < ND_SEMANTIC_FEATURE_DIM; i++) z += (double)row[i] * x[i];
        out[e] = (float)z;
        sumsq += z * z;
    }
    if (!(sumsq > 0.0) || !isfinite(sumsq)) return -1;
    float inv = (float)(1.0 / sqrt(sumsq));
    for (size_t e = 0; e < ND_SEMANTIC_EMBED_DIM; e++) out[e] *= inv;
    return 0;
}

int nd_semantic_ranker_load(NDSemanticRanker *r, const char *path, char *err, size_t errcap) {
    if (!r || !path) return -1;
    memset(r, 0, sizeof(*r));
    FILE *f = fopen(path, "rb");
    if (!f) {
        seterr(err, errcap, "open semantic ranker");
        return -1;
    }
    NDSemanticRankerHeader h;
    if (fread(&h, 1u, sizeof(h), f) != sizeof(h) || memcmp(h.magic, "NDSRANK1", 8u) != 0 ||
        h.version != 1u || h.fdim != ND_SEMANTIC_FEATURE_DIM || h.edim != ND_SEMANTIC_EMBED_DIM ||
        h.flags != 0u || h.reserved != 0u) {
        fclose(f);
        seterr(err, errcap, "invalid semantic ranker header");
        return -1;
    }
    size_t matrix_count = ND_SEMANTIC_FEATURE_DIM * ND_SEMANTIC_EMBED_DIM;
    size_t bias_count = ND_SEMANTIC_EMBED_DIM;
    r->q_w = (float *)malloc(matrix_count * sizeof(float));
    r->q_b = (float *)malloc(bias_count * sizeof(float));
    r->c_w = (float *)malloc(matrix_count * sizeof(float));
    r->c_b = (float *)malloc(bias_count * sizeof(float));
    if (!r->q_w || !r->q_b || !r->c_w || !r->c_b) {
        fclose(f);
        nd_semantic_ranker_free(r);
        seterr(err, errcap, "oom semantic ranker");
        return -1;
    }
    if (fread(r->q_w, sizeof(float), matrix_count, f) != matrix_count ||
        fread(r->q_b, sizeof(float), bias_count, f) != bias_count ||
        fread(r->c_w, sizeof(float), matrix_count, f) != matrix_count ||
        fread(r->c_b, sizeof(float), bias_count, f) != bias_count || fgetc(f) != EOF) {
        fclose(f);
        nd_semantic_ranker_free(r);
        seterr(err, errcap, "truncated/trailing semantic ranker");
        return -1;
    }
    fclose(f);
    r->loaded = 1;
    return 0;
}

void nd_semantic_ranker_free(NDSemanticRanker *r) {
    if (!r) return;
    free(r->q_w);
    free(r->q_b);
    free(r->c_w);
    free(r->c_b);
    memset(r, 0, sizeof(*r));
}

int nd_semantic_ranker_embed_query(const NDSemanticRanker *r, const char *text,
                                   float out[ND_SEMANTIC_EMBED_DIM]) {
    return r && r->loaded && text ? embed(r->q_w, r->q_b, text, out) : -1;
}

int nd_semantic_ranker_embed_candidate(const NDSemanticRanker *r, const char *text,
                                       float out[ND_SEMANTIC_EMBED_DIM]) {
    return r && r->loaded && text ? embed(r->c_w, r->c_b, text, out) : -1;
}

float nd_semantic_ranker_similarity(const NDSemanticRanker *r, const char *query,
                                    const char *candidate) {
    float q[ND_SEMANTIC_EMBED_DIM];
    float c[ND_SEMANTIC_EMBED_DIM];
    if (nd_semantic_ranker_embed_query(r, query, q) != 0 ||
        nd_semantic_ranker_embed_candidate(r, candidate, c) != 0) return -INFINITY;
    float score = 0.0f;
    for (size_t i = 0; i < ND_SEMANTIC_EMBED_DIM; i++) score += q[i] * c[i];
    return score;
}
