<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# NeuralDesk Native Validators

    Tool ID: `tool.project-validators`

    ## Role in NeuralDesk development

    Validate architecture, documentation, responsiveness, tests and skills/tooling registries.

    ## Current implementations

    - `tools/validate_architecture.py`
- `tools/validate_documentation.py`
- `tools/validate_responsive.py`
- `tools/validate_testing.py`

    ## Capabilities provided

    - `test.static.execute.v1`
- `release.gates.execute.v1`
- `documentation.sync.v1`

    ## Constraints

    - Must pass before structural release.

    ## Portable alternatives

    - CI implementation of the same checks

    ## Rule

    The capability is more important than the tool name. A future AI may replace this tool if it provides equivalent capabilities and passes the relevant quality gates.
