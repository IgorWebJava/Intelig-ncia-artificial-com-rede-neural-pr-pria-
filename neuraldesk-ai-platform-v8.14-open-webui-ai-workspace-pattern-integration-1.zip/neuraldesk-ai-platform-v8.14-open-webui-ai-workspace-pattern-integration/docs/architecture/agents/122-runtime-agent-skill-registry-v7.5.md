<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 122 — Runtime Agent Skill Registry

`platform/agent-skill-registry/` is the runtime catalog for user agents. `habilidades/` remains development-maintenance knowledge. This separation is mandatory.
