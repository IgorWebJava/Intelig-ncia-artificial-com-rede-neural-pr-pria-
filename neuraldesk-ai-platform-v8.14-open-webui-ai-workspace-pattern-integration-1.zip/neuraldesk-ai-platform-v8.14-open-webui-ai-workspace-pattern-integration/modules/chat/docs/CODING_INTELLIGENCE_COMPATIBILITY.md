<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: chat -->
# Coding Intelligence Compatibility — chat

**Release:** V8.13  
**Profile:** `coding-intelligence-patterns-v1`  
**Truth boundary:** UI contract ready; coding engine not connected.

This module preserves all prior semantics while adding an inspectable future coding-intelligence surface. Coding execution remains owned by future modules under `neural-engine/modules/13-coding-intelligence-runtime/`.

## Non-regression
`preserve → extend → bridge`. Root aliases stay redirects. Existing actions/tabs/routes remain valid.
