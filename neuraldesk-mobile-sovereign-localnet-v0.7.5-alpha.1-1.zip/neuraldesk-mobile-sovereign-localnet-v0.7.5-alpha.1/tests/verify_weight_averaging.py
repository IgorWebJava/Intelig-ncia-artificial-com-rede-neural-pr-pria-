#!/usr/bin/env python3
from pathlib import Path
import tempfile,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'training'))
from checkpoint_manager import save_checkpoint
from weight_averaging import average_checkpoints,build_candidate

bindings={'architecture':'fixture-v1','datasetSha256':'a'*64,'tokenizerSha256':'b'*64,'scriptSha256':'c'*64}
with tempfile.TemporaryDirectory() as td:
    d=Path(td);paths=[]
    for step,val in [(10,1.0),(20,3.0),(30,5.0)]:
        p=save_checkpoint(d,phase='SFT',step=step,model={'w':np.array([val,val+1],dtype=np.float32)},optimizer={},bindings=bindings);paths.append(p)
    avg,weights,_=average_checkpoints(paths,bindings)
    assert np.allclose(avg['w'],np.array([3.0,4.0],dtype=np.float32));assert abs(sum(weights)-1)<1e-12
    out,rp=build_candidate(paths,bindings,d/'average')
    assert out.is_file() and rp.is_file() and 'AVERAGING_CANDIDATE_NOT_PROMOTED' in rp.read_text()
    bad=dict(bindings);bad['datasetSha256']='d'*64
    try: average_checkpoints(paths,bad); raise AssertionError('binding drift accepted')
    except ValueError: pass
    pbad=save_checkpoint(d,phase='SFT',step=40,model={'w':np.ones((2,2),dtype=np.float32)},optimizer={},bindings=bindings)
    try: average_checkpoints([paths[0],pbad],bindings); raise AssertionError('shape mismatch accepted')
    except ValueError: pass
print('WEIGHT_AVERAGING PASS compatible=true binding_drift_rejected=true shape_mismatch_rejected=true promotion=false')
