#include "nd_resource.h"

static unsigned thermal_reduction(const NDResourcePolicy *p, unsigned thermal_status) {
    if (!p) return 0u;
    if (thermal_status >= 5u) return p->thermal_backoff_percent;
    if (thermal_status >= 4u) return (p->thermal_backoff_percent * 3u) / 4u;
    if (thermal_status >= 3u) return p->thermal_backoff_percent / 2u;
    return 0u;
}

NDMobileProfile nd_resource_select_profile(unsigned long ram_mb, unsigned cores, int is_64bit) {
    if (!is_64bit || ram_mb < 3072ul || cores < 4u) return ND_PROFILE_MICRO;
    if (ram_mb >= 6144ul && cores >= 8u) return ND_PROFILE_MOBILE_PLUS;
    return ND_PROFILE_MOBILE;
}

NDResourcePolicy nd_resource_policy(NDMobileProfile profile) {
    NDResourcePolicy p;
    p.profile = profile;
    if (profile == ND_PROFILE_MOBILE_PLUS) {
        p.max_context_bytes = 65536u;
        p.max_rag_chunks = 8u;
        p.max_output_bytes = 16384u;
        p.max_threads = 4u;
        p.deadline_ms = 10000u;
        p.thermal_backoff_percent = 20u;
    } else if (profile == ND_PROFILE_MOBILE) {
        p.max_context_bytes = 49152u;
        p.max_rag_chunks = 6u;
        p.max_output_bytes = 12288u;
        p.max_threads = 3u;
        p.deadline_ms = 7500u;
        p.thermal_backoff_percent = 30u;
    } else {
        p.max_context_bytes = 24576u;
        p.max_rag_chunks = 4u;
        p.max_output_bytes = 8192u;
        p.max_threads = 2u;
        p.deadline_ms = 5000u;
        p.thermal_backoff_percent = 40u;
    }
    return p;
}

const char *nd_resource_profile_name(NDMobileProfile profile) {
    if (profile == ND_PROFILE_MOBILE_PLUS) return "MOBILE_PLUS";
    if (profile == ND_PROFILE_MOBILE) return "MOBILE";
    return "MICRO";
}

int nd_resource_admit(const NDResourcePolicy *p, size_t q, size_t c) {
    if (!p || q == 0u || q > 4096u) return 0;
    if (c > p->max_context_bytes) return 0;
    if (p->max_output_bytes < 256u || p->max_threads == 0u || p->deadline_ms == 0u) return 0;
    return 1;
}

size_t nd_resource_effective_output_bytes(const NDResourcePolicy *p, unsigned thermal_status) {
    if (!p || p->max_output_bytes == 0u) return 0u;
    unsigned reduction = thermal_reduction(p, thermal_status);
    size_t keep = (p->max_output_bytes * (size_t)(100u - reduction)) / 100u;
    if (keep < 1024u) keep = 1024u;
    if (keep > p->max_output_bytes) keep = p->max_output_bytes;
    return keep;
}

unsigned nd_resource_effective_threads(const NDResourcePolicy *p, unsigned thermal_status) {
    if (!p || p->max_threads == 0u) return 0u;
    unsigned reduction = thermal_reduction(p, thermal_status);
    unsigned keep = (p->max_threads * (100u - reduction)) / 100u;
    if (keep == 0u) keep = 1u;
    if (keep > p->max_threads) keep = p->max_threads;
    return keep;
}

unsigned nd_resource_effective_deadline_ms(const NDResourcePolicy *p, unsigned thermal_status) {
    if (!p || p->deadline_ms == 0u) return 0u;
    if (thermal_status >= 5u) {
        unsigned shortened = (p->deadline_ms * 3u) / 4u;
        return shortened ? shortened : 1u;
    }
    return p->deadline_ms;
}

const char *nd_resource_abi_name(NDHardwareAbi abi) {
    if (abi == ND_ABI_ARM64) return "ARM64";
    if (abi == ND_ABI_X86_64) return "X86_64";
    if (abi == ND_ABI_ARM32) return "ARM32";
    if (abi == ND_ABI_X86) return "X86";
    return "UNKNOWN";
}

const char *nd_resource_provider_name(NDHardwareProvider provider) {
    if (provider == ND_PROVIDER_CPU_C99) return "CPU_C99";
    if (provider == ND_PROVIDER_GPU) return "GPU";
    if (provider == ND_PROVIDER_NPU) return "NPU";
    return "AUTO";
}

NDHardwareRoute nd_resource_route_hardware(const NDHardwareCapabilities *c,
                                           NDHardwareProvider requested,
                                           int require_physical_certification) {
    NDHardwareRoute route;
    route.status = ND_ROUTE_INVALID;
    route.requested = requested;
    route.selected = ND_PROVIDER_AUTO;
    route.profile = ND_PROFILE_MICRO;
    route.abi = ND_ABI_UNKNOWN;
    route.executor_available = 0;
    route.accelerator_detected_but_unavailable = 0;
    route.physical_hardware_certified = 0;
    route.automatic_default_switch = 0;
    if (c == NULL || c->logical_cores == 0u || c->ram_mb == 0ul) return route;
    route.profile = nd_resource_select_profile(c->ram_mb, c->logical_cores, c->is_64bit);
    route.abi = c->abi;
    route.physical_hardware_certified = c->physical_hardware_certified ? 1 : 0;
    if (requested != ND_PROVIDER_AUTO && requested != ND_PROVIDER_CPU_C99 &&
        requested != ND_PROVIDER_GPU && requested != ND_PROVIDER_NPU) return route;
    if (require_physical_certification && !c->physical_hardware_certified) {
        route.status = ND_ROUTE_NOT_CERTIFIED;
        return route;
    }
    if (requested == ND_PROVIDER_AUTO || requested == ND_PROVIDER_CPU_C99) {
        if (!c->cpu_c99_executor_available) {
            route.status = ND_ROUTE_PROVIDER_UNAVAILABLE;
            return route;
        }
        route.selected = ND_PROVIDER_CPU_C99;
        route.executor_available = 1;
        route.status = ND_ROUTE_OK;
        return route;
    }
    if (requested == ND_PROVIDER_GPU) {
        route.accelerator_detected_but_unavailable = c->gpu_detected && !c->gpu_executor_available;
        if (!c->gpu_executor_available) {
            route.status = ND_ROUTE_PROVIDER_UNAVAILABLE;
            return route;
        }
        route.selected = ND_PROVIDER_GPU;
        route.executor_available = 1;
        route.status = ND_ROUTE_OK;
        return route;
    }
    route.accelerator_detected_but_unavailable = c->npu_detected && !c->npu_executor_available;
    if (!c->npu_executor_available) {
        route.status = ND_ROUTE_PROVIDER_UNAVAILABLE;
        return route;
    }
    route.selected = ND_PROVIDER_NPU;
    route.executor_available = 1;
    route.status = ND_ROUTE_OK;
    return route;
}
