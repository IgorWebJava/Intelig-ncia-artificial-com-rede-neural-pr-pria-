<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent UI → Backend Map

| UI area | Future owner/service |
|---|---|
| Projects | Project Registry / Project Service |
| Agent definitions/versions | Agent Service |
| Runtime skills | Agent Skill Registry |
| Tools | Tool Catalog / Gateway |
| Knowledge | Knowledge Service |
| Model profile | AI Capability Fabric / Config |
| Evaluations | Training/Evaluation Service |
| Runs | Agent Runtime |
| Approvals | Approval Service |
| Audit | Audit Service |
| Operations | Observability/Read Models |
