import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from module_testkit import TestContext
class ResponsiveMultimodalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.ctx=TestContext(__file__)
    def test_adaptive_surface_profile(self):
        ui=self.ctx.manifest['ui_surface']; self.assertTrue(ui['responsive']); self.assertEqual(ui['profile'],'intelligence-experience-v2'); self.assertEqual(ui['design_system'],'neuraldesk-intelligence-design-v2');
        for device in ['phone','tablet','notebook','desktop','tv','tv_4k']: self.assertIn(device,ui['device_classes'])
        for mode in ['touch','mouse','keyboard','remote']: self.assertIn(mode,ui['interaction_modes'])
    def test_multimodal_modes_declared(self):
        modes=self.ctx.manifest['ui_surface']['content_modes']
        for mode in ['text','image','audio','video','document','structured_data','tool_result']: self.assertIn(mode,modes)
    def test_responsive_css_features(self):
        for token in ['@media',':focus-visible','prefers-reduced-motion','prefers-contrast','safe-area-inset','pointer:coarse']:
            with self.subTest(token=token): self.assertIn(token,self.ctx.css)
    def test_visual_matrix_declared(self):
        matrix=self.ctx.json_file('visual/viewport-matrix.json'); self.assertEqual(set(matrix['viewports']),{'phone','tablet','notebook','desktop_tv','tv4k'})
    def test_readable_typography_floor_is_documented_in_css(self):
        self.assertIn('font-size:11px',self.ctx.css); self.assertNotIn('font-size:5px',self.ctx.css); self.assertNotIn('font-size:6px',self.ctx.css)
if __name__=='__main__': unittest.main()
