<!-- neuraldesk-documentation-sync: V8.8 -->

# Module Preview — Advanced AI Chat Workspace

Canonical preview:

```text
modules/chat/preview/page-preview.png
```

Source UI:

```text
modules/chat/ui/chat.html
```

Standard capture profile:

```text
module-preview-v1
1600x1000
viewport capture
```

Regenerate after any meaningful visual UI change.

Command:

```text
python tools/generate_module_previews.py --module chat
```
