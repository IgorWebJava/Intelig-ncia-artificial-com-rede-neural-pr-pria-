# Security, Safety and Trust Strategy

Trust controls apply at every execution boundary.

Controls:
- identity and tenant isolation;
- least privilege;
- secret management;
- prompt/tool injection defenses;
- sandboxing;
- content/data policy;
- approval tiers;
- egress restrictions;
- audit;
- retention;
- incident response.

High-risk actions must disclose WHAT, WHY, WHO, DATA, RISK, COST, PERMISSION and REVERSIBILITY before approval.
