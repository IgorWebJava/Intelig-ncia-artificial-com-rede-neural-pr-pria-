<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
# V8.2 — Intelligence Experience Suite

## Added
- Intelligence Design System 2.
- Comfortable / Balanced / Dense density modes.
- Universal Context Lens.
- Provenance Everywhere.
- Trust Layer.
- Adaptive Inspector pattern.
- Visual version/diff/rollback surfaces.
- Specialized mechanics across all 10 modules.

## Module upgrades
- Home: continuity + Work Graph.
- Chat: Adaptive Workspace surfaces.
- Agents: Agent Design Studio + version compare.
- Knowledge: Library / Ingestion / Retrieval Labs.
- Tools: Marketplace / Builder / Testbench.
- Training: Experiment Lab + prompt diff.
- Operations: trace waterfall + anomaly explanation.
- Audit: investigation workspace + evidence package.
- System Config: Change Planner V2.
- Settings: Memory / Privacy / Accessibility.

Scope remains template/interface only.
