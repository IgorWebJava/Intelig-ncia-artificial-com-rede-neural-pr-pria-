#!/usr/bin/env python3
"""Verify the mandatory lessons/anti-regression protocol is wired into generation paths."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
LESSONS_REL = 'memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md'
LESSONS = ROOT / LESSONS_REL
assert LESSONS.is_file(), LESSONS_REL
text = LESSONS.read_text(encoding='utf-8')
for required in [
    'Regra zero:',
    'O que fizemos certo',
    'O que fizemos errado',
    'Gates mínimos antes de qualquer promoção',
    'Este arquivo é a primeira leitura obrigatória do projeto.',
]:
    assert required in text, required
manifest = json.loads((ROOT / 'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))
pre = manifest['mandatoryPreGenerationRead']
assert pre['path'] == LESSONS_REL, pre
assert pre['policy'] == 'READ_AND_ANALYZE_BEFORE_ANY_GENERATION_TRAINING_MODIFICATION_OR_RELEASE'

wired = [
    'training/materialize_datasets.py',
    'training/train_knowledge_retriever.py',
    'training/train_context_pointer.py',
    'training/train_relation_classifier.py',
    'training/train_release.py',
    'training/build_open_knowledge_shard.py',
    'training/train_semantic_ranker.py',
    'training/weight_averaging.py',
    'training/materialize_generative_v074.py',
    'training/build_tokenizer_v074.py',
    'training/train_generative_micro_v074.py',
    'training/materialize_generative_v074_v2.py',
    'training/build_tokenizer_v074_v2.py',
    'training/build_token_cache_v074_v2.py',
    'training/train_generative_micro_v074_v3.py',
    'training/train_generative_micro_v074_v3_batch.py',
    'training/finetune_generative_micro_v074_v3_sft_v2.py',
    'training/pretrain_generative_micro_v074_v3_data_scale_v2.py',
    'training/build_governance_v075.py',
    'scripts/build_host.sh',
    'scripts/verify_sanitize.sh',
    'scripts/verification_checkpoint.py',
    'scripts/verify_jni_host.sh',
    'scripts/verify_kotlin_host.sh',
    'scripts/generate_release_metadata.py',
    'scripts/package_release.py',
    'scripts/model_authority.py',
    'scripts/verify.sh',
]
for rel in wired:
    src = (ROOT / rel).read_text(encoding='utf-8')
    assert 'pre_generation_lessons_check.py' in src, f'precheck not wired: {rel}'

p = subprocess.run([sys.executable, str(ROOT / 'scripts/pre_generation_lessons_check.py')], cwd=ROOT, text=True, capture_output=True)
assert p.returncode == 0, (p.stdout, p.stderr)
sha = hashlib.sha256(LESSONS.read_bytes()).hexdigest()
assert sha in p.stdout, (sha, p.stdout)
print('lessons-protocol PASS', sha, len(wired), 'generation/build paths wired')
