<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# V6.5 — Documentação Organizada por Página

## Mudança

Toda documentação específica foi reorganizada por módulo/página.

## Estrutura

```text
docs/index/
docs/chat/
docs/dashboard-center/
docs/training/
docs/knowledge-center/
docs/tools-center/
docs/settings/
docs/project/
```

Também foram centralizados:

- changelogs em `docs/project/history/`;
- verificações em `docs/project/verification/`;
- decisões transversais em `docs/project/architecture/`.

Cada pasta de página agora possui `README.md`.
