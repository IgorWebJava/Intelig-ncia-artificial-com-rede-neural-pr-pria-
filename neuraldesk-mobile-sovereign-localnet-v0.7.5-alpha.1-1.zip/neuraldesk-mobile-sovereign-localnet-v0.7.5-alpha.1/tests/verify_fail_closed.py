#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile

ROOT=Path('.')
GOOD={
 'r':ROOT/'models/neuraldesk-knowledge-retriever-v0.5.ndkr',
 'k':ROOT/'models/neuraldesk-knowledge-v0.5.ndkb',
 'q':ROOT/'models/neuraldesk-context-pointer-v0.5.ndqa',
 'l':ROOT/'models/neuraldesk-relation-classifier-v0.5.ndrl',
}

def run(r,k,q,l):
    return subprocess.run(['./build/ndassistant',str(r),str(k),str(q),str(l),'Qual é a capital do Brasil?'],
                          stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode

cases=[]
with tempfile.TemporaryDirectory() as td:
    d=Path(td)
    for key,path in GOOD.items():
        raw=path.read_bytes()
        variants={
            'truncated':raw[:-17],
            'trailing':raw+b'X',
            'magic':bytes([raw[0]^0x55])+raw[1:],
        }
        for name,data in variants.items():
            bad=d/f'{key}-{name}.bin';bad.write_bytes(data)
            args=dict(GOOD);args[key]=bad
            rc=run(args['r'],args['k'],args['q'],args['l'])
            assert rc!=0,(key,name,rc)
            cases.append((key,name))
print('fail-closed PASS',len(cases),'corruptions rejected')
