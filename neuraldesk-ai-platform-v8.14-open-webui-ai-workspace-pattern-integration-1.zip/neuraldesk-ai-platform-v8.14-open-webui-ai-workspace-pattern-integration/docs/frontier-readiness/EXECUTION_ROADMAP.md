<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Execution Roadmap

The roadmap is dependency-driven, not feature-count driven.

| Phase | Objective | Main exit result |
|---|---|---|
| 00 | Measurement and baselines | Reproducible benchmark/eval baseline |
| 01 | Executable core | Durable platform primitives and API boundary |
| 02 | Model + project intelligence | Real chat/project/memory/context over model APIs |
| 03 | Agents, tools and knowledge | Safe tool/RAG/agent execution |
| 04 | Multimodal + research | Voice, vision, research and controlled browser workflows |
| 05 | Work completion | Durable tasks, artifacts, background work and resume |
| 06 | Production control plane | SLO, security, audit, canary, rollback and cost governance |
| 07 | Own-model program | Specialized NeuralDesk-owned models |
| 08 | Frontier research | Scale/architecture/post-training/serving research |

## Program rule

A later phase may be researched early, but it cannot become a production dependency before its prerequisite phases meet exit gates.

## Preferred market strategy

Reach product parity quickly using replaceable frontier providers, then invest proprietary research where it creates defensible advantage.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
