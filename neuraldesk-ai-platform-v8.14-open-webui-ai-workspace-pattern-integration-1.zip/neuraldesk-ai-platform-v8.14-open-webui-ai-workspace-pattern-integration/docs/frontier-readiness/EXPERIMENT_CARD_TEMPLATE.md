# Experiment Card Template

- Experiment ID:
- Hypothesis:
- Owner module:
- Dataset/workload:
- Model/version:
- Hardware/provider:
- Baseline:
- Candidate:
- Metrics:
- Quality/safety floors:
- Result:
- Reproducibility artifacts:
- Adoption decision:
- Rollback/fallback:
