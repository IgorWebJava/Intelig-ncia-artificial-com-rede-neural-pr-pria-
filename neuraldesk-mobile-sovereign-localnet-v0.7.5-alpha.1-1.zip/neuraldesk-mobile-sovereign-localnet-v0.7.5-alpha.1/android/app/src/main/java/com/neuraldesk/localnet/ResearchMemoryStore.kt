package com.neuraldesk.localnet

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Opt-in encrypted local research memory. New rows persist only question,
 * source and evidence context; generated answers are deliberately not stored.
 */
class ResearchMemoryStore(private val context: Context) {
    private val file = File(context.filesDir, "research-memory-v2.enc.jsonl")
    private val legacyFile = File(context.filesDir, "research-memory.jsonl")
    private val prefs = context.getSharedPreferences("neuraldesk-research-memory", Context.MODE_PRIVATE)
    private val keyAlias = "neuraldesk.research.memory.v2"
    private val stop = setOf(
        "que", "qual", "quais", "quem", "como", "onde", "quando", "para", "por",
        "uma", "uns", "umas", "com", "sem", "sobre", "projeto", "sistema", "diga", "informe"
    )

    fun isEnabled(): Boolean = prefs.getBoolean("enabled", false)

    @Synchronized
    fun setEnabled(enabled: Boolean) {
        if (enabled) {
            getOrCreateKey()
            migrateLegacyIfNeeded()
        }
        prefs.edit().putBoolean("enabled", enabled).apply()
    }

    @Synchronized
    fun clear() {
        if (file.exists()) require(file.delete()) { "não foi possível apagar memória de pesquisa" }
        if (legacyFile.exists()) require(legacyFile.delete()) { "não foi possível apagar memória legada" }
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return JSONObject()
            .put("v", 2)
            .put("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .put("ciphertext", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .toString()
    }

    private fun decrypt(line: String): String {
        val envelope = JSONObject(line)
        if (!envelope.has("ciphertext")) return line
        require(envelope.optInt("v", -1) == 2) { "versão de memória criptografada incompatível" }
        val iv = Base64.decode(envelope.getString("iv"), Base64.NO_WRAP)
        val encrypted = Base64.decode(envelope.getString("ciphertext"), Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }

    private fun rewriteEncrypted(lines: List<String>) {
        val temporary = File(file.parentFile, ".${file.name}.writing")
        if (temporary.exists()) require(temporary.delete()) { "staging de memória residual" }
        try {
            FileOutputStream(temporary).bufferedWriter().use { writer ->
                for (line in lines.takeLast(128)) writer.append(line).append('\n')
                writer.flush()
            }
            FileOutputStream(temporary, true).use { it.fd.sync() }
            Files.move(
                temporary.toPath(), file.toPath(),
                StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE
            )
        } finally {
            if (temporary.exists()) temporary.delete()
        }
    }

    private fun migrateLegacyIfNeeded() {
        if (!legacyFile.isFile) return
        val migrated = legacyFile.readLines().takeLast(128).map { encrypt(it) }
        val existing = if (file.isFile) file.readLines().takeLast(128) else emptyList()
        rewriteEncrypted((existing + migrated).takeLast(128))
        require(legacyFile.delete()) { "não foi possível remover memória plaintext após migração" }
    }

    private fun terms(text: String): Set<String> =
        text.lowercase()
            .split(Regex("[^\\p{L}\\p{N}-]+"))
            .filter { it.length >= 3 && it !in stop }
            .toSet()

    @Synchronized
    fun append(question: String, source: String, contextText: String) {
        if (!isEnabled()) return
        val old = if (file.exists()) file.readLines().takeLast(127) else emptyList()
        val row = JSONObject()
            .put("timestamp_ms", System.currentTimeMillis())
            .put("question", question.take(4096))
            .put("source", source.take(2048))
            .put("context", contextText.take(12_000))
            .toString()
        rewriteEncrypted(old + encrypt(row))
    }

    @Synchronized
    fun findRelevant(question: String, maxChars: Int = 12_000): String? {
        if (!isEnabled() || !file.exists()) return null
        val queryTerms = terms(question)
        if (queryTerms.isEmpty()) return null
        val ranked = file.readLines().asReversed().mapNotNull { line ->
            runCatching {
                val row = JSONObject(decrypt(line))
                val evidence = row.optString("context", "")
                val sourceQuestion = row.optString("question", "")
                val hay = terms("$sourceQuestion $evidence")
                val overlap = queryTerms.count { it in hay }
                val ratio = overlap.toDouble() / queryTerms.size.toDouble()
                Triple(overlap + ratio, evidence, row.optString("source", ""))
            }.getOrNull()
        }.filter { it.first >= 2.0 }
            .sortedByDescending { it.first }
            .take(6)
        if (ranked.isEmpty()) return null
        val builder = StringBuilder()
        for ((_, evidence, source) in ranked) {
            val block = if (source.isBlank()) evidence else "Fonte memorizada: $source. $evidence"
            if (builder.length + block.length + 2 > maxChars) continue
            if (builder.isNotEmpty()) builder.append("\n")
            builder.append(block)
        }
        return builder.toString().ifBlank { null }
    }
}
