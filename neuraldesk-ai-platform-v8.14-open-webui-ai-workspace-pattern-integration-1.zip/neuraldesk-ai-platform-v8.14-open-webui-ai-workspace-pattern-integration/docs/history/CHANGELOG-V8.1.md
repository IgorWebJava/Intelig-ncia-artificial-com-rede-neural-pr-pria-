<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
# V8.1 — Autonomous Assistant Experience Template

## Added
- `autonomous-assistant-experience-v1` UI contract;
- Mission Control;
- project switch/pause/resume visual mechanics;
- visual checkpoints;
- assistant modes;
- Plan & Tasks;
- safe Activity Timeline;
- Project Context & Memory surface;
- Agents/Tools visibility;
- enhanced Artifact Workspace;
- continuous voice control surface without microphone capture;
- assistant experience development skill and governance boundary.

## Not added
No autonomous engine/backend, planner/orchestrator, real agent/tool/web execution, persistent memory, background task runtime or computer-use engine.
