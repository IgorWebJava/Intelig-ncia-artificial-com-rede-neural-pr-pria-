<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.app-shell; current: modules/app-shell/docs/CURRENT_STATE.md -->
# Index / Launcher Page

## Responsabilidade

`modules/app-shell/ui/index.html` é exclusivamente um launcher visual opcional.

Ele não deve:

- conter a implementação interna das outras páginas;
- armazenar estado necessário para os módulos;
- ser pré-requisito para Chat, Dashboard, Training, Knowledge, Tools ou Settings.

## Navegação

O launcher pode apontar para:

```text
modules/chat/ui/chat.html
modules/operations/ui/dashboard-center.html
modules/training/ui/training.html
modules/knowledge/ui/knowledge-center.html
modules/tools/ui/tools-center.html
modules/settings/ui/settings.html
modules/audit/ui/audit-center.html
modules/system-config/ui/system-config-center.html
```

## CSS

```text
index.html → modules/app-shell/ui/index.css
```

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/app-shell/
UI:        modules/app-shell/ui/index.html
CSS:       modules/app-shell/ui/index.css
Manifest:  modules/app-shell/module.manifest.json
Contracts: modules/app-shell/contracts/
Data:      modules/app-shell/data/
Docs:      modules/app-shell/docs/
```

The root `index.html` file, when present, is only a backward-compatible route alias.
