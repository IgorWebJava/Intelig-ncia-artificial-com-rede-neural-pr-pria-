<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 112 — Test Pyramid V7.3

```text
                   Replacement / Canary
                 AI / Agent / Tool E2E
              API / DB / Event Integration
                  Browser Visual
             Contract / Security / UI
             Architecture / Manifests
```

The lower layers run today against the static modular package.
Upper layers are already specified and become executable as runtime services are implemented.
