#include "nd_knowledge.h"
#include <stdio.h>
#include <string.h>
int main(int argc,char **argv){
    if(argc<4){fprintf(stderr,"usage: %s RETRIEVER KB QUESTION [rich]\n",argv[0]);return 2;}
    char e[256],out[8192];NDKnowledgeBase kb;NDKnowledgeRetriever r;NDRetrievalResult rr;
    if(nd_knowledge_load(argv[2],&kb,e,sizeof(e))){fprintf(stderr,"kb: %s\n",e);return 1;}
    if(nd_retriever_load(argv[1],kb.count,&r,e,sizeof(e))){fprintf(stderr,"retriever: %s\n",e);nd_knowledge_free(&kb);return 1;}
    int rich=argc>4?1:!nd_knowledge_prefers_short(argv[3]);
    if(nd_knowledge_answer(&kb,&r,argv[3],rich,out,sizeof(out),&rr,e,sizeof(e))){fprintf(stderr,"answer: %s\n",e);nd_retriever_free(&r);nd_knowledge_free(&kb);return 1;}
    printf("class=%u accepted=%d confidence=%.9f margin=%.9f\n%s\n",rr.class_id,rr.accepted,rr.confidence,rr.margin,out);
    nd_retriever_free(&r);nd_knowledge_free(&kb);return 0;
}
