<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 100 — Modular Platform Architecture

## Invariant

```text
A module must never depend on another module's private implementation.
```

Allowed dependencies:

1. versioned public contract;
2. declared capability;
3. stable platform primitive.

Canonical modules live in `modules/<module>/`.
