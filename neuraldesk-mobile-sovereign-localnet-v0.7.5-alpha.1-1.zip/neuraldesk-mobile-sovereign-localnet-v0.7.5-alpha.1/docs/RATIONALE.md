# Architectural Rationale — v0.7.2-alpha.1

## 1. Mais inteligência não significa apenas mais parâmetros

Tentativas generativas pequenas chegaram a loss muito baixa e ainda trocaram fatos. A linha promovida usa especialistas onde há ganho mensurável e ferramentas/memória onde determinismo é superior.

## 2. Relação explícita resolve competição contextual

A heurística v0.4 acertou apenas 50/400 num holdout em que a mesma entidade aparecia com atributos concorrentes. O classificador de relação elevou o mesmo problema a 400/400. O ganho vem de entender **qual atributo** a pergunta pede, não de aumentar o texto da resposta.

## 3. Redes neurais são proponentes quando o erro pode corromper um fato

O pointer condicionado passou 2.000/2.000 Golden, mas somente 9/12 probes realmente livres. Em vez de esconder essa limitação, a arquitetura introduziu candidate acceptance: 12/12 respostas finais corretas, seis por fallback para evidência grounded.

## 4. Threshold global não é ajustado para perseguir benchmark

Quando `endpoint numérico ... utiliza` produziu margem baixa por competição com protocolo, a correção não diminuiu o threshold global. O runtime aceita a classe apenas quando há cue explícita única coerente com o próprio top-1 neural.

## 5. Preprocessamento é parte dos pesos

Um checksum hexadecimal expôs divergência Python↔C: mascarar parcialmente o primeiro dígito alterava features mesmo com pesos iguais. A normalização nativa foi alinhada ao regex de treinamento e o gate voltou a 4.008/4.008.

## 6. Fatos auditáveis ficam fora dos pesos quando possível

A `.ndkb` permite corrigir/versionar conhecimento sem retrain obrigatório. O retriever aprende relevância; a resposta continua auditável.

## 7. Reprodutibilidade é requisito de promoção

Retriever, KB, relation classifier e pointer foram reproduzidos duas vezes com bytes idênticos aos assets distribuídos. Seed sem comparação byte a byte não é prova suficiente.

## 8. O arquivo de lições é dependência de engenharia

Todo erro relevante descoberto durante evolução é registrado **antes** da correção. O objetivo é tornar falhas anteriores parte da política executável da próxima mudança.

## 9. Open knowledge é recuperação subordinada, não “mais parâmetros”

O NDOS adiciona cobertura auditável sem alterar os 543.094 parâmetros neurais. Ele só entra depois de contexto, cálculo, memória e conhecimento interno; score e margem falham fechado. Isso preserva a separação entre conhecimento armazenado e decisão aprendida.

## 10. Fonte de verdade precisa sobreviver a upgrade do app

Usar `models/` como única fonte no build não basta se o Android reutilizar uma cópia antiga em `filesDir`. A alpha.2 passa a comparar conteúdo empacotado e instalado e substituir atomicamente cópias divergentes antes do JNI.

## 11. Evidence precisa carregar identidade de versão

Um `PASS` genérico em arquivo chamado `FINAL_*` pode pertencer a outra release. Os gates finais agora emitem a versão e `generate_release_metadata.py` rejeita evidence cuja versão não coincida com `PROJECT_MANIFEST.json`.

## 12. Corrigir semântica determinística antes de escalar parâmetros

Os diálogos mostraram erros que uma rede maior não deveria mascarar: precedência matemática, split incorreto, atributo de memória e troca de entidade. A v0.6.1 corrige primeiro essas invariantes e mede a superioridade em holdouts.

## 13. Neural-first, sparse-second

O retriever neural preserva autoridade quando aceita. Sparse existe apenas como recuperação conservadora após recusa e foi endurecido porque a primeira versão aumentou recall às custas de factualidade (`Noveria-999`). Precisão/fail-closed continua acima de cobertura.

## 14. Estado conversacional bounded antes de um decoder geral

Um turno anterior resolve coreferências simples sem fabricar um LLM. Esse mecanismo é explicitamente limitado e serve como degrau testável para uma futura arquitetura generativa, não como substituto enganoso dela.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
