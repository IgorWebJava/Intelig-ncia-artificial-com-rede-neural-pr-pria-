<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Deterministic Correctness & Oracle Strategy

NeuralDesk future model implementations require a correct reference path before optimized paths. Tests must span operator, layer and model levels and compare reference/full-recompute/incremental/optimized paths.

A tiny oracle must preserve the relevant tensor graph and boundary conditions; it must not be so small that architectural failure modes disappear. Fixtures should deliberately break plausible incorrect implementations.

Where stochastic decoding is enabled, deterministic parity applies to fixed-seed or greedy/reference modes; distributional equivalence needs separate statistical tests.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
