# v0.7.5 current additions

- `HISTORICAL_CAPABILITY_CONVERGENCE_V075.md` — matriz profunda de capacidades/version lineages e decisões de merge.
- `STREAMING_HARDWARE_GOVERNANCE_V075.md` — contratos executáveis de streaming, hardware routing, governance e accumulation.

# Documentation Index — v0.7.4-alpha.2

Documentos canônicos top-level:

- `ANDROID_BUILD.md`
- `ARCHITECTURE.md`
- `CLEANUP_AUDIT.md`
- `COMPREHENSIVE_AUDIT.md`
- `CURRENT_STATE.md`
- `DIALOGUE_GROUNDING_V062.md`
- `DOCUMENTATION_INDEX.md`
- `EVALUATION.md`
- `HISTORICAL_CAPABILITY_MERGE_AUDIT.md`
- `HISTORICAL_CONVERGENCE_V071.md`
- `HISTORICAL_DEEP_AUDIT_V072.md`
- `INTEGRATION_WITH_NEURALDESK_v0.63.md`
- `INTERNET_ACCESS.md`
- `KIMI_K3_REFERENCE_REVIEW.md`
- `LOCAL_RAG_V071.md`
- `MOBILE_PROFILES.md`
- `MOBILE_RUNTIME_HARDENING_V073.md`
- `MODEL_AUTHORITY_V071.md`
- `MODEL_AUTHORITY_V072.md`
- `MODEL_FORMAT.md`
- `OFFLINE_CONTINUITY_V072.md`
- `OPEN_KNOWLEDGE_SHARD.md`
- `PROJECT_STRUCTURE.md`
- `RATIONALE.md`
- `RECONSTRUCTION_LINEAGE.md`
- `RELEASE_NOTES.md`
- `RELIABILITY_DEVICE_V071.md`
- `ROBUST_INTENT_V063_RECOVERY.md`
- `SECURITY.md`
- `SOURCE_OF_TRUTH.md`
- `TRAINING.md`
- `TRUTH_BOUNDARY.md`

O arquivo obrigatório de continuidade é `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md` e precede qualquer modificação.

Documentos com sufixos de versões anteriores permanecem canônicos como lineage/histórico técnico; a autoridade corrente é `PROJECT_MANIFEST.json` + `CURRENT_STATE.md` + `MOBILE_RUNTIME_HARDENING_V073.md` + evidence versionada v0.7.3.

<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Registry regenerado a partir dos bytes reais da árvore v0.7.2; nenhum documento top-level ficou fora de `canonicalDocs`.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.


- `GENERATIVE_RUNTIME_V074.md` — runtime generativo/training candidate alpha.2 e truth boundary.
