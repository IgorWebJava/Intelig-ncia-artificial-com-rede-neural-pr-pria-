#include "nd_knowledge.h"
#include <math.h>
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static void seterr(char *e,size_t n,const char *fmt,...){if(!e||!n)return;va_list a;va_start(a,fmt);vsnprintf(e,n,fmt,a);va_end(a);}
static int mul_ok(size_t a,size_t b,size_t *o){if(a&&b>SIZE_MAX/a)return 0;*o=a*b;return 1;}
static int add_ok(size_t a,size_t b,size_t *o){if(b>SIZE_MAX-a)return 0;*o=a+b;return 1;}
static char *read_string(FILE *f,uint32_t n,char *e,size_t ec){
    if(n>65536u){seterr(e,ec,"knowledge string exceeds limit");return NULL;}
    char *s=(char*)malloc((size_t)n+1u);if(!s){seterr(e,ec,"oom knowledge string");return NULL;}
    if(n&&fread(s,1,n,f)!=n){free(s);seterr(e,ec,"truncated knowledge string");return NULL;}
    s[n]=0;return s;
}
void nd_knowledge_free(NDKnowledgeBase *kb){
    if(!kb)return;
    if(kb->records){for(uint32_t i=0;i<kb->count;i++){free(kb->records[i].question);free(kb->records[i].short_answer);free(kb->records[i].rich_answer);free(kb->records[i].category);}free(kb->records);}
    memset(kb,0,sizeof(*kb));
}
int nd_knowledge_load(const char *path,NDKnowledgeBase *kb,char *e,size_t ec){
    if(!path||!kb){seterr(e,ec,"invalid knowledge arguments");return -1;}memset(kb,0,sizeof(*kb));
    FILE *f=fopen(path,"rb");if(!f){seterr(e,ec,"cannot open knowledge base");return -1;}
    uint32_t h[3];if(fread(h,sizeof(uint32_t),3,f)!=3){seterr(e,ec,"short knowledge header");fclose(f);return -1;}
    if(h[0]!=ND_KB_MAGIC||h[1]!=ND_KB_VERSION||!h[2]||h[2]>4096u){seterr(e,ec,"invalid knowledge header");fclose(f);return -1;}
    kb->count=h[2];kb->records=(NDKnowledgeRecord*)calloc(kb->count,sizeof(*kb->records));if(!kb->records){seterr(e,ec,"oom knowledge records");fclose(f);return -1;}
    for(uint32_t i=0;i<kb->count;i++){
        uint32_t n[4];if(fread(n,sizeof(uint32_t),4,f)!=4){seterr(e,ec,"truncated knowledge record header");nd_knowledge_free(kb);fclose(f);return -1;}
        if(!n[0]||!n[1]||!n[2]||!n[3]){seterr(e,ec,"empty knowledge field");nd_knowledge_free(kb);fclose(f);return -1;}
        NDKnowledgeRecord *r=&kb->records[i];
        r->question=read_string(f,n[0],e,ec);if(!r->question){nd_knowledge_free(kb);fclose(f);return -1;}
        r->short_answer=read_string(f,n[1],e,ec);if(!r->short_answer){nd_knowledge_free(kb);fclose(f);return -1;}
        r->rich_answer=read_string(f,n[2],e,ec);if(!r->rich_answer){nd_knowledge_free(kb);fclose(f);return -1;}
        r->category=read_string(f,n[3],e,ec);if(!r->category){nd_knowledge_free(kb);fclose(f);return -1;}
    }
    if(fgetc(f)!=EOF){seterr(e,ec,"trailing knowledge bytes rejected");nd_knowledge_free(kb);fclose(f);return -1;}
    fclose(f);return 0;
}
void nd_retriever_free(NDKnowledgeRetriever *r){if(!r)return;free(r->storage);memset(r,0,sizeof(*r));}
int nd_retriever_load(const char *path,uint32_t expected_records,NDKnowledgeRetriever *r,char *e,size_t ec){
    if(!path||!r){seterr(e,ec,"invalid retriever arguments");return -1;}memset(r,0,sizeof(*r));FILE *f=fopen(path,"rb");if(!f){seterr(e,ec,"cannot open retriever");return -1;}
    if(fread(&r->h,sizeof(r->h),1,f)!=1){seterr(e,ec,"short retriever header");fclose(f);return -1;}
    NDRetrieverHeader *h=&r->h;
    if(h->magic!=ND_RETRIEVER_MAGIC||h->version!=ND_RETRIEVER_VERSION||h->feature_dim!=4096u||!h->hidden_dim||h->hidden_dim>512u||h->classes<2u||h->classes>4097u||h->classes!=expected_records+1u){seterr(e,ec,"invalid retriever header");fclose(f);return -1;}
    size_t a,b,c,total=0;if(!mul_ok(h->feature_dim,h->hidden_dim,&a)||!mul_ok(h->hidden_dim,h->classes,&b)||!add_ok(a,h->hidden_dim,&c)||!add_ok(c,b,&c)||!add_ok(c,h->classes,&total)){seterr(e,ec,"retriever size overflow");fclose(f);return -1;}
    r->storage_floats=total;size_t bytes;if(!mul_ok(total,sizeof(float),&bytes)){seterr(e,ec,"retriever byte size overflow");fclose(f);return -1;}
    r->storage=(float*)malloc(bytes);if(!r->storage){seterr(e,ec,"oom retriever weights");fclose(f);return -1;}
    if(fread(r->storage,sizeof(float),total,f)!=total){seterr(e,ec,"truncated retriever weights");nd_retriever_free(r);fclose(f);return -1;}
    if(fgetc(f)!=EOF){seterr(e,ec,"trailing retriever bytes rejected");nd_retriever_free(r);fclose(f);return -1;}fclose(f);
    float *p=r->storage;r->w1=p;p+=a;r->b1=p;p+=h->hidden_dim;r->w2=p;p+=b;r->b2=p;p+=h->classes;
    if((size_t)(p-r->storage)!=total){seterr(e,ec,"retriever layout mismatch");nd_retriever_free(r);return -1;}return 0;
}
static uint32_t fnv_update(uint32_t h,const unsigned char *p,size_t n){for(size_t i=0;i<n;i++){h^=p[i];h*=16777619u;}return h;}
static uint32_t hash_prefixed(unsigned char prefix,const unsigned char *p,size_t n){uint32_t h=2166136261u;h^=prefix;h*=16777619u;return fnv_update(h,p,n);}
static int word_byte(unsigned char x){return(x>=(unsigned char)'0'&&x<=(unsigned char)'9')||(x>=(unsigned char)'a'&&x<=(unsigned char)'z')||x>=128u;}
static int ws(unsigned char x){return x==' '||x=='\t'||x=='\r'||x=='\n';}
static size_t normalize(const char *s,unsigned char *o,size_t cap){size_t k=0;int space=0;for(const unsigned char *p=(const unsigned char*)s;*p;p++){unsigned char x=*p;if(x>='A'&&x<='Z')x=(unsigned char)(x+('a'-'A'));if(ws(x)){if(k&&!space){if(k>=cap)return 0;o[k++]=' ';}space=1;}else{if(k>=cap)return 0;o[k++]=x;space=0;}}if(k&&o[k-1]==' ')k--;return k;}
static int build_features(const char *question,float *v,uint32_t dim,char *e,size_t ec){
    size_t qn=strlen(question);if(!qn||qn>4096u){seterr(e,ec,"question exceeds retriever limit");return -1;}unsigned char *b=(unsigned char*)malloc(qn+1u);if(!b){seterr(e,ec,"oom normalized question");return -1;}size_t n=normalize(question,b,qn+1u);if(!n){free(b);seterr(e,ec,"empty normalized question");return -1;}memset(v,0,(size_t)dim*sizeof(float));
    size_t i=0;while(i<n){while(i<n&&!word_byte(b[i]))i++;size_t j=i;while(j<n&&word_byte(b[j]))j++;if(j>i){uint32_t h1=hash_prefixed((unsigned char)'w',b+i,j-i);uint32_t h2=hash_prefixed((unsigned char)'W',b+i,j-i);v[h1%dim]+=2.0f;v[h2%dim]+=2.0f;}i=(j>i)?j:i+1u;}
    const size_t ns[3]={3u,4u,5u};const unsigned char ps[3]={'3','4','5'};for(size_t z=0;z<3;z++){size_t ng=ns[z];if(n<ng)continue;for(size_t x=0;x+ng<=n;x++){int any=0;for(size_t y=0;y<ng;y++)if(!ws(b[x+y])){any=1;break;}if(!any)continue;uint32_t h=hash_prefixed(ps[z],b+x,ng);v[h%dim]+=0.25f;}}
    double ss=0.0;for(uint32_t x=0;x<dim;x++)ss+=(double)v[x]*v[x];if(ss<=0.0){free(b);seterr(e,ec,"empty retriever features");return -1;}float inv=(float)(1.0/sqrt(ss));for(uint32_t x=0;x<dim;x++)v[x]*=inv;free(b);return 0;
}
int nd_retriever_infer(const NDKnowledgeRetriever *r,const char *question,NDRetrievalResult *result,char *e,size_t ec){
    if(!r||!r->storage||!question||!result){seterr(e,ec,"invalid retriever input");return -1;}uint32_t f=r->h.feature_dim,h=r->h.hidden_dim,c=r->h.classes;float *x=(float*)calloc(f,sizeof(float)),*z=(float*)malloc((size_t)h*sizeof(float)),*logits=(float*)calloc(c,sizeof(float));if(!x||!z||!logits){free(x);free(z);free(logits);seterr(e,ec,"oom retriever workspace");return -1;}if(build_features(question,x,f,e,ec)){free(x);free(z);free(logits);return -1;}
    for(uint32_t j=0;j<h;j++){z[j]=r->b1[j];}
    for(uint32_t i=0;i<f;i++){
        float xi=x[i];
        if(xi==0.0f)continue;
        const float *row=r->w1+(size_t)i*h;
        for(uint32_t j=0;j<h;j++){z[j]+=xi*row[j];}
    }
    for(uint32_t j=0;j<h;j++){z[j]=tanhf(z[j]);}
    for(uint32_t k=0;k<c;k++){logits[k]=r->b2[k];}
    for(uint32_t j=0;j<h;j++){
        float zj=z[j];
        const float *row=r->w2+(size_t)j*c;
        for(uint32_t k=0;k<c;k++){logits[k]+=zj*row[k];}
    }
    uint32_t top=0u,second=1u;
    if(logits[second]>logits[top]){uint32_t t=top;top=second;second=t;}
    for(uint32_t k=2u;k<c;k++){
        if(logits[k]>logits[top]){second=top;top=k;}
        else if(logits[k]>logits[second]){second=k;}
    }
    float mx=logits[top];double sum=0.0;for(uint32_t k=0;k<c;k++)sum+=exp((double)logits[k]-mx);float p1=(float)(1.0/sum);float p2=(float)(exp((double)logits[second]-mx)/sum);result->class_id=top;result->confidence=p1;result->margin=p1-p2;result->accepted=(top+1u<c&&p1>=0.12f&&result->margin>=0.03f)?1:0;
    free(x);free(z);free(logits);return 0;
}
static int contains_ascii_ci(const char *s,const char *needle){size_t n=strlen(needle);if(!n)return 1;for(;*s;s++){size_t i=0;while(i<n&&s[i]){unsigned char a=(unsigned char)s[i],b=(unsigned char)needle[i];if(a>='A'&&a<='Z')a=(unsigned char)(a+32);if(b>='A'&&b<='Z')b=(unsigned char)(b+32);if(a!=b)break;i++;}if(i==n)return 1;}return 0;}
int nd_knowledge_prefers_short(const char *question){if(!question)return 0;return contains_ascii_ci(question,"sem explic")||contains_ascii_ci(question,"somente a resposta")||contains_ascii_ci(question,"só a resposta")||contains_ascii_ci(question,"so a resposta")||contains_ascii_ci(question,"em poucas palavras")||contains_ascii_ci(question,"brevemente");}

typedef struct { char s[72]; size_t n; } NDSparseTerm;

static int sparse_word(unsigned char c){return isalnum(c)||c>=128u||c=='-';}
static int sparse_term_eq(const NDSparseTerm *a,const NDSparseTerm *b){
    if(a->n==b->n&&memcmp(a->s,b->s,a->n)==0)return 1;
    return a->n>=5u&&b->n>=5u&&memcmp(a->s,b->s,5u)==0;
}
static int sparse_stop(const NDSparseTerm *t){
    static const char *v[]={"o","a","os","as","um","uma","uns","umas","de","do","da","dos","das","em","no","na","nos","nas","por","para","com","sem","sobre","que","qual","quais","quem","como","onde","quando","porque","e","ou","é","se","eu","me","meu","minha","cada","tipo","projeto","sistema","registro","esta","está","este","isso","aquele","aquela","ao","aos","informe","diga","responda","explique","palavras","suas","sua","seu","mais","ficou","entre","ser","pode","podem","usar","usa","usado","usada","usados","usadas","ter","tem","tende","tendem"};
    for(size_t i=0;i<sizeof(v)/sizeof(v[0]);i++){size_t n=strlen(v[i]);if(t->n==n&&memcmp(t->s,v[i],n)==0)return 1;}
    return 0;
}
static size_t sparse_terms(const char *text,NDSparseTerm *out,size_t cap){
    size_t n=strlen(text),i=0u,k=0u;
    while(i<n&&k<cap){
        while(i<n&&!sparse_word((unsigned char)text[i]))i++;
        size_t j=i;
        while(j<n&&sparse_word((unsigned char)text[j]))j++;
        if(j>i){
            NDSparseTerm t;size_t z=j-i;if(z>=sizeof(t.s))z=sizeof(t.s)-1u;
            for(size_t x=0;x<z;x++){unsigned char c=(unsigned char)text[i+x];t.s[x]=(char)((c>='A'&&c<='Z')?c+32:c);}
            t.s[z]=0;t.n=z;
            if(z>=2u&&!sparse_stop(&t)){
                int dup=0;for(size_t x=0;x<k;x++)if(sparse_term_eq(&out[x],&t)){dup=1;break;}
                if(!dup)out[k++]=t;
            }
        }
        i=j>i?j:i+1u;
    }
    return k;
}
static int sparse_has(const NDSparseTerm *v,size_t n,const NDSparseTerm *t){for(size_t i=0;i<n;i++)if(sparse_term_eq(&v[i],t))return 1;return 0;}
static int has_upper_acronym(const char *q){
    size_t n=strlen(q),i=0u;
    while(i<n){while(i<n&&!isalnum((unsigned char)q[i]))i++;size_t j=i;int upper=0,lower=0;
        while(j<n&&isalnum((unsigned char)q[j])){if(q[j]>='A'&&q[j]<='Z')upper++;if(q[j]>='a'&&q[j]<='z')lower++;j++;}
        size_t z=j-i;if(z>=2u&&z<=8u&&upper==(int)z&&lower==0)return 1;i=j>i?j:i+1u;
    }return 0;
}

static int acronym_token(const char *s, size_t n) {
    if (n < 2u || n > 12u) return 0;
    size_t upper = 0u;
    size_t alpha = 0u;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') {
            upper++;
            alpha++;
        } else if (c >= 'a' && c <= 'z') {
            return 0;
        } else if (!isdigit(c)) {
            return 0;
        }
    }
    return alpha >= 2u && upper == alpha;
}
static int text_has_ascii_token_ci(const char *text, const char *tok) {
    size_t tn = strlen(tok);
    size_t n = strlen(text);
    size_t i = 0u;
    while (i < n) {
        while (i < n && !isalnum((unsigned char)text[i])) i++;
        size_t j = i;
        while (j < n && isalnum((unsigned char)text[j])) j++;
        if (j - i == tn) {
            size_t k = 0u;
            for (; k < tn; k++) {
                unsigned char a = (unsigned char)text[i + k];
                unsigned char b = (unsigned char)tok[k];
                if (a >= 'A' && a <= 'Z') a = (unsigned char)(a + 32);
                if (b >= 'A' && b <= 'Z') b = (unsigned char)(b + 32);
                if (a != b) break;
            }
            if (k == tn) return 1;
        }
        i = j > i ? j : i + 1u;
    }
    return 0;
}
static int record_has_acronym(const NDKnowledgeRecord *r, const char *tok) {
    return text_has_ascii_token_ci(r->question, tok) ||
           text_has_ascii_token_ci(r->short_answer, tok) ||
           text_has_ascii_token_ci(r->rich_answer, tok);
}
static int record_preserves_query_acronyms(const NDKnowledgeRecord *r,const char *q){
    size_t n=strlen(q),i=0u;int saw=0;
    while(i<n){while(i<n&&!isalnum((unsigned char)q[i]))i++;size_t j=i;while(j<n&&isalnum((unsigned char)q[j]))j++;
        if(j>i&&acronym_token(q+i,j-i)){char tok[16];size_t z=j-i;memcpy(tok,q+i,z);tok[z]=0;saw=1;if(!record_has_acronym(r,tok))return 0;}
        i=j>i?j:i+1u;
    }
    return saw?1:1;
}
static int unique_acronym_record(const NDKnowledgeBase *kb,const char *q,uint32_t *out){
    size_t n=strlen(q),i=0u;char toks[8][16];size_t tc=0u;
    while(i<n&&tc<8u){while(i<n&&!isalnum((unsigned char)q[i]))i++;size_t j=i;while(j<n&&isalnum((unsigned char)q[j]))j++;
        if(j>i&&acronym_token(q+i,j-i)){size_t z=j-i;memcpy(toks[tc],q+i,z);toks[tc][z]=0;tc++;}
        i=j>i?j:i+1u;
    }
    if (!tc) return 0;
    size_t matches = 0u;
    uint32_t idx = 0u;
    for(uint32_t r=0u;r<kb->count;r++){int all=1;for(size_t t=0;t<tc;t++)if(!record_has_acronym(&kb->records[r],toks[t])){all=0;break;}if(all){matches++;idx=r;if(matches>1u)return 0;}}
    if(matches==1u){*out=idx;return 1;}return 0;
}
static int sparse_term_structured_entity(const NDSparseTerm *term) {
    int alpha = 0, digit = 0, separator = 0;
    for (size_t i = 0u; i < term->n; i++) {
        unsigned char c = (unsigned char)term->s[i];
        if (isalpha(c) || c >= 128u) alpha = 1;
        else if (isdigit(c)) digit = 1;
        else if (c == '-' || c == '_') separator = 1;
    }
    return alpha && digit && separator;
}

static int sparse_exact_has(const NDSparseTerm *terms, size_t count, const NDSparseTerm *needle) {
    for (size_t i = 0u; i < count; i++) {
        if (terms[i].n == needle->n && memcmp(terms[i].s, needle->s, needle->n) == 0) return 1;
    }
    return 0;
}

static int record_preserves_query_structured_entities(const NDKnowledgeRecord *record, const char *question) {
    NDSparseTerm qt[48], rt[96];
    size_t qn = sparse_terms(question, qt, 48u);
    char combined[4096];
    int w = snprintf(combined, sizeof(combined), "%s %s %s",
                     record->question ? record->question : "",
                     record->short_answer ? record->short_answer : "",
                     record->rich_answer ? record->rich_answer : "");
    if (w < 0 || (size_t)w >= sizeof(combined)) return 0;
    size_t rn = sparse_terms(combined, rt, 96u);
    for (size_t i = 0u; i < qn; i++) {
        if (sparse_term_structured_entity(&qt[i]) && !sparse_exact_has(rt, rn, &qt[i])) return 0;
    }
    return 1;
}

static size_t record_query_content_overlap(const NDKnowledgeRecord *record, const char *question) {
    NDSparseTerm qt[48];
    NDSparseTerm rt[96];
    size_t qn = sparse_terms(question, qt, 48u);
    if (!qn) return 0u;
    char combined[4096];
    int w = snprintf(combined, sizeof(combined), "%s %s %s",
                     record->question ? record->question : "",
                     record->short_answer ? record->short_answer : "",
                     record->rich_answer ? record->rich_answer : "");
    if (w < 0 || (size_t)w >= sizeof(combined)) return 0u;
    size_t rn = sparse_terms(combined, rt, 96u);
    size_t overlap = 0u;
    for (size_t i = 0u; i < qn; i++) {
        if (sparse_has(rt, rn, &qt[i])) overlap++;
    }
    return overlap;
}

static int sparse_fallback(const NDKnowledgeBase *kb,const char *question,NDRetrievalResult *rr){
    uint32_t acronym_idx=0u;if(unique_acronym_record(kb,question,&acronym_idx)){rr->class_id=acronym_idx;rr->confidence=0.90f;rr->margin=0.50f;rr->accepted=1;return 1;}
    NDSparseTerm qt[48];size_t qn=sparse_terms(question,qt,48u);if(!qn)return 0;
    float best=0.0f,second=0.0f;uint32_t best_i=0u;size_t best_mr=0u;
    for(uint32_t i=0u;i<kb->count;i++){
        NDSparseTerm rt[48];size_t rn=sparse_terms(kb->records[i].question,rt,48u);if(!rn)continue;
        size_t mq=0u,mr=0u;for(size_t z=0;z<qn;z++)if(sparse_has(rt,rn,&qt[z]))mq++;for(size_t z=0;z<rn;z++)if(sparse_has(qt,qn,&rt[z]))mr++;
        float sc=0.45f*((float)mq/(float)qn)+0.55f*((float)mr/(float)rn);
        if(sc>best){second=best;best=sc;best_i=i;best_mr=mr;}else if(sc>second)second=sc;
    }
    float margin=best-second;int acronym=has_upper_acronym(question);
    int accept=(best_mr>=3u&&best>=0.52f&&margin>=0.12f)||(acronym&&best_mr>=1u&&best>=0.65f&&margin>=0.20f);
    if(!accept)return 0;
    rr->class_id=best_i;
    rr->confidence=best;
    rr->margin=margin;
    rr->accepted=1;
    return 1;
}

int nd_knowledge_answer(const NDKnowledgeBase *kb,const NDKnowledgeRetriever *r,const char *question,int rich,char *out,size_t outcap,NDRetrievalResult *result,char *e,size_t ec){
    if(!kb||!r||!question||!out||!outcap){seterr(e,ec,"invalid knowledge answer input");return -1;}NDRetrievalResult rr;if(nd_retriever_infer(r,question,&rr,e,ec))return -1;if(rr.accepted&&rr.class_id<kb->count&&!record_preserves_query_acronyms(&kb->records[rr.class_id],question))rr.accepted=0;if(rr.accepted&&rr.class_id<kb->count&&!record_preserves_query_structured_entities(&kb->records[rr.class_id],question))rr.accepted=0;if(rr.accepted&&rr.class_id<kb->count&&rr.confidence<0.20f&&record_query_content_overlap(&kb->records[rr.class_id],question)==0u)rr.accepted=0;if(!rr.accepted)sparse_fallback(kb,question,&rr);if(result)*result=rr;
    const char *ans;if(!rr.accepted||rr.class_id>=kb->count)ans="Não sei com segurança. Não há conhecimento local confiável suficiente para responder a essa pergunta.";else ans=rich?kb->records[rr.class_id].rich_answer:kb->records[rr.class_id].short_answer;
    size_t n=strlen(ans);if(n+1u>outcap){seterr(e,ec,"knowledge answer buffer too small");return -1;}memcpy(out,ans,n+1u);return 0;
}
