<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Skills Acceptance

A skill record is valid when it:

- has a stable `skill_id`;
- describes durable/reproducible project knowledge;
- declares required development capabilities;
- references relevant artifacts/modules;
- avoids secrets/private reasoning;
- does not duplicate an existing skill under another name;
- is registered in `REGISTRO_HABILIDADES.json`.
