#ifndef ND_KNOWLEDGE_H
#define ND_KNOWLEDGE_H
#include <stddef.h>
#include <stdint.h>
#define ND_KB_MAGIC 0x314b444eu
#define ND_KB_VERSION 1u
#define ND_RETRIEVER_MAGIC 0x3152444eu
#define ND_RETRIEVER_VERSION 1u

typedef struct {
    char *question;
    char *short_answer;
    char *rich_answer;
    char *category;
} NDKnowledgeRecord;

typedef struct {
    uint32_t count;
    NDKnowledgeRecord *records;
} NDKnowledgeBase;

typedef struct {
    uint32_t magic, version, feature_dim, hidden_dim, classes, seed;
} NDRetrieverHeader;

typedef struct {
    NDRetrieverHeader h;
    float *storage;
    size_t storage_floats;
    float *w1; /* [feature_dim, hidden_dim] */
    float *b1; /* [hidden_dim] */
    float *w2; /* [hidden_dim, classes] */
    float *b2; /* [classes] */
} NDKnowledgeRetriever;

typedef struct {
    uint32_t class_id;
    float confidence;
    float margin;
    int accepted;
} NDRetrievalResult;

int nd_knowledge_load(const char *path, NDKnowledgeBase *kb, char *err, size_t errcap);
void nd_knowledge_free(NDKnowledgeBase *kb);
int nd_retriever_load(const char *path, uint32_t expected_records, NDKnowledgeRetriever *r, char *err, size_t errcap);
void nd_retriever_free(NDKnowledgeRetriever *r);
int nd_retriever_infer(const NDKnowledgeRetriever *r, const char *question, NDRetrievalResult *result, char *err, size_t errcap);
int nd_knowledge_answer(const NDKnowledgeBase *kb, const NDKnowledgeRetriever *r, const char *question, int rich, char *out, size_t outcap, NDRetrievalResult *result, char *err, size_t errcap);
int nd_knowledge_prefers_short(const char *question);
#endif
