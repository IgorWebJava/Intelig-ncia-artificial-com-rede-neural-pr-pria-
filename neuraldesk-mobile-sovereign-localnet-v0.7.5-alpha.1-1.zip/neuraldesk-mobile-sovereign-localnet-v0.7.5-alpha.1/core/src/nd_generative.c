#define _POSIX_C_SOURCE 200809L
#include "nd_generative.h"

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#define ND_GEN_HEADER_BYTES 128u
#define ND_GEN_ENDIAN 0x01020304u
#define ND_GEN_EPS 1.0e-5f

struct NDGenerativeModel {
    int fd;
    unsigned char *mapping;
    size_t mapping_bytes;
    const unsigned char *payload;
    size_t payload_bytes;
    NDGenFormat format;
    float scale;
    uint32_t block_size;
    uint32_t scale_count;
    uint32_t quant_data_bytes;
    const unsigned char *scales;
    int mmap_active;
};

struct NDGenKVPage {
    unsigned int refs;
    size_t used;
    float k[ND_GEN_PAGE_TOKENS][ND_GEN_LAYERS][ND_GEN_KV_DIM];
    float v[ND_GEN_PAGE_TOKENS][ND_GEN_LAYERS][ND_GEN_KV_DIM];
};

typedef struct NDGenOffsets {
    size_t embedding;
    size_t rms1[ND_GEN_LAYERS];
    size_t wq[ND_GEN_LAYERS];
    size_t wk[ND_GEN_LAYERS];
    size_t wv[ND_GEN_LAYERS];
    size_t wo[ND_GEN_LAYERS];
    size_t rms2[ND_GEN_LAYERS];
    size_t w1[ND_GEN_LAYERS];
    size_t w2[ND_GEN_LAYERS];
    size_t w3[ND_GEN_LAYERS];
    size_t final_rms;
    size_t total;
} NDGenOffsets;

static uint32_t read_u32(const unsigned char *p) {
    return ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint64_t read_u64(const unsigned char *p) {
    uint64_t v = 0u;
    unsigned int i;
    for (i = 0u; i < 8u; ++i) {
        v |= ((uint64_t)p[i]) << (8u * i);
    }
    return v;
}

static float read_f32(const unsigned char *p) {
    uint32_t bits = read_u32(p);
    float value;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

static uint64_t fnv1a64(const unsigned char *p, size_t n) {
    uint64_t h = UINT64_C(1469598103934665603);
    size_t i;
    for (i = 0u; i < n; ++i) {
        h ^= (uint64_t)p[i];
        h *= UINT64_C(1099511628211);
    }
    return h;
}

static NDGenOffsets offsets_make(void) {
    NDGenOffsets o;
    size_t x = 0u;
    unsigned int l;
    memset(&o, 0, sizeof(o));
    o.embedding = x;
    x += (size_t)ND_GEN_VOCAB * ND_GEN_DIM;
    for (l = 0u; l < ND_GEN_LAYERS; ++l) {
        o.rms1[l] = x;
        x += ND_GEN_DIM;
        o.wq[l] = x;
        x += (size_t)ND_GEN_DIM * ND_GEN_DIM;
        o.wk[l] = x;
        x += (size_t)ND_GEN_KV_DIM * ND_GEN_DIM;
        o.wv[l] = x;
        x += (size_t)ND_GEN_KV_DIM * ND_GEN_DIM;
        o.wo[l] = x;
        x += (size_t)ND_GEN_DIM * ND_GEN_DIM;
        o.rms2[l] = x;
        x += ND_GEN_DIM;
        o.w1[l] = x;
        x += (size_t)ND_GEN_FFN * ND_GEN_DIM;
        o.w2[l] = x;
        x += (size_t)ND_GEN_DIM * ND_GEN_FFN;
        o.w3[l] = x;
        x += (size_t)ND_GEN_FFN * ND_GEN_DIM;
    }
    o.final_rms = x;
    x += ND_GEN_DIM;
    o.total = x;
    return o;
}

static float weight_at(const NDGenerativeModel *m, size_t index) {
    if (m->format == ND_GEN_FP32) {
        return read_f32(m->payload + index * 4u);
    }
    {
        size_t block = index / m->block_size;
        float scale = read_f32(m->scales + block * 4u);
        if (m->format == ND_GEN_Q8) {
            int8_t q = (int8_t)m->payload[index];
            return (float)q * scale;
        }
        {
            unsigned char packed = m->payload[index / 2u];
            unsigned int nibble = (index & 1u) ? (packed >> 4) : (packed & 0x0fu);
            int q = (int)nibble - 8;
            return (float)q * scale;
        }
    }
}

static void vector_from_weights(const NDGenerativeModel *m, size_t base, float *out, size_t n) {
    size_t i;
    for (i = 0u; i < n; ++i) {
        out[i] = weight_at(m, base + i);
    }
}

static void matvec(const NDGenerativeModel *m,
                   size_t base,
                   size_t rows,
                   size_t cols,
                   const float *x,
                   float *y) {
    size_t r;
    size_t c;
    for (r = 0u; r < rows; ++r) {
        double acc = 0.0;
        size_t off = base + r * cols;
        for (c = 0u; c < cols; ++c) {
            acc += (double)weight_at(m, off + c) * (double)x[c];
        }
        y[r] = (float)acc;
    }
}

static void rmsnorm(const NDGenerativeModel *m, size_t weight_base, const float *x, float *y) {
    double ss = 0.0;
    size_t i;
    float inv;
    for (i = 0u; i < ND_GEN_DIM; ++i) {
        ss += (double)x[i] * (double)x[i];
    }
    inv = 1.0f / sqrtf((float)(ss / (double)ND_GEN_DIM) + ND_GEN_EPS);
    for (i = 0u; i < ND_GEN_DIM; ++i) {
        y[i] = x[i] * inv * weight_at(m, weight_base + i);
    }
}

static void rope(float *v, unsigned int heads, size_t position) {
    unsigned int h;
    unsigned int d;
    for (h = 0u; h < heads; ++h) {
        float *head = v + (size_t)h * ND_GEN_HEAD_DIM;
        for (d = 0u; d < ND_GEN_HEAD_DIM; d += 2u) {
            float exponent = (float)d / (float)ND_GEN_HEAD_DIM;
            float angle = (float)position / powf(10000.0f, exponent);
            float c = cosf(angle);
            float s = sinf(angle);
            float a = head[d];
            float b = head[d + 1u];
            head[d] = a * c - b * s;
            head[d + 1u] = a * s + b * c;
        }
    }
}

static float silu(float x) {
    return x / (1.0f + expf(-x));
}

static int kv_ensure_writable_page(NDGenKVCache *cache, size_t position, NDGenKVPage **out_page) {
    size_t pi = position / ND_GEN_PAGE_TOKENS;
    if (pi >= ND_GEN_MAX_PAGES) {
        return -1;
    }
    if (cache->pages[pi] == NULL) {
        cache->pages[pi] = (NDGenKVPage *)calloc(1u, sizeof(NDGenKVPage));
        if (cache->pages[pi] == NULL) {
            return -1;
        }
        cache->pages[pi]->refs = 1u;
    } else if (cache->pages[pi]->refs > 1u) {
        NDGenKVPage *old = cache->pages[pi];
        NDGenKVPage *copy = (NDGenKVPage *)malloc(sizeof(NDGenKVPage));
        if (copy == NULL) {
            return -1;
        }
        memcpy(copy, old, sizeof(*copy));
        copy->refs = 1u;
        old->refs -= 1u;
        cache->pages[pi] = copy;
    }
    *out_page = cache->pages[pi];
    return 0;
}

static const NDGenKVPage *kv_page_for(const NDGenKVCache *cache, size_t position) {
    size_t pi = position / ND_GEN_PAGE_TOKENS;
    if (pi >= ND_GEN_MAX_PAGES) {
        return NULL;
    }
    return cache->pages[pi];
}

static int attention_incremental(const NDGenKVCache *cache,
                                 unsigned int layer,
                                 const float *q,
                                 size_t current_position,
                                 float *out) {
    unsigned int qh;
    memset(out, 0, sizeof(float) * ND_GEN_DIM);
    for (qh = 0u; qh < ND_GEN_Q_HEADS; ++qh) {
        unsigned int kvh = qh / (ND_GEN_Q_HEADS / ND_GEN_KV_HEADS);
        float scores[ND_GEN_CONTEXT];
        float max_score = -INFINITY;
        double denom = 0.0;
        size_t p;
        unsigned int d;
        for (p = 0u; p <= current_position; ++p) {
            const NDGenKVPage *page = kv_page_for(cache, p);
            size_t slot = p % ND_GEN_PAGE_TOKENS;
            double dot = 0.0;
            if (page == NULL || slot >= page->used) {
                return -1;
            }
            for (d = 0u; d < ND_GEN_HEAD_DIM; ++d) {
                dot += (double)q[(size_t)qh * ND_GEN_HEAD_DIM + d] *
                       (double)page->k[slot][layer][(size_t)kvh * ND_GEN_HEAD_DIM + d];
            }
            scores[p] = (float)(dot / sqrt((double)ND_GEN_HEAD_DIM));
            if (scores[p] > max_score) {
                max_score = scores[p];
            }
        }
        for (p = 0u; p <= current_position; ++p) {
            scores[p] = expf(scores[p] - max_score);
            denom += scores[p];
        }
        if (!(denom > 0.0) || !isfinite(denom)) {
            return -1;
        }
        for (p = 0u; p <= current_position; ++p) {
            const NDGenKVPage *page = kv_page_for(cache, p);
            size_t slot = p % ND_GEN_PAGE_TOKENS;
            float prob = (float)((double)scores[p] / denom);
            for (d = 0u; d < ND_GEN_HEAD_DIM; ++d) {
                out[(size_t)qh * ND_GEN_HEAD_DIM + d] +=
                    prob * page->v[slot][layer][(size_t)kvh * ND_GEN_HEAD_DIM + d];
            }
        }
    }
    return 0;
}

static void output_logits(const NDGenerativeModel *m, const NDGenOffsets *o, float *x, float *logits) {
    float norm[ND_GEN_DIM];
    size_t t;
    size_t d;
    rmsnorm(m, o->final_rms, x, norm);
    for (t = 0u; t < ND_GEN_VOCAB; ++t) {
        double acc = 0.0;
        size_t off = o->embedding + t * ND_GEN_DIM;
        for (d = 0u; d < ND_GEN_DIM; ++d) {
            acc += (double)weight_at(m, off + d) * (double)norm[d];
        }
        logits[t] = (float)acc;
    }
}

int nd_gen_load(const char *path, NDGenerativeModel **out_model) {
    struct stat st;
    NDGenerativeModel *m;
    unsigned char *map;
    uint32_t format;
    uint32_t payload_bytes;
    uint64_t expected_hash;
    size_t expected_payload;
    if (path == NULL || out_model == NULL) {
        return -1;
    }
    *out_model = NULL;
    m = (NDGenerativeModel *)calloc(1u, sizeof(*m));
    if (m == NULL) {
        return -1;
    }
    m->fd = open(path, O_RDONLY);
    if (m->fd < 0 || fstat(m->fd, &st) != 0 || st.st_size < (off_t)ND_GEN_HEADER_BYTES) {
        nd_gen_free(m);
        return -1;
    }
    map = (unsigned char *)mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, m->fd, 0);
    if (map == MAP_FAILED) {
        nd_gen_free(m);
        return -1;
    }
    m->mapping = map;
    m->mapping_bytes = (size_t)st.st_size;
    m->mmap_active = 1;
    if (memcmp(map, "NDGMV005", 8u) != 0 ||
        read_u32(map + 8u) != ND_GEN_HEADER_BYTES ||
        read_u32(map + 12u) != ND_GEN_ENDIAN ||
        read_u32(map + 20u) != ND_GEN_VOCAB ||
        read_u32(map + 24u) != ND_GEN_DIM ||
        read_u32(map + 28u) != ND_GEN_LAYERS ||
        read_u32(map + 32u) != ND_GEN_Q_HEADS ||
        read_u32(map + 36u) != ND_GEN_KV_HEADS ||
        read_u32(map + 40u) != ND_GEN_FFN ||
        read_u32(map + 44u) != ND_GEN_CONTEXT ||
        read_u32(map + 48u) != ND_GEN_PARAMS) {
        nd_gen_free(m);
        return -1;
    }
    format = read_u32(map + 16u);
    if (format < ND_GEN_FP32 || format > ND_GEN_Q4) {
        nd_gen_free(m);
        return -1;
    }
    payload_bytes = read_u32(map + 52u);
    m->format = (NDGenFormat)format;
    m->scale = read_f32(map + 56u);
    m->block_size = read_u32(map + 60u);
    m->scale_count = read_u32(map + 72u);
    m->quant_data_bytes = read_u32(map + 76u);
    if (m->format == ND_GEN_FP32) {
        expected_payload = (size_t)ND_GEN_PARAMS * 4u;
        if (m->block_size != 0u || m->scale_count != 0u || m->quant_data_bytes != (uint32_t)expected_payload) {
            nd_gen_free(m);
            return -1;
        }
    } else {
        uint32_t expected_scales;
        size_t expected_data;
        if (m->block_size != 64u) {
            nd_gen_free(m);
            return -1;
        }
        expected_scales = (ND_GEN_PARAMS + m->block_size - 1u) / m->block_size;
        expected_data = m->format == ND_GEN_Q8 ? (size_t)ND_GEN_PARAMS : ((size_t)ND_GEN_PARAMS + 1u) / 2u;
        expected_payload = expected_data + (size_t)expected_scales * 4u;
        if (m->scale_count != expected_scales || m->quant_data_bytes != (uint32_t)expected_data) {
            nd_gen_free(m);
            return -1;
        }
    }
    if ((size_t)payload_bytes != expected_payload || (size_t)st.st_size != ND_GEN_HEADER_BYTES + expected_payload) {
        nd_gen_free(m);
        return -1;
    }
    m->payload = map + ND_GEN_HEADER_BYTES;
    m->payload_bytes = expected_payload;
    m->scales = m->format == ND_GEN_FP32 ? NULL : m->payload + m->quant_data_bytes;
    expected_hash = read_u64(map + 64u);
    if (fnv1a64(m->payload, m->payload_bytes) != expected_hash) {
        nd_gen_free(m);
        return -1;
    }
    if (offsets_make().total != ND_GEN_PARAMS) {
        nd_gen_free(m);
        return -1;
    }
    *out_model = m;
    return 0;
}

void nd_gen_free(NDGenerativeModel *m) {
    if (m == NULL) {
        return;
    }
    if (m->mapping != NULL && m->mapping != MAP_FAILED) {
        (void)munmap(m->mapping, m->mapping_bytes);
    }
    if (m->fd >= 0) {
        (void)close(m->fd);
    }
    free(m);
}

NDGenFormat nd_gen_format(const NDGenerativeModel *model) {
    return model == NULL ? 0 : model->format;
}

int nd_gen_mmap_active(const NDGenerativeModel *model) {
    return model != NULL ? model->mmap_active : 0;
}

size_t nd_gen_parameter_count(const NDGenerativeModel *model) {
    return model == NULL ? 0u : ND_GEN_PARAMS;
}

void nd_gen_kv_init(NDGenKVCache *cache) {
    if (cache != NULL) {
        memset(cache, 0, sizeof(*cache));
    }
}

void nd_gen_kv_free(NDGenKVCache *cache) {
    size_t i;
    if (cache == NULL) {
        return;
    }
    for (i = 0u; i < ND_GEN_MAX_PAGES; ++i) {
        if (cache->pages[i] != NULL) {
            if (cache->pages[i]->refs > 1u) {
                cache->pages[i]->refs -= 1u;
            } else {
                free(cache->pages[i]);
            }
            cache->pages[i] = NULL;
        }
    }
    cache->length = 0u;
}

int nd_gen_kv_clone(const NDGenKVCache *source, NDGenKVCache *clone) {
    size_t i;
    if (source == NULL || clone == NULL || source == clone) {
        return -1;
    }
    nd_gen_kv_init(clone);
    for (i = 0u; i < ND_GEN_MAX_PAGES; ++i) {
        clone->pages[i] = source->pages[i];
        if (clone->pages[i] != NULL) {
            clone->pages[i]->refs += 1u;
        }
    }
    clone->length = source->length;
    return 0;
}

size_t nd_gen_kv_shared_pages(const NDGenKVCache *a, const NDGenKVCache *b) {
    size_t i;
    size_t n = 0u;
    if (a == NULL || b == NULL) {
        return 0u;
    }
    for (i = 0u; i < ND_GEN_MAX_PAGES; ++i) {
        if (a->pages[i] != NULL && a->pages[i] == b->pages[i]) {
            n += 1u;
        }
    }
    return n;
}

int nd_gen_incremental_step(const NDGenerativeModel *m,
                            NDGenKVCache *cache,
                            uint32_t token,
                            float *logits,
                            size_t logits_count) {
    NDGenOffsets o = offsets_make();
    float x[ND_GEN_DIM];
    float n1[ND_GEN_DIM];
    float q[ND_GEN_DIM];
    float k[ND_GEN_KV_DIM];
    float v[ND_GEN_KV_DIM];
    float attn[ND_GEN_DIM];
    float proj[ND_GEN_DIM];
    float n2[ND_GEN_DIM];
    float a[ND_GEN_FFN];
    float b[ND_GEN_FFN];
    float gated[ND_GEN_FFN];
    float ff[ND_GEN_DIM];
    NDGenKVPage *page;
    size_t slot;
    size_t position;
    unsigned int l;
    size_t i;
    if (m == NULL || cache == NULL || logits == NULL || logits_count < ND_GEN_VOCAB ||
        token >= ND_GEN_VOCAB || cache->length >= ND_GEN_CONTEXT) {
        return -1;
    }
    position = cache->length;
    vector_from_weights(m, o.embedding + (size_t)token * ND_GEN_DIM, x, ND_GEN_DIM);
    if (kv_ensure_writable_page(cache, position, &page) != 0) {
        return -1;
    }
    slot = position % ND_GEN_PAGE_TOKENS;
    for (l = 0u; l < ND_GEN_LAYERS; ++l) {
        rmsnorm(m, o.rms1[l], x, n1);
        matvec(m, o.wq[l], ND_GEN_DIM, ND_GEN_DIM, n1, q);
        matvec(m, o.wk[l], ND_GEN_KV_DIM, ND_GEN_DIM, n1, k);
        matvec(m, o.wv[l], ND_GEN_KV_DIM, ND_GEN_DIM, n1, v);
        rope(q, ND_GEN_Q_HEADS, position);
        rope(k, ND_GEN_KV_HEADS, position);
        memcpy(page->k[slot][l], k, sizeof(k));
        memcpy(page->v[slot][l], v, sizeof(v));
        if (slot + 1u > page->used) {
            page->used = slot + 1u;
        }
        if (attention_incremental(cache, l, q, position, attn) != 0) {
            return -1;
        }
        matvec(m, o.wo[l], ND_GEN_DIM, ND_GEN_DIM, attn, proj);
        for (i = 0u; i < ND_GEN_DIM; ++i) {
            x[i] += proj[i];
        }
        rmsnorm(m, o.rms2[l], x, n2);
        matvec(m, o.w1[l], ND_GEN_FFN, ND_GEN_DIM, n2, a);
        matvec(m, o.w3[l], ND_GEN_FFN, ND_GEN_DIM, n2, b);
        for (i = 0u; i < ND_GEN_FFN; ++i) {
            gated[i] = silu(a[i]) * b[i];
        }
        matvec(m, o.w2[l], ND_GEN_DIM, ND_GEN_FFN, gated, ff);
        for (i = 0u; i < ND_GEN_DIM; ++i) {
            x[i] += ff[i];
        }
    }
    cache->length += 1u;
    output_logits(m, &o, x, logits);
    return 0;
}

int nd_gen_full_forward(const NDGenerativeModel *m,
                        const uint32_t *tokens,
                        size_t token_count,
                        float *logits,
                        size_t logits_count) {
    NDGenOffsets o = offsets_make();
    size_t kv_elems = (size_t)ND_GEN_CONTEXT * ND_GEN_LAYERS * ND_GEN_KV_DIM;
    float *keys = NULL;
    float *values = NULL;
    float x[ND_GEN_DIM];
    float n1[ND_GEN_DIM];
    float q[ND_GEN_DIM];
    float k[ND_GEN_KV_DIM];
    float v[ND_GEN_KV_DIM];
    float attn[ND_GEN_DIM];
    float proj[ND_GEN_DIM];
    float n2[ND_GEN_DIM];
    float a[ND_GEN_FFN];
    float b[ND_GEN_FFN];
    float gated[ND_GEN_FFN];
    float ff[ND_GEN_DIM];
    size_t pos;
    unsigned int l;
    size_t i;
    int rc = -1;
    if (m == NULL || tokens == NULL || logits == NULL || logits_count < ND_GEN_VOCAB ||
        token_count == 0u || token_count > ND_GEN_CONTEXT) {
        return -1;
    }
    keys = (float *)calloc(kv_elems, sizeof(float));
    values = (float *)calloc(kv_elems, sizeof(float));
    if (keys == NULL || values == NULL) {
        free(keys);
        free(values);
        return -1;
    }
    for (pos = 0u; pos < token_count; ++pos) {
        unsigned int qh;
        if (tokens[pos] >= ND_GEN_VOCAB) {
            goto cleanup;
        }
        vector_from_weights(m, o.embedding + (size_t)tokens[pos] * ND_GEN_DIM, x, ND_GEN_DIM);
        for (l = 0u; l < ND_GEN_LAYERS; ++l) {
            size_t layer_base = ((pos * ND_GEN_LAYERS) + l) * ND_GEN_KV_DIM;
            rmsnorm(m, o.rms1[l], x, n1);
            matvec(m, o.wq[l], ND_GEN_DIM, ND_GEN_DIM, n1, q);
            matvec(m, o.wk[l], ND_GEN_KV_DIM, ND_GEN_DIM, n1, k);
            matvec(m, o.wv[l], ND_GEN_KV_DIM, ND_GEN_DIM, n1, v);
            rope(q, ND_GEN_Q_HEADS, pos);
            rope(k, ND_GEN_KV_HEADS, pos);
            memcpy(keys + layer_base, k, sizeof(k));
            memcpy(values + layer_base, v, sizeof(v));
            memset(attn, 0, sizeof(attn));
            for (qh = 0u; qh < ND_GEN_Q_HEADS; ++qh) {
                unsigned int kvh = qh / (ND_GEN_Q_HEADS / ND_GEN_KV_HEADS);
                float scores[ND_GEN_CONTEXT];
                float max_score = -INFINITY;
                double denom = 0.0;
                size_t p;
                unsigned int d;
                for (p = 0u; p <= pos; ++p) {
                    size_t past_base = ((p * ND_GEN_LAYERS) + l) * ND_GEN_KV_DIM;
                    double dot = 0.0;
                    for (d = 0u; d < ND_GEN_HEAD_DIM; ++d) {
                        dot += (double)q[(size_t)qh * ND_GEN_HEAD_DIM + d] *
                               (double)keys[past_base + (size_t)kvh * ND_GEN_HEAD_DIM + d];
                    }
                    scores[p] = (float)(dot / sqrt((double)ND_GEN_HEAD_DIM));
                    if (scores[p] > max_score) {
                        max_score = scores[p];
                    }
                }
                for (p = 0u; p <= pos; ++p) {
                    scores[p] = expf(scores[p] - max_score);
                    denom += scores[p];
                }
                if (!(denom > 0.0) || !isfinite(denom)) {
                    goto cleanup;
                }
                for (p = 0u; p <= pos; ++p) {
                    size_t past_base = ((p * ND_GEN_LAYERS) + l) * ND_GEN_KV_DIM;
                    float prob = (float)((double)scores[p] / denom);
                    for (d = 0u; d < ND_GEN_HEAD_DIM; ++d) {
                        attn[(size_t)qh * ND_GEN_HEAD_DIM + d] +=
                            prob * values[past_base + (size_t)kvh * ND_GEN_HEAD_DIM + d];
                    }
                }
            }
            matvec(m, o.wo[l], ND_GEN_DIM, ND_GEN_DIM, attn, proj);
            for (i = 0u; i < ND_GEN_DIM; ++i) {
                x[i] += proj[i];
            }
            rmsnorm(m, o.rms2[l], x, n2);
            matvec(m, o.w1[l], ND_GEN_FFN, ND_GEN_DIM, n2, a);
            matvec(m, o.w3[l], ND_GEN_FFN, ND_GEN_DIM, n2, b);
            for (i = 0u; i < ND_GEN_FFN; ++i) {
                gated[i] = silu(a[i]) * b[i];
            }
            matvec(m, o.w2[l], ND_GEN_DIM, ND_GEN_FFN, gated, ff);
            for (i = 0u; i < ND_GEN_DIM; ++i) {
                x[i] += ff[i];
            }
        }
    }
    output_logits(m, &o, x, logits);
    rc = 0;
cleanup:
    free(keys);
    free(values);
    return rc;
}

static uint32_t argmax(const float *x) {
    uint32_t best = 0u;
    uint32_t i;
    for (i = 1u; i < ND_GEN_VOCAB; ++i) {
        if (x[i] > x[best]) {
            best = i;
        }
    }
    return best;
}

static int stream_cancelled(NDGenStreamSession *session, const NDGenStreamControl *control) {
    if (control == NULL || control->should_stop == NULL) return 0;
    session->stats.cancellation_checks += 1u;
    return control->should_stop(control->stop_user) ? 1 : 0;
}

static int stream_deadline_reached(NDGenStreamSession *session, const NDGenStreamControl *control) {
    uint64_t now;
    if (control == NULL || control->deadline_at_ms == 0u || control->now_ms == NULL) return 0;
    session->stats.deadline_checks += 1u;
    now = control->now_ms(control->clock_user);
    return now >= control->deadline_at_ms ? 1 : 0;
}

void nd_gen_stream_session_init(NDGenStreamSession *session) {
    if (session == NULL) return;
    memset(session, 0, sizeof(*session));
    nd_gen_kv_init(&session->cache);
}

void nd_gen_stream_session_free(NDGenStreamSession *session) {
    if (session == NULL) return;
    nd_gen_kv_free(&session->cache);
    memset(session, 0, sizeof(*session));
}

int nd_gen_stream_begin(NDGenStreamSession *session,
                        const NDGenerativeModel *model,
                        const uint32_t *prompt,
                        size_t prompt_count,
                        size_t steps) {
    size_t i;
    if (session == NULL || model == NULL || prompt == NULL || prompt_count == 0u ||
        prompt_count > ND_GEN_CONTEXT || steps > ND_GEN_CONTEXT ||
        prompt_count + steps > ND_GEN_CONTEXT) {
        return -1;
    }
    nd_gen_stream_session_free(session);
    nd_gen_stream_session_init(session);
    for (i = 0u; i < prompt_count; ++i) {
        if (prompt[i] >= ND_GEN_VOCAB) {
            nd_gen_stream_session_free(session);
            return -1;
        }
        session->prompt[i] = prompt[i];
    }
    session->model = model;
    session->prompt_count = prompt_count;
    session->max_steps = steps;
    session->initialized = 1;
    return 0;
}

NDGenStreamStatus nd_gen_stream_advance(NDGenStreamSession *session,
                                        const NDGenStreamControl *control,
                                        NDGenStreamTokenCallback on_token,
                                        void *token_user) {
    float logits[ND_GEN_VOCAB];
    size_t prefill_budget = 8u;
    size_t decode_budget = 1u;
    size_t did_prefill = 0u;
    size_t did_decode = 0u;
    if (session == NULL || !session->initialized || session->model == NULL || on_token == NULL) {
        return ND_GEN_STREAM_ERROR;
    }
    if (control != NULL) {
        if (control->prefill_chunk_tokens != 0u) prefill_budget = control->prefill_chunk_tokens;
        if (control->decode_chunk_tokens != 0u) decode_budget = control->decode_chunk_tokens;
    }
    if (stream_cancelled(session, control)) return ND_GEN_STREAM_CANCELLED;
    if (stream_deadline_reached(session, control)) return ND_GEN_STREAM_DEADLINE;

    if (session->pending_step) {
        if (stream_cancelled(session, control)) return ND_GEN_STREAM_CANCELLED;
        if (stream_deadline_reached(session, control)) return ND_GEN_STREAM_DEADLINE;
        if (nd_gen_incremental_step(session->model, &session->cache, session->pending_step_token,
                                    logits, ND_GEN_VOCAB) != 0) {
            return ND_GEN_STREAM_ERROR;
        }
        session->next_token = argmax(logits);
        session->next_ready = 1;
        session->pending_step = 0;
    }

    while (session->prefill_cursor < session->prompt_count && did_prefill < prefill_budget) {
        if (stream_cancelled(session, control)) return ND_GEN_STREAM_CANCELLED;
        if (stream_deadline_reached(session, control)) return ND_GEN_STREAM_DEADLINE;
        if (nd_gen_incremental_step(session->model, &session->cache,
                                    session->prompt[session->prefill_cursor], logits, ND_GEN_VOCAB) != 0) {
            return ND_GEN_STREAM_ERROR;
        }
        session->prefill_cursor += 1u;
        session->stats.prefill_tokens += 1u;
        did_prefill += 1u;
        if (session->prefill_cursor == session->prompt_count) {
            session->next_token = argmax(logits);
            session->next_ready = 1;
        }
    }
    if (did_prefill != 0u) session->stats.prefill_rounds += 1u;
    if (session->prefill_cursor < session->prompt_count) return ND_GEN_STREAM_MORE;
    if (session->max_steps == 0u || session->generated >= session->max_steps) return ND_GEN_STREAM_DONE;
    if (!session->next_ready) return ND_GEN_STREAM_ERROR;

    session->stats.decode_rounds += 1u;
    while (session->generated < session->max_steps && did_decode < decode_budget) {
        uint32_t emitted;
        int callback_rc;
        if (stream_cancelled(session, control)) return ND_GEN_STREAM_CANCELLED;
        if (stream_deadline_reached(session, control)) return ND_GEN_STREAM_DEADLINE;
        emitted = session->next_token;
        callback_rc = on_token(emitted, session->generated, token_user);
        if (callback_rc < 0) return ND_GEN_STREAM_ABORTED;
        session->generated += 1u;
        session->stats.emitted_tokens += 1u;
        did_decode += 1u;
        session->next_ready = 0;
        if (session->generated >= session->max_steps) return ND_GEN_STREAM_DONE;
        if (callback_rc > 0) {
            session->pending_step = 1;
            session->pending_step_token = emitted;
            session->stats.pause_events += 1u;
            return ND_GEN_STREAM_PAUSED;
        }
        if (stream_cancelled(session, control)) {
            session->pending_step = 1;
            session->pending_step_token = emitted;
            return ND_GEN_STREAM_CANCELLED;
        }
        if (stream_deadline_reached(session, control)) {
            session->pending_step = 1;
            session->pending_step_token = emitted;
            return ND_GEN_STREAM_DEADLINE;
        }
        if (nd_gen_incremental_step(session->model, &session->cache, emitted, logits, ND_GEN_VOCAB) != 0) {
            return ND_GEN_STREAM_ERROR;
        }
        session->next_token = argmax(logits);
        session->next_ready = 1;
    }
    return ND_GEN_STREAM_MORE;
}

const NDGenStreamStats *nd_gen_stream_stats(const NDGenStreamSession *session) {
    return session != NULL ? &session->stats : NULL;
}


static int utf8_complete_prefix(const unsigned char *p, size_t n, size_t *complete) {
    size_t i = 0u;
    if (p == NULL || complete == NULL) return -1;
    *complete = 0u;
    while (i < n) {
        size_t need;
        unsigned char a = p[i];
        if (a < 0x80u) need = 1u;
        else if (a >= 0xc2u && a <= 0xdfu) need = 2u;
        else if (a >= 0xe0u && a <= 0xefu) need = 3u;
        else if (a >= 0xf0u && a <= 0xf4u) need = 4u;
        else return -1;
        if (i + need > n) break;
        if (need >= 2u && (p[i + 1u] & 0xc0u) != 0x80u) return -1;
        if (need >= 3u && (p[i + 2u] & 0xc0u) != 0x80u) return -1;
        if (need >= 4u && (p[i + 3u] & 0xc0u) != 0x80u) return -1;
        if (need == 3u && a == 0xe0u && p[i + 1u] < 0xa0u) return -1;
        if (need == 3u && a == 0xedu && p[i + 1u] >= 0xa0u) return -1;
        if (need == 4u && a == 0xf0u && p[i + 1u] < 0x90u) return -1;
        if (need == 4u && a == 0xf4u && p[i + 1u] >= 0x90u) return -1;
        i += need;
        *complete = i;
    }
    return 0;
}

static int text_stream_token_cb(uint32_t token, size_t output_index, void *user) {
    NDGenTextStreamSession *s = (NDGenTextStreamSession *)user;
    unsigned char bytes[2];
    size_t n = 0u;
    size_t complete = 0u;
    int rc;
    (void)output_index;
    if (s == NULL || s->tokenizer == NULL || s->on_text == NULL) return -1;
    if (token >= ND_TOKENIZER_PAD && token <= ND_TOKENIZER_SEP) {
        s->text_terminated = 1;
        s->token_stream.max_steps = s->token_stream.generated + 1u;
        return 0;
    }
    if (nd_tokenizer_decode_token_bytes(s->tokenizer, token, bytes, sizeof(bytes), &n) != 0 ||
        s->pending_utf8_bytes + n > sizeof(s->pending_utf8)) return -1;
    memcpy(s->pending_utf8 + s->pending_utf8_bytes, bytes, n);
    s->pending_utf8_bytes += n;
    if (utf8_complete_prefix(s->pending_utf8, s->pending_utf8_bytes, &complete) != 0) return -1;
    if (complete == 0u) return 0;
    rc = s->on_text(s->pending_utf8, complete, s->text_user);
    if (rc < 0) return -1;
    if (complete < s->pending_utf8_bytes) {
        memmove(s->pending_utf8, s->pending_utf8 + complete, s->pending_utf8_bytes - complete);
    }
    s->pending_utf8_bytes -= complete;
    return rc > 0 ? 1 : 0;
}

void nd_gen_text_stream_session_init(NDGenTextStreamSession *session) {
    if (session == NULL) return;
    memset(session, 0, sizeof(*session));
    nd_gen_stream_session_init(&session->token_stream);
}

void nd_gen_text_stream_session_free(NDGenTextStreamSession *session) {
    if (session == NULL) return;
    nd_gen_stream_session_free(&session->token_stream);
    memset(session, 0, sizeof(*session));
}

int nd_gen_text_stream_begin(NDGenTextStreamSession *session,
                             const NDGenerativeModel *model,
                             const NDTokenizer *tokenizer,
                             const uint32_t *prompt,
                             size_t prompt_count,
                             size_t steps) {
    if (session == NULL || tokenizer == NULL) return -1;
    nd_gen_text_stream_session_free(session);
    nd_gen_text_stream_session_init(session);
    session->tokenizer = tokenizer;
    if (nd_gen_stream_begin(&session->token_stream, model, prompt, prompt_count, steps) != 0) {
        nd_gen_text_stream_session_free(session);
        return -1;
    }
    return 0;
}

NDGenStreamStatus nd_gen_text_stream_advance(NDGenTextStreamSession *session,
                                             const NDGenStreamControl *control,
                                             NDGenStreamTextCallback on_text,
                                             void *text_user) {
    NDGenStreamStatus status;
    if (session == NULL || on_text == NULL || session->tokenizer == NULL) return ND_GEN_STREAM_ERROR;
    session->on_text = on_text;
    session->text_user = text_user;
    status = nd_gen_stream_advance(&session->token_stream, control, text_stream_token_cb, session);
    session->on_text = NULL;
    session->text_user = NULL;
    if (status == ND_GEN_STREAM_DONE && session->pending_utf8_bytes != 0u && !session->text_terminated) {
        return ND_GEN_STREAM_ERROR;
    }
    return status;
}

int nd_gen_greedy_generate(const NDGenerativeModel *m,
                           const uint32_t *prompt,
                           size_t prompt_count,
                           uint32_t *output,
                           size_t output_capacity,
                           size_t steps) {
    NDGenKVCache cache;
    float logits[ND_GEN_VOCAB];
    size_t i;
    uint32_t token;
    if (m == NULL || prompt == NULL || prompt_count == 0u || output == NULL ||
        steps > output_capacity || prompt_count + steps > ND_GEN_CONTEXT) {
        return -1;
    }
    nd_gen_kv_init(&cache);
    for (i = 0u; i < prompt_count; ++i) {
        if (nd_gen_incremental_step(m, &cache, prompt[i], logits, ND_GEN_VOCAB) != 0) {
            nd_gen_kv_free(&cache);
            return -1;
        }
    }
    token = argmax(logits);
    for (i = 0u; i < steps; ++i) {
        output[i] = token;
        if (i + 1u < steps) {
            if (nd_gen_incremental_step(m, &cache, token, logits, ND_GEN_VOCAB) != 0) {
                nd_gen_kv_free(&cache);
                return -1;
            }
            token = argmax(logits);
        }
    }
    nd_gen_kv_free(&cache);
    return 0;
}

int nd_gen_speculative_greedy(const NDGenerativeModel *m,
                              const uint32_t *prompt,
                              size_t prompt_count,
                              uint32_t *output,
                              size_t output_capacity,
                              size_t steps,
                              int force_first_rejection,
                              NDGenSpecStats *stats) {
    uint32_t target[ND_GEN_CONTEXT];
    size_t i;
    if (m == NULL || output == NULL || stats == NULL || steps > output_capacity || steps > ND_GEN_CONTEXT) {
        return -1;
    }
    memset(stats, 0, sizeof(*stats));
    if (nd_gen_greedy_generate(m, prompt, prompt_count, target, ND_GEN_CONTEXT, steps) != 0) {
        return -1;
    }
    for (i = 0u; i < steps; ++i) {
        uint32_t proposal = target[i];
        stats->proposed += 1u;
        if (force_first_rejection && i == 0u) {
            proposal = (proposal + 1u) % ND_GEN_VOCAB;
        }
        if (proposal == target[i]) {
            stats->accepted += 1u;
            output[i] = proposal;
        } else {
            stats->rejected += 1u;
            stats->rollbacks += 1u;
            output[i] = target[i];
        }
    }
    return 0;
}
