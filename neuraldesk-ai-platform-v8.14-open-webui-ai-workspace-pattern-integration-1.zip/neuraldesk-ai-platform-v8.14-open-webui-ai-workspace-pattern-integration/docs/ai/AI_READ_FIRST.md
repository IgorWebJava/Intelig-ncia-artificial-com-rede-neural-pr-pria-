<!-- neuraldesk-documentation-sync: V8.12 -->
# AI Read First — NeuralDesk V8.11

Before changing this project, read in order:

1. `memória/ESTADO_ATUAL.json`
2. `docs/CURRENT_STATE.md`
3. `docs/SOURCE_OF_TRUTH.md`
4. `docs/architecture/CURRENT_ARCHITECTURE.md`
5. `docs/architecture/CURRENT_NEURAL_ENGINE_BLUEPRINT.md`
6. `docs/architecture/CURRENT_INTERFACE_ENGINE_TRACEABILITY.md`
7. `habilidades/AI_HANDOFF.md`
8. relevant interface module `module.manifest.json` + `docs/CURRENT_STATE.md`
9. relevant Neural Engine `module.blueprint.json` + `CURRENT_STATE.md`
10. tests/previews/registries affected by the change.

## Critical boundary

The interface is implemented at V8.11 as a cooperative additive evolution. The Neural Engine is documentation-only. Do not claim or implement engine behavior unless the user explicitly requests a future implementation phase.

## Change protocol

Every mechanic/capability change must synchronize: implementation or blueprint → contracts/registry → module docs → global docs → memory → skills → tests/validators → inventory → new complete ZIP.

## V8.7 frontier readiness

Before planning executable Neural Engine work, read:
- `../frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
- `../frontier-readiness/EXECUTION_ROADMAP.md`
- `../../neural-engine/registry/frontier-readiness.json`

Treat `D0`, `UI0`, parity targets and differentiation targets as documentation states, never as implemented capabilities.


## V8.8 Kimi K3 research
Before implementing model architecture, artifact loading or memory-aware serving, also read `../../neural-engine/research/kimi-k3-2026/README.md` and the linked adoption/benchmark documents. Research patterns do not override NeuralDesk contracts.

## V8.10 Qwen3-Omni research
Before implementing multimodal/realtime/speech model behavior, read `../../neural-engine/research/qwen3-omni-2026/README.md` and the owning module blueprints. Do not treat external Qwen latency/quality as a NeuralDesk result.


## V8.10 agent-harness research
Before implementing project/session/agent/tool runtime behavior, read `neural-engine/research/deepseek-harness-2026/README.md`, the 12 modules under `neural-engine/modules/11-agent-harness-runtime/`, and the semantic durability/session evolution strategies. Preserve the documentation-only boundary until an executable-engine release is explicitly authorized.


## Engine ↔ UI Bridge V8.11
Before changing interface or engine docs, inspect `platform/engine-ui-bridge/registry.json` and run both non-regression/compatibility gates. Do not mark engine states executable while `neural_engine_code_status` is `NOT_IMPLEMENTED`.


## V8.11 cooperative evolution

Preserve V8.10 semantics, extend additively, bridge every future engine module to a UI owner, keep root aliases as redirects, and never claim Engine Bridge simulation is executable Neural Engine behavior.
