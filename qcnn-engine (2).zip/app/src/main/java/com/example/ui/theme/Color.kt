package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val QuantumCyan = Color(0xFF00FFCC)
val QuantumPink = Color(0xFFFF0055)
val QuantumGold = Color(0xFFFFD700)
val QuantumBgDark = Color(0xFF0A0B10)
val QuantumPanelDark = Color(0xFF121420)
val QuantumTextLight = Color(0xFFE2E8F0)
val QuantumMuted = Color(0xFF64748B)
