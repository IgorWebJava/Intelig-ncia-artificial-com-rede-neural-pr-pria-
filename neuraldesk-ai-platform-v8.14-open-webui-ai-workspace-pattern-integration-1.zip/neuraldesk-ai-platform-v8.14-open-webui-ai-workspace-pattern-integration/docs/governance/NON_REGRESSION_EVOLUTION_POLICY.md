<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.governance -->
# Non-Regression Evolution Policy

NeuralDesk evolves by **preserve → extend → bridge**.

A release fails if it removes a baseline route, tab, action, contract key or provided capability without an explicit compatibility adapter and approved migration record. Visual modernization may rearrange surfaces, but semantic capability cannot silently disappear.

Engine evolution must likewise preserve supported session/event/schema readers under the declared compatibility policy or fail loud.
