<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Success Metrics and Scorecard

## Product outcome
- task completion rate;
- artifact acceptance rate;
- time-to-useful-result;
- resume success after project pause;
- user correction/rework rate.

## Intelligence
- benchmark quality;
- reasoning/task accuracy;
- hallucination/unsupported claim rate;
- structured-output validity;
- tool selection success.

## Knowledge/research
- retrieval recall/precision;
- citation correctness;
- freshness;
- source quality;
- research coverage.

## Agents
- task completion;
- tool error rate;
- unnecessary delegation rate;
- plan churn;
- cost vs direct-model baseline.

## Performance
- TTFT;
- p50/p95/p99 latency;
- inter-token latency;
- throughput;
- concurrency;
- memory utilization.

## Reliability
- availability;
- job recovery rate;
- checkpoint restore rate;
- provider failover success;
- error budget.

## Safety/security
- policy violation rate;
- approval bypass rate;
- prompt/tool injection success rate in red-team;
- data leakage incidents.

## Economics
- cost per successful task;
- cost per artifact;
- token/tool/provider spend;
- infrastructure utilization.

## Promotion rule
A candidate may improve one dimension only if protected dimensions stay above defined floors.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
