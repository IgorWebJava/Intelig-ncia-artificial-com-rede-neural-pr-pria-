# Project Structure — v0.7.4-alpha.2

## Owners móveis v0.7.3

Não há nova árvore de runtime paralela. O delta altera os owners existentes `nd_assistant`, `nd_resource`, `nd_rag`, JNI/Kotlin/asset store e adiciona somente o gate `nd_execution_control_test`. A documentação específica é `MOBILE_RUNTIME_HARDENING_V073.md`.


```text
memória/
  LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md
core/include, core/src
  runtime C99 + NDOS loader/search
cli/
  ndassistant host
models/
  4 assets v0.5 + 1 NDOS v0.6
training/
  trainers neurais herdados + NDOS builder + dados de reconstrução
tests/
  gates herdados + parity/provenance/reproduction NDOS
evaluation/
  relatórios + holdouts
android/
  Kotlin + JNI do mesmo núcleo + RuntimeIdentity + CanonicalAssetStore
scripts/
  precheck/build/clean/verify/sanitize/package
docs/
  documentação canônica + COMPREHENSIVE_AUDIT.md
verification/
  evidências finais
```

A release não pode conter `.ndsh`, assets v0.4, build/caches/checkpoints, scripts rejeitados ou duplicação de assets Android.

## Gate v0.6.1

`tests/nd_conversational_correctness_test.c` é o holdout comportamental pós-implementação permanente. `tests/nd_calculator_test.c` e `tests/nd_planner_test.c` também foram ampliados; `scripts/verify.sh` e `scripts/verify_sanitize.sh` executam o novo gate.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


## v0.7.2 core owners

`core/{include,src}/nd_network_policy.*`, `nd_pilot.*`, `nd_outbox.*`, `nd_project.*`, `nd_model_acquisition.*` e `nd_benchmark.*` são owners C99 first-party. `training/weight_averaging.py` é tooling de training candidate-only.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

