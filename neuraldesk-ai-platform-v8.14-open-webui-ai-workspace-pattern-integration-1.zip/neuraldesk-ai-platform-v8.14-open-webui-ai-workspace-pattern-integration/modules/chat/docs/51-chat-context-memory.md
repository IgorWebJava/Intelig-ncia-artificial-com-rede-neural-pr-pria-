<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 51 — Context, Memory e Sources

## Context Sources

```text
Conversation
Project Memory
Files
Knowledge
Web
Tools
```

## Context Inspector

A UI prevê:

- quantidade de mensagens;
- arquivos;
- chunks;
- web sources;
- tool results;
- consumo de contexto;
- fontes mais relevantes.

## Segurança

O contexto não deve contornar permissões.

Retrieval, files, project memory e tools devem respeitar:

- tenant;
- project;
- user;
- roles;
- document permissions;
- tool scopes.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
