package com.neuraldesk.localnet

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/**
 * Installs a canonical asset without materializing the whole model in the JVM heap.
 * The packaged stream is hashed while it is copied to a staging file; an existing
 * runtime copy is reused only when its SHA-256 is identical.
 */
object CanonicalAssetStore {
    private const val BUFFER_BYTES = 64 * 1024

    private fun digestFile(file: File): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_BYTES)
        FileInputStream(file).use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read > 0) digest.update(buffer, 0, read)
            }
        }
        return digest.digest()
    }

    @Synchronized
    fun install(target: File, packaged: InputStream): File {
        val parent = target.parentFile ?: error("asset sem diretório pai")
        require(parent.isDirectory || parent.mkdirs()) { "não foi possível criar diretório de assets" }
        val temporary = File(parent, ".${target.name}.installing")
        if (temporary.exists()) require(temporary.delete()) { "não foi possível limpar staging antigo" }

        val packagedDigest = MessageDigest.getInstance("SHA-256")
        var bytes = 0L
        val buffer = ByteArray(BUFFER_BYTES)
        try {
            FileOutputStream(temporary).use { output ->
                while (true) {
                    val read = packaged.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    output.write(buffer, 0, read)
                    packagedDigest.update(buffer, 0, read)
                    bytes += read.toLong()
                }
                output.fd.sync()
            }
            require(bytes > 0L) { "asset canônico vazio" }
            val expected = packagedDigest.digest()
            require(digestFile(temporary).contentEquals(expected)) { "staging divergiu do asset empacotado" }

            if (target.isFile && target.length() == bytes && digestFile(target).contentEquals(expected)) {
                require(temporary.delete()) { "não foi possível limpar staging idêntico" }
                return target
            }

            Files.move(
                temporary.toPath(),
                target.toPath(),
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE
            )
            require(target.isFile && target.length() == bytes && digestFile(target).contentEquals(expected)) {
                "asset instalado divergiu do asset empacotado"
            }
            return target
        } finally {
            if (temporary.exists()) temporary.delete()
        }
    }
}
