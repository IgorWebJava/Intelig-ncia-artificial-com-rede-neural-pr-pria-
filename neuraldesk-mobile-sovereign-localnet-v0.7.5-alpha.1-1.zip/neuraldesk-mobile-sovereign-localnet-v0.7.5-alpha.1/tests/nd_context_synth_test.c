#include "nd_context_qa.h"
#include "nd_context_synth.h"
#include "nd_relation.h"
#include <stdio.h>
#include <string.h>

int main(int argc,char **argv){
    if(argc!=5){fprintf(stderr,"usage: %s QA RELATION QUESTION CONTEXT\n",argv[0]);return 2;}
    char e[256],out[16384];NDContextQA qa;NDRelationClassifier rel;NDContextSynthesisResult r;
    memset(&rel,0,sizeof(rel));
    if(nd_context_qa_load(argv[1],&qa,e,sizeof(e))){fprintf(stderr,"qa: %s\n",e);return 1;}
    if(nd_relation_load(argv[2],&rel,e,sizeof(e))){fprintf(stderr,"relation: %s\n",e);nd_context_qa_free(&qa);return 1;}
    int rc=nd_context_synthesize_ex(&qa,&rel,argv[3],argv[4],1,out,sizeof(out),&r,e,sizeof(e));
    nd_relation_free(&rel);nd_context_qa_free(&qa);
    if(rc){fprintf(stderr,"synth: %s\n",e);return 1;}
    printf("found=%d pointer=%d proposed=%d rejected=%d relation=%u evidence=%zu score=%.3f\n%s\n",
           r.found,r.used_pointer,r.pointer_proposed,r.pointer_rejected,r.relation_id,r.evidence_count,r.best_score,out);
    return 0;
}
