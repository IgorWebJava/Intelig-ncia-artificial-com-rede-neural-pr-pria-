# v0.7.5 — Streaming, Hardware Routing, Governance & Training Mechanics

Status: **IMPLEMENTED MECHANICS / NOT_PROMOTED**.

## Streaming

The same `nd_generative` owner now exposes stateful computational streaming. The prefill cursor and paged KV cache persist between `advance()` calls. `prefill_chunk_tokens` and `decode_chunk_tokens` bound cooperative work. Optional `should_stop` and monotonic deadline callbacks are checked in both phases. A token callback may return pause/backpressure without changing the canonical token sequence.

`NDGenTextStreamSession` adds the byte-tokenizer adapter required by the mobile contract: incomplete multibyte UTF-8 bytes are buffered until a valid code point/prefix can be emitted. Special tokenizer control tokens terminate text output rather than being decoded as user-visible bytes.

## Hardware routing

`nd_resource` remains the sole resource owner and now adds ABI/provider routing. Supported executable provider in this release is only `CPU_C99`. GPU/NPU requests fail closed unless a future real executor is wired. `AUTO` never silently switches to an unavailable accelerator. Physical certification remains an independent boolean gate and is false in this environment.

## Governance

Current governance artifacts:
- `training/data/governance_v075/CURRENT_CORPUS_GOVERNANCE.json`;
- `training/data/governance_v075/SOURCE_CATALOG.csv`.

The v0.63 historical Golden hash is preserved for lineage but its bytes are not available, so it is not imported. Current validation/holdouts remain evaluation-only.

## Data-scale gradient accumulation

`training/pretrain_generative_micro_v074_v3_data_scale_v2.py` uses token-cache-bound microbatches and now supports accumulation as part of its config identity. Default v0.7.5 mechanic: 8-tokenized-example microbatch (`1 rich + 7 context`) accumulated 8 times, effective 64 examples/update (`8 rich + 56 context`). Loss is divided by the actual accumulation group size. Gradient clipping and AdamW occur once per group. Run budgets and checkpoint cadence must land on optimizer boundaries.

This mechanic does not promote the Micro v3 weights and does not resume old batch8 checkpoints because their config hash represents a different trajectory.
