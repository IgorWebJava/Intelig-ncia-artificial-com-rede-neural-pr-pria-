<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.architecture; current: docs/architecture/CURRENT_ARCHITECTURE.md -->
# Current Architecture — V8.14

```text
                    NeuralDesk Intelligence Workspace OS
                                 │
                       Experience / App Shell
                                 │
          ┌──────────────────────┼──────────────────────┐
          ▼                      ▼                      ▼
       Projects              Tasks/Runs           Search/Create
          │
   ┌──────┼────────┬──────────┬──────────┐
   ▼      ▼        ▼          ▼          ▼
 Chat   Agents  Knowledge    Tools     Training
   │      │        │          │          │
   └──────┴────────┴──────┬───┴──────────┘
                          ▼
                 AI Capability Fabric
                          │
                    Provider Adapters

Control Plane: Operations · Audit · System Config
User Plane: Settings

──────────────── COOPERATIVE ENGINE BRIDGE ────────────────
                          │
                  cooperative-engine-bridge-v1
                          │
                          ▼
                    Neural Engine Blueprint
             94 documentation-only modules
                    391 capabilities
                          │
  Foundation · Cognition · Agents/Tools · Knowledge/MM
  Execution · Quality/Ops · Platform · Model Research
  Training · Inference · Post-training/Eval · Harness Runtime
```

## Current implementation boundary

The V8.11 interface is an additive evolution of the V8.2 Intelligence Experience. Canonical module HTML/CSS and module-owned JavaScript implement local UI behavior, Engine Bridge surfaces, responsive states, tests and previews. The Neural Engine itself remains **NOT IMPLEMENTED**: there is no production model inference, durable backend session runtime, real agent/tool execution, model training/serving or distributed engine behavior in this package.

## Current counts

- Canonical UI modules: **10**
- Resolved current platform/UI capabilities: **106**
- Future Neural Engine modules: **94**
- Future Neural Engine capabilities: **391**
- Interface mechanics traced to future engine owners: **149**
- Engine modules mapped to UI owners: **94/94**

## Non-regression architecture law

`preserve → extend → bridge`

1. **Preserve** V8.10 routes, aliases, tabs, actions, contracts and capability semantics.
2. **Extend** only through additive/versioned capabilities or explicit migrations.
3. **Bridge** every future engine module to an owning UI surface or an explicit headless/admin representation.
4. A root HTML alias remains a compatibility redirect; canonical implementation lives under `modules/<module>/ui/`.
5. Unsupported future capabilities must fail visibly; they must not silently degrade into a different behavior.

## Stable profiles

- Experience: `intelligence-experience-v2`
- Workspace runtime: `workspace-runtime-v2`
- Design System: `neuraldesk-intelligence-design-v2`
- Engine/UI bridge: `cooperative-engine-bridge-v1`
- Testing: `module-quality-v2`

## Engine/UI bridge

`platform/engine-ui-bridge/registry.json` is the machine-readable ownership map. `contracts/ui/engine-ui-bridge.schema.json` defines the bridge contract. The bridge is a truth-preserving interface contract: `UI_CONTRACT_READY` does not imply `ENGINE_IMPLEMENTED`.

## AI Workspace V8.14
`open-webui-ai-workspace-patterns-v1` is an additive workspace layer over the existing Engine Bridge, Agent Platform and Coding Intelligence profiles.
