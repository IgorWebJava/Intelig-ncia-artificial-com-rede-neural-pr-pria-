#include "nd_planner.h"

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static void seterr(char *e, size_t n, const char *fmt, ...) {
    if (!e || !n) return;
    va_list a;
    va_start(a, fmt);
    vsnprintf(e, n, fmt, a);
    va_end(a);
}

static unsigned char lo(unsigned char c) {
    return (c >= (unsigned char)'A' && c <= (unsigned char)'Z')
               ? (unsigned char)(c + ('a' - 'A'))
               : c;
}

static const char *find_ci(const char *s, const char *needle) {
    size_t n = strlen(s), m = strlen(needle);
    if (!m || m > n) return NULL;
    for (size_t i = 0; i + m <= n; i++) {
        size_t j = 0;
        for (; j < m; j++) {
            if (lo((unsigned char)s[i + j]) != lo((unsigned char)needle[j])) break;
        }
        if (j == m) return s + i;
    }
    return NULL;
}

static void trim_copy(char *dst, size_t cap, const char *begin, const char *end) {
    while (begin < end && isspace((unsigned char)*begin)) begin++;
    while (end > begin && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - begin);
    if (n >= cap) n = cap - 1u;
    memcpy(dst, begin, n);
    dst[n] = 0;
}

static int token_has_entity_shape(const char *s, size_t n) {
    int upper = 0, alpha = 0, digit = 0;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') {
            upper = 1;
            alpha = 1;
        } else if ((c >= 'a' && c <= 'z') || c >= 128u) {
            alpha = 1;
        } else if (c >= '0' && c <= '9') {
            digit = 1;
        }
    }
    return alpha && (upper || digit);
}

static int common_capitalized(const char *s, size_t n) {
    static const char *v[] = {
        "Qual", "Quais", "Quem", "Quanto", "Quantos", "Quantas", "Onde", "Quando",
        "Como", "Explique", "Informe", "Diga", "Responda", "Com", "Nas", "Nos", "No", "Na", "Se"
    };
    for (size_t i = 0; i < sizeof(v) / sizeof(v[0]); i++) {
        if (strlen(v[i]) == n && memcmp(v[i], s, n) == 0) return 1;
    }
    return 0;
}

static int find_anchor(const char *goal, char *anchor, size_t cap) {
    const char *candidate = NULL;
    size_t n = strlen(goal), i = 0;
    while (i < n) {
        while (i < n && !(isalnum((unsigned char)goal[i]) || (unsigned char)goal[i] >= 128u)) i++;
        size_t j = i;
        while (j < n && (isalnum((unsigned char)goal[j]) || goal[j] == '-' || goal[j] == '_' ||
                         (unsigned char)goal[j] >= 128u)) j++;
        if (j > i && token_has_entity_shape(goal + i, j - i) &&
            !common_capitalized(goal + i, j - i)) {
            candidate = goal + i;
        }
        i = j > i ? j : i + 1u;
    }
    if (!candidate) return 0;
    const char *end = goal + n;
    while (end > candidate &&
           (isspace((unsigned char)end[-1]) || end[-1] == '?' || end[-1] == '!' ||
            end[-1] == '.' || end[-1] == ',' || end[-1] == ';')) {
        end--;
    }
    size_t z = (size_t)(end - candidate);
    if (!z || z >= cap) return 0;
    memcpy(anchor, candidate, z);
    anchor[z] = 0;
    return 1;
}

static int starts_ci(const char *s, const char *prefix) {
    while (*prefix) {
        if (!*s || lo((unsigned char)*s) != lo((unsigned char)*prefix)) return 0;
        s++;
        prefix++;
    }
    return 1;
}

static int goal_needs_anchor(const char *goal) {
    const char *p = goal;
    while (*p && isspace((unsigned char)*p)) p++;
    return starts_ci(p, "quem ") || starts_ci(p, "qual ") || starts_ci(p, "quais ") ||
           starts_ci(p, "onde ") || starts_ci(p, "quando ") || starts_ci(p, "como ") ||
           starts_ci(p, "o que ") || starts_ci(p, "por que ") ||
           find_ci(p, ", qual ") || find_ci(p, ", quais ") || find_ci(p, ", quem ");
}

static int segment_has_interrogative_intent(const char *begin, const char *end) {
    char tmp[ND_PLAN_GOAL_BYTES];
    trim_copy(tmp, sizeof(tmp), begin, end);
    static const char *cues[] = {
        "qual ", "quais ", "quem ", "quanto ", "quantos ", "quantas ",
        "onde ", "quando ", "como ", "por que ", "o que ", "explique ",
        "informe ", "diga ", "responda "
    };
    for (size_t i = 0; i < sizeof(cues) / sizeof(cues[0]); i++) {
        if (find_ci(tmp, cues[i])) return 1;
    }
    return strchr(tmp, '?') != NULL;
}

static int planner_topic_stop(const char *s, size_t n) {
    static const char *v[] = {
        "qual", "quais", "quem", "onde", "quando", "como", "porque", "por", "que",
        "isso", "essa", "esse", "sobre", "pode", "podem", "ser", "seja", "útil", "util",
        "uma", "um", "para", "com", "sem", "do", "da", "dos", "das", "de", "em", "no", "na"
    };
    for (size_t i = 0; i < sizeof(v) / sizeof(v[0]); i++) {
        if (strlen(v[i]) == n) {
            size_t j = 0u;
            for (; j < n; j++) if (lo((unsigned char)s[j]) != lo((unsigned char)v[i][j])) break;
            if (j == n) return 1;
        }
    }
    return 0;
}

static int goal_has_own_topic(const char *goal) {
    static const char *cues[] = {
        "qual ", "quais ", "quem ", "onde ", "quando ", "como ", "por que ", "o que "
    };
    const char *core = goal;
    const char *best = NULL;
    for (size_t c = 0; c < sizeof(cues) / sizeof(cues[0]); c++) {
        const char *hit = find_ci(goal, cues[c]);
        if (hit && (!best || hit < best)) best = hit;
    }
    if (best) core = best;
    size_t n = strlen(core), i = 0u, meaningful = 0u;
    while (i < n) {
        while (i < n && !(isalnum((unsigned char)core[i]) || (unsigned char)core[i] >= 128u)) i++;
        size_t j = i;
        while (j < n && (isalnum((unsigned char)core[j]) || (unsigned char)core[j] >= 128u)) j++;
        if (j > i && j - i >= 3u && !planner_topic_stop(core + i, j - i)) {
            meaningful++;
            if (meaningful >= 3u) return 1;
        }
        i = j > i ? j : i + 1u;
    }
    return 0;
}

static int goal_has_entity(const char *goal) {
    size_t n = strlen(goal), i = 0;
    while (i < n) {
        while (i < n && !(isalnum((unsigned char)goal[i]) || (unsigned char)goal[i] >= 128u)) i++;
        size_t j = i;
        while (j < n && (isalnum((unsigned char)goal[j]) || goal[j] == '-' || goal[j] == '_' ||
                         (unsigned char)goal[j] >= 128u)) j++;
        if (j > i && token_has_entity_shape(goal + i, j - i) &&
            !common_capitalized(goal + i, j - i)) return 1;
        i = j > i ? j : i + 1u;
    }
    return 0;
}

static int inherit_anchor(NDPlan *plan, char *err, size_t errcap) {
    if (plan->goal_count < 2u) return 0;
    char anchor[384];
    anchor[0] = 0;
    for (size_t i = 0; i < plan->goal_count; i++) {
        if (find_anchor(plan->goals[i].text, anchor, sizeof(anchor))) break;
    }
    if (!anchor[0]) return 0;

    for (size_t i = 0; i < plan->goal_count; i++) {
        if (!goal_needs_anchor(plan->goals[i].text) || goal_has_entity(plan->goals[i].text) ||
            goal_has_own_topic(plan->goals[i].text)) continue;
        char original[ND_PLAN_GOAL_BYTES];
        memcpy(original, plan->goals[i].text, sizeof(original));
        original[sizeof(original) - 1u] = 0;
        size_t n = strlen(original);
        int punct = n > 0u && (original[n - 1u] == '?' || original[n - 1u] == '!' || original[n - 1u] == '.');
        char pc = punct ? original[n - 1u] : 0;
        if (punct) original[n - 1u] = 0;
        int w = snprintf(plan->goals[i].text, sizeof(plan->goals[i].text), "%s sobre %s%c",
                         original, anchor, pc ? pc : ' ');
        if (w < 0 || (size_t)w >= sizeof(plan->goals[i].text)) {
            seterr(err, errcap, "planner inherited goal exceeds bounds");
            return -1;
        }
        if (!pc) {
            size_t z = strlen(plan->goals[i].text);
            while (z && isspace((unsigned char)plan->goals[i].text[z - 1u])) {
                plan->goals[i].text[--z] = 0;
            }
        }
    }
    return 0;
}

static const char *last_find_ci_before(const char *begin, const char *end, const char *needle) {
    const char *last = NULL;
    const char *p = begin;
    while (p < end) {
        const char *hit = find_ci(p, needle);
        if (!hit || hit >= end) break;
        last = hit;
        p = hit + 1;
    }
    return last;
}

static void strip_topic_lead(char *topic) {
    static const char *triggers[] = {" usar ", " comparar ", " aplicar ", " combinar ", " entre "};
    const char *best = NULL;
    size_t best_len = 0u;
    for (size_t i = 0; i < sizeof(triggers) / sizeof(triggers[0]); i++) {
        const char *p = find_ci(topic, triggers[i]);
        while (p) {
            best = p;
            best_len = strlen(triggers[i]);
            p = find_ci(p + 1, triggers[i]);
        }
    }
    if (best) {
        const char *start = best + best_len;
        memmove(topic, start, strlen(start) + 1u);
    }
    size_t n = strlen(topic);
    size_t lead = 0u;
    while (lead < n && isspace((unsigned char)topic[lead])) lead++;
    if (lead) memmove(topic, topic + lead, n - lead + 1u);
}

static void strip_topic_tail(char *topic) {
    static const char *tails[] = {" na inferência", " na inferencia", " no sistema", " no modelo", " em inferência", " em inferencia"};
    const char *best = NULL;
    for (size_t i = 0; i < sizeof(tails) / sizeof(tails[0]); i++) {
        const char *p = find_ci(topic, tails[i]);
        if (p && (!best || p < best)) best = p;
    }
    if (best) topic[(size_t)(best - topic)] = 0;
    size_t n = strlen(topic);
    while (n && isspace((unsigned char)topic[n - 1u])) topic[--n] = 0;
}

static int build_distributed_goal(char *dst, size_t cap, const char *tail,
                                  const char *reference, const char *topic) {
    const char *hit = find_ci(tail, reference);
    if (!hit) return -1;
    size_t pre = (size_t)(hit - tail);
    size_t refn = strlen(reference);
    size_t tn = strlen(topic);
    size_t post = strlen(hit + refn);
    if (pre + tn + post + 1u > cap) return -1;
    memcpy(dst, tail, pre);
    memcpy(dst + pre, topic, tn);
    memcpy(dst + pre + tn, hit + refn, post + 1u);
    return 0;
}

static int try_expand_distributive_pair(const char *question, NDPlan *plan,
                                        char *err, size_t errcap) {
    const char *comma = strchr(question, ',');
    if (!comma || comma == question) return 0;
    const char *tail = comma + 1;
    while (*tail && isspace((unsigned char)*tail)) tail++;

    static const char *refs[] = {
        "cada técnica", "cada tecnica", "cada abordagem", "cada método", "cada metodo",
        "cada um", "cada uma"
    };
    const char *reference = NULL;
    for (size_t i = 0; i < sizeof(refs) / sizeof(refs[0]); i++) {
        if (find_ci(tail, refs[i])) {
            reference = refs[i];
            break;
        }
    }
    if (!reference) return 0;

    const char *sep = last_find_ci_before(question, comma, " e ");
    if (!sep) return 0;
    char left[256], right[256];
    trim_copy(left, sizeof(left), question, sep);
    trim_copy(right, sizeof(right), sep + 3, comma);
    strip_topic_lead(left);
    strip_topic_tail(left);
    strip_topic_tail(right);
    if (!left[0] || !right[0] || strlen(left) > 160u || strlen(right) > 160u) return 0;

    memset(plan, 0, sizeof(*plan));
    if (build_distributed_goal(plan->goals[0].text, sizeof(plan->goals[0].text),
                               tail, reference, left) ||
        build_distributed_goal(plan->goals[1].text, sizeof(plan->goals[1].text),
                               tail, reference, right)) {
        seterr(err, errcap, "planner distributed goal exceeds bounds");
        return -1;
    }
    plan->goal_count = 2u;
    return 1;
}

static int generic_article_split_allowed(const char *connector, const char *right) {
    static const char *generic[] = {" e o ", " e a ", " e os ", " e as "};
    static const char *attributes[] = {
        "responsável", "responsavel", "coordenador", "coordenadora", "código", "codigo",
        "versão", "versao", "data", "cor", "material", "fabricante", "protocolo", "porta",
        "checksum", "bateria", "capital", "idioma", "massa", "sensor", "identificador",
        "status", "líder", "lider", "nome", "valor", "tamanho", "quantidade"
    };
    int is_generic = 0;
    for (size_t i = 0; i < sizeof(generic) / sizeof(generic[0]); i++) {
        if (strcmp(connector, generic[i]) == 0) {
            is_generic = 1;
            break;
        }
    }
    if (!is_generic) return 1;
    while (*right && isspace((unsigned char)*right)) right++;
    if (starts_ci(right, "o ")) right += 2;
    else if (starts_ci(right, "a ")) right += 2;
    else if (starts_ci(right, "os ")) right += 3;
    else if (starts_ci(right, "as ")) right += 3;
    while (*right && isspace((unsigned char)*right)) right++;
    for (size_t i = 0; i < sizeof(attributes) / sizeof(attributes[0]); i++) {
        if (starts_ci(right, attributes[i])) return 1;
    }
    return 0;
}

int nd_plan_build(const char *question, NDPlan *plan, char *err, size_t errcap) {
    static const char *connectors[] = {
        ", qual ", ", quais ", ", quem ", ", quanto ", ", quantos ", ", quantas ",
        ", onde ", ", quando ", ", como ", ", por que ", ", o que ",
        " e qual ", " e quais ", " e quem ", " e quanto ", " e quantos ", " e quantas ",
        " e onde ", " e quando ", " e como ", " e por que ", " e o que ",
        " e o ", " e a ", " e os ", " e as ", ";"
    };
    if (!question || !plan) {
        seterr(err, errcap, "invalid planner input");
        return -1;
    }
    size_t qn = strlen(question);
    if (!qn || qn > 4096u) {
        seterr(err, errcap, "planner question exceeds bounds");
        return -1;
    }

    int distributed = try_expand_distributive_pair(question, plan, err, errcap);
    if (distributed < 0) return -1;
    if (distributed > 0) return 0;

    memset(plan, 0, sizeof(*plan));
    const char *cursor = question;
    while (*cursor && plan->goal_count < ND_PLAN_MAX_GOALS) {
        const char *best = NULL;
        const char *conn = NULL;
        const char *first_comma = strchr(cursor, ',');
        for (size_t i = 0; i < sizeof(connectors) / sizeof(connectors[0]); i++) {
            const char *p = find_ci(cursor, connectors[i]);
            if (p && connectors[i][0] == ',' && p == first_comma &&
                !segment_has_interrogative_intent(cursor, p)) {
                p = find_ci(p + 1, connectors[i]);
            }
            if (p && !generic_article_split_allowed(connectors[i], p + 3)) {
                p = find_ci(p + 1, connectors[i]);
            }
            if (p && (!best || p < best)) {
                best = p;
                conn = connectors[i];
            }
        }
        if (!best) {
            NDPlanGoal *g = &plan->goals[plan->goal_count];
            trim_copy(g->text, sizeof(g->text), cursor, cursor + strlen(cursor));
            if (g->text[0]) plan->goal_count++;
            break;
        }
        NDPlanGoal *g = &plan->goals[plan->goal_count];
        trim_copy(g->text, sizeof(g->text), cursor, best);
        if (g->text[0]) plan->goal_count++;
        if (plan->goal_count >= ND_PLAN_MAX_GOALS) break;
        if (strcmp(conn, ";") == 0) {
            cursor = best + 1;
        } else if (conn[0] == ',') {
            cursor = best + 2;
        } else {
            cursor = best + 3;
        }
    }
    if (plan->goal_count == 0u) {
        seterr(err, errcap, "planner produced no goals");
        return -1;
    }
    if (inherit_anchor(plan, err, errcap)) return -1;
    return 0;
}
