<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 71 — System Audit, Trace & Control Center

## Objetivo

Criar uma caixa-preta operacional do NeuralDesk capaz de correlacionar:

- users;
- agents;
- services;
- pages;
- knowledge;
- tools/MCP;
- models;
- training;
- security;
- approvals;
- system changes;
- deployments;
- incidents;
- console queries;
- integrity;
- retention.

## Página

```text
audit-center.html
```

## CSS

```text
modules/audit/ui/audit-center.css
```

## Regra

A página é visual e independente.

O console é read-only por padrão.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
