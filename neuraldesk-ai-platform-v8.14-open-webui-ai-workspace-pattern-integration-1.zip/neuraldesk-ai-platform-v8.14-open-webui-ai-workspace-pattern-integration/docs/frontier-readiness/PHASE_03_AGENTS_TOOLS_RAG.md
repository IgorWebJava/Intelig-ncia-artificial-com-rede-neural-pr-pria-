# Phase 03 — Knowledge, Tools and Agents

Status: DOCUMENTATION-ONLY


Implement Knowledge/RAG, tool runtime, policy/approval, skill runtime, workflow/event runtime, agent runtime, planner/orchestrator and evaluation/verification.

Required order:
1. safe tool contracts;
2. knowledge retrieval and citations;
3. deterministic workflows;
4. single-agent tool use;
5. multi-agent only where benchmark evidence shows value.

Exit result:
- agents act only through governed capabilities;
- risky actions are approval-gated;
- RAG has citation/provenance;
- agent quality is evaluated against single-agent/direct-model baselines.
