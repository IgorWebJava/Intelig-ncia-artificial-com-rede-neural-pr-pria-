<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 101 — Module Package Standard

```text
modules/<module>/
├── module.manifest.json
├── ui/
├── contracts/
├── data/
├── docs/
└── compatibility/
```

A module must be removable/replaced as one package.
