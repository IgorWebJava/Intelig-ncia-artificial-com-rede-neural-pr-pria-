#ifndef ND_RAG_H
#define ND_RAG_H

#include <stddef.h>
#include <stdint.h>
#include "nd_semantic_ranker.h"

#define ND_RAG_MAX_CHUNKS 128u
#define ND_RAG_MAX_CHUNKS_PER_DOC 16u
#define ND_RAG_CHUNK_TEXT 1024u
#define ND_RAG_DOC_ID 96u
#define ND_RAG_TOKEN_HASHES 80u

typedef struct {
    char doc_id[ND_RAG_DOC_ID];
    char text[ND_RAG_CHUNK_TEXT];
    size_t token_count;
    uint32_t token_hashes[ND_RAG_TOKEN_HASHES];
    uint64_t document_hash;
    uint64_t last_access;
} NDRagChunk;

typedef struct {
    NDRagChunk chunks[ND_RAG_MAX_CHUNKS];
    size_t count;
    uint64_t logical_clock;
} NDRagIndex;

typedef struct {
    int found;
    size_t hit_count;
    float best_score;
} NDRagResult;

typedef struct {
    size_t chunks;
    size_t documents;
    uint64_t logical_clock;
} NDRagStats;

void nd_rag_init(NDRagIndex *index);
void nd_rag_clear(NDRagIndex *index);
int nd_rag_add_document(NDRagIndex *index, const char *doc_id, const char *text,
                        char *err, size_t errcap);
int nd_rag_query(NDRagIndex *index, const char *query, size_t top_k,
                 char *out, size_t outcap, NDRagResult *result,
                 char *err, size_t errcap);
int nd_rag_query_ranked(NDRagIndex *index, const char *query, size_t top_k,
                        const NDSemanticRanker *ranker,
                        char *out, size_t outcap, NDRagResult *result,
                        char *err, size_t errcap);
void nd_rag_stats(const NDRagIndex *index, NDRagStats *stats);
int nd_rag_save(const NDRagIndex *index, const char *path, char *err, size_t errcap);
int nd_rag_load(NDRagIndex *index, const char *path, char *err, size_t errcap);

#endif
