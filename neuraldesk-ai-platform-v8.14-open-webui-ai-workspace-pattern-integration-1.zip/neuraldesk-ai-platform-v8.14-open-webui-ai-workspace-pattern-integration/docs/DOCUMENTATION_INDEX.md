<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.documentation -->
# Documentation Index — V8.12

## Start here

1. `CURRENT_STATE.md`
2. `SOURCE_OF_TRUTH.md`
3. `frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
4. `frontier-readiness/EXECUTIVE_VISION.md`
5. `frontier-readiness/COMPETITIVE_GAP_MATRIX.md`
6. `frontier-readiness/EXECUTION_ROADMAP.md`
7. `architecture/CURRENT_ARCHITECTURE.md`
8. `architecture/CURRENT_FRONTIER_READINESS_ARCHITECTURE.md`
9. `architecture/CURRENT_NEURAL_ENGINE_BLUEPRINT.md`
10. `architecture/CURRENT_INTERFACE_ENGINE_TRACEABILITY.md`
11. `governance/CURRENT_GOVERNANCE.md`
12. `governance/CURRENT_FRONTIER_PROGRAM_GOVERNANCE.md`
13. `ai/AI_READ_FIRST.md`

## Interface modules
- `../modules/agents/docs/CURRENT_STATE.md`
- `../modules/agents/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/app-shell/docs/CURRENT_STATE.md`
- `../modules/app-shell/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/audit/docs/CURRENT_STATE.md`
- `../modules/audit/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/chat/docs/CURRENT_STATE.md`
- `../modules/chat/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/knowledge/docs/CURRENT_STATE.md`
- `../modules/knowledge/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/operations/docs/CURRENT_STATE.md`
- `../modules/operations/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/settings/docs/CURRENT_STATE.md`
- `../modules/settings/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/system-config/docs/CURRENT_STATE.md`
- `../modules/system-config/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/tools/docs/CURRENT_STATE.md`
- `../modules/tools/docs/FUTURE_EXECUTABLE_READINESS.md`
- `../modules/training/docs/CURRENT_STATE.md`
- `../modules/training/docs/FUTURE_EXECUTABLE_READINESS.md`

## Neural Engine

- `../neural-engine/CURRENT_STATE.md`
- `../neural-engine/README.md`
- `../neural-engine/implementation/FRONTIER_EXECUTION_MASTER_PLAN.md`
- `../neural-engine/registry/frontier-readiness.json`
- every engine module: `CURRENT_STATE.md` + `FRONTIER_READINESS.md`

## Frontier readiness package

See `frontier-readiness/README.md` for the complete 45+ document planning set.

## V8.8 Kimi K3 engineering research
- `frontier-readiness/KIMI_K3_ENGINEERING_INTEGRATION.md`
- `frontier-readiness/MEMORY_AWARE_MODEL_SERVING_STRATEGY.md`
- `frontier-readiness/DETERMINISTIC_CORRECTNESS_AND_ORACLE_STRATEGY.md`
- `frontier-readiness/MODEL_ARTIFACT_TRUST_STRATEGY.md`
- `frontier-readiness/STORAGE_AWARE_INFERENCE_STRATEGY.md`
- `frontier-readiness/EXPERT_CACHE_POLICY_RESEARCH.md`
- `frontier-readiness/KDA_ATTNRES_LATENTMOE_RESEARCH_TRACK.md`
- `frontier-readiness/LONG_HORIZON_AGENTIC_RL_STRATEGY.md`
- `frontier-readiness/HARDWARE_FIT_AND_MEMORY_PRESET_STRATEGY.md`
- `../neural-engine/research/kimi-k3-2026/README.md`


## V8.10 research package
- `../neural-engine/research/deepseek-harness-2026/` — DeepSeek Harness architecture x-ray and provider-agnostic adoption plan.

- `architecture/CURRENT_ENGINE_UI_COMPATIBILITY.md`
- `governance/NON_REGRESSION_EVOLUTION_POLICY.md`
- `../platform/engine-ui-bridge/registry.json`


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.


## V8.12 AutoGPT Platform research
- `../neural-engine/research/autogpt-platform-2026/` — modern AutoGPT Platform architecture x-ray and independent adoption plan.
- `../neural-engine/architecture/AUTOGPT_AGENT_PLATFORM_ARCHITECTURE_INTEGRATION.md`
- `../neural-engine/modules/12-agent-platform-runtime/` — 13 documentation-only future modules.


## V8.13 Coding Intelligence
- `docs/architecture/CURRENT_CODING_INTELLIGENCE.md`
- `neural-engine/research/claw-code-2026/README.md`
- `neural-engine/modules/13-coding-intelligence-runtime/`
