<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Python Runtime

    Tool ID: `tool.python-runtime`

    ## Role in NeuralDesk development

    Deterministic project generation, JSON/SQL/docs updates, validators, test runners and ZIP packaging.

    ## Current implementations

    - `python_user_visible`
- `Python 3 standard library`

    ## Capabilities provided

    - `python.execute.v1`
- `filesystem.read.v1`
- `filesystem.write.v1`
- `filesystem.copy.v1`
- `filesystem.search.v1`
- `json.read-write.v1`
- `archive.zip.create.v1`
- `test.static.execute.v1`
- `diff.compare.v1`
- `release.package.v1`

    ## Constraints

    - Runtime scripts must be deterministic.
- Do not embed secrets.
- Internet is not assumed inside Python runtime.

    ## Portable alternatives

    - any Python 3 runtime
- CI runner with Python

    ## Rule

    The capability is more important than the tool name. A future AI may replace this tool if it provides equivalent capabilities and passes the relevant quality gates.
