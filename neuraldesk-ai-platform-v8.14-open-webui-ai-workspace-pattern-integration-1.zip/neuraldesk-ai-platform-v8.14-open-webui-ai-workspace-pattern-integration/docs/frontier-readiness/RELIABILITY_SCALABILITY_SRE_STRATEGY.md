# Reliability, Scalability and SRE Strategy

Production AI is a distributed system.

Required disciplines:
- SLOs and error budgets;
- queue/backpressure;
- timeouts/retries/circuit breakers;
- idempotency;
- load shedding;
- graceful degradation;
- provider failover;
- capacity models;
- autoscaling;
- disaster recovery;
- chaos/failure testing;
- incident runbooks.

Model quality regressions are operational incidents, not only ML issues.
