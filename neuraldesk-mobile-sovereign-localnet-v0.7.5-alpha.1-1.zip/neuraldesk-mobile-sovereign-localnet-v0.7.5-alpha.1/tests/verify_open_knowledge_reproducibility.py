#!/usr/bin/env python3
from pathlib import Path
import hashlib, subprocess, sys, tempfile
R=Path(__file__).resolve().parents[1]; builder=R/'training/build_open_knowledge_shard.py'; records=R/'training/data/open_knowledge/pira_reconstruction_records_v1.jsonl'; canonical=R/'models/neuraldesk-open-knowledge-pira-v0.6.ndos'
with tempfile.TemporaryDirectory() as td:
    td=Path(td); outs=[]
    for i in (1,2):
        out=td/f'r{i}.ndos'; rep=td/f'r{i}.json'; subprocess.run([sys.executable,str(builder),'--records',str(records),'--output',str(out),'--report',str(rep)],cwd=R,check=True,capture_output=True,text=True); outs.append(out.read_bytes())
    assert outs[0]==outs[1]==canonical.read_bytes()
sha=hashlib.sha256(canonical.read_bytes()).hexdigest(); print('open-knowledge-reproducibility PASS',sha)
