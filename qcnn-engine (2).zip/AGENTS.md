# 🧠 MEMÓRIA CENTRAL & DIRETRIZES DO PROJETO QCNN ENGINE v5.0

> **DOCUMENTO DE LEITURA OBRIGATÓRIA PARA A IA DESENVOLVEDORA**
> Toda vez que qualquer modificação, nova funcionalidade ou refatoração for iniciada, este arquivo e a pasta `/docs` **DEVEM** ser consultados para evitar alucinações, evitar recriação de código existente e manter estrita obediência à arquitetura orientada a objetos baseada em plugins.

---

## 🚫 1. PRINCÍPIOS FUNDAMENTAIS & RESTRIÇÕES CRÍTICAS (ANTI-ALUCINAÇÃO)

1. **AUTONOMIA 100% PURA (SEM IA EXTERNA / SEM GEMINI / SEM LLMs DE TERCEIROS)**:
   - **NÃO** importar, nem tentar conectar APIs externas de IA (Google Gemini, OpenAI, Claude, HuggingFace, etc.).
   - Todo o processamento semântico, expansão fractal, cálculo harmônico e diálogo por ressonância é feito **artesanalmente e localmente** pelo nosso motor matemático quântico-cabalístico (`QCNN`).
   - O projeto opera 100% offline e independente.

2. **REUTILIZAÇÃO OBRIGATÓRIA DE CÓDIGO (NÃO DUPLICAR NADA)**:
   - Antes de escrever qualquer classe, função ou dicionário, verifique se ele já existe em `docs/CATALOGO_MODULOS.md` ou nos pacotes existentes.
   - É terminantemente proibido criar classes duplicadas, funções repetidas ou recriar lógica já existente.

3. **ARQUITETURA ORIENTADA A OBJETOS (POO) & SISTEMA DE PLUGINS**:
   - **TUDO É UM MÓDULO/PLUGIN PLUGÁVEL**: Qualquer nova funcionalidade (filtros, geradores de ondas, decodificadores, sintetizadores, coletores de telemetria) deve implementar a interface padrão de plugin (`IQcnnPlugin` em Kotlin / `BaseQcnnPlugin` em Python).
   - Qualquer módulo deve poder ser conectado (`attach`) ou desconectado (`detach`) do Pipeline Central sem quebrar o sistema.
   - Baixo acoplamento e alta coesão em todas as classes.

---

## 📋 2. REGISTRO PERMANENTE DE ACERTOS E ERROS (HISTÓRICO DE APRENDIZADO)

Consulte detalhadamente `docs/REGISTRO_ERROS_ACERTOS.md`. Abaixo estão os 8 marcos validados:

### ✅ ACERTOS CONFIRMADOS:
- **1. Emulação Ternária Bitwise (`[-1, 0, 1]` via flags `10`, `01`, `00`)**: Eficiência extrema de memória (RAM < 12MB) e tempo de execução na casa dos microssegundos.
- **2. Filtro de Adjacência Gramatical**: Validação de arestas no grafo das 22 letras para evitar loops e anagramas dissonantes.
- **3. Interface Híbrida Web/Android**: A interface HTML5 roda no servidor Python Flask local (`http://127.0.0.1:5000`), embutida no Android via WebView com `AndroidBridge`, ou standalone no browser.
- **4. Áudio Senoidal PCM Nativo**: `AudioTrack` em Kotlin gera frequências harmônicas reais sem bibliotecas externas pesadas.
- **5. Reconhecimento de Voz Web Speech API**: Transcrição nativa de voz para texto em português sem modelos pesados de nuvem.
- **6. Diálogo Natural por Ressonância Conceitual**: Mapeamento de nós conceituais com frequências áureas e superposição semântica.
- **7. Absorção Automática e Scraping Local Offline**: Varredura de arquivos `.txt` locais quando ocorre vácuo harmônico, com sintonização áurea dinâmica.
- **8. Núcleo de Emaranhamento Web Leve**: Requisição HTTP pura ultra-rápida para resumos leves com persistência vitalícia em RAM e disco local.
- **9. Monitor de Frequências Senoidais (Canvas Nativo)**: Renderização trigonométrica $y = \sin(x)$ fluida a 60fps sem bibliotecas gráficas pesadas (sem Chart.js/D3.js).
- **10. Consolidação de Inicialização da WebView e Resiliência da Ponte**: Configuração exaustiva de acessos de assets e fallback universal no JavaScript e Kotlin.
- **11. Computação Hiperdimensional (HDC $D=2048$)**: Projeção e operações de binding, bundling e similaridade vetorial bipolar instantânea sem redes neurais pesadas.
- **12. Síntese Gramatical Fractal**: Recombinação determinística e estruturada de múltiplos nós conceituais em superposição.

### ❌ ERROS A NUNCA MAIS REPETIR:
- **NUNCA** hardcodar dicionários ou lógicas soltas fora da estrutura modular de plugins.
- **NUNCA** chamar ferramentas ou sugerir dependências de nuvem para o processamento de linguagem natural.
- **NUNCA** esquecer o mapeamento bidirecional da interface HTML (ela deve manter compatibilidade simultânea com o backend Python `fetch('/colapsar')` e com a ponte Android nativa `window.AndroidBridge`).
- **NUNCA** criar arquivos gigantes monolíticos sem separação de responsabilidades.

---

## 🧬 4. DIRETRIZ ARQUITETURAL: HOLOGRAFIA FRACTAL & AUTO-CURA REGENERATIVA (MÓDULOS & SUBAGENTES)

1. **Autonomia de Memória por Módulo/Subagente (Princípio Hermético-Holográfico)**:
   - Todo módulo, plugin, agente ou subagente do QCNN Engine DEVE possuir seu próprio repositório de memória local independente (`HolographicMemoryStore`), com vetor HDC local, histórico de ativação e nós conceituais próprios.
   - "O que está dentro é como o que está fora; o que está fora é como o que está dentro": a arquitetura de um subagente individual espelha fielmente a arquitetura do ecossistema central, variando estritamente na sua escala/proporção de capacidade.

2. **Protocolo de Auto-Cura e Regeneração Cruzada (Self-Healing Consensus)**:
   - Nenhuma camada opera em isolamento cego. Se um módulo apresentar entropia elevada, perda de coerência ou falha de colapso, as camadas adjacentes e o auditor de auto-cura (`SelfHealingConsensusPlugin` - M22) comparam o estado com o holograma de memória correspondente.
   - O estado correto é reconstituído instantaneamente por triangulação matemática e ressonância harmônica, eliminando qualquer alucinação ou inconsistência antes de colapsar a resposta final para o usuário.

3. **Consistência Proporcional Escalar**:
   - Módulos menores (micro-plugins) processam e preservam memórias em dimensões otimizadas locais.
   - Módulos maiores (oráculos multiverso e pipeline central) agregam as projeções em superposição, garantindo redundância, estabilidade contínua e fidelidade total na entrega.

---

## 🧩 5. ESTRUTURA MODULAR DO PROJETO

```text
/
├── AGENTS.md                  <-- Memória central e regras vitais da IA
├── GEMINI.md                  <-- Espelho de diretrizes
├── interface.html             <-- Interface universal do Chat Quântico
├── app.py                     <-- Servidor Python Flask modularizado
├── qcnn/                      <-- Pacote Modular Python (Plugins & Core)
│   ├── __init__.py
│   ├── core/
│   │   ├── interfaces.py      <-- Contratos Base e Interfaces de Plugins
│   │   ├── context.py         <-- Contexto de Execução Compartilhado
│   │   └── pipeline.py        <-- Orquestrador de Plugins
│   └── plugins/
│       ├── matriz_letras.py   <-- Tabela das 22 Letras Fundamentais
│       ├── ternary_bitwise.py <-- Plugin de estados ternários
│       ├── milui_expansion.py <-- Plugin de expansão cabalística
│       ├── adjacency_filter.py<-- Plugin de filtragem anti-anagrama
│       ├── harmonic_frequency.py <-- Plugin de frequências áureas em Hz
│       ├── hyperdimensional_computing.py <-- Plugin HDC (D=2048)
│       ├── fractal_grammar.py <-- Plugin de síntese gramatical fractal
│       ├── conceptual_dialogue.py <-- Plugin de conversação, absorção e web
│       └── telemetry_meter.py <-- Plugin de métricas e latência
├── docs/                      <-- Documentação completa
│   ├── README.md
│   ├── REGISTRO_ERROS_ACERTOS.md
│   ├── REGISTRO_TESTES_RESULTADOS.md <-- Registro oficial e histórico de testes reais do motor
│   ├── ARQUITETURA_MODULAR_PLUGINS.md
│   └── CATALOGO_MODULOS.md
└── app/                       <-- App Nativo Android (Kotlin + Jetpack Compose)
    └── src/main/java/com/example/
        ├── MainActivity.kt
        └── engine/
            ├── core/          <-- Interfaces e Contexto em Kotlin
            ├── plugins/       <-- Implementações plugáveis dos módulos
            └── QcnnEngine.kt  <-- Orquestrador do Motor no Android
```
