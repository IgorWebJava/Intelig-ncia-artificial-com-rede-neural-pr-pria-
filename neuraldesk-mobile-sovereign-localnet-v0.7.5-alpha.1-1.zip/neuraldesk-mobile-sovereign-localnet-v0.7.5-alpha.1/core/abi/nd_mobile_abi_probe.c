typedef unsigned long nd_size_t;

typedef struct {
    unsigned abi_version;
    unsigned feature_bits;
    nd_size_t state_bytes;
} NDPortableAbiInfo;

NDPortableAbiInfo nd_portable_abi_info(void) {
    NDPortableAbiInfo v;
    v.abi_version = 71u;
    v.feature_bits = 0x0000003fu;
    v.state_bytes = (nd_size_t)sizeof(NDPortableAbiInfo);
    return v;
}

unsigned nd_portable_environment_probe(void) {
    return 71u;
}
