#!/usr/bin/env python3
"""Materialize Micro-v2 generative training inputs from already-governed local sources.

No evaluation Golden is imported. Pira validation and the historical six v0.7.4
holdouts are reserved before any training-eligible source is accepted.
"""
from __future__ import annotations
import hashlib, importlib.util, json, re, subprocess, sys, unicodedata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'training/data/generative_v074_v2'
PIRA=ROOT/'training/data/open_knowledge/historical_full/pira_human_records_v06.jsonl'
KB=ROOT/'training/knowledge_base.py'
CP=ROOT/'training/data/context_pointer_train.jsonl'
KR=ROOT/'training/data/knowledge_retriever_train.tsv'
HOLD=ROOT/'evaluation/generative_v074/HOLDOUT_PROBES.json'
PRE=ROOT/'scripts/pre_generation_lessons_check.py'

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s:str)->str:
    s=unicodedata.normalize('NFKC',s).casefold()
    s=re.sub(r'\s+',' ',s).strip()
    return s

def dump(path:Path, rows:list[dict]):
    data=''.join(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n' for r in rows).encode('utf-8')
    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(data)

def main()->int:
    subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
    pira=[json.loads(x) for x in PIRA.read_text(encoding='utf-8').splitlines() if x.strip()]
    ptrain=[r for r in pira if r.get('split')=='train']; pval=[r for r in pira if r.get('split')=='validation']
    if len(ptrain)!=1141 or len(pval)!=140: raise SystemExit('Pira split invariant failed')
    hold=json.loads(HOLD.read_text(encoding='utf-8'))['probes']
    reserved_validation={norm(r['question']) for r in pval}
    reserved_holdout={norm(r['prompt']) for r in hold}
    if len(reserved_validation)!=140 or len(reserved_holdout)!=6: raise SystemExit('reserved-set uniqueness failed')
    reserved=reserved_validation|reserved_holdout

    spec=importlib.util.spec_from_file_location('nd_kb',KB); mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod)
    records=list(mod.RECORDS)
    if len(records)!=201: raise SystemExit('knowledge record count drift')

    rich=[]; context=[]; replay=[]; excluded=[]; seen=set()
    def add_rich(rec:dict):
        qn=norm(rec['question']); key=(qn,norm(rec['response']))
        if qn in reserved:
            excluded.append({'source':rec['source'],'question':rec['question'],'reason':'RESERVED_EVALUATION'}); return
        if key in seen: return
        seen.add(key); rich.append(rec)
        replay.append({'id':rec['id'],'text':rec['question']+'\n'+rec['response'],'source':rec['source'],'trainingEligible':True})

    for r in ptrain:
        add_rich({'id':'pira:'+str(r['source_id']),'question':r['question'],'response':r['answer'],'source':'PIRA_2_0_CC_BY_4_0','trainingEligible':True})
    for i,r in enumerate(records):
        add_rich({'id':f'kb:{i:03d}:canonical','question':r.q,'response':r.rich,'source':'NEURALDESK_FIRST_PARTY_KB','trainingEligible':True})

    # Retriever training questions are first-party paraphrases. Map only valid KB ids;
    # id 201 is a deliberate unknown class and is not converted into factual SFT.
    kr_added=0
    for line_no,line in enumerate(KR.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        sid,q=line.split('\t',1); idx=int(sid)
        if 0<=idx<len(records):
            before=len(rich)
            add_rich({'id':f'kr:{line_no:04d}:kb{idx:03d}','question':q,'response':records[idx].rich,'source':'NEURALDESK_FIRST_PARTY_RETRIEVER_TRAIN','trainingEligible':True})
            kr_added += int(len(rich)>before)

    kinds={}; cp_added=0
    for line_no,line in enumerate(CP.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        r=json.loads(line); qn=norm(r['question'])
        if qn in reserved:
            excluded.append({'source':'CONTEXT_POINTER_TRAIN','question':r['question'],'reason':'RESERVED_EVALUATION'}); continue
        rec={'id':f'cp:{line_no:05d}','question':r['question'],'context':r['context'],'response':r['answer'],'kind':r.get('kind','unknown'),'source':'NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN','trainingEligible':True}
        context.append(rec); cp_added+=1; kinds[rec['kind']]=kinds.get(rec['kind'],0)+1
        replay.append({'id':rec['id'],'text':'Contexto: '+rec['context']+'\nPergunta: '+rec['question']+'\nResposta: '+rec['response'],'source':rec['source'],'trainingEligible':True})

    # Global exact question separation across every training source.
    train_q={norm(r['question']) for r in rich}|{norm(r['question']) for r in context}
    leak_val=sorted(train_q & reserved_validation); leak_hold=sorted(train_q & reserved_holdout)
    if leak_val or leak_hold: raise SystemExit(f'global leakage validation={leak_val[:2]} holdout={leak_hold[:2]}')

    val=[{'id':'pira:'+str(r['source_id']),'question':r['question'],'answer':r['answer'],'source':'PIRA_2_0_CC_BY_4_0','usage':'EVALUATION_ONLY'} for r in pval]
    rp=OUT/'rich_sft.jsonl'; cp=OUT/'context_sft.jsonl'; pp=OUT/'causal_replay.jsonl'; vp=OUT/'pira_validation.jsonl'; ep=OUT/'excluded_reserved.jsonl'
    dump(rp,rich); dump(cp,context); dump(pp,replay); dump(vp,val); dump(ep,excluded)
    prov={
      'schema':'neuraldesk-generative-corpus-v074-alpha2-micro-v2-v1','status':'MATERIALIZED_NOT_TRAINED',
      'sources':{
        'pira':{'path':str(PIRA.relative_to(ROOT)),'sha256':sha(PIRA),'license':'CC BY 4.0','trainOriginal':1141,'validationOriginal':140},
        'knowledgeBase':{'path':str(KB.relative_to(ROOT)),'sha256':sha(KB),'rights':'NEURALDESK_FIRST_PARTY','records':201},
        'retrieverTrain':{'path':str(KR.relative_to(ROOT)),'sha256':sha(KR),'rights':'NEURALDESK_FIRST_PARTY','mappedRichVariants':kr_added},
        'contextPointerTrain':{'path':str(CP.relative_to(ROOT)),'sha256':sha(CP),'rights':'NEURALDESK_FIRST_PARTY','records':cp_added,'kinds':kinds},
        'historicalHoldout':{'path':str(HOLD.relative_to(ROOT)),'sha256':sha(HOLD),'usage':'EVALUATION_ONLY'}},
      'materialized':{'richSft':len(rich),'contextSft':len(context),'causalReplay':len(replay),'validation':len(val),'excludedReserved':len(excluded),
                      'richSftSha256':sha(rp),'contextSftSha256':sha(cp),'replaySha256':sha(pp),'validationSha256':sha(vp)},
      'governance':{'globalQuestionCrossSplitLeakage':0,'historicalHoldoutExactPromptLeakage':0,'validationUsedForTraining':False,'validationUsedForTokenizerFit':False,'goldenFilesUsedForTraining':False,'historicalAuthored48':'NOT_RECOVERED_DO_NOT_FABRICATE'}
    }
    (OUT/'PROVENANCE.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(f"GENERATIVE_CORPUS_V2 PASS rich={len(rich)} context={len(context)} replay={len(replay)} validation={len(val)} excluded={len(excluded)} krVariants={kr_added} globalQuestionCrossSplitLeakage=0 historicalHoldoutExactPromptLeakage=0")
    return 0
if __name__=='__main__': raise SystemExit(main())
