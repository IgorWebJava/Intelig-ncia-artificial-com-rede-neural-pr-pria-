package com.example.engine

import android.webkit.JavascriptInterface
import com.example.engine.plugins.HardwareTelemetryPlugin
import org.json.JSONObject

/**
 * Ponte JavaScript para comunicação bidirecional entre a WebView (HTML5/CSS3)
 * e o Motor Nativo QCNN em Kotlin.
 */
class QuantumJsBridge(private val engine: QcnnEngine) {

    @JavascriptInterface
    fun processSeed(seed: String?): String {
        return processSeedWithObserver(seed, 0.5, "Dialética", 0.8)
    }

    @JavascriptInterface
    fun processSeedWithObserver(seed: String?, risk: Double, philosophy: String?, rigor: Double): String {
        return try {
            val validSeed = if (seed.isNullOrBlank()) "Alef" else seed.trim()
            val validPhil = if (philosophy.isNullOrBlank()) "Dialética" else philosophy.trim()
            val result = engine.processSeed(validSeed, risk.coerceIn(0.0, 1.0), validPhil, rigor.coerceIn(0.0, 1.0))
            result.toJson()
        } catch (e: Exception) {
            JSONObject().apply {
                put("resposta", "Colapso executado no vácuo de contingência quântica.")
                put("arvore", "Alef")
                put("estado", "00 (Vácuo)")
                put("frequencia", "1.62 Hz")
                put("latencia", "0.010ms")
            }.toString()
        }
    }

    @JavascriptInterface
    fun getDeviceRamMB(): String {
        return try {
            val telemetryPlugin = engine.getPlugin("hardware_telemetry") as? HardwareTelemetryPlugin
            val ram = telemetryPlugin?.getHardwareRamMB() ?: 12
            ram.toString()
        } catch (e: Exception) {
            "12"
        }
    }
}
