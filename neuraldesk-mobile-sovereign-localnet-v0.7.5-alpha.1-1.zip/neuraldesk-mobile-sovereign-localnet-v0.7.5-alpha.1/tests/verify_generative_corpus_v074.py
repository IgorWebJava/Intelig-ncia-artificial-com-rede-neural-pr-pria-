#!/usr/bin/env python3
import hashlib,json,re,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; D=ROOT/'training/data/generative_v074'
def rows(n): return [json.loads(x) for x in (D/n).read_text(encoding='utf-8').splitlines() if x.strip()]
def norm(s): return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',s).casefold()).strip()
p=json.loads((D/'PROVENANCE.json').read_text())
s=rows('sft_train.jsonl'); r=rows('causal_replay.jsonl'); v=rows('pira_validation.jsonl')
assert len(v)==140 and len(s)==len(r)
assert all(x['usage']=='EVALUATION_ONLY' for x in v)
assert not ({norm(x['question']) for x in s}&{norm(x['question']) for x in v})
assert p['governance']['globalQuestionCrossSplitLeakage']==0
assert p['governance']['validationUsedForTraining'] is False and p['governance']['validationUsedForTokenizerFit'] is False
assert p['governance']['historicalAuthored48']=='NOT_RECOVERED_DO_NOT_FABRICATE'
for k,n in [('sftSha256','sft_train.jsonl'),('replaySha256','causal_replay.jsonl'),('validationSha256','pira_validation.jsonl')]:
    assert hashlib.sha256((D/n).read_bytes()).hexdigest()==p['materialized'][k]
print(f"GENERATIVE_CORPUS_VERIFY PASS sft={len(s)} replay={len(r)} validation={len(v)} leakage=0")
