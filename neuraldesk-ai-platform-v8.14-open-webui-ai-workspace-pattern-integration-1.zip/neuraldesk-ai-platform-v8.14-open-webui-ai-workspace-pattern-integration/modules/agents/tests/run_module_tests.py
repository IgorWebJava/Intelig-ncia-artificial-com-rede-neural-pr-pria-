#!/usr/bin/env python3
from pathlib import Path
import unittest, sys, json, datetime

TESTS = Path(__file__).resolve().parent
suite = unittest.defaultTestLoader.discover(str(TESTS / "automated"), pattern="test_*.py")
runner = unittest.TextTestRunner(verbosity=1)
result = runner.run(suite)

report = {
    "module_id": json.loads((TESTS.parent / "module.manifest.json").read_text(encoding="utf-8"))["module_id"],
    "suite_version": json.loads((TESTS / "test.manifest.json").read_text(encoding="utf-8"))["suite_version"],
    "status": "pass" if result.wasSuccessful() else "fail",
    "tests_run": result.testsRun,
    "failures": len(result.failures),
    "errors": len(result.errors),
    "skipped": len(result.skipped),
    "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(TESTS / "reports").mkdir(exist_ok=True)
(TESTS / "reports" / "automated-result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
sys.exit(0 if result.wasSuccessful() else 1)
