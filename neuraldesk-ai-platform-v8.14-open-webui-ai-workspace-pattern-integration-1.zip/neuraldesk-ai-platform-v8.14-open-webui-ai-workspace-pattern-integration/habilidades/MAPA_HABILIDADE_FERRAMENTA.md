<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->

# Mapa Habilidade / Capability / Ferramenta

| Capability | Ferramentas atuais | Portabilidade |
|---|---|---|
| `accessibility.structural.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `ai.capability.fabric.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `ai.model-replacement.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `archive.zip.create.v1` | `tool.python-runtime` | Pode ser substituída por provider equivalente |
| `asyncapi.author.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `audit.trace.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `browser.render.v1` | `tool.browser-renderer` | Pode ser substituída por provider equivalente |
| `browser.screenshot.v1` | `tool.browser-renderer` | Pode ser substituída por provider equivalente |
| `browser.viewport-test.v1` | `tool.browser-renderer` | Pode ser substituída por provider equivalente |
| `capability.registry.manage.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `contract.registry.manage.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `css.author.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `data.ownership.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `diff.compare.v1` | `tool.python-runtime`, `tool.container-shell` | Pode ser substituída por provider equivalente |
| `documentation.author.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `documentation.sync.v1` | `tool.project-validators` | Pode ser substituída por provider equivalente |
| `eventing.outbox.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `filesystem.copy.v1` | `tool.python-runtime` | Pode ser substituída por provider equivalente |
| `filesystem.read.v1` | `tool.python-runtime`, `tool.container-shell` | Pode ser substituída por provider equivalente |
| `filesystem.search.v1` | `tool.python-runtime`, `tool.container-shell` | Pode ser substituída por provider equivalente |
| `filesystem.write.v1` | `tool.python-runtime` | Pode ser substituída por provider equivalente |
| `html.author.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `json.read-write.v1` | `tool.python-runtime` | Pode ser substituída por provider equivalente |
| `jsonschema.author-validate.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `module.architecture.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `module.manifest.author.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `multimodal.contract.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `observability.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `openapi.author.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `project.memory.read.v1` | `tool.project-memory-service` | Pode ser substituída por provider equivalente |
| `project.memory.update.v1` | `tool.project-memory-service` | Pode ser substituída por provider equivalente |
| `project.skills.read.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `project.skills.update.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `python.execute.v1` | `tool.python-runtime` | Pode ser substituída por provider equivalente |
| `release.gates.execute.v1` | `tool.project-validators` | Pode ser substituída por provider equivalente |
| `release.package.v1` | `tool.python-runtime` | Pode ser substituída por provider equivalente |
| `release.versioning.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `responsive.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `security.threat-model.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `shell.execute.v1` | `tool.container-shell` | Pode ser substituída por provider equivalente |
| `source.verify.v1` | `tool.web-research` | Pode ser substituída por provider equivalente |
| `sql.postgresql.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `test.scenario.design.v1` | _skill/knowledge capability_ | Pode ser substituída por provider equivalente |
| `test.static.execute.v1` | `tool.python-runtime`, `tool.project-validators` | Pode ser substituída por provider equivalente |
| `test.visual.execute.v1` | `tool.browser-renderer` | Pode ser substituída por provider equivalente |
| `web.research.v1` | `tool.web-research` | Pode ser substituída por provider equivalente |
| `browser.preview.capture.v1` | `tool.browser-renderer` | Pode ser substituída por provider equivalente |


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
