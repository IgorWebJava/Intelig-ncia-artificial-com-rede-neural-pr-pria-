#!/usr/bin/env python3
from pathlib import Path
import hashlib,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'core/abi/nd_mobile_abi_probe.c'
targets={
 'android-arm64':'aarch64-linux-android26',
 'android-x86_64':'x86_64-linux-android26',
 'ios-arm64':'arm64-apple-ios13.0',
 'ios-sim-x86_64':'x86_64-apple-ios13.0-simulator',
}
with tempfile.TemporaryDirectory() as td:
 d=Path(td);results={}
 for name,target in targets.items():
  a=d/(name+'.o');b=d/(name+'.2.o')
  cmd=['clang','-target',target,'-ffreestanding','-fno-stack-protector','-fno-ident','-O2','-c',str(SRC),'-o']
  subprocess.run(cmd+[str(a)],check=True);subprocess.run(cmd+[str(b)],check=True)
  ba=a.read_bytes();bb=b.read_bytes();assert ba==bb and len(ba)>0
  kind=subprocess.check_output(['file','-b',str(a)],text=True).strip();results[name]=(len(ba),hashlib.sha256(ba).hexdigest(),kind)
 for n,(size,digest,kind) in results.items():print(f'cross-target {n} bytes={size} sha256={digest} type={kind}')
print('MOBILE_CROSS_TARGET_ABI PASS targets=4 deterministic=true app_link=false device_execution=false')
