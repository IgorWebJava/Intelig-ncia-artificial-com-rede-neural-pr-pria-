<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Documentation Governance

    Skill ID: `neuraldesk.documentation-governance.v1`

    ## Category

    `documentation`

    ## Introduced

    `V6.5`

    ## Required development capabilities

    - `documentation.author.v1`
- `documentation.sync.v1`
- `filesystem.search.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/<module>/docs/`
- `docs/`
- `memória/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
