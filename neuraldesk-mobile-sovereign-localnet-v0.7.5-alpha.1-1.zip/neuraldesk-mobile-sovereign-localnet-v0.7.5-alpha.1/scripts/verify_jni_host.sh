#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/scripts/pre_generation_lessons_check.py"
JAVAC="$(command -v javac || true)"
if [[ -z "$JAVAC" ]]; then
  echo "javac não encontrado; JNI host syntax gate não pode ser executado" >&2
  exit 2
fi
JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$JAVAC")")")"
PLATFORM_INCLUDE="$JAVA_HOME/include/linux"
[[ -d "$PLATFORM_INCLUDE" ]] || PLATFORM_INCLUDE="$JAVA_HOME/include/darwin"
cc -std=c99 -Wall -Wextra -Werror -Wshadow -Wpointer-arith -Wstrict-prototypes \
  -I"$JAVA_HOME/include" -I"$PLATFORM_INCLUDE" -I"$ROOT/core/include" \
  -fsyntax-only "$ROOT/android/app/src/main/cpp/neuraldesk_jni.c"
printf 'JNI_HOST_SYNTAX PASS\n'
