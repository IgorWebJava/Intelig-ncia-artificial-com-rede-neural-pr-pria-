#include "nd_tokenizer.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(int argc,char **argv){NDTokenizer *t=NULL;const unsigned char text[]="Quantização móvel preserva UTF-8: ação, memória, café e KV cache.";uint32_t ids[256];unsigned char out[512];size_t ni=0,no=0;if(argc!=2){fprintf(stderr,"usage: %s TOKENIZER\n",argv[0]);return 2;}if(nd_tokenizer_load(argv[1],&t)!=0)return 3;if(nd_tokenizer_vocab(t)!=512u)return 4;if(nd_tokenizer_encode(t,text,sizeof(text)-1u,ids,256u,&ni)!=0)return 5;if(nd_tokenizer_decode(t,ids,ni,out,sizeof(out),&no)!=0)return 6;if(no!=sizeof(text)-1u||memcmp(out,text,no)!=0)return 7;printf("TOKENIZER PASS vocab=512 bytes=%zu tokens=%zu roundtrip=exact\n",sizeof(text)-1u,ni);nd_tokenizer_free(t);return 0;}
