#include "nd_generative.h"
#include "nd_tokenizer.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){NDGenerativeModel *m=NULL;NDTokenizer *t=NULL;uint32_t enc[ND_GEN_CONTEXT],prompt[ND_GEN_CONTEXT],out[ND_GEN_CONTEXT],clean[ND_GEN_CONTEXT];unsigned char text[4096];size_t n=0,pn=0,on=0,cn=0,bn=0,max_tokens,i;if(argc!=5){fprintf(stderr,"usage: %s MODEL TOKENIZER MAX_TOKENS PROMPT\n",argv[0]);return 2;}max_tokens=(size_t)strtoul(argv[3],NULL,10);if(max_tokens==0||max_tokens>128)return 3;if(nd_gen_load(argv[1],&m)!=0||nd_tokenizer_load(argv[2],&t)!=0)return 4;if(nd_tokenizer_encode(t,(const unsigned char*)argv[4],strlen(argv[4]),enc,ND_GEN_CONTEXT-2,&n)!=0)return 5;prompt[pn++]=ND_TOKENIZER_BOS;for(i=0;i<n&&pn<ND_GEN_CONTEXT-1;i++)prompt[pn++]=enc[i];prompt[pn++]=ND_TOKENIZER_SEP;if(pn+max_tokens>ND_GEN_CONTEXT)max_tokens=ND_GEN_CONTEXT-pn;if(nd_gen_greedy_generate(m,prompt,pn,out,ND_GEN_CONTEXT,max_tokens)!=0)return 6;on=max_tokens;for(i=0;i<on;i++){if(out[i]==ND_TOKENIZER_EOS)break;if(out[i]>=ND_TOKENIZER_PAD&&out[i]<=ND_TOKENIZER_SEP)break;clean[cn++]=out[i];}if(cn>0&&nd_tokenizer_decode(t,clean,cn,text,sizeof(text)-1,&bn)!=0)return 7;text[bn]=0;printf("TOKENS");for(i=0;i<on;i++)printf(" %u",out[i]);printf("\nTEXT %s\n",text);nd_tokenizer_free(t);nd_gen_free(m);return 0;}
