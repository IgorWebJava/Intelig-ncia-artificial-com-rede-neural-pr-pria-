<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Criar Novo Módulo

1. Ler memória e habilidades.
2. Definir responsabilidade/boundary do módulo.
3. Definir `module_id`, owner e data ownership.
4. Criar `modules/<module>/`.
5. Criar manifest.
6. Definir provides/requires capabilities.
7. Criar OpenAPI/AsyncAPI/config/permissions/adaptive contracts.
8. Criar UI/CSS se o módulo tiver superfície.
9. Criar docs e tests.
10. Registrar Module Registry/Capability Registry/Contract Registry.
11. Criar compatibility matrix.
12. Atualizar System Config/Audit se relevante.
13. Atualizar memória/habilidades.
14. Executar todos os release gates.
