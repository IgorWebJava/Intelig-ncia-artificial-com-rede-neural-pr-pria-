<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent Acceptance Criteria

- Project-scoped agents and catalog represented.
- Create/edit/rename/clone/archive/delete lifecycle represented.
- Runtime skill registry separate from development skills.
- Existing Tool Catalog reused.
- Knowledge/AI/Training/Audit/Operations integrated by capability.
- Teams/handoffs/workflows represented.
- Multimodal and responsive profile preserved.
- Version/evaluation/deployment/rollback represented.
- No direct DB or provider SDK in UI.
- Module-owned tests/docs/contracts/ownership included.
