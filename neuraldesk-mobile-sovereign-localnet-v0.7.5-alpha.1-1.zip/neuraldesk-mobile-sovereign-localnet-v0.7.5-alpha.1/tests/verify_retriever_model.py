#!/usr/bin/env python3
from pathlib import Path
import struct
p=Path('models/neuraldesk-knowledge-retriever-v0.5.ndkr')
b=p.read_bytes(); assert len(b)>=24
magic,version,feat,hidden,classes,seed=struct.unpack_from('<6I',b,0)
assert magic==0x3152444e and version==1
assert feat==4096 and hidden==64 and classes==202 and seed==101,(feat,hidden,classes,seed)
floats=feat*hidden+hidden+hidden*classes+classes
assert len(b)==24+floats*4,(len(b),24+floats*4)
print('knowledge-retriever-format PASS',floats,'floats')
