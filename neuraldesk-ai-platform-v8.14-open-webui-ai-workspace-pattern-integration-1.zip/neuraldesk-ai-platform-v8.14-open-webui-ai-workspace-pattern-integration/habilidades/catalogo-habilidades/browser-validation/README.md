<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Browser Visual & Responsive Validation

    Skill ID: `neuraldesk.browser-validation.v1`

    ## Category

    `quality-ui`

    ## Introduced

    `V6.4`

    ## Required development capabilities

    - `browser.render.v1`
- `browser.viewport-test.v1`
- `browser.screenshot.v1`
- `test.visual.execute.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `modules/<module>/tests/visual/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
