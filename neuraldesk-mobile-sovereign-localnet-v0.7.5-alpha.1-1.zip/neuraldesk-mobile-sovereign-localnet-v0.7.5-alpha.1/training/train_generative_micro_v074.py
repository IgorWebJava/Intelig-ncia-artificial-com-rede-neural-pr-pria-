#!/usr/bin/env python3
"""Deterministic stage-only Micro generative trainer for v0.7.4 alpha.2.

This script NEVER writes promoted runtime assets under models/. It produces
external checkpoints/staged candidates and reports. Promotion is a separate
Model Authority operation after independent quality gates.
"""
from __future__ import annotations
import argparse, hashlib, json, math, os, random, struct, subprocess, sys
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'training/data/generative_v074'
PRE=ROOT/'scripts/pre_generation_lessons_check.py'
V=512; D=160; L=6; QH=10; KVH=2; HD=16; KVD=32; FF=448; MAX_CTX=256; PARAMS=1742880; HEADER=128

class BytePairTokenizer:
    def __init__(self,path:Path):
        b=path.read_bytes()
        if len(b)!=568 or b[:8]!=b'NDTKV001': raise ValueError('invalid tokenizer bytes')
        self.pairs=[tuple(b[64+i*2:66+i*2]) for i in range(252)]
        self.map={p:260+i for i,p in enumerate(self.pairs)}
    def encode(self,text:str)->list[int]:
        b=text.encode('utf-8'); out=[]; i=0
        while i<len(b):
            if i+1<len(b) and (b[i],b[i+1]) in self.map: out.append(self.map[(b[i],b[i+1])]); i+=2
            else: out.append(b[i]); i+=1
        return out
    def decode(self,ids:list[int])->str:
        out=bytearray()
        for t in ids:
            if t<256: out.append(t)
            elif 260<=t<512: out.extend(self.pairs[t-260])
        return out.decode('utf-8','replace')

class RMSNorm(nn.Module):
    def __init__(self,n:int): super().__init__(); self.weight=nn.Parameter(torch.ones(n))
    def forward(self,x): return x*torch.rsqrt(x.pow(2).mean(-1,keepdim=True)+1e-5)*self.weight

def rope_adjacent(x:torch.Tensor)->torch.Tensor:
    # x [B,T,H,HD], C99 contract rotates adjacent pairs (0,1),(2,3)...
    B,T,H,N=x.shape; pos=torch.arange(T,device=x.device,dtype=x.dtype)
    dims=torch.arange(0,N,2,device=x.device,dtype=x.dtype)
    ang=pos[:,None]/torch.pow(torch.tensor(10000.0,device=x.device,dtype=x.dtype),dims[None,:]/N)
    c=ang.cos()[None,:,None,:]; s=ang.sin()[None,:,None,:]
    even=x[...,0::2]; odd=x[...,1::2]
    y=torch.empty_like(x); y[...,0::2]=even*c-odd*s; y[...,1::2]=even*s+odd*c
    return y

class Block(nn.Module):
    def __init__(self):
        super().__init__(); self.rms1=RMSNorm(D); self.wq=nn.Linear(D,D,bias=False); self.wk=nn.Linear(D,KVD,bias=False); self.wv=nn.Linear(D,KVD,bias=False); self.wo=nn.Linear(D,D,bias=False); self.rms2=RMSNorm(D); self.w1=nn.Linear(D,FF,bias=False); self.w2=nn.Linear(FF,D,bias=False); self.w3=nn.Linear(D,FF,bias=False)
    def forward(self,x):
        B,T,_=x.shape; n=self.rms1(x); q=rope_adjacent(self.wq(n).view(B,T,QH,HD)); k=rope_adjacent(self.wk(n).view(B,T,KVH,HD)); v=self.wv(n).view(B,T,KVH,HD)
        k=k.repeat_interleave(QH//KVH,dim=2).transpose(1,2); v=v.repeat_interleave(QH//KVH,dim=2).transpose(1,2); q=q.transpose(1,2)
        scores=(q@k.transpose(-2,-1))/math.sqrt(HD); mask=torch.ones(T,T,device=x.device,dtype=torch.bool).tril(); scores=scores.masked_fill(~mask,-torch.inf)
        a=torch.softmax(scores,dim=-1)@v; x=x+self.wo(a.transpose(1,2).contiguous().view(B,T,D)); n=self.rms2(x); x=x+self.w2(F.silu(self.w1(n))*self.w3(n)); return x

class Micro(nn.Module):
    def __init__(self):
        super().__init__(); self.embedding=nn.Embedding(V,D); self.blocks=nn.ModuleList([Block() for _ in range(L)]); self.final_rms=RMSNorm(D); self.apply(self._init)
    @staticmethod
    def _init(m):
        if isinstance(m,(nn.Linear,nn.Embedding)): nn.init.normal_(m.weight,mean=0.0,std=0.02)
    def forward(self,ids):
        x=self.embedding(ids)
        for b in self.blocks: x=b(x)
        return F.linear(self.final_rms(x),self.embedding.weight)

def sha(path:Path)->str: return hashlib.sha256(path.read_bytes()).hexdigest()
def read_jsonl(path:Path): return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
def file_bindings(tok:Path):
    return {'sft':sha(DATA/'sft_train.jsonl'),'replay':sha(DATA/'causal_replay.jsonl'),'validation':sha(DATA/'pira_validation.jsonl'),'provenance':sha(DATA/'PROVENANCE.json'),'tokenizer':sha(tok)}
def config_dict(a,tok):
    return {'schema':'nd-v074-train-config-v1','arch':{'vocab':V,'dim':D,'layers':L,'qHeads':QH,'kvHeads':KVH,'ffn':FF,'context':MAX_CTX,'params':PARAMS},'seed':a.seed,'seqLen':a.seq_len,'pretrainSteps':a.pretrain_steps,'sftSteps':a.sft_steps,'pretrainLr':a.pretrain_lr,'sftLr':a.sft_lr,'weightDecay':a.weight_decay,'bindings':file_bindings(tok)}
def canon_hash(obj:Any)->str: return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def tensor_hash(named)->str:
    h=hashlib.sha256()
    for name,t in sorted(named,key=lambda x:x[0]):
        a=t.detach().cpu().contiguous().numpy(); h.update(name.encode()+b'\0'); h.update(str(a.dtype).encode()+b'\0'); h.update(str(a.shape).encode()+b'\0'); h.update(a.tobytes())
    return h.hexdigest()
def optimizer_hash(opt)->str:
    sd=opt.state_dict(); h=hashlib.sha256()
    for g in sd['param_groups']:
        for k in sorted(k for k in g if k!='params'): h.update(f'g:{k}={g[k]}\n'.encode())
        h.update(('params:'+','.join(map(str,g['params']))+'\n').encode())
    for pid,state in sorted(sd['state'].items()):
        h.update(f'p:{pid}\n'.encode())
        for k,v in sorted(state.items()):
            h.update((k+'\0').encode())
            if torch.is_tensor(v):
                a=v.detach().cpu().contiguous().numpy(); h.update(str(a.dtype).encode()+str(a.shape).encode()+a.tobytes())
            else: h.update(repr(v).encode())
    return h.hexdigest()
def checkpoint_write(path:Path,model,opt,cfg,pre_done,sft_done,phase,initial_val):
    path.parent.mkdir(parents=True,exist_ok=True)
    blob={'schema':'nd-v074-checkpoint-v1','config':cfg,'configSha256':canon_hash(cfg),'pretrainDone':pre_done,'sftDone':sft_done,'phase':phase,'initialValidationLoss':initial_val,'model':model.state_dict(),'optimizer':opt.state_dict(),'modelStateSha256':tensor_hash(model.state_dict().items()),'optimizerStateSha256':optimizer_hash(opt)}
    torch.save(blob,path)
    side={'checkpointSha256':sha(path),'configSha256':blob['configSha256'],'modelStateSha256':blob['modelStateSha256'],'optimizerStateSha256':blob['optimizerStateSha256'],'phase':phase,'pretrainDone':pre_done,'sftDone':sft_done}
    path.with_suffix(path.suffix+'.json').write_text(json.dumps(side,indent=2,sort_keys=True)+'\n')
    return side
def checkpoint_load(path:Path,model,opt,cfg):
    side=json.loads(path.with_suffix(path.suffix+'.json').read_text())
    if sha(path)!=side['checkpointSha256'] or side['configSha256']!=canon_hash(cfg): raise ValueError('checkpoint integrity/config binding failed')
    b=torch.load(path,map_location='cpu',weights_only=False)
    if b['configSha256']!=canon_hash(cfg) or b['config']!=cfg: raise ValueError('checkpoint internal binding failed')
    model.load_state_dict(b['model']); opt.load_state_dict(b['optimizer'])
    if tensor_hash(model.state_dict().items())!=b['modelStateSha256'] or optimizer_hash(opt)!=b['optimizerStateSha256']: raise ValueError('checkpoint state digest mismatch')
    return b

def sample_causal(rows,tok,step,seq_len):
    r=rows[(step*9973+17)%len(rows)]; ids=[257]+tok.encode(r['text'])+[258]
    if len(ids)<2: ids=[257,258]
    need=seq_len+1
    if len(ids)>need:
        span=len(ids)-need+1; off=(step*37)%span; ids=ids[off:off+need]
    if len(ids)<need: ids=ids+[256]*(need-len(ids))
    x=torch.tensor(ids[:-1],dtype=torch.long)[None,:]; y=torch.tensor(ids[1:],dtype=torch.long)[None,:]; y[y==256]=-100
    return x,y

def sample_sft(rows,tok,step,seq_len):
    r=rows[(step*9967+23)%len(rows)]; q=tok.encode(r['question']); ans=tok.encode(r['response'])+[258]
    # bounded prompt while preserving at least 16 answer tokens when available
    max_prompt=max(2,seq_len-min(16,len(ans))); prompt=([257]+q+[259])[-max_prompt:]
    ids=prompt+ans; ids=ids[:seq_len+1]
    if len(ids)<2: ids=[257,258]
    xids=ids[:-1]; yids=ids[1:]; response_start=max(0,len(prompt)-1)
    y=[(-100 if i<response_start else t) for i,t in enumerate(yids)]
    if len(xids)<seq_len: xids+= [256]*(seq_len-len(xids)); y += [-100]*(seq_len-len(y))
    return torch.tensor(xids,dtype=torch.long)[None,:],torch.tensor(y,dtype=torch.long)[None,:]

def loss_for(model,x,y):
    logits=model(x); return F.cross_entropy(logits.view(-1,V),y.view(-1),ignore_index=-100)
def eval_validation(model,rows,tok,limit,seq_len):
    model.eval(); vals=[]
    with torch.no_grad():
        for i,r in enumerate(rows[:limit]):
            rr={'question':r['question'],'response':r['answer']}; x,y=sample_sft([rr],tok,i,seq_len); vals.append(float(loss_for(model,x,y)))
    model.train(); return sum(vals)/len(vals) if vals else float('nan')
def flatten_weights(model):
    arr=[model.embedding.weight.detach().cpu().numpy().astype('<f4').ravel()]
    for b in model.blocks:
        for x in (b.rms1.weight,b.wq.weight,b.wk.weight,b.wv.weight,b.wo.weight,b.rms2.weight,b.w1.weight,b.w2.weight,b.w3.weight): arr.append(x.detach().cpu().numpy().astype('<f4').ravel())
    arr.append(model.final_rms.weight.detach().cpu().numpy().astype('<f4').ravel()); out=np.concatenate(arr); assert out.size==PARAMS; return out
def fnv(data):
    h=1469598103934665603
    for b in data: h=((h^b)*1099511628211)&0xffffffffffffffff
    return h
def export_ndgm(model,path:Path,fmt:str='fp32'):
    w=flatten_weights(model).astype(np.float32)
    block=0; scale_count=0
    if fmt=='fp32': payload=w.astype('<f4').tobytes(); code=1; data_bytes=len(payload)
    else:
        block=64; limit=127 if fmt=='q8' else 7; qs=[]; scales=[]
        for i in range(0,w.size,block):
            c=w[i:i+block]; mx=float(np.max(np.abs(c))) if c.size else 0.0; sc=(mx/limit) if mx>0 else 1.0; scales.append(sc); qs.extend(np.clip(np.rint(c/sc),-limit,limit).astype(np.int16).tolist())
        if fmt=='q8': data=np.asarray(qs,dtype=np.int8).tobytes(); code=2
        else:
            packed=bytearray()
            for i in range(0,len(qs),2):
                a=int(qs[i])+8; b=(int(qs[i+1])+8) if i+1<len(qs) else 8; packed.append((a&15)|((b&15)<<4))
            data=bytes(packed); code=3
        sb=np.asarray(scales,dtype='<f4').tobytes(); payload=data+sb; data_bytes=len(data); scale_count=len(scales)
    h=bytearray(HEADER); h[:8]=b'NDGMV003'; vals=[HEADER,0x01020304,code,V,D,L,QH,KVH,FF,MAX_CTX,PARAMS,len(payload)]
    for i,v in enumerate(vals): struct.pack_into('<I',h,8+4*i,v)
    struct.pack_into('<f',h,56,0.0); struct.pack_into('<I',h,60,block); struct.pack_into('<Q',h,64,fnv(payload)); struct.pack_into('<I',h,72,scale_count); struct.pack_into('<I',h,76,data_bytes)
    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(h+payload); return sha(path)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output-dir',required=True); ap.add_argument('--checkpoint-dir',required=True); ap.add_argument('--resume'); ap.add_argument('--pretrain-steps',type=int,default=1400); ap.add_argument('--sft-steps',type=int,default=900); ap.add_argument('--run-step-budget',type=int,default=0); ap.add_argument('--seq-len',type=int,default=128); ap.add_argument('--validation-limit',type=int,default=140); ap.add_argument('--seed',type=int,default=7402); ap.add_argument('--pretrain-lr',type=float,default=3e-4); ap.add_argument('--sft-lr',type=float,default=1e-4); ap.add_argument('--weight-decay',type=float,default=0.01); ap.add_argument('--checkpoint-every',type=int,default=100)
    a=ap.parse_args(); subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
    if not (8<=a.seq_len<=MAX_CTX) or a.pretrain_steps<0 or a.sft_steps<0 or not (1<=a.validation_limit<=140): raise SystemExit('invalid bounded config')
    torch.set_num_threads(1); torch.set_num_interop_threads(1); torch.use_deterministic_algorithms(True); torch.backends.mkldnn.enabled=False; random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    tok_path=DATA/'tokenizer-v1.ndtk'; tok=BytePairTokenizer(tok_path); cfg=config_dict(a,tok_path); out=Path(a.output_dir); ckdir=Path(a.checkpoint_dir); out.mkdir(parents=True,exist_ok=True); ckdir.mkdir(parents=True,exist_ok=True)
    sft=read_jsonl(DATA/'sft_train.jsonl'); replay=read_jsonl(DATA/'causal_replay.jsonl'); val=read_jsonl(DATA/'pira_validation.jsonl')
    model=Micro(); assert sum(p.numel() for p in model.parameters())==PARAMS
    opt=torch.optim.AdamW(model.parameters(),lr=a.pretrain_lr,weight_decay=a.weight_decay)
    pre=0; sf=0; phase='pretrain'; init_val=None
    if a.resume:
        b=checkpoint_load(Path(a.resume),model,opt,cfg); pre=int(b['pretrainDone']); sf=int(b['sftDone']); phase=str(b['phase']); init_val=float(b['initialValidationLoss']); print(f'RESUME PASS phase={phase} pretrainDone={pre} sftDone={sf} checkpoint={a.resume}',flush=True)
    budget=a.run_step_budget if a.run_step_budget>0 else 10**18; used=0
    if init_val is None: init_val=eval_validation(model,val,tok,a.validation_limit,a.seq_len)
    print(f'VALIDATION baseline={init_val:.6f} items={a.validation_limit} resumed={bool(a.resume)}',flush=True)
    while pre<a.pretrain_steps and used<budget:
        for g in opt.param_groups:g['lr']=a.pretrain_lr
        x,y=sample_causal(replay,tok,pre,a.seq_len); opt.zero_grad(set_to_none=True); loss=loss_for(model,x,y); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step(); pre+=1;used+=1;phase='pretrain'
        if pre==1 or pre%40==0 or pre==a.pretrain_steps: print(f'PRETRAIN step={pre}/{a.pretrain_steps} loss={float(loss.detach()):.6f}',flush=True)
        if a.checkpoint_every>0 and pre%a.checkpoint_every==0 and pre<a.pretrain_steps:
            checkpoint_write(ckdir/f'checkpoint-pre{pre}-sft{sf}.pt',model,opt,cfg,pre,sf,phase,init_val)
    if pre>=a.pretrain_steps: phase='sft'
    while pre>=a.pretrain_steps and sf<a.sft_steps and used<budget:
        for g in opt.param_groups:g['lr']=a.sft_lr
        # 75% response-only SFT, 25% causal replay
        if sf%4==3: x,y=sample_causal(replay,tok,a.pretrain_steps+sf,a.seq_len)
        else: x,y=sample_sft(sft,tok,sf,a.seq_len)
        opt.zero_grad(set_to_none=True); loss=loss_for(model,x,y); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step(); sf+=1;used+=1;phase='sft'
        if sf==1 or sf%40==0 or sf==a.sft_steps: print(f'SFT step={sf}/{a.sft_steps} loss={float(loss.detach()):.6f}',flush=True)
        if a.checkpoint_every>0 and sf%a.checkpoint_every==0 and sf<a.sft_steps:
            checkpoint_write(ckdir/f'checkpoint-pre{pre}-sft{sf}.pt',model,opt,cfg,pre,sf,phase,init_val)
    if pre<a.pretrain_steps or sf<a.sft_steps:
        cp=ckdir/f'checkpoint-pre{pre}-sft{sf}.pt'; side=checkpoint_write(cp,model,opt,cfg,pre,sf,phase,init_val); print(f'PAUSED_CHECKPOINT_RESUMABLE path={cp} sha256={side["checkpointSha256"]} modelStateSha256={side["modelStateSha256"]}',flush=True); return 3
    final_val=eval_validation(model,val,tok,a.validation_limit,a.seq_len); staged=out/'staging/micro-fp32.ndgm'; asset_sha=export_ndgm(model,staged,'fp32')
    q8_path=out/'staging/micro-q8.ndgm'; q8_sha=export_ndgm(model,q8_path,'q8')
    q4_path=out/'staging/micro-q4.ndgm'; q4_sha=export_ndgm(model,q4_path,'q4')
    rep={'schema':'neuraldesk-generative-training-report-v074-alpha2-v1','status':'EXPERIMENTAL_NOT_PROMOTED','config':cfg,'initialValidationLoss':init_val,'finalValidationLoss':final_val,'validationItems':a.validation_limit,'modelStateSha256':tensor_hash(model.state_dict().items()),'optimizerStateSha256':optimizer_hash(opt),'stagedFp32':{'path':str(staged),'sha256':asset_sha,'bytes':staged.stat().st_size},'stagedQ8':{'path':str(q8_path),'sha256':q8_sha,'bytes':q8_path.stat().st_size},'stagedQ4':{'path':str(q4_path),'sha256':q4_sha,'bytes':q4_path.stat().st_size},'promotionAuthorized':False}
    (out/'TRAINING_REPORT.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n'); cp=ckdir/f'checkpoint-terminal-pre{pre}-sft{sf}.pt'; checkpoint_write(cp,model,opt,cfg,pre,sf,'terminal',init_val)
    print(f'TRAINING_TERMINAL_NOT_PROMOTED validation={final_val:.6f} modelStateSha256={rep["modelStateSha256"]} stagedFp32Sha256={asset_sha}',flush=True); return 0
if __name__=='__main__': raise SystemExit(main())
