#!/usr/bin/env python3
"""Privacy-safe physical device lab packet validator. Fixtures never imply certification."""
from __future__ import annotations
import hashlib,json,re
REQUIRED={'RUN','MEMORY','THERMAL','ENERGY','NETWORK','LIFECYCLE','ACCESSIBILITY'}
NETWORK={'WIFI','CELLULAR','METERED','OFFLINE'}
LIFECYCLE={'COLD_START','MEMORY_PRESSURE','STORAGE_PRESSURE','KILL_RESUME','NETWORK_SWITCH','PERMISSION_REVOKED','UPDATE_INTERRUPTED','OUTBOX_IDEMPOTENCY','FALLBACK'}
FORBIDDEN=re.compile(r'(imei|imsi|android.?id|advertis|udid|mac.?address|ip.?address|prompt|response|output|api.?key|authorization|password|token)',re.I)
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def packet_hash(p):d={k:v for k,v in p.items() if k!='packetSha256'};return hashlib.sha256(canonical(d)).hexdigest()
def validate_packets(packets):
 if not packets:return {'ready':False,'reason':'EMPTY'}
 kinds=set(); networks=set(); lifecycle=set(); last=-1
 for p in packets:
  raw=json.dumps(p,sort_keys=True)
  if FORBIDDEN.search(raw):return {'ready':False,'reason':'PRIVACY_GUARD'}
  if p.get('sequence',-1)<=last:return {'ready':False,'reason':'NON_MONOTONIC_SEQUENCE'}
  last=p['sequence'];kind=p.get('kind');kinds.add(kind)
  if p.get('packetSha256')!=packet_hash(p):return {'ready':False,'reason':'PACKET_HASH_MISMATCH'}
  if kind=='NETWORK':networks.add(p.get('scenario'))
  if kind=='LIFECYCLE':lifecycle.add(p.get('scenario'))
 missing=REQUIRED-kinds
 return {'ready':not missing and NETWORK<=networks and LIFECYCLE<=lifecycle,'missingKinds':sorted(missing),'missingNetwork':sorted(NETWORK-networks),'missingLifecycle':sorted(LIFECYCLE-lifecycle),'physicalRunPerformed':False,'certified':False}
