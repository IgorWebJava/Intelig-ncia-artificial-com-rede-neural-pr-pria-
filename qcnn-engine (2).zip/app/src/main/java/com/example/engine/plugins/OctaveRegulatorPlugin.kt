package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Módulo 4: Regulador de Oitavas & Zoom Cognitivo Recursivo (KODEX ALEPH v12.5).
 * Mede a complexidade semântica do prompt para determinar a Oitava Cognitiva (1 a 5).
 */
class OctaveRegulatorPlugin : IQcnnPlugin {
    override val pluginId: String = "octave_regulator"
    override var isEnabled: Boolean = true

    private val palavrasChaveComplexidade = listOf(
        "como", "por que", "porque", "explique", "analise", "descreva",
        "detalhe", "compare", "relacione", "fundamento", "profundo"
    )

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val promptLower = context.prompt.lowercase()
        val palavras = promptLower.split(Regex("\\s+")).filter { it.isNotBlank() }
        val numPalavras = palavras.size

        var oitava = 1
        val matches = palavrasChaveComplexidade.count { promptLower.contains(it) }
        if (matches > 0) {
            oitava += min(2, matches)
        }
        if (numPalavras > 8) {
            oitava += 1
        }
        if (numPalavras > 15) {
            oitava += 1
        }

        oitava = min(5, max(1, oitava))
        context.metadata["oitava_cognitiva"] = oitava

        val fatorEscala = (1.61803398875).pow((oitava - 1) * 0.5)
        context.metadata["fator_escala_oitava"] = (fatorEscala * 1000).toInt() / 1000.0

        if (context.totalFrequencyHz > 0) {
            context.totalFrequencyHz *= fatorEscala
        }

        return context
    }
}
