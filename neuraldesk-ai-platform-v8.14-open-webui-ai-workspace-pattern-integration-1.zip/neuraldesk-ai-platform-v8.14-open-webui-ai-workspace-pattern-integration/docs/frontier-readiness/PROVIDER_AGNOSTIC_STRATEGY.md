# Provider-Agnostic Strategy

NeuralDesk must depend on capabilities rather than vendor APIs.

## Required adapter classes
- frontier cloud model providers;
- self-hosted high-throughput serving;
- local/portable inference;
- embeddings/rerank providers;
- voice/realtime providers;
- image/video providers.

## Selection inputs
quality, modality, latency, context window, tool support, data residency, cost, health, rate limits and policy.

## Mandatory fallback
Every critical capability documents at least one fallback path or explicit degraded mode.
