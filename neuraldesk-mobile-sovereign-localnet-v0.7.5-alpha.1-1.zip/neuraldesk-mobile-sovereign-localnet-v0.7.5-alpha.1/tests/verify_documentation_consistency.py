#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / 'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))
version = manifest['version']

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

# Every top-level documentation artifact is registered, and every registered doc exists.
doc_paths = sorted(f'docs/{p.name}' for p in (ROOT / 'docs').glob('*.md'))
registered = manifest['canonicalDocs']
assert registered[0] == 'memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md'
assert sorted(registered[1:]) == doc_paths, (registered, doc_paths)
for rel in registered:
    assert (ROOT / rel).is_file(), rel

# Current docs may discuss v0.5 historically, but none may advertise itself as current v0.5.
for rel in doc_paths:
    first = (ROOT / rel).read_text(encoding='utf-8').splitlines()[0]
    assert not re.search(r'\bv0\.5\b', first), f'stale current title: {rel}: {first}'

readme = (ROOT / 'README.md').read_text(encoding='utf-8')
current = (ROOT / 'docs/CURRENT_STATE.md').read_text(encoding='utf-8')
architecture = (ROOT / 'docs/ARCHITECTURE.md').read_text(encoding='utf-8')
android_doc = (ROOT / 'docs/ANDROID_BUILD.md').read_text(encoding='utf-8')
assert f'v{version}' in readme
assert f'v{version}' in current
assert f'v{version}' in current.splitlines()[0], current.splitlines()[0]
assert f'versionName: `{version}`' in android_doc or f'versionName: **`{version}`**' in android_doc or f'versionName: `{version}`;' in android_doc
assert manifest['architecture']['orchestrator'] in architecture
assert 'CanonicalAssetStore' in android_doc
assert 'missing -> install' in android_doc
assert 'stale -> replace' in android_doc

# Real asset bytes are stronger evidence than manifest prose.
for spec in manifest['models'].values():
    p = ROOT / spec['path']
    assert p.is_file(), spec['path']
    assert p.stat().st_size == spec['bytes'], (spec['path'], p.stat().st_size, spec['bytes'])
    assert sha(p) == spec['sha256'], spec['path']

# Android public identity must agree across build, runtime identity and UI wiring.
gradle = (ROOT / 'android/app/build.gradle.kts').read_text(encoding='utf-8')
identity = (ROOT / 'android/app/src/main/java/com/neuraldesk/localnet/RuntimeIdentity.kt').read_text(encoding='utf-8')
main = (ROOT / 'android/app/src/main/java/com/neuraldesk/localnet/MainActivity.kt').read_text(encoding='utf-8')
web = (ROOT / 'android/app/src/main/java/com/neuraldesk/localnet/WebContextClient.kt').read_text(encoding='utf-8')
wiki = (ROOT / 'android/app/src/main/java/com/neuraldesk/localnet/WikipediaResearchClient.kt').read_text(encoding='utf-8')
layout = (ROOT / 'android/app/src/main/res/layout/activity_main.xml').read_text(encoding='utf-8')
store = (ROOT / 'android/app/src/main/java/com/neuraldesk/localnet/CanonicalAssetStore.kt').read_text(encoding='utf-8')
assert f'versionCode = {manifest["android"]["versionCode"]}' in gradle
assert f'versionName = "{version}"' in gradle
assert f'const val VERSION = "{version}"' in identity
assert 'RuntimeIdentity.VERSION' in main
assert 'CanonicalAssetStore.install' in main
assert 'RuntimeIdentity.USER_AGENT' in web and 'RuntimeIdentity.USER_AGENT' in wiki
assert 'NeuralDesk LocalNet v0.5' not in layout
assert 'StandardCopyOption.ATOMIC_MOVE' in store
assert 'InputStream' in store
assert 'MessageDigest.getInstance("SHA-256")' in store
assert '.readBytes()' not in store

# Trainer enforcement must exist before canonical export anchors.
retriever = (ROOT / 'training/train_knowledge_retriever.py').read_text(encoding='utf-8')
pointer = (ROOT / 'training/train_context_pointer.py').read_text(encoding='utf-8')
assert retriever.index('knowledge retriever below mandatory Golden') < retriever.index('export_model(model, args.out)')
assert pointer.index('context pointer below mandatory Golden') < pointer.index('export(model, args.out)')

# Release evidence generation must be bound to the manifest version, not a generic PASS.
metadata = (ROOT / 'scripts/generate_release_metadata.py').read_text(encoding='utf-8')
verify = (ROOT / 'scripts/verify.sh').read_text(encoding='utf-8')
sanitize = (ROOT / 'scripts/verify_sanitize.sh').read_text(encoding='utf-8')
assert "version = manifest['version']" in metadata
assert "pass_marker = f'{suite.upper()} PASS version={version}'" in metadata
assert "RECEIPTS PASS version" in metadata
assert "digest mismatch" in metadata
assert manifest['verificationPolicy']['verifyMarker'] == f'VERIFY PASS version={version}'
assert manifest['verificationPolicy']['sanitizerMarker'] == f'SANITIZER PASS version={version}'
assert "VERIFY PASS version=%s" in verify
assert "SANITIZER PASS version=%s" in sanitize

# Documentation index must enumerate every top-level doc by basename.
index = (ROOT / 'docs/DOCUMENTATION_INDEX.md').read_text(encoding='utf-8')
for rel in doc_paths:
    assert Path(rel).name in index, f'missing from documentation index: {rel}'

print(
    'documentation-code-asset-consistency PASS',
    f'version={version}',
    f'docs={len(doc_paths)}',
    f'assets={len(manifest["models"])}'
)
