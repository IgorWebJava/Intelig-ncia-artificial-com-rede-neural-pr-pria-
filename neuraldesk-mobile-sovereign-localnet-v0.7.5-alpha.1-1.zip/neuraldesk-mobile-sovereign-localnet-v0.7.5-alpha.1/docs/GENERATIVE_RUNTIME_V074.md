# Generative Runtime & Training Candidate — v0.7.4-alpha.2

**Status:** `CANDIDATE_NOT_PROMOTED / ASSISTANT_GENERATIVE_ROUTE_DISABLED`  
**Rollback:** final atestado `v0.7.3-alpha.1`  
**Lineage:** reconstrução nova; não é byte-idêntica ao workspace perdido `v0.7.4-alpha.1`.

## Runtime C99

Owner único: `core/src/nd_generative.c` + `core/include/nd_generative.h`. O runtime implementa Transformer causal first-party com `vocab=512`, `dim=160`, 6 camadas, 10 query heads, 2 KV heads, `ffn=448`, contexto máximo 256, RMSNorm, GQA, RoPE em pares adjacentes, SwiGLU e embedding/output tied. A topologia contém **1.742.880 parâmetros**.

Formato mecânico: `NDGM v3`. O loader valida header, dimensões, tamanho e checksum do payload e usa `mmap` read-only. Os formatos estruturais são FP32, Q8 e Q4. Os testes de mecânica usam fixtures determinísticas criadas em `build/`; essas fixtures **não são modelos aprovados** e nunca entram em `models/`.

Mecânicas implementadas e separadas de qualidade dos pesos: full-forward oracle independente, inferência incremental, paged KV, copy-on-write/refcount, prefix reuse e speculative greedy target verification com negative control de rejection/rollback. `speedupClaimed=false` até benchmark físico futuro.

## Corpus governado

`training/materialize_generative_v074.py` cria bytes congelados sob `training/data/generative_v074/`. A fonte Pirá verificável preserva 1.141 registros train e 140 validation. Os 140 validation são `EVALUATION_ONLY` e são reservados antes da inclusão de qualquer fonte treinável. O corpus adiciona 201 Q/A first-party existentes somente durante materialização; o trainer não lê `knowledge_base.py` dinamicamente.

Materialização atual: 1.342 SFT + 1.342 replay causal + 140 validation; `globalQuestionCrossSplitLeakage=0`. As 48 instruções autoradas históricas não foram recuperadas e são registradas como `NOT_RECOVERED_DO_NOT_FABRICATE`.

## Tokenizer

`NDTK v1` possui 512 IDs: 256 bytes, 4 especiais e 252 bigramas de bytes aprendidos exclusivamente nos 1.342 registros treináveis. Validation utilizado no fitting: **0**. O decoder C99 é byte-reversível para tokens textuais e rejeita asset corrompido.

## Treinamento e checkpoint

`training/train_generative_micro_v074.py` é stage-only: CPU determinístico, MKLDNN desligado, inicialização `std=0.02`, AdamW, pretraining causal, mixed-SFT response-only com 25% causal replay, clipping e checkpoint/resume integrity-bound. Checkpoint vincula arquitetura, configuração, corpus e tokenizer; resume com binding diferente falha fechado.

O trainer escreve somente diretórios externos/staging. Ele **não** pode escrever modelo generativo em `models/`, não assina promotion e não ativa serving. A autoridade separada continua sendo `scripts/model_authority.py` e só poderá ser estendida depois de qualidade independente.

## Gates antes de qualquer promoção

1. mecânica C99 + corruption negative controls;
2. corpus/provenance/leakage;
3. tokenizer reversível + corruption;
4. Python↔C FP32 forward parity;
5. uninterrupted ↔ pause/resume equivalence;
6. 140 Pirá validation + seis probes holdout brutos;
7. qualidade/paridade próprias FP32/Q8/Q4 (Q8 >=90% top-1; Q4 >=75% top-1, além dos probes);
8. duas reproduções finais determinísticas;
9. promotion authority independente Ed25519;
10. safety precheck + output postcheck antes de integrar ao assistant;
11. todos os gates herdados, ASan/UBSan, Android/JNI e ZIP reextraído.

Até esses gates terminarem, `promotionAuthorized=false`, `assistantActivated=false` e `servingActivated=false` são invariantes obrigatórias.
