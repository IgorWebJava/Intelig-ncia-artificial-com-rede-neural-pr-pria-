-- NeuralDesk V6.9 — PostgreSQL data-platform foundation
-- Server-side database schema. Never expose DB credentials to browser pages.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS platform;
CREATE SCHEMA IF NOT EXISTS configuration;
CREATE SCHEMA IF NOT EXISTS audit;

CREATE TABLE IF NOT EXISTS platform.tenants (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    status text NOT NULL DEFAULT 'active',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.workspaces (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES platform.tenants(id),
    name text NOT NULL,
    status text NOT NULL DEFAULT 'active',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.projects (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id uuid NOT NULL REFERENCES platform.workspaces(id),
    name text NOT NULL,
    status text NOT NULL DEFAULT 'active',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS configuration.module_registry (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    module_key text NOT NULL UNIQUE,
    display_name text NOT NULL,
    page_path text,
    api_namespace text NOT NULL,
    event_namespace text NOT NULL,
    config_namespace text NOT NULL,
    owner text NOT NULL,
    enabled boolean NOT NULL DEFAULT true,
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS configuration.config_versions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    version_no bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
    environment text NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    description text,
    created_by text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz
);

CREATE TABLE IF NOT EXISTS configuration.system_config (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    namespace text NOT NULL,
    config_key text NOT NULL,
    value jsonb NOT NULL,
    value_type text NOT NULL DEFAULT 'json',
    scope_type text NOT NULL, -- global | environment | tenant | workspace | project | module | user
    scope_id uuid,
    environment text,
    version_id uuid NOT NULL REFERENCES configuration.config_versions(id),
    status text NOT NULL DEFAULT 'effective',
    locked boolean NOT NULL DEFAULT false,
    owner text NOT NULL,
    updated_by text NOT NULL,
    config_hash text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE(namespace, config_key, scope_type, scope_id, environment, version_id)
);

CREATE INDEX IF NOT EXISTS idx_system_config_lookup
ON configuration.system_config(namespace, config_key, scope_type, scope_id, environment, status);

CREATE INDEX IF NOT EXISTS idx_system_config_value_gin
ON configuration.system_config USING gin(value);

CREATE TABLE IF NOT EXISTS configuration.feature_flags (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    flag_key text NOT NULL UNIQUE,
    description text,
    enabled boolean NOT NULL DEFAULT false,
    environment text,
    scope_type text NOT NULL DEFAULT 'global',
    scope_id uuid,
    rollout_percent numeric(5,2) CHECK (rollout_percent BETWEEN 0 AND 100),
    rules jsonb NOT NULL DEFAULT '{}'::jsonb,
    version_id uuid REFERENCES configuration.config_versions(id),
    owner text NOT NULL,
    updated_by text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS configuration.integration_registry (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_key text NOT NULL UNIQUE,
    integration_type text NOT NULL,
    status text NOT NULL DEFAULT 'disabled',
    endpoint_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    secret_ref text, -- reference only; never plaintext secret
    environment text,
    owner text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.outbox_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    event_type text NOT NULL,
    event_version integer NOT NULL DEFAULT 1,
    tenant_id uuid,
    workspace_id uuid,
    project_id uuid,
    trace_id text,
    correlation_id text,
    payload jsonb NOT NULL,
    occurred_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz,
    publish_attempts integer NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_outbox_unpublished
ON platform.outbox_events(occurred_at)
WHERE published_at IS NULL;

CREATE TABLE IF NOT EXISTS audit.audit_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    occurred_at timestamptz NOT NULL DEFAULT now(),
    event_type text NOT NULL,
    actor_type text NOT NULL,
    actor_id text,
    tenant_id uuid,
    workspace_id uuid,
    project_id uuid,
    module text,
    resource_type text,
    resource_id text,
    action text NOT NULL,
    status text NOT NULL,
    severity text,
    risk text,
    trace_id text,
    correlation_id text,
    before_value jsonb,
    after_value jsonb,
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    integrity_hash text,
    previous_hash text
);

CREATE INDEX IF NOT EXISTS idx_audit_time ON audit.audit_events(occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_trace ON audit.audit_events(trace_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit.audit_events(actor_type, actor_id);

-- Example module registry seed data.
INSERT INTO configuration.module_registry
(module_key, display_name, page_path, api_namespace, event_namespace, config_namespace, owner)
VALUES
('chat','Chat Workspace','chat.html','/chat','chat','chat','AI Platform'),
('operations','AI Operations','dashboard-center.html','/operations','ops','operations','Platform/SRE'),
('training','Training Studio','training.html','/training','training','training','AI Platform'),
('knowledge','Knowledge Center','knowledge-center.html','/knowledge','knowledge','knowledge','Knowledge Platform'),
('tools','Tool Center','tools-center.html','/tools','tools','tools','Platform'),
('agents','Agent Studio','agents.html','/agents','agents','agents','AI Platform'),
('settings','User Settings','settings.html','/preferences','settings','preferences','Platform'),
('audit','Audit Center','audit-center.html','/audit','audit','audit','Security'),
('system-config','System Configuration','system-config-center.html','/config','config','config','Platform')
ON CONFLICT (module_key) DO NOTHING;
