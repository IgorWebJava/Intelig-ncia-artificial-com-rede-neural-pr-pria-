# Memória Mestre do Projeto — NeuralDesk V8.11

## Estado atual

NeuralDesk é um Intelligence Workspace OS modular. V8.11 é uma evolução coordenada da interface e da documentação do futuro Neural Engine. A interface canônica agora é V8.11, preserva as mecânicas V8.10/V8.2 por compatibilidade e adiciona `cooperative-engine-bridge-v1` sem introduzir execução real do Neural Engine.

## Interface atual

- 10 módulos canônicos.
- 106 capabilities atuais resolvidas.
- Perfis estáveis: `intelligence-experience-v2`, `workspace-runtime-v2`, `neuraldesk-intelligence-design-v2`, `module-quality-v2`.
- Perfil aditivo V8.11: `cooperative-engine-bridge-v1`.
- JavaScript permanece module-owned e limitado a interação/local simulation; não executa backend/model/agent/tool/network runtime.
- Root HTML files são aliases/redirecionadores de compatibilidade, não UIs canônicas.

## Neural Engine futuro

`neural-engine/` contém **94 módulos documentais**, **391 capabilities futuras** e rastreabilidade para **149 mecânicas de interface**. Todos os 94 módulos estão mapeados a uma superfície de interface em `platform/engine-ui-bridge/registry.json`. O Neural Engine continua `DOCUMENTATION_ONLY / NOT_IMPLEMENTED`.

## Regra central de evolução

`preserve → extend → bridge`

- preservar semântica existente;
- estender de forma aditiva/versionada;
- conectar todo novo módulo/capability futuro a uma superfície/contrato de interface;
- bloquear regressões pelo `tools/validate_non_regression.py`;
- bloquear engine modules sem owner UI pelo `tools/validate_engine_ui_compatibility.py`.

Nunca confundir `IMPLEMENTED-TEMPLATE-UI` / `UI_CONTRACT_READY` com `IMPLEMENTED-ENGINE`.

## Continuidade

Antes de modificar: leia `ESTADO_ATUAL.json`, `docs/CURRENT_STATE.md`, `docs/SOURCE_OF_TRUTH.md`, `docs/architecture/CURRENT_ENGINE_UI_COMPATIBILITY.md`, `docs/ai/AI_READ_FIRST.md`, `habilidades/AI_HANDOFF.md` e os docs atuais dos módulos UI/Engine envolvidos.

## V8.11 — Cooperative Non-Regressive Engine/UI Evolution

- Interface e documentação do Neural Engine passam a evoluir juntas.
- 106 capabilities atuais resolvidas.
- 94 módulos futuros / 391 capabilities do engine.
- 149 mecânicas UI↔Engine rastreadas.
- 94/94 módulos do engine com ownership de interface.
- Engine Bridge local de interface; nenhum backend/engine executável.
- Baseline semântico V8.10 preservado por gate automático.

## Programa Frontier V8.7

O objetivo futuro é primeiro alcançar paridade executável usando providers/modelos frontier substituíveis, depois diferenciar o NeuralDesk pela integração de Projects, Agents, Tools, Knowledge, Artifacts, Evaluation, Operations, Audit, Provenance, Trust e modelos cloud/local/próprios.

O programa possui 9 ondas P00–P08 e maturidade D0–D6. Nesta release todos os 64 módulos do Neural Engine permanecem D0/documentation-only.

Nunca afirmar que NeuralDesk superou outro sistema sem benchmark reproduzível no workload/metric definido.

## V8.8 — Kimi K3 Engineering Research Integration

Research from `FareedKhan-dev/kimi-k3-in-c`, the official `MoonshotAI/Kimi-K3` repository and the Kimi K3 technical report was integrated as provider-agnostic documentation. The Neural Engine remains non-executable. Key additions: memory-aware weight streaming, expert-weight cache, strict model artifact validation, deterministic/reference parity, KDA, Attention Residuals, Stable LatentMoE, expert balance training and long-horizon agentic RL.

## V8.9 — Qwen3-Omni Native Omni-Modal Research Integration

Added provider-agnostic blueprint owners for semantic/expression decoupling, audio perception, temporal multimodal alignment, realtime scheduling, modality admission, neural speech codec/rendering, omni-modal curriculum/post-training/evaluation. No executable Neural Engine code.


## V8.10 — DeepSeek Harness Agent Runtime Architecture Integration

- Documentation-only release; canonical V8.2 interface unchanged.
- Neural Engine: 94 future modules / 391 capabilities.
- Added semantic session durability, replay, guarded tool effects, provider-federated subagents, compaction/spill, schema evolution, runtime invariants, benchmark ablation and governed dynamic extension patterns.
- No Neural Engine runtime/source implementation introduced.


## V8.11 — Cooperative Non-Regression
Interface and Neural Engine documentation now evolve together. Preserve V8.10 semantics, extend capabilities additively, and bridge every future engine module to an interface owner. Engine remains NOT_IMPLEMENTED.


## Estado coordenado V8.11
94 future modules / 391 capabilities / 149 mapped UI mechanics. Current UI/platform registry resolves 106 capabilities. Engine execution remains NOT_IMPLEMENTED.


## V8.13 — Coding Intelligence
The current release is V8.13. Preserve V8.12 semantics and the `preserve → extend → bridge` rule. Coding Intelligence uses `coding-intelligence-patterns-v1`; future execution lives under `neural-engine/modules/13-coding-intelligence-runtime/` and remains NOT IMPLEMENTED.

## V8.14 — Open WebUI AI Workspace Pattern Integration
The project added `open-webui-ai-workspace-patterns-v1` while preserving V8.13. Current platform: 157 resolved capabilities; future Neural Engine: 145 modules / 757 capabilities; 199 UI↔Engine mechanics. Open WebUI is research only; no upstream code is copied.
