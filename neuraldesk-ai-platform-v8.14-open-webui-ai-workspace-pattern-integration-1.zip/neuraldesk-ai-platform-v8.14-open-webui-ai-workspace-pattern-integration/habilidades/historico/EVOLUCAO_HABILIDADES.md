<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Evolução das Habilidades — NeuralDesk

A competência de desenvolvimento foi crescendo junto com o sistema:

```text
HTML/CSS UI
→ Knowledge/Tools/Ops modeling
→ documentation/memory
→ Training/Evaluation
→ Audit/Security
→ PostgreSQL/Data Platform/Eventing
→ Modular Contracts/Capabilities
→ AI Fabric/Multimodal
→ Responsive TV/Mobile
→ Module-owned Testing
→ Skills/Tools Capability Registry
```

V7.4 formaliza esse conhecimento para futuras IAs/equipes.
→ Agent Projects / Runtime Skills / Multi-Agent Orchestration
```

V7.5 formaliza o design de agentes do usuário separado das habilidades de desenvolvimento.

- V7.6 — Module Preview Registry, geração automática de previews e validação de freshness por hash.
