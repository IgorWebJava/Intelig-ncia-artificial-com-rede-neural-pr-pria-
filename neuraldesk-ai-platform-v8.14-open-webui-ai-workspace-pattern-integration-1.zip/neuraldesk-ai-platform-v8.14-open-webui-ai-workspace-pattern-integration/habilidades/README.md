<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->
# Habilidades — NeuralDesk V7.7

This folder is the portable development knowledge layer.

```text
memória/     = what/why/current state
habilidades/ = how/skills/capabilities/tools/workflows
```

## Read order

1. `HABILIDADES_MESTRE_PROJETO.md`
2. `ESTADO_ATUAL_HABILIDADES.json`
3. `AI_HANDOFF.md`
4. `REGISTRO_HABILIDADES.json`
5. `REGISTRO_FERRAMENTAS.json`
6. `capabilities/CAPABILITY_REGISTRY.json`
7. applicable workflow

Never store credentials, production secrets, private data or private chain-of-thought.


## V8.12 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
