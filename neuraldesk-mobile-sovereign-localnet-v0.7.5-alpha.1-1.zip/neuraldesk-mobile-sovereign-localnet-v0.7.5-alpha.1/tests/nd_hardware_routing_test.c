#include "nd_resource.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    NDHardwareCapabilities c;
    NDHardwareRoute r;
    memset(&c, 0, sizeof(c));
    c.ram_mb = 8192ul;
    c.logical_cores = 8u;
    c.is_64bit = 1;
    c.abi = ND_ABI_ARM64;
    c.cpu_c99_executor_available = 1;
    c.gpu_detected = 1;
    c.npu_detected = 1;

    r = nd_resource_route_hardware(&c, ND_PROVIDER_AUTO, 0);
    if (r.status != ND_ROUTE_OK || r.selected != ND_PROVIDER_CPU_C99 ||
        r.profile != ND_PROFILE_MOBILE_PLUS || r.automatic_default_switch != 0) return 1;

    r = nd_resource_route_hardware(&c, ND_PROVIDER_GPU, 0);
    if (r.status != ND_ROUTE_PROVIDER_UNAVAILABLE || !r.accelerator_detected_but_unavailable ||
        r.executor_available) return 2;

    r = nd_resource_route_hardware(&c, ND_PROVIDER_NPU, 0);
    if (r.status != ND_ROUTE_PROVIDER_UNAVAILABLE || !r.accelerator_detected_but_unavailable ||
        r.executor_available) return 3;

    r = nd_resource_route_hardware(&c, ND_PROVIDER_CPU_C99, 1);
    if (r.status != ND_ROUTE_NOT_CERTIFIED) return 4;
    c.physical_hardware_certified = 1;
    r = nd_resource_route_hardware(&c, ND_PROVIDER_CPU_C99, 1);
    if (r.status != ND_ROUTE_OK || r.selected != ND_PROVIDER_CPU_C99) return 5;

    c.ram_mb = 2048ul;
    c.logical_cores = 8u;
    c.is_64bit = 1;
    c.physical_hardware_certified = 0;
    r = nd_resource_route_hardware(&c, ND_PROVIDER_AUTO, 0);
    if (r.status != ND_ROUTE_OK || r.profile != ND_PROFILE_MICRO) return 6;

    if (strcmp(nd_resource_abi_name(ND_ABI_ARM64), "ARM64") != 0 ||
        strcmp(nd_resource_provider_name(ND_PROVIDER_CPU_C99), "CPU_C99") != 0) return 7;

    puts("HARDWARE_ROUTING PASS auto=CPU_C99 gpu_fail_closed=true npu_fail_closed=true physical_cert_gate=true privacyProfileNoIdentifiers=true");
    return 0;
}
