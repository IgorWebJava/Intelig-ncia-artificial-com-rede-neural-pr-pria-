# Historical Deep Audit — v0.7.2-alpha.1

Scope: all recoverable NeuralDesk conversations, persisted Library artifacts, complete Mobile Runtime ZIP lineage v0.1-v0.63, LocalNet ZIPs, V7/V8 artifacts through V8.22, and the frozen v0.7.1 release.

## Method

Capabilities were compared by executable owner, contracts, tests and final-release evidence rather than version number. A historical feature was ported only when it added a property absent from v0.7.1 and could be reexpressed without external AI dependencies or parallel authorities. Documentation-only V8 blueprints were treated as design inputs, not implementation evidence.

## Deep findings beyond v0.7.1

| Historical mechanism | Strongest evidence | v0.7.2 decision |
|---|---|---|
| Local Projects | early Mobile Runtime executable core | PORT metadata owner |
| Durable outbox + dependencies | v0.22-v0.24 executable | PORT as local-task-only outbox |
| Adaptive network policy | early executable core | PORT |
| Pilot/master kill | v0.16 executable | PORT and enforce in NDAssistant/JNI |
| Model acquisition preflight | early executable core | PORT assessment only |
| Benchmark evaluation | early executable core | PORT `MEASURED_NOT_CERTIFIED` |
| Artifact Manager | v0.13 executable | DEFER: no current artifact UI/consumer; model authority already owns model artifacts |
| Image preprocessing | early executable core | DEFER until a visual model is promoted |
| Companion pairing | early executable core | DEFER: no current desktop companion owner in LocalNet |
| Remote-provider router/outbox delivery | pre-sovereign line | DO NOT PORT: conflicts with first-party-only inference |
| API/RBAC backend v0.29-v0.30 | executable server line | DO NOT duplicate in single-user native app; security patterns preserved where applicable |
| Tensor/autograd/training v0.34-v0.40 | executable reference/training line | current specialist trainers + integrity checkpoint/model authority are stronger for active models |
| Paged KV/speculative/weight streaming | v0.47-v0.50 | only relevant when a generative backbone is promoted; keep as future gate, no fake active decoder |
| Cross-backend observability | v0.51 | current Run Journal + Device Lab + model authority preserve bounded local evidence; production serving still absent |
| Android shared kernel/JVM/DEX | v0.54-v0.62 | current Kotlin/JNI is the active app boundary; preserve pre-cert truth boundary, do not add parallel DEX runtime |
| Curated corpus/Golden | v0.63 | governance/holdout principles preserved; historical Pirá full candidate remains non-activated |
| SWA/checkpoint averaging | V8.20/V8.22 docs only | IMPLEMENT executable compatible candidate builder, never auto-promote |
| Agents/coding/multimodal/GPU/NPU | V8 docs/blueprints | DEFER until executable first-party owner + evaluation exists |

## Current convergence result

v0.7.2 keeps v0.7.1 as direct rollback and adds offline continuity/control mechanics without altering neural weights or promoted datasets. The release must rerun all inherited 12/12, 7/7, 11/11, Live QA, model, Safety, RAG, Android, sanitizer and package-reextract gates before promotion.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
