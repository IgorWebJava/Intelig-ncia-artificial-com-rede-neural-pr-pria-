#!/usr/bin/env python3
"""Generate a deterministic post-implementation holdout for evidence coverage.

The values/entities differ from the pointer training corpus.  The suite stresses
multi-goal decomposition, temporal conflicts, sentence reordering, three-goal
coverage and fail-closed behavior when one requested fact is absent.
"""
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "evaluation" / "fixtures" / "context_composition_holdout.tsv"
RNG = random.Random(930031)

NAMES = ["Nara", "Otávio", "Helena", "Samuel", "Yara", "Miguel", "Cecília", "Davi", "Iara", "Tomás"]
OLD_COLORS = ["azul", "branca", "preta", "cinza", "amarela", "marrom"]
NEW_COLORS = ["verde-limão", "magenta", "cobre", "índigo", "esmeralda", "laranja"]
STATUSES = ["operacional", "em revisão", "homologado", "ativo", "em validação", "estável"]


def build():
    rows = []
    for i in range(80):
        entity = f"Atlas-{i+900:03d}"
        old = f"LEG-{2100+i}"
        new = f"NX-{8100+i}"
        owner = NAMES[i % len(NAMES)]
        old_color = OLD_COLORS[i % len(OLD_COLORS)]
        new_color = NEW_COLORS[(i * 5 + 1) % len(NEW_COLORS)]
        status = STATUSES[(i * 3 + 2) % len(STATUSES)]
        sentences = [
            f"O identificador anterior de {entity} era {old}.",
            f"O identificador atual de {entity} é {new}.",
            f"{owner} responde oficialmente por {entity}.",
            f"A cor anterior de {entity} era {old_color}.",
            f"A cor atual de {entity} é {new_color}.",
            f"O status de {entity} está {status}.",
            f"O relatório de {entity} foi revisado pela equipe local.",
        ]
        RNG.shuffle(sentences)
        context = " ".join(sentences)
        cases = [
            (f"Qual é o identificador atual de {entity} e quem responde por ele?", f"{new};{owner}", old),
            (f"Quem responde oficialmente por {entity} e qual é a cor atual?", f"{owner};{new_color}", old_color),
            (f"Qual era a cor anterior de {entity} e qual é a cor atual?", f"{old_color};{new_color}", "-"),
            (f"Qual é o identificador atual de {entity} e qual é o status?", f"{new};{status}", old),
            (f"Diga o identificador atual de {entity}, quem responde por ele e qual é a cor atual.", f"{new};{owner};{new_color}", f"{old};{old_color}"),
            (f"Quem responde por {entity} e qual é o identificador atual?", f"{owner};{new}", old),
            (f"Qual é o identificador atual de {entity} e quando será lançado?", "Não encontrei evidência suficiente", new),
            (f"Qual é a temperatura do núcleo de Netuno no observatório Quasar-{i:03d}?", "Não encontrei evidência suficiente", "-"),
        ]
        rows.extend((required, forbidden, question, context) for question, required, forbidden in cases)
    return rows


def main():
    rows = build()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join("\t".join(row) for row in rows) + "\n", encoding="utf-8")
    print(f"context composition holdout materialized: {len(rows)} rows")


if __name__ == "__main__":
    main()
