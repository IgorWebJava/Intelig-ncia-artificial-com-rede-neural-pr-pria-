# v0.7.5 security addendum

Hardware routing não persiste hostname, CPU model, serial, device ID ou network ID. GPU/NPU detection sem executor não concede capability. Run Journal continua sem prompt/resposta brutos e agora registra apenas fases/status/source sanitizados. Streaming consulta cancel/deadline durante prefill e decode; nenhum desses mecanismos ativa serving público ou modelo não promovido.

# Security and Grounding — v0.7.4-alpha.2

## Mobile lifecycle/privacy v0.7.3

JNI usa mutex/condition e `free()` aguarda idle após sinalizar cancelamento. Assets são verificados por SHA-256 incremental antes do replace. RAG persistido possui checksum/version/trailing-byte rejection. Research Memory é default-off e, quando habilitada, usa AES-GCM + Android Keystore; não persiste a resposta do assistant. Esses controles são host/estrutura e não equivalem a pentest ou certificação de aparelho.


Safety bounded executa prompt precheck e output postcheck; `universalSafetyClaim=false`. Unknown/current events permanecem fail-closed. Promotion/activation Ed25519 são separadas e a chave privada não é distribuída. O journal não persiste prompt/output bruto. Device Lab aplica privacy guard.

## Fail-closed de artefatos

Os quatro assets neurais/KB herdados são submetidos a corrupção controlada em `verify_fail_closed.py`: **12/12** variantes rejeitadas. O NDOS possui gate independente: **4/4** corrupções rejeitadas (magic, truncamento, trailing bytes e bucket count inválido). Não se soma esses números como se fossem um único corpus de segurança; são duas superfícies verificadas separadamente.

## Grounding contextual

- entity-match sozinho não cobre uma pergunta;
- relação solicitada deve ser sustentada;
- temporalidade `atual/anterior` não é tratada como sinônimo;
- objetivos multipartes exigem cobertura independente;
- candidato do pointer pode ser rejeitado;
- ausência de suporte específico não pode ser preenchida com fato genérico só para evitar incerteza.

## Relation acceptance

O gate padrão exige confiança e margem. Uma aceitação adicional só é permitida quando o top-1 possui confiança mínima e uma cue explícita **única**, sem cue concorrente. Isso evita baixar globalmente thresholds para perseguir um benchmark.

## Rede

Texto remoto é input não confiável. O cliente Android limita aquisição ao fluxo HTTPS documentado e não executa JavaScript remoto como parte do runtime neural. Endereços/destinos passam pelas validações do cliente.

## Bounds principais

- pergunta: até 4.096 bytes;
- contexto: até 65.536 bytes;
- objetivos: até 8;
- evidências usadas na síntese: bounded;
- memória explícita: até 128 entradas, cada uma bounded.

## Limite de segurança

Os gates não substituem fuzzing contínuo, pentest, assinatura de produção, hardening de APK ou campanha física independente.

## NDOS v1

O loader NDOS adiciona quatro corrupções explícitas ao gate: magic alterado, truncamento, trailing byte e bucket count inválido. A busca não aceita apenas top-1: score absoluto e margem para o segundo candidato precisam passar simultaneamente. No conjunto negativo de calibração, 0/25 perguntas foram aceitas.

O texto de resposta vem diretamente do registro humano local. Não existe execução de conteúdo do shard, template remoto ou chamada de modelo externo.

## Integridade de assets Android

`CanonicalAssetStore` não confia em existência de arquivo persistido. Ele compara conteúdo com o asset empacotado, usa staging, `fsync`, replace atômico e reabre os bytes finais. O gate JVM testa ausência, identidade e cópia stale. Isso comprova a lógica JVM no host; não é prova de filesystem/ART em dispositivo físico.

## Evidence de release

`FINAL_VERIFY.log` e `FINAL_SANITIZER.log` só podem alimentar `REPORT.json` quando contêm marcador com a **mesma versão** do manifest corrente. Checksum de evidence stale não é considerado prova semântica de release.

### JNI error-path audit

A auditoria alpha.2 passou a rejeitar `jstring` obrigatório nulo e organiza `GetStringUTFChars`/`ReleaseStringUTFChars` de forma linear também em falhas parciais. O gate host recompila essa boundary com warnings como erro; OOM real/ART continua fora da evidência física.

## Hardening sparse e conversacional v0.6.1

O fallback sparse nunca antecede um resultado neural aceito. Após recusa neural, consultas não-acrônimo exigem cobertura lexical mais alta e margem; a regressão `Noveria-999` é permanente para impedir substituição de uma entidade específica por um fato conhecido apenas porque a relação `capital/país` coincide.

O estado conversacional guarda apenas um turno bounded e não executa conteúdo, não chama rede e não modifica pesos. Follow-up é expansão de contexto local, portanto não deve ser confundido com memória ilimitada ou treinamento online.


## Local control / offline security v0.7.2

Pilot master kill e feature allowlist são exclusivamente locais e sem controle remoto. Durable Outbox persiste somente conteúdo da tarefa local + IDs opacos/metadata; erro bruto não é persistido. Network Policy nunca autoriza IA externa. Project IDs rejeitam path traversal/control chars. Model Acquisition é preflight sem fetch/licença automática. Benchmark evidence não inclui prompt/resposta/endpoint/secret e permanece `MEASURED_NOT_CERTIFIED`.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

