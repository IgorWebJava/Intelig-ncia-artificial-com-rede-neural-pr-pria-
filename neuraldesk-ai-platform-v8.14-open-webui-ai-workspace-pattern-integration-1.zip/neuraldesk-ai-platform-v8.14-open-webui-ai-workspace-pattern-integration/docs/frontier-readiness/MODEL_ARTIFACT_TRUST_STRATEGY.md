<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Model Artifact Trust Strategy

Model checkpoints, config, tensor indexes, tokenizer assets and conversion outputs are untrusted inputs. Validate hashes/checksums, declared architecture, required fields, tensor names/shapes/dtypes, offsets/ranges, allocation bounds and tokenizer parity before model activation.

Fail closed on missing architecture-defining configuration. Never silently substitute defaults that can produce plausible but incorrect inference.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
