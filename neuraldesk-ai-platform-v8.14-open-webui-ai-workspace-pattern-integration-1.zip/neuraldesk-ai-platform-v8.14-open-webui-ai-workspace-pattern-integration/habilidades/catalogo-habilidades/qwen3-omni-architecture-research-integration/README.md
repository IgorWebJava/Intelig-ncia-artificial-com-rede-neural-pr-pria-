<!-- neuraldesk-documentation-sync: V8.10 -->
# Qwen3-Omni Native Omnimodal Architecture Research Integration

Skill ID: `neuraldesk.qwen3-omni-architecture-research-integration.v1`

Use primary model, paper, upstream implementation and serving sources to extract provider-agnostic omni-modal patterns. Preserve provenance, benchmark gates, non-regression requirements and documentation-only boundaries. Never copy a provider architecture wholesale or claim external benchmarks as NeuralDesk results.
