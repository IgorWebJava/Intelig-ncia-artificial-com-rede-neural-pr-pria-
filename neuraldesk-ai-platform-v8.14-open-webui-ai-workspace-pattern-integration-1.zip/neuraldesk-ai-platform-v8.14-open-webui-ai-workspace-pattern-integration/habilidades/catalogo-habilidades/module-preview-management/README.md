<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Module Preview Generation & Governance

Skill ID: `neuraldesk.module-preview-management.v1`

## Purpose

Generate and preserve a current visual reference for every canonical NeuralDesk module.

## Canonical location

```text
modules/<module>/preview/page-preview.png
```

## Invariants

- the image must be captured from the canonical module UI;
- the preview must travel with the module;
- the preview must be regenerated after meaningful visual changes;
- generated metadata must identify the source UI and module version;
- previews are visual references, not proof of backend functionality.
