<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# Data Contract — chat.html

## Responsibility

Conversations, projects, context and agent runtime

## Access rule

```text
Page / Client
→ API / BFF
→ Application Service
→ Data Platform
```

The browser/page does **not** receive direct database credentials.

## Authoritative data

- `conversations`
- `messages`
- `projects`
- `attachments_metadata`
- `agent_profiles`
- `model_profiles`

## Events consumed/emitted

- `chat.*`
- `config.changed`
- `agent.profile.changed`
- `model.profile.changed`

## Consistency

Durable changes use a database transaction. When other modules must react, the transaction also writes an outbox event. Consumers refresh their state from the authoritative service/data source.

## Security

- authenticated access;
- authorization before writes;
- tenant/project scope where applicable;
- audit for sensitive changes;
- secrets stored as external secret references, not plaintext configuration.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
