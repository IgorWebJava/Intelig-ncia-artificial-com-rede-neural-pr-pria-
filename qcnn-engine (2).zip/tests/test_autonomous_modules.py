"""
Testes de Unidade para os Módulos de Autonomia Total (M23: AutonomousConsolidation e M24: GoalDrivenAgentLoop).
"""

import unittest
import os
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.autonomous_consolidation import AutonomousConsolidationPlugin
from qcnn.plugins.goal_driven_agent_loop import GoalDrivenAgentLoopPlugin
from qcnn.plugins.holographic_snapshot_store import HolographicSnapshotStorePlugin


class TestAutonomousModules(unittest.TestCase):
    def test_autonomous_consolidation_execution(self):
        plugin = AutonomousConsolidationPlugin()
        resultado = plugin.consolidar_memoria(["quantica", "relatividade", "gravidade", "consciencia"])
        
        self.assertEqual(resultado["status"], "CONSOLIDADO")
        self.assertGreaterEqual(resultado["ciclo"], 1)
        self.assertIn("total_analogias", resultado)
        self.assertGreaterEqual(resultado["reducao_entropia"], 0.0)
        self.assertEqual(resultado["nos_otimizados"], 4)

    def test_goal_driven_agent_loop(self):
        plugin = GoalDrivenAgentLoopPlugin()
        ctx = QcnnExecutionContext(prompt="meta: Construir mapa vetorial do universo quântico")
        ctx = plugin.execute(ctx)
        
        resultado = ctx.metadata.get("goal_driven_loop")
        self.assertIsNotNone(resultado)
        self.assertEqual(resultado["status_geral"], "SUCESSO_AUTONOMO")
        self.assertEqual(len(resultado["etapas_executadas"]), 4)
        self.assertIn("PLANO AGÊNTICO AUTÔNOMO", ctx.custom_response)

    def test_holographic_snapshot_store_persistence_and_recovery(self):
        test_db = "./storage_android/test_holographic_store.db"
        if os.path.exists(test_db):
            os.remove(test_db)
            
        plugin = HolographicSnapshotStorePlugin(db_path=test_db)
        
        # Teste 1: Salvar e recuperar snapshot
        snap_id = plugin.salvar_snapshot(0.98, ["quantica", "luz"], {"teste": "valido"})
        self.assertGreater(snap_id, 0)
        
        ultimo_snap = plugin.carregar_ultimo_snapshot()
        self.assertIsNotNone(ultimo_snap)
        self.assertEqual(ultimo_snap["coerencia_score"], 0.98)
        self.assertIn("quantica", ultimo_snap["nos_ativos"])
        
        # Teste 2: Memória de longo prazo
        plugin.salvar_memoria_permanente("constante_planck", "6.626e-34 J.s", frequencia_hz=528.0)
        mem = plugin.buscar_memoria_permanente("constante_planck")
        self.assertIsNotNone(mem)
        self.assertEqual(mem["conteudo"], "6.626e-34 J.s")
        self.assertEqual(mem["frequencia_hz"], 528.0)
        
        if os.path.exists(test_db):
            os.remove(test_db)


if __name__ == "__main__":
    unittest.main()
