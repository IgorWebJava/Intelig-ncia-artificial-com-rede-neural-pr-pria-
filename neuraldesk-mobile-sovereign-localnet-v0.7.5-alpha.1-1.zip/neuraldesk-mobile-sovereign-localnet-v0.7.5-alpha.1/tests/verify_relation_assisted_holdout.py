#!/usr/bin/env python3
from __future__ import annotations
import json
import re
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MODEL=str(ROOT/'models/neuraldesk-context-pointer-v0.5.ndqa')
REL=str(ROOT/'models/neuraldesk-relation-classifier-v0.5.ndrl')
DATA=str(ROOT/'evaluation/fixtures/relation_assisted_context_holdout.tsv')

def run(with_relation: bool):
    cmd=[str(ROOT/'build/nd_context_batch'),MODEL,DATA]
    if with_relation: cmd.append(REL)
    p=subprocess.run(cmd,text=True,capture_output=True)
    m=re.search(r'context_synthesis\s+(\d+)/(\d+)\s+PASS',p.stdout)
    assert m,(p.returncode,p.stdout,p.stderr)
    return int(m.group(1)),int(m.group(2)),p.returncode,p.stderr

base,total,_,_=run(False)
neural,total2,rc,stderr=run(True)
assert total==400 and total2==400,(total,total2)
assert base==50,(base,total)
assert rc==0 and neural==400,(neural,total2,stderr)
report={
    'suite':'relation-assisted-adversarial-holdout',
    'total':total,
    'heuristic_only_passed':base,
    'relation_assisted_passed':neural,
    'delta':neural-base,
}
(ROOT/'evaluation/RELATION_ASSISTED_CONTEXT_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(f"relation-assisted-holdout PASS heuristic={base}/{total} neural={neural}/{total}")
