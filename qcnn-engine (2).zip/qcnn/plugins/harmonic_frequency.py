from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.matriz_letras import MATRIZ_22_LETRAS

class HarmonicFrequencyPlugin(BaseQcnnPlugin):
    """
    Acumulador Harmônico de Frequências em Hz com base na Proporção Áurea.
    """
    @property
    def plugin_id(self) -> str:
        return "harmonic_frequency"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        freq_total = 0.0
        for letra in context.chain:
            dados = MATRIZ_22_LETRAS.get(letra, {})
            freq_total += dados.get("frequencia_hz", 0.0)

        if not context.chain and context.target_seed in MATRIZ_22_LETRAS:
            freq_total = MATRIZ_22_LETRAS[context.target_seed]["frequencia_hz"]

        context.total_frequency_hz = round(freq_total, 2)
        return context
