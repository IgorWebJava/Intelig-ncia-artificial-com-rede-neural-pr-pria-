<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Data & Event Consistency — V7.1

## Persistent truth

PostgreSQL is the primary relational SSOT for durable transactional/configuration state.

## Module ownership

Each mutable dataset has one authoritative owner module.

## Cross-module access

Forbidden:

```text
Module A → private tables of Module B
```

Allowed:

```text
Module A → Versioned API → Module B
```

or:

```text
Module B publishes versioned event
→ Module A consumes event
```

## Distributed changes

Use the Transactional Outbox pattern:

```text
BEGIN
  persist aggregate state
  persist outbox event
COMMIT
```

The event publisher then forwards the event to the event stream.

Consumers must be idempotent and should use version/event IDs for deduplication.
