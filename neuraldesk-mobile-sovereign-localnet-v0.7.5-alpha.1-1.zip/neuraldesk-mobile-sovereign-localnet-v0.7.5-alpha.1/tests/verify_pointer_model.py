#!/usr/bin/env python3
from pathlib import Path
import struct
p=Path('models/neuraldesk-context-pointer-v0.5.ndqa')
b=p.read_bytes(); assert len(b)>=28
magic,version,vocab,embedding,hidden,radius,maxspan=struct.unpack_from('<7I',b,0)
assert magic==0x3151444e and version==2
assert vocab==259 and embedding==48 and hidden==96 and radius==12 and maxspan==160
relations=25
expected_floats=(vocab*embedding + (2*radius+1)*embedding*hidden + embedding*hidden +
                 relations*hidden + hidden + hidden + 1 + hidden + 1)
assert len(b)==28+expected_floats*4,(len(b),28+expected_floats*4)
print('context-pointer-format-v05 PASS',expected_floats,'floats')
