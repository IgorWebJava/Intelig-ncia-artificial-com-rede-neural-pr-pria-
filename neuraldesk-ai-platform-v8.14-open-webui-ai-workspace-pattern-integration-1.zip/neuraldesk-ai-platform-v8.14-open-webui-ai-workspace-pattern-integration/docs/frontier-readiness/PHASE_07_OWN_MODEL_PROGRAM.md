# Phase 07 — NeuralDesk-Owned Model Program

Status: DOCUMENTATION-ONLY


Start with specialized models that create product leverage:
- embeddings;
- rerankers;
- classifiers/router models;
- safety/moderation;
- extraction/structured models;
- small reasoning/task models;
- speech or vision specialists where justified.

Build data curation, tokenizer, synthetic data, PEFT, distillation and post-training foundations.

Do not begin with a giant frontier foundation model unless Phase 00 economics and Phase 06 operational maturity justify it.

Exit result: measurable proprietary intelligence on selected workloads.

## V8.9 omni-modal model program

Any NeuralDesk-owned multimodal model must pass independent text/image/audio/video/audiovisual non-regression gates and separate X→Text / X→Speech evaluation before promotion.
