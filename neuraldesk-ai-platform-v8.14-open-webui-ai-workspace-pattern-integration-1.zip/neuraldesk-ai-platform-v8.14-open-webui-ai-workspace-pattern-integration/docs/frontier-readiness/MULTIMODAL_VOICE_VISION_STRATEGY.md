# Multimodal, Voice and Vision Strategy

Supported future inputs: text, image, audio, video, document, screen/camera streams and structured data.

Voice modes:
- off;
- push-to-talk;
- conversation mode;
- continuous assistant mode with explicit consent.

Critical requirements:
- interruption/barge-in;
- latency budget;
- visible capture state;
- privacy controls;
- transcript provenance;
- media retention policy;
- cross-modal context linking.
