#!/usr/bin/env python3
from __future__ import annotations
import array,json,os,shutil,struct,subprocess,sys,tempfile
from pathlib import Path
from train_generative_micro_v074_v3 import DATA,ROOT,Tok,sha
from token_cache_v074 import MAGIC,HEADER,TokenCache
PRE=ROOT/'scripts/pre_generation_lessons_check.py'
SRC=DATA/'causal_replay.jsonl'; TOKP=DATA/'tokenizer-v2.ndtk'; OUT=DATA/'token_cache_v2'
FILTERS={
 'rich_replay.ndtc':('RICH_NON_CONTEXT',lambda r:r.get('source')!='NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN'),
 'context_replay.ndtc':('CONTEXT_POINTER_ONLY',lambda r:r.get('source')=='NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN'),
}
def build(name,label,pred,tok):
 OUT.mkdir(parents=True,exist_ok=True);target=OUT/name;tmp_tokens=OUT/(name+'.tokens.tmp'); offsets=[0]; rows=0; tokens=0
 with tmp_tokens.open('wb') as tf,SRC.open(encoding='utf-8') as f:
  for line in f:
   r=json.loads(line)
   if not pred(r):continue
   ids=tok.encode(r['text']); a=array.array('H',ids)
   if sys.byteorder!='little':a.byteswap()
   a.tofile(tf);tokens+=len(ids);offsets.append(tokens);rows+=1
  tf.flush();os.fsync(tf.fileno())
 tmp=OUT/(name+'.tmp')
 with tmp.open('wb') as out:
  out.write(HEADER.pack(MAGIC,rows,tokens));out.write(struct.pack('<%dQ'%len(offsets),*offsets))
  with tmp_tokens.open('rb') as tf:shutil.copyfileobj(tf,out,1<<20)
  out.flush();os.fsync(out.fileno())
 os.replace(tmp,target);tmp_tokens.unlink();dfd=os.open(OUT,os.O_RDONLY)
 try:os.fsync(dfd)
 finally:os.close(dfd)
 meta={'schema':'neuraldesk-token-cache-v074-v1','filter':label,'source':'causal_replay.jsonl','sourceSha256':sha(SRC),'tokenizer':'tokenizer-v2.ndtk','tokenizerSha256':sha(TOKP),'rows':rows,'tokens':tokens,'fileSha256':sha(target),'validationRows':0,'holdoutRows':0,'trainingEligibleOnly':True}
 side=target.with_suffix(target.suffix+'.json');side.write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n',encoding='utf-8')
 return meta

def main():
 subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True);tok=Tok(TOKP);metas={}
 for n,(label,pred) in FILTERS.items():metas[n]=build(n,label,pred,tok)
 # Reopen through the production reader and compare deterministic source rows.
 srcsha=sha(SRC);toksha=sha(TOKP);caches={n:TokenCache(OUT/n,expected_source_sha=srcsha,expected_tokenizer_sha=toksha,expected_filter=label) for n,(label,_) in FILTERS.items()}
 rows={n:[] for n in FILTERS}
 with SRC.open(encoding='utf-8') as f:
  for line in f:
   r=json.loads(line)
   key='context_replay.ndtc' if r.get('source')=='NEURALDESK_FIRST_PARTY_CONTEXT_POINTER_TRAIN' else 'rich_replay.ndtc'
   if len(rows[key])<12:rows[key].append(r['text'])
 for name,texts in rows.items():
  for i,text in enumerate(texts):
   if list(map(int,caches[name].row(i)))!=tok.encode(text):raise SystemExit(f'TOKEN_CACHE_PARITY_FAIL {name} row={i}')
 print('TOKEN_CACHE_V074_V2 PASS '+ ' '.join(f"{n}:rows={m['rows']}:tokens={m['tokens']}:sha={m['fileSha256']}" for n,m in metas.items()))
 return 0
if __name__=='__main__':raise SystemExit(main())
