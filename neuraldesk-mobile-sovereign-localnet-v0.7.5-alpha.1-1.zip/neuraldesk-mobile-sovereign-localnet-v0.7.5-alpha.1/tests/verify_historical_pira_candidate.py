#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'PROJECT_MANIFEST.json').read_text())
spec=m['candidateArtifacts']['open_knowledge_full_pira']; p=ROOT/spec['path']; r=json.loads((ROOT/'evaluation/open_knowledge_full/BUILD_REPORT.json').read_text())
assert p.is_file() and p.stat().st_size==spec['bytes']==r['bytes']
sha=hashlib.sha256(p.read_bytes()).hexdigest(); assert sha==spec['sha256']==r['sha256']
assert spec['records']==r['records']==1281 and spec['state']=='CANDIDATE_NOT_ACTIVATED_PRECISION_GATE_PENDING'
assert m['architecture']['openKnowledgeFullCandidateActive'] is False
assert m['modelAuthority']['openKnowledgeFullCandidateActivated'] is False
print(f'HISTORICAL_PIRA_CANDIDATE PASS records=1281 sha256={sha} activated=false')
