import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.core.pipeline import QcnnPipeline
from qcnn.core.context import QcnnExecutionContext, CollapseResult
from qcnn.core.interfaces import BaseQcnnPlugin

class DummyPlugin(BaseQcnnPlugin):
    @property
    def plugin_id(self) -> str:
        return "dummy_test"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        context.custom_response = "Dummy Processed: " + context.prompt
        context.final_state = "10 (Dummy OK)"
        context.total_frequency_hz = 432.0
        return context

class TestCoreEngine(unittest.TestCase):
    def setUp(self):
        self.pipeline = QcnnPipeline()

    def test_pipeline_registration_and_unregistration(self):
        dummy = DummyPlugin()
        self.pipeline.register_plugin(dummy)
        self.assertIn("dummy_test", self.pipeline.list_plugins())
        
        # Test duplicate registration is ignored
        self.pipeline.register_plugin(dummy)
        self.assertEqual(self.pipeline.list_plugins().count("dummy_test"), 1)
        
        # Unregister
        removed = self.pipeline.unregister_plugin("dummy_test")
        self.assertEqual(removed, dummy)
        self.assertNotIn("dummy_test", self.pipeline.list_plugins())

    def test_plugin_enable_disable(self):
        dummy = DummyPlugin()
        self.pipeline.register_plugin(dummy)
        dummy.is_enabled = False
        
        res = self.pipeline.process("Teste Desabilitado")
        self.assertNotEqual(res.resposta, "Dummy Processed: Teste Desabilitado")
        
        dummy.is_enabled = True
        res2 = self.pipeline.process("Teste Habilitado")
        self.assertEqual(res2.resposta, "Dummy Processed: Teste Habilitado")

    def test_context_metadata_and_collapse_result(self):
        context = QcnnExecutionContext(prompt="Teste Contexto")
        context.metadata["prisma_risco"] = 0.75
        self.assertEqual(context.metadata["prisma_risco"], 0.75)
        self.assertEqual(context.prompt, "Teste Contexto")
        
        res = CollapseResult(
            resposta="Resp Teste",
            arvore="A -> B",
            frequencia="432.00 Hz",
            estado="10 (Ativo)",
            latencia="1.234ms",
            metadata={"key": "val"}
        )
        d = res.to_dict()
        self.assertEqual(d["resposta"], "Resp Teste")
        self.assertEqual(d["metadata"]["key"], "val")

if __name__ == "__main__":
    unittest.main()
