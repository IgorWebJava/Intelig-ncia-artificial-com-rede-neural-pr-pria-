<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 52 — Agents, Tools e Approvals no Chat

## Agent Activity

O template mostra estados operacionais seguros:

```text
Understanding
Searching
Retrieving
Selecting tools
Executing
Preparing answer
```

Não deve expor cadeia de pensamento privada.

## Tool Call

Cada tool call pode mostrar:

- tool name;
- status;
- duration;
- result count;
- environment;
- risk;
- link para Tool Center.

## Human Approval

Ações de risco podem apresentar:

- tool;
- agent;
- risk;
- recipients/target;
- purpose;
- preview;
- Reject;
- Approve.

A execução real pertence ao backend.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
