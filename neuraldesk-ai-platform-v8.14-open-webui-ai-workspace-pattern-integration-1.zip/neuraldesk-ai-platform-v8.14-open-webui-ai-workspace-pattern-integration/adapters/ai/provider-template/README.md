<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.ai.provider-template

    Replaceable adapter template.

    Provides:
    - `ai.text.generate.v1`
- `ai.vision.understand.v1`
- `ai.tool_calling.v1`
- `ai.structured_output.v1`

    Domain modules must never import this adapter implementation directly.
    Binding occurs through the corresponding platform gateway/registry.
