import unittest
from qcnn.core.holographic_memory import HolographicMemoryStore
from qcnn.plugins.self_healing_consensus import SelfHealingConsensusPlugin
from qcnn.core.context import QcnnExecutionContext
from qcnn.core.pipeline import QcnnPipeline

class TestHolographicSelfHealing(unittest.TestCase):

    def test_holographic_memory_store_operations(self):
        store = HolographicMemoryStore(owner_id="subagent_test", dimension=10000, capacity=5)
        
        # Teste de gravação e recuperação
        store.memorize("QuantumCoherence", frequency=432.0, state="10 (Ativo)")
        store.memorize("FractalExpansion", frequency=528.0, state="10 (Ativo)")
        
        rec = store.recall("quantumcoherence")
        self.assertIsNotNone(rec)
        self.assertEqual(rec["frequency"], 432.0)
        
        # Teste de recuperação por frequência de ressonância
        matches = store.recall_by_frequency(430.0, tolerance_hz=5.0)
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["concept"], "QuantumCoherence")
        
        # Teste de Coerência e Snapshot
        coherence = store.calculate_coherence()
        self.assertTrue(0.0 <= coherence <= 1.0)
        
        snap = store.snapshot()
        self.assertEqual(snap["owner_id"], "subagent_test")
        self.assertEqual(snap["records_count"], 2)
        
        # Teste de restauração em novo store
        new_store = HolographicMemoryStore(owner_id="subagent_mirror")
        restored = new_store.restore_from_snapshot(snap)
        self.assertTrue(restored)
        self.assertEqual(new_store.count(), 2)

    def test_self_healing_frequency_and_tree_repair(self):
        plugin = SelfHealingConsensusPlugin()
        
        # Contexto com frequência zerada e árvore corrompida/vazia
        ctx = QcnnExecutionContext(prompt="teste anomalia", target_seed="Alef")
        ctx.total_frequency_hz = 0.0
        ctx.chain = []
        ctx.metadata["c_score"] = 0.50 # Contradição / alucinação
        
        healed_ctx = plugin.execute(ctx)
        
        # Valida que o auto-reparo reestabeleceu os parâmetros
        self.assertEqual(healed_ctx.total_frequency_hz, 432.00)
        self.assertTrue(len(healed_ctx.chain) >= 2)
        self.assertEqual(healed_ctx.metadata["c_score"], 0.98)
        self.assertTrue(healed_ctx.metadata["self_healing_applied"])
        self.assertEqual(healed_ctx.metadata["cross_consensus_status"], "COERÊNCIA_REGENERADA")
        self.assertIn("healing_actions", healed_ctx.metadata)

    def test_nominal_coherence_without_repair(self):
        plugin = SelfHealingConsensusPlugin()
        
        ctx = QcnnExecutionContext(prompt="teste nominal", target_seed="Shin")
        ctx.total_frequency_hz = 511.30
        ctx.chain = ["Shin", "Yud", "Vav"]
        ctx.metadata["c_score"] = 1.0
        
        nominal_ctx = plugin.execute(ctx)
        self.assertFalse(nominal_ctx.metadata["self_healing_applied"])
        self.assertEqual(nominal_ctx.metadata["cross_consensus_status"], "COERÊNCIA_NOMINAL")

if __name__ == '__main__':
    unittest.main()
