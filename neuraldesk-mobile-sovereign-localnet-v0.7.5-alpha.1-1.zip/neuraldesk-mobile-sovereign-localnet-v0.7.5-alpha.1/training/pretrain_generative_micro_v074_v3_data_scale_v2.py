#!/usr/bin/env python3
"""Data-scale pretraining v2 for Micro-v3.

Experimental, stage-only and NOT_PROMOTED. It consumes the completed pre-SFT
Micro-v3 checkpoint as an immutable predecessor, resets AdamW, and defines an
epoch by full coverage of the large first-party context source. Rich replay is
cycled alongside it. Context loss is explicitly down-weighted so broad context
coverage cannot silently dominate the model's response voice.
"""
from __future__ import annotations
import argparse, hashlib, json, math, os, random, subprocess, sys
from pathlib import Path
from typing import Any
import numpy as np
import torch

from train_generative_micro_v074_v3 import DATA, ROOT, MicroV3, bindings, ch, export, oh, pad, sha, th
from token_cache_v074 import TokenCache
from finetune_generative_micro_v074_v3_sft_v2 import verify_predecessor

PRE=ROOT/'scripts/pre_generation_lessons_check.py'

SCHEMA_CONFIG='nd-v075-micro-v3-data-scale-pretrain-v2-accum-config-v1'
SCHEMA_CHECKPOINT='nd-v075-micro-v3-data-scale-pretrain-v2-accum-checkpoint-v1'
SCHEMA_REPORT='neuraldesk-generative-pretrain-report-v075-alpha1-micro-v3-data-scale-v2-accum-v1'

def _seed(base:int, epoch:int, source:str)->int:
    m=f'{base}|data-scale-pretrain-v2|{epoch}|{source}|nd-v074'.encode()
    return int.from_bytes(hashlib.sha256(m).digest()[:8],'little')

def permutation(n:int,seed:int,epoch:int,source:str)->list[int]:
    p=list(range(n)); random.Random(_seed(seed,epoch,source)).shuffle(p); return p

def _slice_cycle(p:list[int],start:int,count:int)->list[int]:
    if not p or count<0: raise ValueError('invalid permutation/count')
    return [p[(start+i)%len(p)] for i in range(count)]

def schedule(rich_n:int,context_n:int,a:argparse.Namespace,epoch:int)->dict[str,Any]:
    return {'epoch':epoch,'richPermutation':permutation(rich_n,a.seed,epoch,'rich_replay'),'contextPermutation':permutation(context_n,a.seed,epoch,'context_replay')}

def config(a:argparse.Namespace,tok_path:Path,counts:dict[str,int],pred:dict[str,Any],cache_bindings:dict[str,str])->dict[str,Any]:
    if a.rich_per_batch+a.context_per_batch!=a.batch_size: raise ValueError('source counts must equal micro batch size')
    if min(a.rich_per_batch,a.context_per_batch)<1: raise ValueError('both sources must contribute')
    if not (0.0<a.context_loss_weight<=1.0 and 0.0<a.rich_loss_weight<=1.0): raise ValueError('invalid loss weights')
    if a.accumulation_steps < 1: raise ValueError('accumulation steps must be positive')
    if a.checkpoint_every_batches and a.checkpoint_every_batches % a.accumulation_steps != 0:
        raise ValueError('checkpoint cadence must land on an optimizer boundary')
    if a.run_batch_budget and a.run_batch_budget % a.accumulation_steps != 0:
        raise ValueError('run batch budget must land on an optimizer boundary')
    return {
      'schema':SCHEMA_CONFIG,
      'arch':{'vocab':512,'dim':320,'layers':10,'qHeads':10,'kvHeads':2,'ffn':896,'context':256,'params':11229760},
      'seed':a.seed,'epochs':a.epochs,'seqLen':a.seq_len,'learningRate':a.lr,'weightDecay':a.weight_decay,'gradClip':a.grad_clip,
      'threads':a.threads,'mkldnn':bool(a.mkldnn),'microBatchSize':a.batch_size,'richPerMicroBatch':a.rich_per_batch,'contextPerMicroBatch':a.context_per_batch,
      'accumulationSteps':a.accumulation_steps,'effectiveBatchSize':a.batch_size*a.accumulation_steps,
      'effectiveRichPerUpdate':a.rich_per_batch*a.accumulation_steps,'effectiveContextPerUpdate':a.context_per_batch*a.accumulation_steps,
      'richLossWeight':a.rich_loss_weight,'contextLossWeight':a.context_loss_weight,
      'epochDefinition':'ONE_FULL_CONTEXT_REPLAY_COVERAGE','optimizerResetAtBoundary':True,'checkpointAtOptimizerBoundaryOnly':True,
      'debugLimits':{'rich':a.rich_limit,'context':a.context_limit},'effectiveCounts':counts,'bindings':bindings(tok_path),'tokenCacheBindings':cache_bindings,
      'predecessor':{k:pred[k] for k in ('checkpointSha256','configSha256','modelStateSha256','optimizerStateSha256')},
    }

def causal_cached(cache:TokenCache,index:int,nonce:int,n:int):
    ids=[257]+[int(x) for x in cache.row(index)]+[258]
    need=n+1
    if len(ids)>need:
        off=(nonce*37)%(len(ids)-need+1);ids=ids[off:off+need]
    if len(ids)<2:ids=[257,258]
    x,y=pad(ids[:-1],ids[1:],n)
    return x.squeeze(0),y.squeeze(0)

def batch(rich_cache,context_cache,a,sched,cursor):
    rs=cursor*a.rich_per_batch; cs=cursor*a.context_per_batch
    ri=_slice_cycle(sched['richPermutation'],rs,a.rich_per_batch); ci=_slice_cycle(sched['contextPermutation'],cs,a.context_per_batch)
    xy=[]; weights=[]
    for j,i in enumerate(ri):
        xy.append(causal_cached(rich_cache,i,sched['epoch']*1000003+cursor*71+j,a.seq_len)); weights.append(a.rich_loss_weight)
    for j,i in enumerate(ci):
        xy.append(causal_cached(context_cache,i,sched['epoch']*1000033+cursor*97+j,a.seq_len)); weights.append(a.context_loss_weight)
    return torch.stack([z[0] for z in xy]),torch.stack([z[1] for z in xy]),torch.tensor(weights,dtype=torch.float32),{'rich':len(ri),'context':len(ci)}

def weighted_loss(model,x,y,weights):
    z=model(x)
    raw=torch.nn.functional.cross_entropy(z.reshape(-1,512),y.reshape(-1),ignore_index=-100,reduction='none').reshape(y.shape)
    mask=y.ne(-100); sums=(raw*mask).sum(1); counts=mask.sum(1).clamp_min(1); per=sums/counts
    return (per*weights).sum()/weights.sum()

def checkpoint_name(st): return f"v3-pretrain-v2-e{st['epoch']}-b{st['batchCursor']}-u{st['updates']}.pt"

def cpwrite(path:Path,model,opt,cfg,st,sched):
    path.parent.mkdir(parents=True,exist_ok=True)
    body={'schema':SCHEMA_CHECKPOINT,'config':cfg,'configSha256':ch(cfg),'state':st,'schedule':sched,'model':model.state_dict(),'optimizer':opt.state_dict(),'modelStateSha256':th(model.state_dict().items()),'optimizerStateSha256':oh(opt)}
    tmp=path.with_name(path.name+'.tmp'); side_tmp=path.with_suffix(path.suffix+'.json.tmp')
    for q in (tmp,side_tmp):
        if q.exists(): q.unlink()
    torch.save(body,tmp)
    with tmp.open('rb+') as f: os.fsync(f.fileno())
    temp_sha=sha(tmp); os.replace(tmp,path); dfd=os.open(path.parent,os.O_RDONLY)
    try: os.fsync(dfd)
    finally: os.close(dfd)
    if sha(path)!=temp_sha: raise IOError('checkpoint hash changed across atomic replace')
    side={'checkpointSha256':temp_sha,'configSha256':body['configSha256'],'modelStateSha256':body['modelStateSha256'],'optimizerStateSha256':body['optimizerStateSha256'],'state':st,'schedule':{'epoch':sched['epoch']}}
    with side_tmp.open('w',encoding='utf-8') as f: f.write(json.dumps(side,indent=2,sort_keys=True)+'\n'); f.flush(); os.fsync(f.fileno())
    os.replace(side_tmp,path.with_suffix(path.suffix+'.json')); dfd=os.open(path.parent,os.O_RDONLY)
    try: os.fsync(dfd)
    finally: os.close(dfd)
    return side

def cpload(path,model,opt,cfg,a,counts):
    side=json.loads(path.with_suffix(path.suffix+'.json').read_text(encoding='utf-8'))
    if sha(path)!=side['checkpointSha256'] or side['configSha256']!=ch(cfg): raise ValueError('checkpoint SHA/config mismatch')
    body=torch.load(path,map_location='cpu',weights_only=False)
    if body.get('schema')!=SCHEMA_CHECKPOINT or body.get('config')!=cfg: raise ValueError('checkpoint schema/config mismatch')
    exp=schedule(counts['richReplay'],counts['contextReplay'],a,int(body['schedule']['epoch']))
    if body['schedule']!=exp: raise ValueError('checkpoint permutation mismatch')
    model.load_state_dict(body['model']);opt.load_state_dict(body['optimizer'])
    if th(model.state_dict().items())!=body['modelStateSha256'] or oh(opt)!=body['optimizerStateSha256']: raise ValueError('state digest mismatch')
    return body

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('--pretrain-checkpoint',required=True);ap.add_argument('--output-dir',required=True);ap.add_argument('--checkpoint-dir',required=True);ap.add_argument('--resume')
    ap.add_argument('--epochs',type=int,default=1);ap.add_argument('--run-batch-budget',type=int,default=0);ap.add_argument('--seq-len',type=int,default=64);ap.add_argument('--seed',type=int,default=7423)
    ap.add_argument('--lr',type=float,default=1.5e-4);ap.add_argument('--weight-decay',type=float,default=0.01);ap.add_argument('--grad-clip',type=float,default=1.0);ap.add_argument('--threads',type=int,default=4);ap.add_argument('--mkldnn',action='store_true')
    ap.add_argument('--batch-size',type=int,default=8);ap.add_argument('--rich-per-batch',type=int,default=1);ap.add_argument('--context-per-batch',type=int,default=7);ap.add_argument('--accumulation-steps',type=int,default=8);ap.add_argument('--rich-loss-weight',type=float,default=1.0);ap.add_argument('--context-loss-weight',type=float,default=0.15)
    ap.add_argument('--checkpoint-every-batches',type=int,default=25);ap.add_argument('--rich-limit',type=int,default=0);ap.add_argument('--context-limit',type=int,default=0)
    a=ap.parse_args(); subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
    if not(1<=a.threads<=8) or a.epochs<1 or a.seq_len>256: raise SystemExit('invalid bounded configuration')
    torch.set_num_threads(a.threads);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.backends.mkldnn.enabled=bool(a.mkldnn);random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
    tok_path=DATA/'tokenizer-v2.ndtk'; source_path=DATA/'causal_replay.jsonl'; cache_dir=DATA/'token_cache_v2'
    source_sha=sha(source_path);tok_sha=sha(tok_path)
    rich_cache=TokenCache(cache_dir/'rich_replay.ndtc',expected_source_sha=source_sha,expected_tokenizer_sha=tok_sha,expected_filter='RICH_NON_CONTEXT')
    context_cache=TokenCache(cache_dir/'context_replay.ndtc',expected_source_sha=source_sha,expected_tokenizer_sha=tok_sha,expected_filter='CONTEXT_POINTER_ONLY')
    rich_n=min(rich_cache.rows,a.rich_limit) if a.rich_limit else rich_cache.rows; context_n=min(context_cache.rows,a.context_limit) if a.context_limit else context_cache.rows
    counts={'richReplay':rich_n,'contextReplay':context_n};cache_bindings={'richCacheSha256':rich_cache.meta['fileSha256'],'contextCacheSha256':context_cache.meta['fileSha256'],'sourceSha256':source_sha,'tokenizerSha256':tok_sha}
    pred=verify_predecessor(Path(a.pretrain_checkpoint),bindings(tok_path));cfg=config(a,tok_path,counts,pred,cache_bindings)
    model=MicroV3();model.load_state_dict(pred['model']);opt=torch.optim.AdamW(model.parameters(),lr=a.lr,weight_decay=a.weight_decay)
    st={'epoch':0,'batchCursor':0,'updates':0,'richSeen':0,'contextSeen':0};sched=schedule(rich_n,context_n,a,0)
    if a.resume:
        body=cpload(Path(a.resume),model,opt,cfg,a,counts);st=body['state'];sched=body['schedule'];print(f"RESUME_V3_PRETRAIN_V2 PASS epoch={st['epoch']} cursor={st['batchCursor']} updates={st['updates']}",flush=True)
    total_batches=math.ceil(context_n/a.context_per_batch);budget=a.run_batch_budget or 10**18;used=0;ckdir=Path(a.checkpoint_dir)
    print(f'DATA_SCALE_PRETRAIN_V2 counts rich={rich_n} context={context_n} microBatches={total_batches} accumulationSteps={a.accumulation_steps} effectiveBatch={a.batch_size*a.accumulation_steps} contextCoveragePerEpoch=1.0 contextLossWeight={a.context_loss_weight}',flush=True)
    while st['epoch']<a.epochs and used<budget:
        ep=st['epoch'];
        if sched['epoch']!=ep:sched=schedule(rich_n,context_n,a,ep)
        cur=st['batchCursor']
        if cur>=total_batches:
            st['epoch']+=1;st['batchCursor']=0
            if st['epoch']>=a.epochs:break
            sched=schedule(rich_n,context_n,a,st['epoch']);continue
        group=min(a.accumulation_steps,total_batches-cur)
        if used+group>budget: break
        opt.zero_grad(set_to_none=True);loss_sum=0.0;group_rich=0;group_context=0
        for micro in range(group):
            micro_cursor=cur+micro
            x,y,w,cov=batch(rich_cache,context_cache,a,sched,micro_cursor)
            z=weighted_loss(model,x,y,w)
            (z/float(group)).backward()
            loss_sum+=float(z.detach());group_rich+=cov['rich'];group_context+=cov['context']
        gn=float(torch.nn.utils.clip_grad_norm_(model.parameters(),a.grad_clip).detach());opt.step()
        st['batchCursor']+=group;st['updates']+=1;st['richSeen']+=group_rich;st['contextSeen']+=group_context;used+=group
        mean_loss=loss_sum/float(group)
        if st['updates']==1 or st['updates']%10==0 or st['batchCursor']>=total_batches:
            print(f"PRETRAIN_V3_DATA_SCALE epoch={ep+1}/{a.epochs} microBatch={st['batchCursor']}/{total_batches} optimizerUpdate={st['updates']} group={group} loss={mean_loss:.6f} gradNorm={gn:.6f} richSeen={st['richSeen']} contextSeen={st['contextSeen']} contextCoverage={min(st['contextSeen'],context_n)/context_n:.6f}",flush=True)
        if a.checkpoint_every_batches and st['batchCursor']%a.checkpoint_every_batches==0:
            p=ckdir/checkpoint_name(st);side=cpwrite(p,model,opt,cfg,st,sched);print(f"CHECKPOINT_V3_PRETRAIN_V2 path={p} sha256={side['checkpointSha256']}",flush=True)
    if st['epoch']<a.epochs:
        p=ckdir/checkpoint_name(st);side=cpwrite(p,model,opt,cfg,st,sched);print(f"PAUSED_V3_PRETRAIN_V2 path={p} sha256={side['checkpointSha256']}",flush=True);return 3
    out=Path(a.output_dir);fp=out/'staging/micro-v3-data-scale-pretrain-v2-fp32.ndgm';q8=out/'staging/micro-v3-data-scale-pretrain-v2-q8.ndgm';q4=out/'staging/micro-v3-data-scale-pretrain-v2-q4.ndgm'
    report={'schema':SCHEMA_REPORT,'status':'EXPERIMENTAL_NOT_PROMOTED','config':cfg,'state':st,'modelStateSha256':th(model.state_dict().items()),'optimizerStateSha256':oh(opt),'stagedFp32':{'path':str(fp),'sha256':export(model,fp,'fp32')},'stagedQ8':{'path':str(q8),'sha256':export(model,q8,'q8')},'stagedQ4':{'path':str(q4),'sha256':export(model,q4,'q4')},'promotionAuthorized':False}
    out.mkdir(parents=True,exist_ok=True);(out/'PRETRAIN_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8');term_sched=schedule(rich_n,context_n,a,max(0,a.epochs-1));cpwrite(ckdir/'v3-data-scale-pretrain-v2-terminal.pt',model,opt,cfg,st,term_sched)
    print(f"PRETRAIN_V3_DATA_SCALE_TERMINAL_NOT_PROMOTED updates={st['updates']} contextSeen={st['contextSeen']} modelStateSha256={report['modelStateSha256']}",flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
