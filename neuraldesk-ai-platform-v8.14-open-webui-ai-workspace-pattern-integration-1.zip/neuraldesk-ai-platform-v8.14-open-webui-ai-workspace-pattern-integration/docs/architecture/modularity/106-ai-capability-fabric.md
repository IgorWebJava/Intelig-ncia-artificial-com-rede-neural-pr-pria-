<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 106 — AI Capability Fabric

```text
Domain Module
→ AI Capability Gateway
→ Model Router
→ Capability Negotiation
→ Provider Adapter
→ Model
```

Provider SDKs are forbidden inside domain modules.
