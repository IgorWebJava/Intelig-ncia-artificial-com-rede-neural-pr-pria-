<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.agents; current: modules/agents/docs/CURRENT_STATE.md -->
# Agent Lifecycle & Evaluation

Lifecycle: Draft → Sandbox → Evaluation → Safety → Staging → Production. Evaluation reuses `training.evaluate.v1` for task completion, tool selection/execution, groundedness, safety, cost, latency and handoff quality. Rollback switches to a previous approved version.
