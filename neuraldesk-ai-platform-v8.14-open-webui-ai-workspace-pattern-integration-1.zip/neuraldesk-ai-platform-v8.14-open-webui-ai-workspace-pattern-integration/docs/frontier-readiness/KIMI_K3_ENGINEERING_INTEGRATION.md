<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Kimi K3 Engineering Integration — NeuralDesk V8.8

This document integrates the best reusable patterns discovered from the independent `kimi-k3-in-c` implementation and the official Kimi K3 release into the NeuralDesk future-engine blueprint. It is documentation-only.

## Highest-value additions
1. Memory-aware weight residency/streaming.
2. Expert-weight cache separated from KV cache.
3. Hardware-fit diagnostics and resource presets.
4. Model artifact/config/tokenizer trust boundary.
5. Deterministic multi-path correctness parity.
6. Adversarial architecture-faithful fixtures.
7. Performance-noise and replicated benchmark governance.
8. KDA / Attention Residual / Stable LatentMoE research tracks.
9. Expert-balance training research.
10. Long-horizon agentic RL with persistent rollout/sandbox-state research.

## Product rule
No Kimi-specific primitive is exposed directly to Chat, Agents, Knowledge or Training. Product modules request stable NeuralDesk capabilities; providers/architectures remain replaceable.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
