# Historical Convergence & Reliability — v0.7.1-alpha.1

A v0.7.1 converge mecanismos comprovados das linhas NeuralDesk anteriores dentro do runtime C99 LocalNet, sem criar um segundo backend paralelo. A auditoria percorreu conversas recuperáveis, ZIPs integrais Mobile Runtime v0.1–v0.63, LocalNet e V7/V8 até V8.22. Documentação histórica nunca é tratada como implementação quando o artefato original era `FUTURE-DOCUMENTATION-ONLY`.

## Capacidades convergidas executáveis

- Semantic Intent Frame e recuperação permanente do contrato Robust Intent v0.6.3;
- Safety precheck/postcheck bounded, `universalSafetyClaim=false`;
- Resource Governor `MICRO/MOBILE/MOBILE_PLUS` por RAM, cores e 64-bit;
- Local RAG com chunking/overlap, BM25 top-N e Semantic Ranker auxiliar;
- Semantic Ranker first-party 131.200 parâmetros, 746/749 no gate relativo;
- resumo extrativo/keywords offline;
- Run Reliability Journal sanitizado, sem prompt/output bruto;
- checkpoint/resume transient integrity-bound;
- Device Lab software/privacy guard, sem alegar execução física;
- Android official-toolchain admission fail-closed;
- cross-target ABI determinístico para quatro targets;
- model promotion e activation Ed25519 separados.

## Capacidades deliberadamente não promovidas

O shard Pirá full de 1.281 registros está materializado apenas como `CANDIDATE_NOT_ACTIVATED_PRECISION_GATE_PENDING`; o shard ativo continua com 31 registros. Não existe Generative Micro promovido nesta release. Não são alegados APK/AAB, Android ART/device, GPU/NPU executor, benchmark físico ou serving público/produção.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
