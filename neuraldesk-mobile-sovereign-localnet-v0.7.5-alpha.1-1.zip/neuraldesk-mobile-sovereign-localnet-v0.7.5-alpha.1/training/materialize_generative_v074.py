#!/usr/bin/env python3
"""Materialize frozen v0.7.4 generative train/evaluation inputs.

This builder is the only step allowed to read mutable Python knowledge source.
The trainer consumes only the materialized JSONL/provenance bytes produced here.
"""
from __future__ import annotations
import hashlib, importlib.util, json, re, subprocess, sys, unicodedata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'training/data/generative_v074'
PIRA=ROOT/'training/data/open_knowledge/historical_full/pira_human_records_v06.jsonl'
KB=ROOT/'training/knowledge_base.py'
PRE=ROOT/'scripts/pre_generation_lessons_check.py'

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s:str)->str:
    s=unicodedata.normalize('NFKC',s).casefold()
    s=re.sub(r'\s+',' ',s).strip()
    return s

def dump(path:Path, rows:list[dict]):
    data=''.join(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n' for r in rows).encode()
    path.write_bytes(data)

def main()->int:
    subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
    rows=[json.loads(x) for x in PIRA.read_text(encoding='utf-8').splitlines() if x.strip()]
    ptrain=[r for r in rows if r.get('split')=='train']
    pval=[r for r in rows if r.get('split')=='validation']
    if len(ptrain)!=1141 or len(pval)!=140: raise SystemExit('Pira split invariant failed')
    reserved={norm(r['question']) for r in pval}
    if len(reserved)!=140: raise SystemExit('validation questions must be unique')
    spec=importlib.util.spec_from_file_location('nd_kb',KB); mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod)
    first=list(mod.R)
    if len(first)!=201: raise SystemExit(f'first-party count changed unexpectedly: {len(first)}')
    sft=[]; replay=[]; excluded=[]
    for r in ptrain:
        if norm(r['question']) in reserved:
            excluded.append({'source':'pira_train','question':r['question']}); continue
        rec={'id':'pira:'+str(r['source_id']),'question':r['question'],'response':r['answer'],'source':'PIRA_2_0_CC_BY_4_0','trainingEligible':True}
        sft.append(rec); replay.append({'id':rec['id'],'text':r['question']+'\n'+r['answer'],'source':rec['source'],'trainingEligible':True})
    for i,r in enumerate(first):
        if norm(r.q) in reserved:
            excluded.append({'source':'first_party','question':r.q}); continue
        rec={'id':f'first-party:{i:03d}','question':r.q,'response':r.rich,'source':'NEURALDESK_FIRST_PARTY','trainingEligible':True}
        sft.append(rec); replay.append({'id':rec['id'],'text':r.q+'\n'+r.rich,'source':rec['source'],'trainingEligible':True})
    train_q={norm(r['question']) for r in sft}
    leakage=sorted(train_q & reserved)
    if leakage: raise SystemExit(f'global question leakage: {leakage[:3]}')
    val=[{'id':'pira:'+str(r['source_id']),'question':r['question'],'answer':r['answer'],'source':'PIRA_2_0_CC_BY_4_0','usage':'EVALUATION_ONLY'} for r in pval]
    OUT.mkdir(parents=True,exist_ok=True)
    sp=OUT/'sft_train.jsonl'; rp=OUT/'causal_replay.jsonl'; vp=OUT/'pira_validation.jsonl'; ep=OUT/'excluded_reserved.jsonl'
    dump(sp,sft); dump(rp,replay); dump(vp,val); dump(ep,excluded)
    prov={
      'schema':'neuraldesk-generative-corpus-v074-alpha2-v1','status':'MATERIALIZED_NOT_TRAINED',
      'piraSource':{'path':str(PIRA.relative_to(ROOT)),'sha256':sha(PIRA),'license':'CC BY 4.0','trainOriginal':1141,'validationOriginal':140},
      'firstPartySource':{'path':str(KB.relative_to(ROOT)),'sha256':sha(KB),'recordsOriginal':201},
      'materialized':{'sftTrain':len(sft),'causalReplay':len(replay),'validation':len(val),'excludedReserved':len(excluded),
                      'sftSha256':sha(sp),'replaySha256':sha(rp),'validationSha256':sha(vp)},
      'governance':{'globalQuestionCrossSplitLeakage':0,'validationUsedForTraining':False,'validationUsedForTokenizerFit':False,
                    'historicalAuthored48':'NOT_RECOVERED_DO_NOT_FABRICATE'},
    }
    pp=OUT/'PROVENANCE.json'; pp.write_text(json.dumps(prov,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(f"GENERATIVE_CORPUS PASS sft={len(sft)} replay={len(replay)} validation={len(val)} excluded={len(excluded)} globalQuestionCrossSplitLeakage=0")
    return 0
if __name__=='__main__': raise SystemExit(main())
