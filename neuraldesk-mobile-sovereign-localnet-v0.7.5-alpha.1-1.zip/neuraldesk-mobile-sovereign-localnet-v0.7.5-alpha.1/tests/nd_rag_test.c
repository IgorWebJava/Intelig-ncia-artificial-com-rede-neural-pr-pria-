#include "nd_rag.h"
#include "nd_semantic_ranker.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int append_byte(const char *path) {
    FILE *f = fopen(path, "ab");
    if (!f) return -1;
    int rc = fputc('X', f) == EOF ? -1 : 0;
    if (fclose(f) != 0) rc = -1;
    return rc;
}

int main(int argc, char **argv) {
    NDRagIndex idx;
    nd_rag_init(&idx);
    char err[256];
    const char *kv =
        "KV cache armazena chaves e valores de atenção de tokens anteriores para evitar recomputação durante inferência autoregressiva. Ele usa memória adicional para reduzir trabalho por token.";
    if (nd_rag_add_document(&idx, "kv-doc", kv, err, sizeof(err))) return 1;
    size_t original_count = idx.count;
    if (nd_rag_add_document(&idx, "kv-doc", kv, err, sizeof(err))) return 1;
    if (idx.count != original_count) return 1;
    if (nd_rag_add_document(&idx, "quant-doc",
        "Quantização representa pesos com menos bits, reduzindo memória e largura de banda. INT8 e INT4 podem exigir calibração para preservar qualidade.",
        err, sizeof(err))) return 1;

    char out[4096];
    NDRagResult result;
    if (nd_rag_query(&idx, "Como KV cache evita recomputação?", 2u,
                     out, sizeof(out), &result, err, sizeof(err))) return 1;
    if (!result.found || !strstr(out, "kv-doc") || !strstr(out, "recomput")) return 1;

    if (nd_rag_add_document(&idx, "kv-doc",
        "KV cache atualizado reutiliza chaves e valores durante inferência autoregressiva e reduz recomputação causal por token.",
        err, sizeof(err))) return 1;
    memset(out, 0, sizeof(out));
    memset(&result, 0, sizeof(result));
    if (nd_rag_query(&idx, "reutiliza chaves valores recomputação", 1u,
                     out, sizeof(out), &result, err, sizeof(err))) return 1;
    if (!result.found || !strstr(out, "atualizado")) return 1;

    int ranked = 0;
    if (argc == 2) {
        NDSemanticRanker ranker;
        if (nd_semantic_ranker_load(&ranker, argv[1], err, sizeof(err))) return 1;
        memset(out, 0, sizeof(out));
        memset(&result, 0, sizeof(result));
        if (nd_rag_query_ranked(&idx,
                "Como reduzir recomputação da atenção durante inferência autoregressiva?",
                1u, &ranker, out, sizeof(out), &result, err, sizeof(err))) {
            nd_semantic_ranker_free(&ranker);
            return 1;
        }
        ranked = result.found && strstr(out, "kv-doc") != NULL;
        nd_semantic_ranker_free(&ranker);
        if (!ranked) return 1;
    }

    const char *path = "/tmp/neuraldesk-rag-v073-test.ndrag";
    remove(path);
    if (nd_rag_save(&idx, path, err, sizeof(err))) return 1;
    NDRagIndex loaded;
    nd_rag_init(&loaded);
    if (nd_rag_load(&loaded, path, err, sizeof(err))) return 1;
    if (loaded.count != idx.count) return 1;
    memset(out, 0, sizeof(out));
    memset(&result, 0, sizeof(result));
    if (nd_rag_query(&loaded, "quantização memória bits", 1u,
                     out, sizeof(out), &result, err, sizeof(err))) return 1;
    if (!result.found || !strstr(out, "quant-doc")) return 1;
    if (append_byte(path)) return 1;
    NDRagIndex corrupt;
    nd_rag_init(&corrupt);
    if (nd_rag_load(&corrupt, path, err, sizeof(err)) == 0) return 1;
    remove(path);

    char large[5001];
    for (size_t i = 0u; i + 1u < sizeof(large); i++) large[i] = (i % 59u == 58u) ? ' ' : (char)('a' + (i % 23u));
    large[sizeof(large) - 1u] = 0;
    for (unsigned i = 0u; i < 24u; i++) {
        char id[32];
        snprintf(id, sizeof(id), "lru-%u", i);
        if (nd_rag_add_document(&loaded, id, large, err, sizeof(err))) return 1;
        if (loaded.count > ND_RAG_MAX_CHUNKS) return 1;
    }
    NDRagStats stats;
    nd_rag_stats(&loaded, &stats);
    if (stats.chunks > ND_RAG_MAX_CHUNKS || stats.documents == 0u || stats.documents >= 24u + 2u) return 1;

    printf("LOCAL_RAG PASS chunks=%zu documents=%zu semantic_rerank=%d persistence=true corruption_rejected=true lru=true\n",
           stats.chunks, stats.documents, ranked);
    return 0;
}
