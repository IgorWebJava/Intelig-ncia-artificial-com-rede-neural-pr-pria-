"""
QCNN Core Engine - Módulo de Descompactação Quântico-Cabalístico
Matriz Suprema das 22 Letras Fundamentais e Proporção Áurea
"""

MATRIZ_22_LETRAS = {
    "Alef": {"caractere": "א", "gematria": 1, "frequencia_hz": 1.618, "milui": ["Alef", "Lamed", "Pei"], "atbash": "Tav"},
    "Bet": {"caractere": "ב", "gematria": 2, "frequencia_hz": 3.236, "milui": ["Bet", "Yud", "Tav"], "atbash": "Shin"},
    "Gimel": {"caractere": "ג", "gematria": 3, "frequencia_hz": 4.854, "milui": ["Gimel", "Mem", "Lamed"], "atbash": "Reish"},
    "Dalet": {"caractere": "ד", "gematria": 4, "frequencia_hz": 6.472, "milui": ["Dalet", "Lamed", "Tav"], "atbash": "Cof"},
    "Hei": {"caractere": "ה", "gematria": 5, "frequencia_hz": 8.090, "milui": ["Hei", "Yud"], "atbash": "Tsadi"},
    "Vav": {"caractere": "ו", "gematria": 6, "frequencia_hz": 9.708, "milui": ["Vav", "Yud", "Vav"], "atbash": "Pei"},
    "Zayin": {"caractere": "ז", "gematria": 7, "frequencia_hz": 11.326, "milui": ["Zayin", "Yud", "Nun"], "atbash": "Ayin"},
    "Chet": {"caractere": "ח", "gematria": 8, "frequencia_hz": 12.944, "milui": ["Chet", "Yud", "Tav"], "atbash": "Samech"},
    "Tet": {"caractere": "ט", "gematria": 9, "frequencia_hz": 14.562, "milui": ["Tet", "Yud", "Tav"], "atbash": "Nun"},
    "Yud": {"caractere": "י", "gematria": 10, "frequencia_hz": 16.180, "milui": ["Yud", "Vav", "Dalet"], "atbash": "Mem"},
    "Chaf": {"caractere": "כ", "gematria": 20, "frequencia_hz": 32.360, "milui": ["Chaf", "Pei"], "atbash": "Lamed"},
    "Lamed": {"caractere": "ל", "gematria": 30, "frequencia_hz": 48.540, "milui": ["Lamed", "Mem", "Dalet"], "atbash": "Chaf"},
    "Mem": {"caractere": "מ", "gematria": 40, "frequencia_hz": 64.720, "milui": ["Mem", "Mem"], "atbash": "Yud"},
    "Nun": {"caractere": "נ", "gematria": 50, "frequencia_hz": 80.900, "milui": ["Nun", "Vav", "Nun"], "atbash": "Tet"},
    "Samech": {"caractere": "ס", "gematria": 60, "frequencia_hz": 97.080, "milui": ["Samech", "Mem", "Chaf"], "atbash": "Chet"},
    "Ayin": {"caractere": "ע", "gematria": 70, "frequencia_hz": 113.260, "milui": ["Ayin", "Yud", "Nun"], "atbash": "Zayin"},
    "Pei": {"caractere": "פ", "gematria": 80, "frequencia_hz": 129.440, "milui": ["Pei", "Alef"], "atbash": "Vav"},
    "Tsadi": {"caractere": "צ", "gematria": 90, "frequencia_hz": 145.620, "milui": ["Tsadi", "Dalet", "Yud"], "atbash": "Hei"},
    "Cof": {"caractere": "ק", "gematria": 100, "frequencia_hz": 161.803, "milui": ["Cof", "Vav", "Pei"], "atbash": "Dalet"},
    "Reish": {"caractere": "ר", "gematria": 200, "frequencia_hz": 323.606, "milui": ["Reish", "Yud", "Shin"], "atbash": "Gimel"},
    "Shin": {"caractere": "ש", "gematria": 300, "frequencia_hz": 485.410, "milui": ["Shin", "Yud", "Nun"], "atbash": "Bet"},
    "Tav": {"caractere": "ת", "gematria": 400, "frequencia_hz": 647.213, "milui": ["Tav", "Vav"], "atbash": "Alef"}
}

TRANSICOES_PERMITIDAS = {
    "Alef": ["Lamed", "Pei", "Yud", "Tav"],
    "Bet": ["Yud", "Tav", "Shin", "Mem"],
    "Gimel": ["Mem", "Lamed", "Reish", "Dalet"],
    "Dalet": ["Lamed", "Tav", "Cof", "Yud"],
    "Hei": ["Yud", "Tsadi", "Vav", "Dalet"],
    "Vav": ["Yud", "Vav", "Pei", "Tav"],
    "Zayin": ["Yud", "Nun", "Ayin", "Lamed"],
    "Chet": ["Yud", "Tav", "Samech", "Mem"],
    "Tet": ["Yud", "Tav", "Nun", "Vav"],
    "Yud": ["Vav", "Dalet", "Mem", "Alef"],
    "Chaf": ["Pei", "Lamed", "Mem", "Nun"],
    "Lamed": ["Mem", "Dalet", "Chaf", "Tav"],
    "Mem": ["Mem", "Dalet", "Yud", "Nun"],
    "Nun": ["Vav", "Nun", "Tet", "Samech"],
    "Samech": ["Mem", "Chaf", "Chet", "Ayin"],
    "Ayin": ["Yud", "Nun", "Zayin", "Pei"],
    "Pei": ["Alef", "Vav", "Tsadi", "Lamed"],
    "Tsadi": ["Dalet", "Yud", "Hei", "Cof"],
    "Cof": ["Vav", "Pei", "Dalet", "Reish"],
    "Reish": ["Yud", "Shin", "Gimel", "Tav"],
    "Shin": ["Yud", "Nun", "Bet", "Alef"],
    "Tav": ["Vav", "Yud", "Alef", "Shin"]
}

def processar_semente(prompt: str) -> dict:
    prompt_limpo = prompt.strip().lower()
    semente = "Alef"
    for chave in MATRIZ_22_LETRAS:
        if chave.lower() in prompt_limpo:
            semente = chave
            break

    dados_semente = MATRIZ_22_LETRAS.get(semente, MATRIZ_22_LETRAS["Alef"])
    camada1 = dados_semente["milui"]
    cadeia = [semente]
    freq_total = dados_semente["frequencia_hz"]

    for letra in camada1:
        filhos = MATRIZ_22_LETRAS.get(letra, {}).get("milui", [])
        for sub in filhos:
            ult = cadeia[-1]
            permitidas = TRANSICOES_PERMITIDAS.get(ult, [])
            if sub in permitidas and sub not in cadeia:
                cadeia.append(sub)
                freq_total += MATRIZ_22_LETRAS.get(sub, {}).get("frequencia_hz", 0.0)

    arvore = " → ".join(cadeia)
    return {
        "resposta": f"Sinal interpretado com sucesso pelo Núcleo 3. A semente '{semente}' ({dados_semente['caractere']}) disparou um pulso de ressonância harmônica áurea. O filtro de adjacência semântica estabilizou a árvore de manifestação real: {arvore}.",
        "arvore": arvore,
        "estado": "10 (Ativação Construtiva)",
        "frequencia": f"{freq_total:.3f} Hz",
        "latencia": "0.012ms"
    }
