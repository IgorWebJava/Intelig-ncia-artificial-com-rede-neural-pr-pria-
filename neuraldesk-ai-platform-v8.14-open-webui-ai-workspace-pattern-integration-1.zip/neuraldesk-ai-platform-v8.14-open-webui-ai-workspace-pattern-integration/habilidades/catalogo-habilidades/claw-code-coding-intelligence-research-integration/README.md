<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: habilidades -->
# Claw Code Coding Intelligence Research Integration

Use current upstream evidence to extract coding-agent patterns, re-express them as NeuralDesk capabilities, preserve non-regression, record provenance/limitations, and validate UI/docs/tests before release. Never equate a registry surface with executable support.
