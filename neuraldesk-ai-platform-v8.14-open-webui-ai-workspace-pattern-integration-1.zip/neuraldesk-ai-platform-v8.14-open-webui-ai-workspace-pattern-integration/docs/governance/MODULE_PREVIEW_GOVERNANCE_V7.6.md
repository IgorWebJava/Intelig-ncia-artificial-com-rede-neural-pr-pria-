<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Module Preview Governance — V7.6

A module package is incomplete without its canonical preview artifact.

Required:

```text
preview/page-preview.png
preview/preview.json
docs/MODULE_PREVIEW.md
```

The preview validator blocks stale/missing previews in structural releases.
