#define _POSIX_C_SOURCE 200809L
#include "nd_relation.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s MODEL\n", argv[0]);
        return 2;
    }
    NDRelationClassifier r;
    char err[256];
    if (nd_relation_load(argv[1], &r, err, sizeof(err))) {
        fprintf(stderr, "%s\n", err);
        return 2;
    }
    char *line = NULL;
    size_t cap = 0;
    size_t total = 0, pass = 0, known = 0, unknown = 0, failures = 0;
    while (getline(&line, &cap, stdin) >= 0) {
        size_t n = strlen(line);
        while (n && (line[n - 1] == '\n' || line[n - 1] == '\r')) line[--n] = 0;
        char *tab = strchr(line, '\t');
        if (!tab) continue;
        *tab++ = 0;
        long expected = strtol(line, NULL, 10);
        NDRelationResult rr;
        if (nd_relation_infer(&r, tab, &rr, err, sizeof(err))) {
            fprintf(stderr, "infer: %s\n", err);
            free(line); nd_relation_free(&r); return 2;
        }
        int ok;
        if (expected == (long)ND_RELATION_COUNT) {
            ok = !rr.accepted;
            unknown++;
        } else {
            ok = rr.accepted && rr.relation_id == (uint32_t)expected;
            known++;
        }
        total++; pass += (size_t)ok;
        if (!ok) {
            failures++;
            if (failures <= 50u) {
                fprintf(stderr, "FAIL expected=%ld got=%s accepted=%d conf=%.6f margin=%.6f text=%s\n",
                        expected, nd_relation_name(rr.relation_id), rr.accepted, rr.confidence, rr.margin, tab);
            }
        }
    }
    free(line);
    nd_relation_free(&r);
    printf("relation_c_gold %zu/%zu known=%zu unknown=%zu\n", pass, total, known, unknown);
    return pass == total ? 0 : 1;
}
