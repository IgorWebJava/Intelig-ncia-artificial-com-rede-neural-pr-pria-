<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->
# AI HANDOFF — NeuralDesk V8.14

## Read first

1. `memória/ESTADO_ATUAL.json`
2. `docs/CURRENT_STATE.md`
3. `docs/SOURCE_OF_TRUTH.md`
4. `docs/ai/AI_CONTEXT_MANIFEST.json`
5. `docs/architecture/CURRENT_ENGINE_UI_COMPATIBILITY.md`
6. `platform/engine-ui-bridge/registry.json`
7. this skills/tooling registry
8. owner UI module `AI_MODULE_HANDOFF.md`
9. owner Neural Engine module `AI_HANDOFF.md` + `INTERFACE_COMPATIBILITY.md` when the change concerns future engine behavior

## Current version model

```text
Package/UI/Architecture/Docs/Memory/Skills: V8.14
Neural Engine documentation: V8.14
Neural Engine executable code: NOT IMPLEMENTED
```

## Stable profiles

`intelligence-experience-v2` / `workspace-runtime-v2` / `neuraldesk-intelligence-design-v2` / `cooperative-engine-bridge-v1` / `agent-platform-patterns-v1` / `coding-intelligence-patterns-v1` / `open-webui-ai-workspace-patterns-v1` / `module-quality-v2`.

## Development rule

Need → abstract development capability → tool/provider → workflow → quality gate. Do not bind continuity to a single AI product/tool name.

## Non-regression rule

`preserve → extend → bridge`.

- Preserve the V8.13 non-regression baseline and every additive V8.14 route, root alias, tab, action, contract and capability semantic.
- Add functionality through versioned/additive contracts unless an explicit migration is approved.
- Keep root HTML files as compatibility redirects; edit canonical UIs only under `modules/<module>/ui/`.
- Every future Neural Engine module must have an interface owner/headless representation in `platform/engine-ui-bridge/registry.json`.
- Never turn `UI_CONTRACT_READY` into an `ENGINE_IMPLEMENTED` claim without executable evidence.

## Truthfulness

Do not claim production autonomous assistant, backend, AI inference, DB writes, agent/tool execution, durable sessions/jobs, computer use, training or serving when only template UI states and documentation exist.

## Mandatory closing sequence

Update implementation/contract/docs/tests as applicable → memory/skills if structural → preview if visual → run non-regression + Engine/UI compatibility gates → run complete release gates → regenerate documentation status registry → regenerate documentation inventory → validate both → new version → one complete ZIP.

## Research inheritance

V8.8 Kimi K3, V8.9 Qwen3-Omni, V8.10 DeepSeek Harness, V8.12 AutoGPT Platform, V8.13 Claw Code and V8.14 Open WebUI research remain reference layers inside the current V8.14 blueprint. They are candidate patterns behind NeuralDesk capabilities, not direct product dependencies.


## V8.12 Agent Platform research
Read `neural-engine/research/autogpt-platform-2026/README.md` before implementing graph/marketplace/trigger/schedule/connector capabilities. No PolyForm Shield source code may be copied.


## V8.13 Coding Intelligence
Before coding-engine work, read `neural-engine/research/claw-code-2026/README.md`, `docs/architecture/CURRENT_CODING_INTELLIGENCE.md`, the owner module blueprint and `platform/engine-ui-bridge/registry.json`. Preserve prior surfaces and keep execution claims truthful. Profile: `coding-intelligence-patterns-v1`.


## V8.13 — Claw Code Coding Intelligence
Use `neural-engine/research/claw-code-2026/`, `docs/architecture/CURRENT_CODING_INTELLIGENCE.md` and the 13-coding-intelligence-runtime blueprints. Preserve V8.12 semantics and never claim the coding engine is connected until executable evidence exists.

## V8.14 AI Workspace integration
Read `neural-engine/research/open-webui-2026/` and preserve `open-webui-ai-workspace-patterns-v1`. Treat legacy Pipelines as non-adopted, extensions as untrusted until isolated/authorized, and UI readiness as distinct from engine execution.
