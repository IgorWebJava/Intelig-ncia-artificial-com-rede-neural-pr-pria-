<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# 121 — Agent Platform Architecture V7.5

```text
Project Registry
→ Agent Studio
→ Agent Definitions / Versions
→ Runtime Skills + Tool/Knowledge bindings
→ AI Capability Fabric
→ Teams / Workflows / Runs
→ Evaluation
→ Audit + Operations
```

Agents depend on public capabilities, never provider implementations.
