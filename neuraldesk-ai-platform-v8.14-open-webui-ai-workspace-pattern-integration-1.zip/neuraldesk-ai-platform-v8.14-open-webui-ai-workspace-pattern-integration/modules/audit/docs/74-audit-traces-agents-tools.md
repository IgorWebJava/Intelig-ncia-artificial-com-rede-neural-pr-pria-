<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# 74 — Traces, Agents & Tools

## Trace

```text
User Request
→ Router
→ Agent
→ Knowledge
→ Model
→ Tool Gateway
→ Tool
→ Response
```

## Agent Run

Registrar:

- run ID
- initiator
- task
- duration
- steps
- tools
- tokens
- cost
- result

## Regra de privacidade

Mostrar estados e eventos operacionais.

Não expor chain-of-thought privada.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
