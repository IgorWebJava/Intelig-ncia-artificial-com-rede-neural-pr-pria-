#include "nd_generative.h"
#include "nd_tokenizer.h"
#include <stdio.h>
#include <string.h>

typedef struct { unsigned char out[64]; size_t n; int pause_once; int paused; } TextCtx;
static int text_cb(const unsigned char *b,size_t n,void *u){TextCtx*c=(TextCtx*)u;if(!c||c->n+n>sizeof(c->out))return -1;memcpy(c->out+c->n,b,n);c->n+=n;if(c->pause_once&&!c->paused){c->paused=1;return 1;}return 0;}
int main(int argc,char**argv){NDGenerativeModel*m=NULL;NDTokenizer*t=NULL;NDGenTextStreamSession s;NDGenStreamControl ctl;TextCtx c;uint32_t prompt[1]={328u};size_t guard=0,pauses=0;if(argc!=3){fprintf(stderr,"usage: %s MODEL TOKENIZER\n",argv[0]);return 2;}if(nd_gen_load(argv[1],&m)||nd_tokenizer_load(argv[2],&t))return 3;memset(&ctl,0,sizeof(ctl));ctl.prefill_chunk_tokens=1;ctl.decode_chunk_tokens=2;memset(&c,0,sizeof(c));c.pause_once=1;nd_gen_text_stream_session_init(&s);if(nd_gen_text_stream_begin(&s,m,t,prompt,1,4))return 4;for(;;){NDGenStreamStatus st=nd_gen_text_stream_advance(&s,&ctl,text_cb,&c);if(st==ND_GEN_STREAM_DONE)break;if(st==ND_GEN_STREAM_PAUSED){pauses++;continue;}if(st!=ND_GEN_STREAM_MORE)return 5;if(++guard>32)return 6;}if(pauses!=1||c.n!=8||memcmp(c.out,"çççç",8)!=0)return 7;nd_gen_text_stream_session_free(&s);nd_tokenizer_free(t);nd_gen_free(m);puts("GENERATIVE_TEXT_STREAM PASS utf8Delta=true multibyte=çx4 backpressure=true canonicalTokenStreaming=true");return 0;}
