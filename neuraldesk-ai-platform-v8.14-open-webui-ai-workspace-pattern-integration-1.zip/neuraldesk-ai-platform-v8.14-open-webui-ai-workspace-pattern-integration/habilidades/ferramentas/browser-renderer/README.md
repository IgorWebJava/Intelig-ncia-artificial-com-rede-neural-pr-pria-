<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Chromium / Playwright Browser Validation

    Tool ID: `tool.browser-renderer`

    ## Role in NeuralDesk development

    Render canonical HTML/CSS, validate viewports, overflow, focus and multimodal phone behavior.

    ## Current implementations

    - `Playwright`
- `Chromium`

    ## Capabilities provided

    - `browser.render.v1`
- `browser.viewport-test.v1`
- `browser.screenshot.v1`
- `test.visual.execute.v1`

    ## Constraints

    - If local navigation is restricted, inline CSS and use set_content.
- Visual tests do not prove backend behavior.

    ## Portable alternatives

    - WebDriver
- Puppeteer
- browser automation service

    ## Rule

    The capability is more important than the tool name. A future AI may replace this tool if it provides equivalent capabilities and passes the relevant quality gates.
