#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, subprocess, tempfile
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
TRAIN=ROOT/'training/train_generative_micro_v074.py'
BIN=ROOT/'build/nd_generative_logits'
spec=importlib.util.spec_from_file_location('v074train',TRAIN); m=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(m)
torch.set_num_threads(1); torch.set_num_interop_threads(1); torch.use_deterministic_algorithms(True); torch.backends.mkldnn.enabled=False; torch.manual_seed(7402); np.random.seed(7402)
model=m.Micro().eval(); assert sum(p.numel() for p in model.parameters())==m.PARAMS
tokens=[257,81,117,97,110,116,105,122,97,99,97,111,259]
with torch.no_grad(): py=model(torch.tensor(tokens,dtype=torch.long)[None,:])[0,-1].cpu().numpy()
with tempfile.TemporaryDirectory(prefix='nd-v074-parity-') as td:
    asset=Path(td)/'candidate.ndgm'; m.export_ndgm(model,asset)
    p=subprocess.run([str(BIN),str(asset),*map(str,tokens)],cwd=ROOT,text=True,capture_output=True,check=True)
    c=np.array([float(line.split()[1]) for line in p.stdout.splitlines()],dtype=np.float64)
assert c.shape==(m.V,)
d=np.abs(c-py.astype(np.float64)); mx=float(d.max()); pi=int(py.argmax()); ci=int(c.argmax())
assert pi==ci,(pi,ci,mx)
assert mx<=2.0e-5,mx
print(f'PYTHON_C_GENERATIVE_PARITY PASS maxAbs={mx:.9g} top1={pi} params={m.PARAMS}')
