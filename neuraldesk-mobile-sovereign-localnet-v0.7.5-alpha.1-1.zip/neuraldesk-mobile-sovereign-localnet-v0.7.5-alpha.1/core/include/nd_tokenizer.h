#ifndef ND_TOKENIZER_H
#define ND_TOKENIZER_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define ND_TOKENIZER_VOCAB 512u
#define ND_TOKENIZER_PAD 256u
#define ND_TOKENIZER_BOS 257u
#define ND_TOKENIZER_EOS 258u
#define ND_TOKENIZER_SEP 259u
typedef struct NDTokenizer NDTokenizer;
int nd_tokenizer_load(const char *path, NDTokenizer **out);
void nd_tokenizer_free(NDTokenizer *tok);
size_t nd_tokenizer_vocab(const NDTokenizer *tok);
int nd_tokenizer_encode(const NDTokenizer *tok,const unsigned char *bytes,size_t byte_count,uint32_t *tokens,size_t token_capacity,size_t *token_count);
int nd_tokenizer_decode(const NDTokenizer *tok,const uint32_t *tokens,size_t token_count,unsigned char *bytes,size_t byte_capacity,size_t *byte_count);
int nd_tokenizer_decode_token_bytes(const NDTokenizer *tok,uint32_t token,unsigned char *bytes,size_t byte_capacity,size_t *byte_count);
#ifdef __cplusplus
}
#endif
#endif
