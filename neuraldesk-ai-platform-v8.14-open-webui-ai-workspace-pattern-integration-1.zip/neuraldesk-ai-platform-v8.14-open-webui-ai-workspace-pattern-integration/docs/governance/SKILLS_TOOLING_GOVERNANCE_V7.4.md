<!-- neuraldesk-documentation-sync: V8.8 -->
<!-- neuraldesk-document-status: HISTORICAL-BASELINE; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation status:** historical/version-specific baseline preserved under the V7.7 synchronization. For current truth use `docs/CURRENT_STATE.md` and the relevant module `docs/CURRENT_STATE.md`.

# Skills & Tooling Governance — V7.4

A structural change is incomplete when it introduces a new method/tool/capability but fails to update `habilidades/`.

Required release evidence now includes:

```text
tools/validate_skills.py
```

The file-based skills registry is the portable source of truth for future AIs/teams.
