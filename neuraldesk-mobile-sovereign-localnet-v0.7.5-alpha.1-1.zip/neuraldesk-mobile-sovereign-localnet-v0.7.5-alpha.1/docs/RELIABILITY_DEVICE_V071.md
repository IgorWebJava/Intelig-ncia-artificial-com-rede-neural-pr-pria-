# Reliability, Checkpoint & Device Pre-Cert — v0.7.1-alpha.1

O Run Reliability Journal persiste apenas IDs/estados/timestamps/source/profile e converte runs `RUNNING` abandonados em `ABANDONED` no próximo boot. Prompt, resposta e erro bruto não são persistidos.

Checkpoints de treino são transitórios, possuem SHA sidecar e bindings de arquitetura/corpus/tokenizer/config; drift e tamper falham fechado, e o gate prova igualdade da trajetória resumed com a execução ininterrupta.

O Device Lab software valida uma matriz de MEMORY/THERMAL/ENERGY/NETWORK/LIFECYCLE/ACCESSIBILITY com privacy guard. Nesta release `physicalRunPerformed=false` e `certified=false`. O Android toolchain admission permanece `ARTIFACTS_PENDING`; cross-target ABI não equivale a app link/device execution.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
