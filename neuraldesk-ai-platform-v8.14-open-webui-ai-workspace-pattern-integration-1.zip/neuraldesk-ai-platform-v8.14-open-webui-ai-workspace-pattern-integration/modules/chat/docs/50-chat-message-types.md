<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: HISTORICAL-OR-REFERENCE-BASELINE; owner: neuraldesk.chat; current: modules/chat/docs/CURRENT_STATE.md -->
# 50 — Tipos de Mensagem e Estados

## Tipos visuais

- user message;
- AI message;
- file attachment;
- image attachment;
- system event;
- agent activity;
- tool call;
- tool result;
- research progress;
- approval request;
- artifact;
- branch suggestion;
- processing state;
- error/retry state.

## Estados operacionais esperados

```text
Idle
Typing
Uploading
Processing
Thinking
Searching
Retrieving
Using Tool
Waiting Approval
Generating
Completed
Stopped
Error
Retrying
```

O backend futuro será responsável por controlar o estado real.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/chat/
UI:        modules/chat/ui/chat.html
CSS:       modules/chat/ui/chat.css
Manifest:  modules/chat/module.manifest.json
Contracts: modules/chat/contracts/
Data:      modules/chat/data/
Docs:      modules/chat/docs/
```

The root `chat.html` file, when present, is only a backward-compatible route alias.
