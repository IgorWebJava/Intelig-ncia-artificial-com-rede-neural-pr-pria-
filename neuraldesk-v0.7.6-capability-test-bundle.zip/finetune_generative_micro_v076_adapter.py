#!/usr/bin/env python3
"""Bounded v0.7.6 adapter-style SFT for Micro-v3.
Trains only the top transformer blocks + final RMSNorm, preserving the single
NDGM/C99 runtime. Stage-only and never writes models/.
"""
from __future__ import annotations
import argparse, hashlib, json, math, os, random, subprocess, sys
from pathlib import Path
import numpy as np, torch
from train_generative_micro_v074_v3 import ROOT, DATA, MicroV3, Tok, ch, export, oh, readj, sha, th
from finetune_generative_micro_v074_v3_sft_v2 import sftrow_v2
PRE=ROOT/'scripts/pre_generation_lessons_check.py'; V76=ROOT/'training/data/generative_v076'
SCHEMA='nd-v076-micro-v3-topblock-sft-config-v1'; CPS='nd-v076-micro-v3-topblock-sft-checkpoint-v1'
def ps(n,seed,tag):
 p=list(range(n));r=random.Random(int.from_bytes(hashlib.sha256(f'{seed}|{tag}'.encode()).digest()[:8],'little'));r.shuffle(p);return p
def cyc(p,start,count):return [p[(start+i)%len(p)] for i in range(count)]
def load_pred(path):
 side=json.loads(path.with_suffix(path.suffix+'.json').read_text());assert sha(path)==side['checkpointSha256'];b=torch.load(path,map_location='cpu',weights_only=False);assert b['schema']=='nd-v074-micro-v3-sft-v2-checkpoint-v1' and th(b['model'].items())==b['modelStateSha256'];return {'checkpointSha256':sha(path),'configSha256':b['configSha256'],'modelStateSha256':b['modelStateSha256'],'model':b['model']}
def cpwrite(path,m,opt,cfg,st):
 body={'schema':CPS,'config':cfg,'configSha256':ch(cfg),'state':st,'model':m.state_dict(),'optimizer':opt.state_dict(),'modelStateSha256':th(m.state_dict().items()),'optimizerStateSha256':oh(opt)};path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp');torch.save(body,tmp)
 with tmp.open('rb+') as f:os.fsync(f.fileno())
 h=sha(tmp);os.replace(tmp,path);side={'checkpointSha256':h,'configSha256':body['configSha256'],'modelStateSha256':body['modelStateSha256'],'optimizerStateSha256':body['optimizerStateSha256'],'state':st};path.with_suffix(path.suffix+'.json').write_text(json.dumps(side,indent=2,sort_keys=True)+'\n');return side
def cpload(path,m,opt,cfg):
 side=json.loads(path.with_suffix(path.suffix+'.json').read_text());assert sha(path)==side['checkpointSha256'] and side['configSha256']==ch(cfg);b=torch.load(path,map_location='cpu',weights_only=False);assert b['schema']==CPS and b['config']==cfg;m.load_state_dict(b['model']);opt.load_state_dict(b['optimizer']);assert th(m.state_dict().items())==b['modelStateSha256'] and oh(opt)==b['optimizerStateSha256'];return b
def batch(rows1,rows2,p1,p2,cursor,tok,n,prompt_cap):
 idx1=cyc(p1,cursor*2,2);idx2=cyc(p2,cursor*2,2);xy=[]
 for i in idx1:xy.append(sftrow_v2(rows1[i],tok,n,prompt_cap,False)[:2])
 for i in idx2:xy.append(sftrow_v2(rows2[i],tok,n,prompt_cap,False)[:2])
 return torch.stack([q[0] for q in xy]),torch.stack([q[1] for q in xy])
def eval_rows(m,rows,tok,n,prompt_cap,limit=0):
 rows=rows[:limit] if limit else rows;m.eval();vals=[]
 with torch.no_grad():
  for st in range(0,len(rows),8):
   xy=[sftrow_v2(r,tok,n,prompt_cap,False)[:2] for r in rows[st:st+8]];x=torch.stack([q[0] for q in xy]);y=torch.stack([q[1] for q in xy]);z=m(x);raw=torch.nn.functional.cross_entropy(z.reshape(-1,512),y.reshape(-1),ignore_index=-100,reduction='none').reshape(y.shape);mask=y.ne(-100);vals += ((raw*mask).sum(1)/mask.sum(1).clamp_min(1)).tolist()
 m.train();return sum(vals)/len(vals)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--predecessor',required=True);ap.add_argument('--output-dir',required=True);ap.add_argument('--checkpoint-dir',required=True);ap.add_argument('--resume');ap.add_argument('--batches',type=int,default=1000);ap.add_argument('--seq-len',type=int,default=128);ap.add_argument('--prompt-cap',type=int,default=40);ap.add_argument('--lr',type=float,default=6e-5);ap.add_argument('--threads',type=int,default=4);ap.add_argument('--train-blocks',type=int,default=3);ap.add_argument('--checkpoint-every',type=int,default=200);ap.add_argument('--eval-limit',type=int,default=0);a=ap.parse_args();subprocess.run([sys.executable,str(PRE)],cwd=ROOT,check=True)
 torch.set_num_threads(a.threads);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.backends.mkldnn.enabled=False;random.seed(7602);np.random.seed(7602);torch.manual_seed(7602)
 tok=Tok(DATA/'tokenizer-v2.ndtk');rich=readj(DATA/'rich_sft.jsonl');proj=readj(V76/'project_sft_train.jsonl');ph=readj(V76/'project_sft_holdout.jsonl');pv=readj(DATA/'pira_validation.jsonl');pv2=[{'question':r['question'],'response':r['answer']} for r in pv];pred=load_pred(Path(a.predecessor))
 cfg={'schema':SCHEMA,'archParams':11229760,'seed':7602,'seqLen':a.seq_len,'promptCap':a.prompt_cap,'lr':a.lr,'threads':a.threads,'trainTopBlocks':a.train_blocks,'batch':{'rich':2,'project':2,'total':4},'batches':a.batches,'bindings':{'rich':sha(DATA/'rich_sft.jsonl'),'projectTrain':sha(V76/'project_sft_train.jsonl'),'projectHoldout':sha(V76/'project_sft_holdout.jsonl'),'projectProvenance':sha(V76/'PROVENANCE.json'),'tokenizer':sha(DATA/'tokenizer-v2.ndtk')},'predecessor':{k:pred[k] for k in ('checkpointSha256','configSha256','modelStateSha256')}}
 m=MicroV3();m.load_state_dict(pred['model']);
 for p in m.parameters():p.requires_grad=False
 for blk in list(m.blocks)[-a.train_blocks:]:
  for p in blk.parameters():p.requires_grad=True
 for p in m.final_rms.parameters():p.requires_grad=True
 tr=[p for p in m.parameters() if p.requires_grad];print('V076_ADAPTER trainable',sum(p.numel() for p in tr),'total',sum(p.numel() for p in m.parameters()),flush=True);opt=torch.optim.AdamW(tr,lr=a.lr,weight_decay=.01);st={'batchCursor':0,'updates':0,'richSeen':0,'projectSeen':0};p1=ps(len(rich),7602,'rich');p2=ps(len(proj),7602,'project')
 if a.resume:b=cpload(Path(a.resume),m,opt,cfg);st=b['state'];print('V076_ADAPTER_RESUME',st,flush=True)
 init_pira=eval_rows(m,pv2,tok,a.seq_len,a.prompt_cap,a.eval_limit);init_proj=eval_rows(m,ph,tok,a.seq_len,a.prompt_cap,a.eval_limit);print(f'V076_ADAPTER_EVAL initialPira={init_pira:.6f} initialProjectHoldout={init_proj:.6f}',flush=True)
 while st['batchCursor']<a.batches:
  x,y=batch(rich,proj,p1,p2,st['batchCursor'],tok,a.seq_len,a.prompt_cap);opt.zero_grad(set_to_none=True);z=torch.nn.functional.cross_entropy(m(x).reshape(-1,512),y.reshape(-1),ignore_index=-100);z.backward();gn=float(torch.nn.utils.clip_grad_norm_(tr,1.0));opt.step();st['batchCursor']+=1;st['updates']+=1;st['richSeen']+=2;st['projectSeen']+=2
  if st['updates']==1 or st['updates']%50==0:print(f"V076_ADAPTER batch={st['batchCursor']}/{a.batches} loss={z.detach().item():.6f} grad={gn:.4f} richSeen={st['richSeen']} projectSeen={st['projectSeen']}",flush=True)
  if a.checkpoint_every and st['batchCursor']%a.checkpoint_every==0:
   pp=Path(a.checkpoint_dir)/f"v076-adapter-b{st['batchCursor']}.pt";ss=cpwrite(pp,m,opt,cfg,st);print('CHECKPOINT',pp,ss['checkpointSha256'],flush=True)
 final_pira=eval_rows(m,pv2,tok,a.seq_len,a.prompt_cap,a.eval_limit);final_proj=eval_rows(m,ph,tok,a.seq_len,a.prompt_cap,a.eval_limit);out=Path(a.output_dir);fp=out/'staging/v076-adapter-fp32.ndgm';q8=out/'staging/v076-adapter-q8.ndgm';q4=out/'staging/v076-adapter-q4.ndgm';term=Path(a.checkpoint_dir)/'v076-adapter-terminal.pt';side=cpwrite(term,m,opt,cfg,st);report={'schema':'neuraldesk-v076-adapter-sft-report-v1','status':'EXPERIMENTAL_NOT_PROMOTED','state':st,'trainableParams':sum(p.numel() for p in tr),'initial':{'piraValidationLoss':init_pira,'projectHoldoutLoss':init_proj},'final':{'piraValidationLoss':final_pira,'projectHoldoutLoss':final_proj},'checkpointSha256':side['checkpointSha256'],'modelStateSha256':side['modelStateSha256'],'fp32':{'path':str(fp),'sha256':export(m,fp,'fp32')},'q8':{'path':str(q8),'sha256':export(m,q8,'q8')},'q4':{'path':str(q4),'sha256':export(m,q4,'q4')},'promotionAuthorized':False};out.mkdir(parents=True,exist_ok=True);(out/'ADAPTER_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print('V076_ADAPTER_TERMINAL',json.dumps(report['final']),flush=True)
if __name__=='__main__':main()
