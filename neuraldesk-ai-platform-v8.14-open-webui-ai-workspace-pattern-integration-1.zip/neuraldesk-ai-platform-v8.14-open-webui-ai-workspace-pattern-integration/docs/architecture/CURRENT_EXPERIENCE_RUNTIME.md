<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.experience-runtime -->
# Current Experience Runtime — V8.11

The implemented experience runtime remains `workspace-runtime-v2` and now carries the compatibility profile `cooperative-engine-bridge-v1`.

## Experience runtime capabilities

- `ui.adaptive-inspector.v1`
- `ui.artifact.workspace.v1`
- `ui.command_palette.v1`
- `ui.context-lens.v1`
- `ui.context.compaction.v1`
- `ui.density.v1`
- `ui.direct.command.v1`
- `ui.engine.bridge.v1`
- `ui.extension.governance.v1`
- `ui.global.search.v1`
- `ui.harness.ablation.v1`
- `ui.job.durability.v1`
- `ui.notification.center.v1`
- `ui.provenance.v1`
- `ui.runtime.interaction.v1`
- `ui.runtime.invariants.v1`
- `ui.sandbox.policy.v1`
- `ui.session.replay.v1`
- `ui.session.schema.v1`
- `ui.specialized-workspace.v1`
- `ui.subagent.federation.v1`
- `ui.task.center.v1`
- `ui.tool.effect.durability.v1`
- `ui.trust-layer.v1`
- `ui.turn.step.timeline.v1`
- `ui.unknown-outcome.v1`
- `ui.version-diff.v1`
- `ui.workflow.canvas.v1`
- `ui.workspace.shell.v1`

## V8.11 bridge behavior

The Engine Bridge is additive. It exposes future engine state, capability ownership, truth-boundary status and local UI simulation without performing backend/model/tool/agent execution. It can be opened/closed and locally simulated by module-owned JavaScript, but it performs no network, persistent or Neural Engine work.

## Non-regression requirement

The V8.10 semantic baseline is captured in `docs/verification/V8.10-NON-REGRESSION-BASELINE.json` and validated by `tools/validate_non_regression.py`.
