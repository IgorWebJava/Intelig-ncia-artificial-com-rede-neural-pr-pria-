<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.agents; current: modules/agents/docs/CONTRACTS_AND_CAPABILITIES.md -->
# Agent Projects & Multi-Agent Studio — Contracts & Capabilities

## Public contract set

- `contracts/openapi.yaml`
- `contracts/asyncapi.yaml`
- `contracts/config.schema.json`
- `contracts/capabilities.json`
- `contracts/permissions.json`
- `contracts/adaptive-ui.json`

## Provides

- `agents.catalog.v1`
- `agents.definition.v1`
- `agents.version.v1`
- `agents.run.v1`
- `agents.team.v1`
- `agents.handoff.v1`
- `agents.workflow.v1`
- `agents.skill.bind.v1`
- `agents.template.v1`
- `agents.evaluate.v1`

## Requires

- `project.manage.v1`
- `agent.skill.catalog.v1`
- `agent.skill.create.v1`
- `agent.skill.version.v1`
- `ai.execute.v1`
- `tools.catalog.v1`
- `tools.execute.v1`
- `knowledge.retrieve.v1`
- `training.evaluate.v1`
- `media.asset.v1`
- `approval.request.v1`
- `config.resolve.v1`
- `audit.write.v1`
- `telemetry.emit.v1`
- `ui.adaptive.v1`
- `ui.multimodal.surface.v1`
- `ui.runtime.interaction.v1`
- `ui.workspace.shell.v1`
- `ui.command_palette.v1`
- `ui.global.search.v1`
- `ui.task.center.v1`
- `ui.notification.center.v1`
- `ui.workflow.canvas.v1`
- `ui.context-lens.v1`
- `ui.provenance.v1`
- `ui.trust-layer.v1`
- `ui.density.v1`
- `ui.version-diff.v1`
- `ui.adaptive-inspector.v1`
- `ui.specialized-workspace.v1`

## UI contract

- experience: `intelligence-experience-v2`
- runtime: `workspace-runtime-v2`
- design: `neuraldesk-intelligence-design-v2`
- template scope: `ui-only`

## Compatibility

Public contracts follow N/N-1 during migrations unless explicitly waived. Capability resolution must remain valid before release.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
