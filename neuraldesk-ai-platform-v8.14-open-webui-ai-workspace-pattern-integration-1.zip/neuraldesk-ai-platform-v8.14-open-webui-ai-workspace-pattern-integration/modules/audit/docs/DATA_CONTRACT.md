<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: neuraldesk.audit; current: modules/audit/docs/CURRENT_STATE.md -->
# Data Contract — audit-center.html

## Responsibility

Audit events, traces and integrity metadata

## Access rule

```text
Page / Client
→ API / BFF
→ Application Service
→ Data Platform
```

The browser/page does **not** receive direct database credentials.

## Authoritative data

- `audit_events`
- `trace_index`
- `integrity_checks`
- `retention_policies`

## Events consumed/emitted

- `audit.*`
- `system.*`
- `config.changed`

## Consistency

Durable changes use a database transaction. When other modules must react, the transaction also writes an outbox event. Consumers refresh their state from the authoritative service/data source.

## Security

- authenticated access;
- authorization before writes;
- tenant/project scope where applicable;
- audit for sensitive changes;
- secrets stored as external secret references, not plaintext configuration.

## V7.1 — Canonical module note

This document is retained as part of the module history/specification.

Canonical V7.x locations:

```text
Module:    modules/audit/
UI:        modules/audit/ui/audit-center.html
CSS:       modules/audit/ui/audit-center.css
Manifest:  modules/audit/module.manifest.json
Contracts: modules/audit/contracts/
Data:      modules/audit/data/
Docs:      modules/audit/docs/
```

The root `audit-center.html` file, when present, is only a backward-compatible route alias.
