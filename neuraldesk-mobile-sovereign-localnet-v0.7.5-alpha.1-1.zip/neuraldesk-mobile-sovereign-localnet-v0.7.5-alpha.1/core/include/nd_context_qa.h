#ifndef ND_CONTEXT_QA_H
#define ND_CONTEXT_QA_H

#include <stddef.h>
#include <stdint.h>
#include "nd_relation.h"

#define ND_QA_MAGIC 0x3151444eu
#define ND_QA_VERSION_V1 1u
#define ND_QA_VERSION 2u

typedef struct {
    uint32_t magic, version, vocab_size, embedding_dim, hidden_dim, radius, max_span_bytes;
} NDContextQAHeader;

typedef struct {
    NDContextQAHeader h;
    float *storage;
    size_t storage_floats;
    float *embedding;
    float *window;
    float *wq;
    float *relation_embedding;
    float *bias;
    float *w_start;
    float b_start;
    float *w_end;
    float b_end;
} NDContextQA;

size_t nd_context_qa_expected_floats(const NDContextQAHeader *h);
int nd_context_qa_load(const char *path, NDContextQA *q, char *err, size_t errcap);
void nd_context_qa_free(NDContextQA *q);
int nd_context_qa_extract_relation(const NDContextQA *q, uint32_t relation_id,
                                   const char *question, const char *context,
                                   char *out, size_t outcap, float *score,
                                   char *err, size_t errcap);
int nd_context_qa_extract(const NDContextQA *q, const char *question, const char *context,
                          char *out, size_t outcap, float *score, char *err, size_t errcap);

#endif
