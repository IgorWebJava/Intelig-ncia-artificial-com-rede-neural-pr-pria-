package com.example.engine.plugins

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.MatrizLetras
import com.example.engine.core.QcnnExecutionContext
import kotlin.math.sin

/**
 * Plugin de Síntese Acústica Quântica via PCM Senoidal.
 */
class AudioSynthesisPlugin : IQcnnPlugin {
    override val pluginId: String = "audio_synthesis"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        if (!isEnabled) return context

        val freqBase = MatrizLetras.MATRIZ_22[context.targetSeed]?.frequenciaHz ?: 1.618
        val freqSom = (55.0 + (freqBase * 1.5)).coerceIn(80.0, 880.0)

        playSubtleQuantumTone(freqSom)
        return context
    }

    private fun playSubtleQuantumTone(freqHz: Double) {
        Thread {
            try {
                val sampleRate = 22050
                val durationMs = 100
                val numSamples = (durationMs * sampleRate) / 1000
                val buffer = ShortArray(numSamples)

                for (i in 0 until numSamples) {
                    val time = i.toDouble() / sampleRate
                    val envelope = when {
                        i < numSamples * 0.2 -> (i.toDouble() / (numSamples * 0.2))
                        i > numSamples * 0.8 -> ((numSamples - i).toDouble() / (numSamples * 0.2))
                        else -> 1.0
                    }
                    val sampleVal = sin(2.0 * Math.PI * freqHz * time) * envelope * 0.12 * Short.MAX_VALUE
                    buffer[i] = sampleVal.toInt().toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()

                Thread.sleep(durationMs.toLong() + 20)
                audioTrack.release()
            } catch (_: Exception) {
                // Modo silencioso caso dispositivo não tenha suporte a áudio no momento
            }
        }.start()
    }
}
