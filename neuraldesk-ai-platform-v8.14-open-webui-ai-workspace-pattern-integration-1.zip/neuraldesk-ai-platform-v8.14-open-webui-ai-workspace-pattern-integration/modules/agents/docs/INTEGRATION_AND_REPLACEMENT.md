<!-- neuraldesk-documentation-sync: V8.13 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.agents; current: modules/agents/docs/INTEGRATION_AND_REPLACEMENT.md -->
# Agent Projects & Multi-Agent Studio — Integration & Replacement

## Integration

Consumers integrate through public capabilities/contracts. Private implementation and private tables are not integration surfaces.

## Replacement sequence

```text
manifest validation
→ contract validation
→ capability resolution
→ contract/module tests
→ data migration check
→ shadow/canary when runtime exists
→ binding switch
→ observability
→ rollback readiness
```

UI replacement must preserve required adaptive/intelligence experience contracts or explicitly version them.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.
