# Memory and Context Strategy

Memory is not one vector database.

Scopes:
- user;
- project;
- conversation;
- session;
- agent working memory;
- organizational knowledge.

Context compilation must:
- retrieve only relevant memories;
- respect permissions and retention;
- track source/provenance;
- enforce token/context budgets;
- summarize safely;
- invalidate stale external facts;
- support forget/export.

Success is measured by task quality and false-memory rate, not by amount stored.
