<!-- neuraldesk-documentation-sync: V8.10 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: platform.documentation; current: docs/CURRENT_STATE.md -->
> **Documentation sync:** reviewed under V7.7. If this specialized document conflicts with a current-state document or manifest, the current source-of-truth precedence applies.

# 46 — Checklist de Desacoplamento

- [x] `index.html` é apenas launcher.
- [x] Chat possui HTML próprio.
- [x] Dashboard possui HTML próprio.
- [x] Knowledge Studio possui HTML próprio.
- [x] Knowledge Center possui HTML próprio.
- [x] Tool Center possui HTML próprio.
- [x] Settings possui HTML próprio.
- [x] Páginas podem ser abertas diretamente.
- [x] Nenhuma página depende do conteúdo HTML do index.
- [x] Nenhum JavaScript foi adicionado.
- [x] Nenhuma tag `<script>` foi adicionada.
- [x] Navegação aponta para páginas reais.
- [x] Documentação de integração atualizada.
