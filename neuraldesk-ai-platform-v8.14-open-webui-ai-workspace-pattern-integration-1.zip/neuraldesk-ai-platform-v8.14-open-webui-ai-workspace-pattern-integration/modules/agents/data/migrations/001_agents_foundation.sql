-- NeuralDesk V7.5 — Agents module reference migration
CREATE SCHEMA IF NOT EXISTS mod_agents;

CREATE TABLE IF NOT EXISTS mod_agents.agent_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL, -- public external reference; no private cross-module FK
  name text NOT NULL,
  description text,
  role text NOT NULL,
  objective text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  current_version_id uuid,
  owner_id text NOT NULL,
  tags jsonb NOT NULL DEFAULT '[]'::jsonb,
  deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mod_agents.agent_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id uuid NOT NULL REFERENCES mod_agents.agent_definitions(id),
  version_no bigint GENERATED ALWAYS AS IDENTITY,
  lifecycle text NOT NULL DEFAULT 'draft',
  model_profile_id text NOT NULL,
  instructions text NOT NULL,
  task_contract jsonb NOT NULL,
  autonomy text NOT NULL DEFAULT 'supervised',
  modalities jsonb NOT NULL DEFAULT '{}'::jsonb,
  guardrails jsonb NOT NULL DEFAULT '{}'::jsonb,
  budgets jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz
);

ALTER TABLE mod_agents.agent_definitions
  ADD CONSTRAINT agent_definitions_current_version_fk
  FOREIGN KEY (current_version_id) REFERENCES mod_agents.agent_versions(id) DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE IF NOT EXISTS mod_agents.agent_skill_bindings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), agent_version_id uuid NOT NULL REFERENCES mod_agents.agent_versions(id),
  skill_id text NOT NULL, skill_version text NOT NULL, config jsonb NOT NULL DEFAULT '{}'::jsonb, enabled boolean NOT NULL DEFAULT true
);
CREATE TABLE IF NOT EXISTS mod_agents.agent_tool_bindings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), agent_version_id uuid NOT NULL REFERENCES mod_agents.agent_versions(id),
  tool_id text NOT NULL, permission_scope jsonb NOT NULL DEFAULT '{}'::jsonb, approval_policy text
);
CREATE TABLE IF NOT EXISTS mod_agents.agent_knowledge_bindings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), agent_version_id uuid NOT NULL REFERENCES mod_agents.agent_versions(id),
  knowledge_ref text NOT NULL, access_scope jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS mod_agents.agent_teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), project_id uuid NOT NULL, name text NOT NULL,
  orchestration_mode text NOT NULL, supervisor_agent_id uuid, config jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS mod_agents.agent_team_members (
  team_id uuid NOT NULL REFERENCES mod_agents.agent_teams(id), agent_id uuid NOT NULL REFERENCES mod_agents.agent_definitions(id),
  role text, handoff_policy jsonb NOT NULL DEFAULT '{}'::jsonb, PRIMARY KEY(team_id,agent_id)
);
CREATE TABLE IF NOT EXISTS mod_agents.agent_workflows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), project_id uuid NOT NULL, name text NOT NULL, version_no bigint GENERATED ALWAYS AS IDENTITY,
  lifecycle text NOT NULL DEFAULT 'draft', graph jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS mod_agents.agent_run_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), agent_id uuid NOT NULL REFERENCES mod_agents.agent_definitions(id),
  agent_version_id uuid NOT NULL REFERENCES mod_agents.agent_versions(id), project_id uuid NOT NULL, status text NOT NULL,
  trace_id text NOT NULL, correlation_id text, usage jsonb NOT NULL DEFAULT '{}'::jsonb, started_at timestamptz NOT NULL DEFAULT now(), completed_at timestamptz
);
