"""
Testes unitários e de integração para os novos módulos multimodais:
- VisualMatrixPlugin
- AudioWaveformPlugin
- CodeSynthesisPlugin
- FileManagerPlugin
- VideoSequencerPlugin
"""

import unittest
import os
from qcnn.core.context import QcnnExecutionContext
from qcnn.plugins.visual_matrix import VisualMatrixPlugin
from qcnn.plugins.audio_waveform import AudioWaveformPlugin
from qcnn.plugins.code_synthesis import CodeSynthesisPlugin
from qcnn.plugins.file_manager import FileManagerPlugin
from qcnn.plugins.video_sequencer import VideoSequencerPlugin


class TestMultimodalPlugins(unittest.TestCase):

    def test_visual_matrix_svg_generation(self):
        plugin = VisualMatrixPlugin()
        ctx = QcnnExecutionContext(prompt="gerar imagem do grafo quantico")
        ctx.total_frequency_hz = 528.0
        res = plugin.execute(ctx)
        self.assertIn("imagem_svg", res.metadata)
        self.assertTrue(res.metadata["imagem_svg"].startswith("<svg"))
        self.assertIn("Multi-V Visual Matrix", res.custom_response)

    def test_audio_waveform_wav_generation(self):
        plugin = AudioWaveformPlugin()
        ctx = QcnnExecutionContext(prompt="gerar audio de 432hz")
        ctx.total_frequency_hz = 432.0
        res = plugin.execute(ctx)
        self.assertIn("audio_wav_base64", res.metadata)
        self.assertGreater(len(res.metadata["audio_wav_base64"]), 1000)
        self.assertIn("Audio Waveform", res.custom_response)

    def test_code_synthesis_python_and_kotlin(self):
        plugin = CodeSynthesisPlugin()
        
        ctx_py = QcnnExecutionContext(prompt="gerar codigo python de ressonancia")
        res_py = plugin.execute(ctx_py)
        self.assertEqual(res_py.metadata["linguagem_sintetizada"], "python")
        self.assertIn("ModuloHarmonico", res_py.custom_response)

        ctx_kt = QcnnExecutionContext(prompt="criar codigo kotlin para android")
        res_kt = plugin.execute(ctx_kt)
        self.assertEqual(res_kt.metadata["linguagem_sintetizada"], "kotlin")
        self.assertIn("package com.example", res_kt.custom_response)

    def test_file_manager_csv_and_json(self):
        plugin = FileManagerPlugin(base_dir="./arquivos_gerados_test")
        
        ctx_csv = QcnnExecutionContext(prompt="gerar csv de metricas")
        res_csv = plugin.execute(ctx_csv)
        self.assertEqual(res_csv.metadata["formato_arquivo"], "csv")
        self.assertTrue(os.path.exists(res_csv.metadata["arquivo_gerado"]))

        ctx_json = QcnnExecutionContext(prompt="gerar json de relatorio")
        res_json = plugin.execute(ctx_json)
        self.assertEqual(res_json.metadata["formato_arquivo"], "json")

    def test_video_sequencer_animation(self):
        plugin = VideoSequencerPlugin()
        ctx = QcnnExecutionContext(prompt="gerar video e animacao fractal")
        ctx.total_frequency_hz = 432.0
        res = plugin.execute(ctx)
        self.assertIn("animacao_svg", res.metadata)
        self.assertEqual(res.metadata["fps"], 60)
        self.assertIn("Video Sequencer", res.custom_response)


if __name__ == "__main__":
    unittest.main()
