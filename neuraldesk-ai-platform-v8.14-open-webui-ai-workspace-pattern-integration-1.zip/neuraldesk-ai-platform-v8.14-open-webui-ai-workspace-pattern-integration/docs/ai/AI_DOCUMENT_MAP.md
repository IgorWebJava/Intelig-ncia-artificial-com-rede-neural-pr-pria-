<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.ai-handoff; current: docs/ai/AI_DOCUMENT_MAP.md -->
# AI Document Map

## Present truth

- `memória/ESTADO_ATUAL.json`
- `docs/CURRENT_STATE.md`
- `docs/SOURCE_OF_TRUTH.md`
- `docs/architecture/CURRENT_*`
- `docs/governance/CURRENT_GOVERNANCE.md`

## Per module

- `module.manifest.json`
- `docs/CURRENT_STATE.md`
- `docs/MECHANICS_AND_FUNCTIONALITY.md`
- `docs/AI_MODULE_HANDOFF.md`
- `contracts/`
- `data/ownership.md`
- `tests/`
- `preview/`

## Development continuity

- `memória/` — what/why/current state/history
- `habilidades/` — how/tools/capabilities/workflows

## Historical evidence

Versioned architecture/governance/history/verification files are baselines only.

## V8.7 frontier readiness

Before planning executable Neural Engine work, read:
- `../frontier-readiness/MASTER_EVOLUTION_PROMPT.md`
- `../frontier-readiness/EXECUTION_ROADMAP.md`
- `../../neural-engine/registry/frontier-readiness.json`

Treat `D0`, `UI0`, parity targets and differentiation targets as documentation states, never as implemented capabilities.



## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
