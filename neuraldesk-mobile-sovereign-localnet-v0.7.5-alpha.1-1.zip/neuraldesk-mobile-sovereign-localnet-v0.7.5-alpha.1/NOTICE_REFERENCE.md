# Referência externa estudada

Referência: https://github.com/FareedKhan-dev/kimi-k3-in-c
Licença do repositório de referência: Apache-2.0.

Esta árvore não redistribui pesos Kimi K3 e não contém código copiado daquele repositório. Foram adotados apenas padrões de engenharia gerais: runtime pequeno em C, configuração/formatos fail-closed, memória limitada, cache explícito, testes de paridade e separação entre motor e produto.

Kimi K3 e seus pesos pertencem aos respectivos autores/licenciadores. NeuralDesk Mobile Sovereign LocalNet é uma implementação própria e independente.
