#!/usr/bin/env python3
"""Build deterministic NeuralDesk Open Knowledge Shard (NDOS v1)."""
from __future__ import annotations
import argparse, collections, hashlib, json, math, pathlib, struct, subprocess, sys

MAGIC=b"NDOSV001"
VERSION=1
BUCKET_COUNT=65536
TOP_K=96
FLAGS=1  # deterministic Portuguese/Latin-1 UTF-8 -> ASCII fold
ACCEPT_SCORE=0.33
ACCEPT_MARGIN=0.08
FNV_OFFSET=14695981039346656037
FNV_PRIME=1099511628211
MASK64=(1<<64)-1

_C3_FOLD={}
for vals,ch in [
 ((0x80,0x81,0x82,0x83,0x84,0x85,0xA0,0xA1,0xA2,0xA3,0xA4,0xA5),'a'),
 ((0x87,0xA7),'c'),((0x88,0x89,0x8A,0x8B,0xA8,0xA9,0xAA,0xAB),'e'),
 ((0x8C,0x8D,0x8E,0x8F,0xAC,0xAD,0xAE,0xAF),'i'),((0x91,0xB1),'n'),
 ((0x92,0x93,0x94,0x95,0x96,0xB2,0xB3,0xB4,0xB5,0xB6),'o'),
 ((0x99,0x9A,0x9B,0x9C,0xB9,0xBA,0xBB,0xBC),'u'),((0x9D,0xBD,0xBF),'y')]:
    for v in vals: _C3_FOLD[v]=ord(ch)

def normalize_bytes(text:str)->bytes:
    src=text.encode('utf-8'); out=bytearray(); sep=True; i=0
    def emit(c:int):
        nonlocal sep
        if 65<=c<=90: c+=32
        keep=(97<=c<=122) or (48<=c<=57)
        if keep: out.append(c); sep=False
        elif not sep and out: out.append(32); sep=True
    while i<len(src):
        x=src[i]
        if x<0x80: emit(x); i+=1; continue
        if x==0xC3 and i+1<len(src) and src[i+1] in _C3_FOLD:
            emit(_C3_FOLD[src[i+1]]); i+=2; continue
        if not sep and out: out.append(32); sep=True
        if x&0xE0==0xC0: i+=2
        elif x&0xF0==0xE0: i+=3
        elif x&0xF8==0xF0: i+=4
        else: i+=1
    if out and out[-1]==32: out.pop()
    return bytes(out)

def fnv1a64(data:bytes)->int:
    h=FNV_OFFSET
    for b in data: h=((h^b)*FNV_PRIME)&MASK64
    return h

def bucket(data:bytes)->int: return fnv1a64(data)&(BUCKET_COUNT-1)

def feature_buckets(text:str)->list[int]:
    norm=normalize_bytes(text); words=norm.split(b' ') if norm else []; out=[]
    out.extend(bucket(b'w:'+w) for w in words if w)
    out.extend(bucket(b'b:'+words[i]+b' '+words[i+1]) for i in range(len(words)-1) if words[i] and words[i+1])
    compact=norm.replace(b' ',b'_')
    for n in (3,4,5):
        prefix=(f'c{n}:').encode('ascii')
        out.extend(bucket(prefix+compact[i:i+n]) for i in range(max(0,len(compact)-n+1)))
    return out

def load_records(path:pathlib.Path)->list[dict]:
    rows=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
    if not rows: raise SystemExit('empty open knowledge records')
    ids=[r['source_id'] for r in rows]
    if len(ids)!=len(set(ids)): raise SystemExit('duplicate source_id')
    return rows

def build(records:list[dict]):
    counters=[]; df=collections.Counter()
    for r in records:
        c=collections.Counter(feature_buckets(r['question'])); counters.append(c); df.update(c.keys())
    n=len(records); idf={b:math.log((n+1.0)/(d+1.0))+1.0 for b,d in df.items()}
    vectors=[]; total=0
    for c in counters:
        items=[(b,float(cnt)*idf[b]) for b,cnt in c.items()]
        items=sorted(items,key=lambda x:(-x[1],x[0]))[:TOP_K]
        items.sort(key=lambda x:x[0]); norm=math.sqrt(sum(w*w for _,w in items))
        if not items or not math.isfinite(norm) or norm<=0: raise SystemExit('invalid record vector')
        vectors.append((items,norm)); total+=len(items)
    return idf,vectors,total

def write_asset(path:pathlib.Path,records,idf,vectors,total):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as f:
        f.write(MAGIC)
        f.write(struct.pack('<IIIIIIIdd',VERSION,len(records),BUCKET_COUNT,len(idf),total,TOP_K,FLAGS,ACCEPT_SCORE,ACCEPT_MARGIN))
        for b in sorted(idf): f.write(struct.pack('<If',b,float(idf[b])))
        for r,(items,norm) in zip(records,vectors):
            sid=r['source_id'].encode(); q=r['question'].encode(); a=r['answer'].encode(); split=0 if r.get('split')=='train' else 1
            f.write(struct.pack('<IIIIId',split,len(sid),len(q),len(a),len(items),norm)); f.write(sid); f.write(q); f.write(a)
            for b,w in items: f.write(struct.pack('<If',b,float(w)))

def main():
    root=pathlib.Path(__file__).resolve().parents[1]
    subprocess.run([sys.executable,str(root/'scripts/pre_generation_lessons_check.py')],cwd=root,check=True)
    ap=argparse.ArgumentParser(); ap.add_argument('--records',type=pathlib.Path,required=True); ap.add_argument('--output',type=pathlib.Path,required=True); ap.add_argument('--report',type=pathlib.Path,required=True)
    a=ap.parse_args(); rows=load_records(a.records); idf,vectors,total=build(rows); write_asset(a.output,rows,idf,vectors,total)
    report={'schema':'neuraldesk-open-knowledge-ndos-v1','magic':MAGIC.decode(),'version':VERSION,'records':len(rows),'bucketCount':BUCKET_COUNT,'idfBuckets':len(idf),'sparseEntries':total,'topK':TOP_K,'flags':FLAGS,'acceptScore':ACCEPT_SCORE,'acceptMargin':ACCEPT_MARGIN,'bytes':a.output.stat().st_size,'sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'featurePolicy':'UTF-8->ASCII deterministic fold; standard FNV-1a 64-bit -> 65536 fixed buckets; word uni/bi + char 3..5; sparse TF-IDF cosine'}
    a.report.parent.mkdir(parents=True,exist_ok=True); a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8'); print(json.dumps(report,sort_keys=True))
if __name__=='__main__': main()
