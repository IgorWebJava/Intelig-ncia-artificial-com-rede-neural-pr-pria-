#include "nd_relation.h"
#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ND_REL_HASH_OFFSET 32u
#define ND_REL_MAX_TEXT 65536u

static const char *NAMES[ND_RELATION_COUNT] = {
    "code","color","temp","owner","status","version","material","language","date","location",
    "capacity","weight","length","count","author","capital","organization","port","license","latency",
    "protocol","manufacturer","priority","region","checksum"
};

static void seterr(char *e,size_t n,const char *fmt,...){if(!e||!n)return;va_list a;va_start(a,fmt);vsnprintf(e,n,fmt,a);va_end(a);}
static int mul_ok(size_t a,size_t b,size_t *o){if(a&&b>SIZE_MAX/a)return 0;*o=a*b;return 1;}
static unsigned char lo(unsigned char c){return(c>='A'&&c<='Z')?(unsigned char)(c+32):c;}
static int ci_prefix(const char *p,const char *needle){while(*needle){if(!*p||lo((unsigned char)*p)!=lo((unsigned char)*needle))return 0;p++;needle++;}return 1;}
static int contains_ci(const char *s,const char *needle){size_t n=strlen(needle);if(!n)return 1;for(;*s;s++){size_t i=0;while(i<n&&s[i]&&lo((unsigned char)s[i])==lo((unsigned char)needle[i]))i++;if(i==n)return 1;}return 0;}

/* Match Python's r"\b\d+(?:[.:-]\d+)*\b" semantics closely enough
 * for the UTF-8 text accepted by this runtime.  In particular, a numeric
 * prefix embedded in an alphanumeric token (for example a hexadecimal
 * checksum beginning with a digit) must NOT be partially masked. */
static int regex_word_byte(unsigned char c){
    return (c>='0'&&c<='9')||(c>='A'&&c<='Z')||(c>='a'&&c<='z')||c=='_'||c>=128u;
}
static const char *numeric_regex_end(const char *begin,const char *p){
    if(!isdigit((unsigned char)*p))return NULL;
    if(p>begin&&regex_word_byte((unsigned char)p[-1]))return NULL;

    const char *q=p;
    while(isdigit((unsigned char)*q))q++;
    const char *best=!regex_word_byte((unsigned char)*q)?q:NULL;

    while((*q=='.'||*q==':'||*q=='-')&&isdigit((unsigned char)q[1])){
        q++;
        while(isdigit((unsigned char)*q))q++;
        if(!regex_word_byte((unsigned char)*q))best=q;
    }
    return best;
}
static uint32_t hp(unsigned char prefix,const unsigned char *p,size_t n){uint32_t h=2166136261u;h^=prefix;h*=16777619u;for(size_t i=0;i<n;i++){h^=p[i];h*=16777619u;}return h;}
static int isword(unsigned char x){return(x>='0'&&x<='9')||(x>='a'&&x<='z')||x>=128u||x=='-'||x=='_'||x=='/'||x=='.';}

static size_t append_normalized_token(unsigned char *out,size_t cap,size_t k,const char *token){
    size_t n=strlen(token);
    if(k>0u){if(k>=cap)return SIZE_MAX;out[k++]=' ';}
    if(k+n>cap)return SIZE_MAX;
    memcpy(out+k,token,n);
    return k+n;
}

static size_t clean_text(const char *in,unsigned char *out,size_t cap){
    size_t k=0u;
    int pending_space=0;
    const char *p=in;
    while(*p){
        if(ci_prefix(p,"Registro-")){
            const char *q=p+9;
            if(isdigit((unsigned char)*q)){
                while(isdigit((unsigned char)*q))q++;
                size_t z=append_normalized_token(out,cap,k,"entidade");
                if(z==SIZE_MAX)return 0u;
                k=z;
                pending_space=1;
                p=q;
                continue;
            }
        }
        if(isdigit((unsigned char)*p)){
            const char *q=numeric_regex_end(in,p);
            if(q){
                size_t z=append_normalized_token(out,cap,k,"numero");
                if(z==SIZE_MAX)return 0u;
                k=z;
                pending_space=1;
                p=q;
                continue;
            }
        }
        unsigned char c=(unsigned char)*p++;
        if(c>='A'&&c<='Z')c=(unsigned char)(c+32);
        if(isspace(c)){
            pending_space=(k>0u);
            continue;
        }
        if(pending_space){
            if(k>=cap)return 0u;
            out[k++]=' ';
            pending_space=0;
        }
        if(k>=cap)return 0u;
        out[k++]=c;
    }
    while(k>0u&&out[k-1u]==' ')k--;
    if(k>=cap)return 0u;
    out[k]=0;
    return k;
}

typedef struct { const char *v[5]; } Cue;
static const Cue CUES[ND_RELATION_COUNT] = {
    {{"código","codigo","identificador",NULL,NULL}}, {{"cor",NULL,NULL,NULL,NULL}}, {{"temperatura","graus celsius","sensor",NULL,NULL}},
    {{"responsável","responsavel","quem responde por",NULL,NULL}}, {{"status","situação","situacao","estado atual",NULL}}, {{"versão","versao","release",NULL,NULL}},
    {{"material","composição material","composicao material",NULL,NULL}}, {{"idioma","língua","lingua",NULL,NULL}}, {{"data","quando ocorre","quando está","quando esta","calendário"}},
    {{"localização","localizacao","onde fica","em qual local",NULL}}, {{"capacidade","comporta",NULL,NULL,NULL}}, {{"peso","pesa","massa",NULL,NULL}},
    {{"comprimento","quanto mede","medida de comprimento","mede",NULL}}, {{"quantidade","unidades","contagem","total de unidades",NULL}}, {{"autor","autoria","escreveu","quem produziu",NULL}},
    {{"capital",NULL,NULL,NULL,NULL}}, {{"organização","organizacao","entidade responde","cuida de","quem mantém"}}, {{"porta","endpoint numérico","endpoint numerico","escutando",NULL}},
    {{"licença","licenca","licenciamento",NULL,NULL}}, {{"latência","latencia","tempo de resposta","demora",NULL}}, {{"protocolo","padrão de comunicação","padrao de comunicacao","se comunica",NULL}},
    {{"fabricante","quem fabrica","empresa produziu","origem industrial",NULL}}, {{"prioridade","urgência","urgencia",NULL,NULL}}, {{"região","regiao","zona de implantação","zona de implantacao",NULL}},
    {{"checksum","hash","impressão de integridade","impressao de integridade",NULL}}
};

static int has_relation_cue(const char *text,uint32_t relation_id){
    if(!text||relation_id>=ND_RELATION_COUNT)return 0;
    for(size_t z=0u;z<5u&&CUES[relation_id].v[z];z++){
        if(contains_ci(text,CUES[relation_id].v[z]))return 1;
    }
    return 0;
}

static int has_unique_top_cue(const char *text,uint32_t top){
    if(top>=ND_RELATION_COUNT||!has_relation_cue(text,top))return 0;
    for(uint32_t ri=0u;ri<ND_RELATION_COUNT;ri++){
        if(ri!=top&&has_relation_cue(text,ri))return 0;
    }
    return 1;
}

static int build_features(const char *text,float *v,uint32_t dim,char *e,size_t ec){
    size_t n=strlen(text);if(!n||n>ND_REL_MAX_TEXT){seterr(e,ec,"relation text exceeds bounds");return -1;}
    unsigned char *b=(unsigned char*)malloc(n*2u+32u);if(!b){seterr(e,ec,"oom relation text");return -1;}
    size_t bn=clean_text(text,b,n*2u+31u);if(!bn){free(b);seterr(e,ec,"cannot normalize relation text");return -1;}
    memset(v,0,(size_t)dim*sizeof(float));
    for(uint32_t ri=0;ri<ND_RELATION_COUNT;ri++){int hits=0;for(size_t z=0;z<5u&&CUES[ri].v[z];z++)if(contains_ci((char*)b,CUES[ri].v[z]))hits++;if(hits){if(hits>3)hits=3;v[ri]=(float)hits*4.0f;}}
    size_t hdim=(size_t)dim-ND_REL_HASH_OFFSET;unsigned char *words[64];size_t wl[64],wc=0;
    size_t i=0;while(i<bn){while(i<bn&&!isword(b[i]))i++;size_t j=i;while(j<bn&&isword(b[j]))j++;if(j>i){if(wc<64u){words[wc]=b+i;wl[wc]=j-i;wc++;}v[ND_REL_HASH_OFFSET+hp('w',b+i,j-i)%hdim]+=2.0f;v[ND_REL_HASH_OFFSET+hp('W',b+i,j-i)%hdim]+=1.0f;}i=(j>i)?j:i+1u;}
    const size_t ns[3]={3u,4u,5u};const unsigned char ps[3]={'3','4','5'};
    for(size_t z=0;z<3u;z++){size_t ng=ns[z];if(bn<ng)continue;for(size_t x=0;x+ng<=bn;x++){int any=0;for(size_t y=0;y<ng;y++)if(!isspace(b[x+y])){any=1;break;}if(any)v[ND_REL_HASH_OFFSET+hp(ps[z],b+x,ng)%hdim]+=0.18f;}}
    for (size_t x = 0; x + 1u < wc; x++) {
        unsigned char tmp[160];
        size_t t = 0;
        if (wl[x] + wl[x + 1u] + 1u < sizeof(tmp)) {
            memcpy(tmp, words[x], wl[x]);
            t = wl[x];
            tmp[t++] = '_';
            memcpy(tmp + t, words[x + 1u], wl[x + 1u]);
            t += wl[x + 1u];
            v[ND_REL_HASH_OFFSET + hp('B', tmp, t) % hdim] += 0.5f;
        }
    }
    double ss=0.0;for(uint32_t x=0;x<dim;x++)ss+=(double)v[x]*v[x];if(ss<=0.0){free(b);seterr(e,ec,"empty relation features");return -1;}float inv=(float)(1.0/sqrt(ss));for(uint32_t x=0;x<dim;x++)v[x]*=inv;free(b);return 0;
}

int nd_relation_load(const char *path,NDRelationClassifier *r,char *e,size_t ec){
    if(!path||!r){seterr(e,ec,"invalid relation load");return -1;}memset(r,0,sizeof(*r));FILE *f=fopen(path,"rb");if(!f){seterr(e,ec,"cannot open relation model");return -1;}
    if(fread(&r->h,sizeof(r->h),1,f)!=1){fclose(f);seterr(e,ec,"short relation header");return -1;}
    NDRelationHeader *h=&r->h;if(h->magic!=ND_RELATION_MAGIC||h->version!=ND_RELATION_VERSION||h->feature_dim!=2048u||h->hidden_dim!=64u||h->classes!=ND_RELATION_COUNT+1u){fclose(f);seterr(e,ec,"invalid relation header");return -1;}
    size_t a,b,total;if(!mul_ok(h->feature_dim,h->hidden_dim,&a)||!mul_ok(h->hidden_dim,h->classes,&b)){fclose(f);seterr(e,ec,"relation size overflow");return -1;}total=a+h->hidden_dim+b+h->classes;
    r->storage=(float*)malloc(total*sizeof(float));if(!r->storage){fclose(f);seterr(e,ec,"oom relation weights");return -1;}r->storage_floats=total;
    if(fread(r->storage,sizeof(float),total,f)!=total||fgetc(f)!=EOF){fclose(f);nd_relation_free(r);seterr(e,ec,"truncated/trailing relation model");return -1;}fclose(f);
    float *p=r->storage;r->w1=p;p+=a;r->b1=p;p+=h->hidden_dim;r->w2=p;p+=b;r->b2=p;return 0;
}
void nd_relation_free(NDRelationClassifier *r){if(!r)return;free(r->storage);memset(r,0,sizeof(*r));}
int nd_relation_infer(const NDRelationClassifier *r,const char *text,NDRelationResult *res,char *e,size_t ec){
    if(!r||!r->storage||!text||!res){seterr(e,ec,"invalid relation infer");return -1;}uint32_t f=r->h.feature_dim,h=r->h.hidden_dim,c=r->h.classes;
    if(c<2u){seterr(e,ec,"relation classifier requires at least two classes");return -1;}
    float *x=(float*)calloc(f,sizeof(float)),*z=(float*)malloc(h*sizeof(float)),*log=(float*)malloc(c*sizeof(float));if(!x||!z||!log){free(x);free(z);free(log);seterr(e,ec,"oom relation workspace");return -1;}
    if(build_features(text,x,f,e,ec)){free(x);free(z);free(log);return -1;}for(uint32_t j=0;j<h;j++)z[j]=r->b1[j];for(uint32_t i=0;i<f;i++){if(x[i]==0)continue;const float *row=r->w1+(size_t)i*h;for(uint32_t j=0;j<h;j++)z[j]+=x[i]*row[j];}for(uint32_t j=0;j<h;j++)z[j]=tanhf(z[j]);
    for (uint32_t k = 0; k < c; k++) log[k] = r->b2[k];
    for (uint32_t j = 0; j < h; j++) {
        const float *row = r->w2 + (size_t)j * c;
        for (uint32_t k = 0; k < c; k++) log[k] += z[j] * row[k];
    }
    uint32_t top=0u;
    uint32_t second=1u;
    if(log[second]>log[top]){
        uint32_t tmp=top;
        top=second;
        second=tmp;
    }
    for(uint32_t k=2u;k<c;k++){
        if(log[k]>log[top]){
            second=top;
            top=k;
        }else if(log[k]>log[second]){
            second=k;
        }
    }
    float mx=log[top];double sum=0;for(uint32_t k=0;k<c;k++)sum+=exp((double)log[k]-mx);float p1=(float)(1.0/sum),p2=(float)(exp((double)log[second]-mx)/sum);
    res->relation_id=top;
    res->confidence=p1;
    res->margin=p1-p2;
    int calibrated=(top<ND_RELATION_COUNT&&p1>=0.30f&&res->margin>=0.10f);
    int explicit_unique=(top<ND_RELATION_COUNT&&p1>=0.30f&&has_unique_top_cue(text,top));
    res->accepted=(calibrated||explicit_unique)?1:0;
    free(x);free(z);free(log);return 0;
}
const char *nd_relation_name(uint32_t id){return id<ND_RELATION_COUNT?NAMES[id]:"unknown";}
