package com.neuraldesk.localnet

object RuntimeIdentity {
    const val VERSION = "0.7.5-alpha.1"
    const val USER_AGENT = "NeuralDeskLocalNet/$VERSION"
}
