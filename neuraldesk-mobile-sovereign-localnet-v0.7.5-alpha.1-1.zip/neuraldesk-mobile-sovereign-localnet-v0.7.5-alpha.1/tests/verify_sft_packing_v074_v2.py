#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'training'))
from train_generative_micro_v074_v3 import Tok
from finetune_generative_micro_v074_v3_sft_v2 import packing_stats, sftrow_v2
D=ROOT/'training/data/generative_v074_v2'; tok=Tok(D/'tokenizer-v2.ndtk')
rows=[json.loads(x) for x in (D/'rich_sft.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
st=packing_stats(rows,tok,128,48)
assert st['rows']==2563
assert st['tokenCoverage']>=0.80,st
# Label alignment: first non-masked target must be first answer token.
for r in rows[:64]:
    x,y,_=sftrow_v2(r,tok,128,48,False)
    nz=(y!=-100).nonzero(as_tuple=False).flatten()
    assert len(nz)>0
    first=int(nz[0]); expected=tok.encode(r['response'])[0] if tok.encode(r['response']) else 258
    assert int(y[first])==expected,(r['id'],first,int(y[first]),expected)
print('SFT_PACKING_V074_V2 PASS rows=%d coverage=%.6f truncated=%d median=%d p90=%d' % (st['rows'],st['tokenCoverage'],st['truncatedRows'],st['answerTokensMedian'],st['answerTokensP90']))
