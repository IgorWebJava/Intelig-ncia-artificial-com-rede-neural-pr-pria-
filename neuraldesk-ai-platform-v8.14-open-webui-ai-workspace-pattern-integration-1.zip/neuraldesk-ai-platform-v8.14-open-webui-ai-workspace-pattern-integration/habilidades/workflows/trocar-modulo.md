<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Trocar Módulo

Candidate registration
→ manifest validation
→ contract validation
→ capability resolution
→ contract tests
→ migration check
→ shadow
→ canary
→ binding switch
→ observability
→ audit
→ rollback window.
