import unittest
import sys
import os
import shutil

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.plugins.assistant_toolkit import AssistantToolkitPlugin
from qcnn.core.context import QcnnExecutionContext

class TestAssistantToolkit(unittest.TestCase):
    def setUp(self):
        self.temp_dir = "./tests_temp_storage"
        os.makedirs(self.temp_dir, exist_ok=True)
        self.plugin = AssistantToolkitPlugin(storage_dir=self.temp_dir)

    def tearDown(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_arithmetic_calculations(self):
        cases = [
            ("Calcule 15 * 85 + 45", "1320"),
            ("Quanto é 25% de 1450", "362.5"),
            ("Calcule 2^10", "1024"),
            ("Calcule (100 + 50) / 3", "50"),
            ("Calcule sqrt(144)", "12"),
            ("Calcule 100 / 0", "Divisão por zero não é definida")
        ]
        for prompt, expected in cases:
            ctx = QcnnExecutionContext(prompt=prompt)
            ctx = self.plugin.execute(ctx)
            self.assertTrue(ctx.custom_response.startswith("🧮 [CÁLCULO MATEMÁTICO SIMBÓLICO EXATO]"), f"Failed for {prompt}")
            self.assertIn(expected, ctx.custom_response)

    def test_unit_conversions(self):
        cases = [
            ("Converta 100 km em milhas", "62.14"),
            ("Converta 50 milhas em km", "80.47"),
            ("Converta 10 metros em centimetros", "1000.00"),
            ("Converta 37 °C em °F", "98.60"),
            ("Converta 100 °F em °C", "37.78"),
            ("Converta 10 kg em libras", "22.05")
        ]
        for prompt, expected in cases:
            ctx = QcnnExecutionContext(prompt=prompt)
            ctx = self.plugin.execute(ctx)
            self.assertTrue(ctx.custom_response.startswith("📐 [CONVERSÃO DE UNIDADES]"), f"Failed for {prompt}")
            self.assertIn(expected, ctx.custom_response)

    def test_workflow_planner(self):
        ctx = QcnnExecutionContext(prompt="Crie um plano de ação para desenvolver um robô autônomo")
        ctx = self.plugin.execute(ctx)
        self.assertTrue(ctx.custom_response.startswith("📋 [PLANO DE AÇÃO ESTRUTURADO DO ASSISTENTE]"))
        self.assertIn("Fase 1 (Fundação & Diagnóstico)", ctx.custom_response)
        self.assertIn("Fase 2 (Estruturação Simbólica)", ctx.custom_response)
        self.assertIn("Fase 3 (Execução & Convergência)", ctx.custom_response)
        self.assertIn("Fase 4 (Validação & Cristalização)", ctx.custom_response)

    def test_non_toolkit_prompts_pass_through(self):
        ctx = QcnnExecutionContext(prompt="O que é a gravidade?")
        ctx = self.plugin.execute(ctx)
        self.assertEqual(ctx.custom_response, "")

if __name__ == "__main__":
    unittest.main()
