# v0.7.5 deep historical convergence addendum

The v0.7.5 audit rechecked all recoverable prior-conversation context and persistent Library evidence by capability rather than version number. The complete decision matrix is `HISTORICAL_CAPABILITY_CONVERGENCE_V075.md`. Fresh ports are computational/UTF-8 streaming, provider routing, sanitized journal progress/drain, current-byte governance and gradient accumulation. Historical v0.63 release-status conflict and missing raw Golden-250 bytes remain explicit blockers to importing that Golden. No external AI path, GPU/NPU executor, multimodal model or agent runtime was fabricated.

# Comprehensive Audit — NeuralDesk Mobile Sovereign LocalNet v0.7.4-alpha.2

## Mobile hardening audit v0.7.3

A auditoria partiu do ZIP integral v0.7.2, nunca de workspace truncado. Foram confirmadas quatro lacunas móveis concretas: lifecycle JNI não single-flight, governor parcialmente declarativo, asset install whole-ByteArray e RAG sem lifecycle persistente. As correções foram feitas nos owners correntes, sem alterar pesos/datasets ou criar engine paralela. O callback do assistant permanece explicitamente não classificado como token streaming generativo.


A auditoria cobriu conversas recuperáveis do aplicativo, ZIPs Mobile Runtime v0.1–v0.63, LocalNet, V7/V8 até V8.22 e a árvore corrente. Apenas mecanismos comprovadamente executáveis ou reimplementados com testes frescos foram promovidos; blueprints documentation-only permanecem documentação. Rollback físico: v0.6.2 reproduzível SHA `40c4aca052b08eb37e01e7aa118882b02ee561484852accf6608d4ed2cdec8e2`.

## 1. Hierarquia obedecida

1. leitura integral de `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md`;
2. `scripts/pre_generation_lessons_check.py`;
3. manifest/source-of-truth;
4. código e integração;
5. assets/datasets;
6. testes e scripts;
7. documentação;
8. evidence de release somente depois da revalidação.

## 2. O que o código realmente implementa

`NDAssistant` decompõe objetivos e usa, por objetivo: contexto grounded → calculadora → memória explícita → Retriever neural + `.ndkb` → NDOS local se o interno recusar → incerteza. O NDOS possui 31 registros, 0 parâmetros neurais e não substitui a autoridade das rotas anteriores. Host CLI e JNI usam o mesmo núcleo C.

## 3. Divergências encontradas

### Corrigidas nesta auditoria

- documentos atuais ainda titulados v0.5;
- arquitetura escrita colocava memória junto do contexto, diferente da precedência real;
- orçamento móvel omitía os 68.177 B do NDOS do total de cinco assets;
- Android reutilizava qualquer arquivo existente em `filesDir`, permitindo asset stale após upgrade com mesmo filename;
- UI Android exibia `v0.5` e User-Agent declarava `0.4.0`;
- `FINAL_SANITIZER.log` e `verification/REPORT.json` eram evidence v0.5 em árvore alpha.2;
- metadata aceitava `PASS` genérico sem vincular o log à versão corrente;
- trainers de Retriever/Pointer mediam Golden obrigatório sem bloquear exportação abaixo do gate.

### Limites mantidos, não mascarados

- não há Android SDK/ART/device/APK/AAB certificado nesta árvore;
- JNI host valida compilação/ABI no host, não execução ART;
- Kotlin host cobre subset e o novo asset-sync JVM, não `MainActivity` real em Android;
- ASan/UBSan é um subset host, não fuzzing completo;
- `WebContextClient` reduz SSRF óbvio por scheme/porta/IP, mas não prova eliminação de DNS-rebinding/TOCTOU;
- Pointer raw livre permanece 9/12; segurança final depende de candidate acceptance/fallback;
- 31 registros NDOS não constituem conhecimento aberto geral.

## 4. Assets canônicos conferidos

| Asset | Bytes | SHA-256 |
|---|---:|---|
| `neuraldesk-knowledge-retriever-v0.5.ndkr` | 1.101.376 | `76a54e02dc6e815fd7786075bfbdf97c43f9845851a118b5c3db2c637edab539` |
| `neuraldesk-knowledge-v0.5.ndkb` | 52.143 | `d6d6969de99195bcbed49e8b4067835bfe3e852bd12e3aca5b2210241dd70652` |
| `neuraldesk-context-pointer-v0.5.ndqa` | 539.748 | `de85e66395b8c9ec590e0ed2f5dcec77b8cf2462444cecdc08a93119f02b79ef` |
| `neuraldesk-relation-classifier-v0.5.ndrl` | 531.332 | `45224521f7c70ad5fa7e14c52cc3a14c4cabd03856d1e5978d70ea804ff4d883` |
| `neuraldesk-open-knowledge-pira-v0.6.ndos` | 68.177 | `b4967b52e02daf3dea5833ee5f7df63ecbf4edc3bf88d95b7f407423f44419c7` |

Total dos cinco assets: **2.292.776 B**. Parâmetros neurais: **543.094**; NDOS: **0 parâmetros**.

## 5. Novos mecanismos anti-regressão

- `CanonicalAssetStore.kt`: identidade por conteúdo, staging, fsync, replace atômico e reabertura;
- probe JVM missing/same/stale;
- `RuntimeIdentity.kt` + gate de versão;
- markers finais versionados;
- metadata fail-closed contra logs stale;
- enforcement Golden dentro dos trainers de Retriever/Pointer;
- `tests/verify_documentation_consistency.py` para drift entre manifest, docs, assets e Android.

## 6. Condição de fechamento

Este documento registra a auditoria e as correções, mas **não autoriza release sozinho**. Depois da última alteração devem passar novamente: `scripts/verify.sh`, `scripts/verify_sanitize.sh`, geração de metadata/checksums e verificação do ZIP reextraído. Somente esses resultados pós-mudança podem mudar o estado final para PASS.

## Estado de fechamento da auditoria

A auditoria do fechamento não confia em nomes `FINAL_*`: o estado operacional atual é `verification/AUDIT_STATUS.json`, e metadata só aceita logs/receipts ligados à versão e ao digest corrente. O empacotamento foi endurecido para reextrair o ZIP em árvore vazia e repetir VERIFY/SANITIZER por fases, com receipts novos fora da árvore distribuída.

### JNI error-path audit

A auditoria alpha.2 passou a rejeitar `jstring` obrigatório nulo e organiza `GetStringUTFChars`/`ReleaseStringUTFChars` de forma linear também em falhas parciais. O gate host recompila essa boundary com warnings como erro; OOM real/ART continua fora da evidência física.

## Continuação v0.6.1 — Conversational Correctness

Após a auditoria alpha.2, 18 diálogos reais expuseram falhas de semântica/orquestração. A candidata v0.6.1 corrigiu as classes reproduzidas e materializou um gate C pós-implementação. Resultados targeted atuais: conversational correctness **12/12**, calculadora **16/16**, planner ampliado PASS e Live QA **35/35**.

Esses resultados não substituem a revalidação agregada. O estado continua `releasePromotionAuthorized=false` até os marcadores exatos de v0.6.1 e a reextração do artefato final.

## Gate retomável vinculado aos inputs

A v0.6.1 mantém os mesmos testes, mas permite executar o fechamento em fases determinísticas quando a janela externa não comporta o agregador monolítico. Cada fase concluída gera um receipt externo à release por `scripts/verification_checkpoint.py`, contendo versão, fase e SHA-256 canônico dos inputs. A fase final exige todos os receipts da mesma versão/digest. Mudança em código, documentação, manifest, modelos ou datasets invalida automaticamente a retomada. Esse mecanismo não transforma timeout em PASS e não autoriza pular cobertura.

## Achado 10.54 — pipeline de release
O motor já podia passar os gates e ainda assim o pipeline publicar evidence semanticamente antiga. O gerador/empacotador agora são tratados como parte do produto: métricas vêm do contrato v0.6.1, logs precisam estar ligados ao digest corrente e a reextração repete VERIFY/SANITIZER por fases antes da attestação externa.


## v0.7.2 deep historical audit

A Library foi revarrida até as conversas/ZIPs Mobile Runtime v0.1-v0.63, LocalNet e V7/V8. A comparação direta de `mobile-runtime/core` mostrou como lacunas reais restantes: projects, outbox/dependencies, network policy, pilot control, model acquisition e benchmark evaluation. Todos foram reexpressos em C99 na v0.7.2. Artifact Manager, image preprocessing e companion pairing foram conscientemente deferidos por ausência de consumidor/owner atual; remote-provider routing foi rejeitado por incompatibilidade com `NEURALDESK_FIRST_PARTY_ONLY`. V8 SWA foi implementado somente como candidate builder governado.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

