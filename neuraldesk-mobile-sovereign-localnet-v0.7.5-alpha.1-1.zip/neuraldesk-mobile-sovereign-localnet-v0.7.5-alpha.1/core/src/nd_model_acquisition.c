#include "nd_model_acquisition.h"

#include <limits.h>

static uint64_t reserve_for_profile(NDMobileProfile p) {
    if (p == ND_PROFILE_MOBILE_PLUS) return 200000000ull;
    if (p == ND_PROFILE_MOBILE) return 100000000ull;
    return 64000000ull;
}

uint64_t nd_model_estimate_bytes(uint64_t parameters, unsigned bits_per_weight, uint64_t overhead) {
    if (parameters == 0u || bits_per_weight == 0u || bits_per_weight > 64u) return 0u;
    if (parameters > UINT64_MAX / (uint64_t)bits_per_weight) return 0u;
    uint64_t bits = parameters * (uint64_t)bits_per_weight;
    uint64_t bytes = bits / 8u + ((bits % 8u) ? 1u : 0u);
    if (UINT64_MAX - bytes < overhead) return 0u;
    return bytes + overhead;
}

NDModelAcquisitionReport nd_model_acquisition_assess(uint64_t parameters,
                                                     unsigned bits_per_weight,
                                                     uint64_t overhead,
                                                     uint64_t quota,
                                                     uint64_t used,
                                                     int storage_known,
                                                     const NDResourcePolicy *resource,
                                                     const NDNetworkSnapshot *network) {
    NDModelAcquisitionReport r;
    r.estimated_model_bytes = nd_model_estimate_bytes(parameters, bits_per_weight, overhead);
    r.reserve_bytes = resource ? reserve_for_profile(resource->profile) : 64000000ull;
    r.free_bytes = 0u;
    r.free_bytes_known = 0;
    r.profile = resource ? resource->profile : ND_PROFILE_MICRO;
    r.network_state = network ? network->state : ND_NETWORK_OFFLINE;
    r.decision = ND_MODEL_ACQUISITION_REQUIRES_CONFIRMATION;
    if (!resource || r.estimated_model_bytes == 0u) {
        r.decision = ND_MODEL_ACQUISITION_BLOCKED_RESOURCE;
        return r;
    }
    if (storage_known && quota >= used) {
        r.free_bytes_known = 1;
        r.free_bytes = quota - used;
        if (r.free_bytes < r.estimated_model_bytes + r.reserve_bytes) {
            r.decision = ND_MODEL_ACQUISITION_BLOCKED_STORAGE;
            return r;
        }
    }
    if (!network || !network->online) r.decision = ND_MODEL_ACQUISITION_CACHE_ONLY_OFFLINE;
    return r;
}

const char *nd_model_acquisition_decision_name(NDModelAcquisitionDecision decision) {
    if (decision == ND_MODEL_ACQUISITION_CACHE_ONLY_OFFLINE) return "CACHE_ONLY_OFFLINE";
    if (decision == ND_MODEL_ACQUISITION_BLOCKED_RESOURCE) return "BLOCKED_RESOURCE";
    if (decision == ND_MODEL_ACQUISITION_BLOCKED_STORAGE) return "BLOCKED_STORAGE";
    return "REQUIRES_CONFIRMATION";
}
