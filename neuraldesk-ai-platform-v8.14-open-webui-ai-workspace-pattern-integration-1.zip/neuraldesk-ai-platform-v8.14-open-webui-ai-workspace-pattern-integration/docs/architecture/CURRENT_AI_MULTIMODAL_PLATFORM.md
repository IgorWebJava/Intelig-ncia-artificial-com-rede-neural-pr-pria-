<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.ai-fabric; current: docs/architecture/CURRENT_AI_MULTIMODAL_PLATFORM.md -->
# Current AI & Multimodal Platform

```text
Domain Module → AI Capability Fabric → Model Router → Capability Negotiation → Provider Adapter → Model
```

Canonical content modes: text, image, audio, video, document, structured data and tool result. Large assets use Asset References/Object Storage in production architecture. Domain/browser modules do not import provider SDKs directly.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
