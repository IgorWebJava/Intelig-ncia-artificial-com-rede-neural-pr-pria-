# v0.7.5 source-of-truth addendum

A autoridade corrente de desenvolvimento é `PROJECT_MANIFEST.json` versão `0.7.5-alpha.1`. `docs/HISTORICAL_CAPABILITY_CONVERGENCE_V075.md` registra as decisões de merge histórico. Implementações antigas em JS/MJS não são runtime paralelo: apenas propriedades vencedoras foram reexpressas nos owners C99/Kotlin atuais. O status histórico contraditório de `v0.63` não é usado como autoridade de release; somente capability evidence e hashes verificáveis são preservados.

# Source of Truth — v0.7.4-alpha.2

## Autoridades adicionadas/estendidas na candidata v0.7.3

- `core/src/nd_assistant.c`: execução cooperativa e mesma política de resposta;
- `core/src/nd_resource.c`: limites efetivos profile/thermal;
- `core/src/nd_rag.c`: único owner RAG, incluindo persistência `NDRAG001` e LRU;
- `android/.../neuraldesk_jni.c`: ownership single-flight/lifecycle do handle;
- `CanonicalAssetStore.kt`: instalação streaming/hashada dos assets;
- `ResearchMemoryStore.kt`: memória de pesquisa opt-in criptografada;
- `PROJECT_MANIFEST.json`: identidade corrente; v0.7.2 permanece source baseline e v0.7.1 rollback externamente atestado.

Nenhum desses owners ativa um modelo generativo inexistente.


Precedência: `PROJECT_MANIFEST.json` + bytes/hash dos assets + testes/evidence atuais > documentação CURRENT > histórico. Promotion assinada não implica activation; activation não implica production/public serving. A autorização final da release continua sendo a attestação externa emitida somente após reextração do ZIP e VERIFY+SANITIZER sobre os próprios bytes.

## Ordem de autoridade

1. `memória/LIÇÕES_APRENDIDAS_E_ANTI_REGRESSAO.md` — erros, acertos, correções e regras anti-regressão; leitura/análise obrigatória.
2. `PROJECT_MANIFEST.json` — identidade, arquitetura, métricas e assets promovidos.
3. `core/include/` + `core/src/` — comportamento C99 executável.
4. `models/` — única fonte de verdade dos cinco assets empacotados de runtime; cópias Android em `filesDir` são cache e precisam ser byte-idênticas ao asset empacotado antes do JNI.
5. `training/` — trainers e builders reproduzíveis.
6. `training/data/` + `evaluation/` — dados e evidências distribuídos.
7. `tests/` + `scripts/verify*.sh` — gates executáveis.
8. `docs/` — explicação e limites.
9. `verification/` — evidências de fechamento da release.

## Regra de conflito

Documentação histórica ou resultado de sessão anterior não promove bytes. Se README, manifest, código, asset e teste divergirem, a release deve permanecer não congelada até reconciliação.

## Assets canônicos

- `models/neuraldesk-knowledge-retriever-v0.5.ndkr`;
- `models/neuraldesk-knowledge-v0.5.ndkb`;
- `models/neuraldesk-context-pointer-v0.5.ndqa`;
- `models/neuraldesk-relation-classifier-v0.5.ndrl`;
- `models/neuraldesk-open-knowledge-pira-v0.6.ndos`.

O quinto asset possui 0 parâmetros neurais. Assets históricos `.ndsh` não pertencem à rota canônica desta release.

## Rollback

Rollback externo: `neuraldesk-mobile-sovereign-localnet-v0.5.0-alpha.1.zip`, SHA-256 `9e0381977230c7502ca0fdb74fe4fb1d7adbdec12d1f7ca735151cc80ac3ad02`.

## Evidence não é autoridade por nome

Arquivos em `verification/` são aceitos somente quando seus marcadores/versão correspondem ao manifest e foram gerados depois da última mudança. `FINAL_*` e `SHA256SUMS` não vencem código/manifest apenas por nome ou checksum. O gerador de metadata falha fechado em evidence de versão diferente.

## Regra v0.6.1 de retrieval interno

O caminho `core/src/nd_knowledge.c` é neural-first. O matcher sparse não é uma segunda base de conhecimento: ele consulta os mesmos 201 registros `.ndkb` e só pode atuar após recusa neural. O NDOS permanece uma fonte separada e posterior.

## Evidência retomável

Receipts de `scripts/verification_checkpoint.py` são estado operacional transitório e ficam fora da árvore distribuída. Eles não são fonte de verdade isolada: só têm validade quando versão e digest dos inputs coincidem e a fase final do respectivo gate os valida antes de emitir o marcador versionado.

## Autoridade de promoção do ZIP
`PROJECT_MANIFEST.json` descreve o candidato e permanece imutável durante os gates. `verification/REPORT.json` prova os gates da árvore fonte, mas não autoriza sozinho o ZIP. A autorização final é uma attestação externa produzida somente após CRC, igualdade de digest, VERIFY e SANITIZER sobre a árvore reextraída e revalidação dos checksums.


## Autoridades adicionais v0.6.2

`core/src/nd_memory.c` é a autoridade para reconstrução de fatos estruturados derivados da memória persistida. `core/src/nd_assistant.c` é a autoridade para histórico bounded, detecção de mudança de tópico, resumo determinístico e política de não-entailment. `core/src/nd_knowledge.c` é a autoridade para preservação de acrônimos antes do fallback sparse. `core/src/nd_planner.c` continua sendo a única autoridade de decomposição/herança de objetivos.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.

<!-- neuraldesk-v073-sync -->
## v0.7.3-alpha.1 synchronization

A autoridade corrente é `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e `MOBILE_RUNTIME_HARDENING_V073.md`. Seções v0.7.2 e anteriores permanecem lineage e não sobrepõem o delta móvel atual. Nenhum peso neural/dataset promovido mudou nesta sincronização.

## Autoridade de diálogo independente e training state v0.7.4-alpha.2

`evaluation/dialogue_v074/CHATGPT_NEURALDESK_DIALOGUE_UTF8_RAW.txt` é a evidence primária do diálogo natural; `DIALOGUE_EVALUATION.json` é o rubric derivado; o transcript ASCII é stress secundário. O diálogo não é training evidence de pesos e não autoriza promoção.

A arquitetura generativa corrente é o único owner `core/src/nd_generative.c` em **NDGM v5 / Micro v3**. O estado de treino resumível permanece externo ao diretório `models/`; o hash atual é `c1f6745b896386e76243749ce1d2a3eea0278215411b472170df0ec6df224b24`, pretraining 350/367. Um complete bundle pode transportar esse checkpoint como estado de desenvolvimento, mas ele nunca deve ser confundido com model asset promovido.
