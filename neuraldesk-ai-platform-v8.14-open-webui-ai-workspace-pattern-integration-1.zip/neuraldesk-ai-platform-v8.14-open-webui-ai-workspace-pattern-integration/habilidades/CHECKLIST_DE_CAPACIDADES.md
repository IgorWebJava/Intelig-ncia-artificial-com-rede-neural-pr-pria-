<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: project.skills -->

# Checklist de Capacidades

## Contexto

- [ ] `project.memory.read.v1`
- [ ] `project.skills.read.v1`
- [ ] módulo proprietário identificado
- [ ] manifest/contratos/ownership/testes lidos

## Alteração de UI

- [ ] `html.author.v1`
- [ ] `css.author.v1`
- [ ] `responsive.design.v1`
- [ ] `accessibility.structural.v1`
- [ ] `browser.viewport-test.v1`

## Alteração de arquitetura

- [ ] `module.architecture.design.v1`
- [ ] `module.manifest.author.v1`
- [ ] `capability.registry.manage.v1`
- [ ] `contract.registry.manage.v1`

## Alteração de dados

- [ ] `sql.postgresql.design.v1`
- [ ] `data.ownership.design.v1`
- [ ] `eventing.outbox.design.v1`

## Alteração de IA

- [ ] `ai.capability.fabric.design.v1`
- [ ] `multimodal.contract.design.v1`
- [ ] `ai.model-replacement.design.v1`

## Release

- [ ] documentação sincronizada
- [ ] memória atualizada
- [ ] habilidades atualizadas
- [ ] testes atualizados
- [ ] validators PASS
- [ ] release versionada
- [ ] ZIP gerado


## Preview do módulo

- [ ] `browser.preview.capture.v1`
- [ ] preview atual consultado antes de redesign
- [ ] preview regenerado após mudança visual
- [ ] `tools/validate_previews.py` PASS


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
