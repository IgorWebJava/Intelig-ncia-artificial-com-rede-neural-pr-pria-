<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform -->
# Current Coding Intelligence Architecture

**Profile:** `coding-intelligence-patterns-v1`  
**Layer introduced:** V8.13  
**Current package compatibility:** V8.14

The current browser layer implements only truthful UI readiness. Future execution is owned by `neural-engine/modules/13-coding-intelligence-runtime/`. The reference path is Task Packet → workspace/rules → context preflight → repo/LSP → guarded tools → branch freshness → Green Contract → bounded recovery → review-ready output.
