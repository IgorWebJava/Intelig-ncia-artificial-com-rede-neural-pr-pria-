#define _POSIX_C_SOURCE 200809L
#include "nd_open_knowledge.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s SHARD < queries.txt\n", argv[0]);
        return 2;
    }
    NDOpenKnowledgeShard shard;
    char err[256];
    if (nd_open_knowledge_load(argv[1], &shard, err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }
    char *line = NULL;
    size_t cap = 0u;
    ssize_t n;
    while ((n = getline(&line, &cap, stdin)) >= 0) {
        while (n > 0 && (line[n-1] == '\n' || line[n-1] == '\r')) line[--n] = 0;
        NDOpenKnowledgeResult r;
        if (nd_open_knowledge_search(&shard, line, &r, err, sizeof(err))) {
            fprintf(stderr, "search: %s\n", err);
            free(line);
            nd_open_knowledge_free(&shard);
            return 1;
        }
        printf("%d\t%s\t%.9f\t%.9f\n", r.found, r.source_id ? r.source_id : "", r.score, r.margin);
    }
    free(line);
    nd_open_knowledge_free(&shard);
    return 0;
}
