#!/usr/bin/env python3
"""Independent Ed25519 model promotion and activation authority for LocalNet."""
from __future__ import annotations
import argparse, base64, hashlib, json, os, subprocess, sys
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

ROOT=Path(__file__).resolve().parents[1]
KEY_DIR=Path(os.environ.get('ND_RELEASE_KEY_DIR','/mnt/data/ndsl_release_keys/v071'))
PRIV=KEY_DIR/'release-ed25519-private.pem'
PUB=ROOT/'verification/release-authority-ed25519-public.pem'
PROM=ROOT/'verification/model-promotion-v0.7.2.json'
ACT=ROOT/'verification/model-activation-v0.7.2.json'
SEM_REPORT=ROOT/'evaluation/SEMANTIC_RANKER_REPORT.json'

CANONICAL=[
 'models/neuraldesk-knowledge-retriever-v0.5.ndkr',
 'models/neuraldesk-knowledge-v0.5.ndkb',
 'models/neuraldesk-context-pointer-v0.5.ndqa',
 'models/neuraldesk-relation-classifier-v0.5.ndrl',
 'models/neuraldesk-open-knowledge-pira-v0.6.ndos',
 'models/neuraldesk-semantic-ranker-v0.7.1.ndsr',
]
CANDIDATE='candidates/neuraldesk-open-knowledge-pira-full-v0.7.1.candidate.ndos'

def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def canonical(obj)->bytes:return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def precheck():subprocess.run([sys.executable,'scripts/pre_generation_lessons_check.py'],cwd=ROOT,check=True)
def ensure_key()->Ed25519PrivateKey:
    KEY_DIR.mkdir(parents=True,exist_ok=True)
    if PRIV.exists():
        key=serialization.load_pem_private_key(PRIV.read_bytes(),password=None)
        if not isinstance(key,Ed25519PrivateKey): raise RuntimeError('release key is not Ed25519')
        return key
    key=Ed25519PrivateKey.generate()
    PRIV.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    os.chmod(PRIV,0o600)
    return key

def public_bytes(key:Ed25519PrivateKey)->bytes:
    return key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)

def write_public(key):
    PUB.parent.mkdir(parents=True,exist_ok=True)
    PUB.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))

def verify_runtime_assets():
    subprocess.run(['bash','scripts/build_host.sh'],cwd=ROOT,check=True)
    for cmd in [
        [sys.executable,'tests/verify_canonical_hashes.py'],
        [sys.executable,'tests/verify_retriever_model.py'],
        [sys.executable,'tests/verify_knowledge_base.py'],
        [sys.executable,'tests/verify_relation_model.py'],
        [sys.executable,'tests/verify_pointer_model.py'],
        [sys.executable,'tests/verify_open_knowledge_provenance.py'],
        [sys.executable,'tests/verify_semantic_ranker.py'],
        [sys.executable,'tests/verify_historical_pira_candidate.py'],
    ]: subprocess.run(cmd,cwd=ROOT,check=True)

def sign_payload(key,payload):
    body=dict(payload); sig=key.sign(canonical(body)); body['signatureEd25519Base64']=base64.b64encode(sig).decode(); return body

def verify_signed(path:Path)->dict:
    d=json.loads(path.read_text(encoding='utf-8')); sig=base64.b64decode(d.pop('signatureEd25519Base64'))
    key=serialization.load_pem_public_key(PUB.read_bytes())
    if not isinstance(key,Ed25519PublicKey): raise RuntimeError('public key type mismatch')
    key.verify(sig,canonical(d)); d['signatureEd25519Base64']=base64.b64encode(sig).decode(); return d

def promote():
    precheck(); verify_runtime_assets(); key=ensure_key(); write_public(key)
    version=json.loads((ROOT/'PROJECT_MANIFEST.json').read_text(encoding='utf-8'))['version']
    assets=[]
    for rel in CANONICAL:
        p=ROOT/rel
        if not p.is_file(): raise RuntimeError(f'missing runtime asset {rel}')
        item={'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)}
        if rel.endswith('neuraldesk-semantic-ranker-v0.7.1.ndsr'):
            sr=json.loads(SEM_REPORT.read_text(encoding='utf-8'))
            if sr.get('sha256')!=item['sha256'] or sr.get('bytes')!=item['bytes'] or sr.get('combinedRatio',0)<0.985 or sr.get('criticalPassed')!=sr.get('criticalComparisons'):
                raise RuntimeError('semantic ranker independent quality/report mismatch')
            item['role']='LOCAL_RAG_AUXILIARY_RERANKER';item['qualityReportSha256']=sha(SEM_REPORT);item['combinedRatio']=sr['combinedRatio']
        assets.append(item)
    candidate=None
    cp=ROOT/CANDIDATE
    if cp.is_file(): candidate={'path':CANDIDATE,'bytes':cp.stat().st_size,'sha256':sha(cp),'activation':'PROHIBITED_PENDING_QUALITY_GATE'}
    payload={
      'schema':'neuraldesk-model-promotion-v1','version':version,'authority':'LOCAL_SOFTWARE_ED25519_NOT_HARDWARE_ATTESTED',
      'publicKeySha256':hashlib.sha256(public_bytes(key)).hexdigest(),'promotedModelSet':'LOCALNET_CANONICAL_FIVE_PLUS_SEMANTIC_RANKER_V072',
      'independentRevalidation':['canonical hashes','format/load gates','open-knowledge provenance'],'assets':assets,
      'unpromotedCandidate':candidate,'generationActivated':False,'hardwarePromotion':False,
    }
    signed=sign_payload(key,payload); PROM.write_text(json.dumps(signed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); verify_signed(PROM)
    print(f'MODEL_PROMOTION PASS assets={len(assets)} publicKeySha256={payload["publicKeySha256"]}')

def activate():
    precheck(); promotion=verify_signed(PROM); key=ensure_key(); write_public(key)
    version=promotion['version']
    payload={
      'schema':'neuraldesk-model-activation-v1','version':version,'promotionManifestSha256':sha(PROM),
      'activationDecision':'ACTIVATE_CANONICAL_LOCALNET_FIVE_PLUS_BOUNDED_SEMANTIC_RANKER','activatedAssets':[x['path'] for x in promotion['assets']],
      'generativeBackbone':'NOT_ACTIVATED_NO_PROMOTED_BACKBONE','fullPiraCandidate':'NOT_ACTIVATED_PENDING_PRECISION',
      'productionServingAuthorized':False,'publicServingAuthorized':False,'physicalCertificationRequiredForHardwarePromotion':True,
    }
    signed=sign_payload(key,payload); ACT.write_text(json.dumps(signed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); verify_signed(ACT)
    print(f'MODEL_ACTIVATION PASS activated={len(payload["activatedAssets"])} generative=false')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('command',choices=['promote','activate','verify']); a=ap.parse_args()
    if a.command=='promote': promote()
    elif a.command=='activate': activate()
    else:
        verify_signed(PROM); verify_signed(ACT); print('MODEL_AUTHORITY_VERIFY PASS')
if __name__=='__main__':main()
