#ifndef ND_OPEN_KNOWLEDGE_H
#define ND_OPEN_KNOWLEDGE_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint32_t bucket;
    float value;
} NDOpenKnowledgeFeature;

typedef struct {
    uint32_t split;
    char *source_id;
    char *question;
    char *answer;
    uint32_t feature_count;
    double norm;
    NDOpenKnowledgeFeature *features;
} NDOpenKnowledgeRecord;

typedef struct {
    uint32_t version;
    uint32_t record_count;
    uint32_t bucket_count;
    uint32_t idf_count;
    uint32_t sparse_entries;
    uint32_t top_k;
    uint32_t flags;
    double accept_score;
    double accept_margin;
    NDOpenKnowledgeFeature *idf;
    NDOpenKnowledgeRecord *records;
} NDOpenKnowledgeShard;

typedef struct {
    int found;
    uint32_t record_index;
    double score;
    double margin;
    const char *source_id;
    const char *question;
    const char *answer;
    uint32_t split;
} NDOpenKnowledgeResult;

int nd_open_knowledge_load(const char *path, NDOpenKnowledgeShard *shard, char *err, size_t errcap);
void nd_open_knowledge_free(NDOpenKnowledgeShard *shard);
int nd_open_knowledge_search(const NDOpenKnowledgeShard *shard,
                             const char *query,
                             NDOpenKnowledgeResult *result,
                             char *err,
                             size_t errcap);

#endif
