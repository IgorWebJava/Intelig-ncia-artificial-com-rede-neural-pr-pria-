#!/usr/bin/env python3
import hashlib, json, re, unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'training/data/generative_v074_v2'
H=ROOT/'evaluation/generative_v074/HOLDOUT_PROBES.json'
def rows(name):
    return [json.loads(x) for x in (D/name).read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(name): return hashlib.sha256((D/name).read_bytes()).hexdigest()
def norm(s): return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',s).casefold()).strip()
p=json.loads((D/'PROVENANCE.json').read_text(encoding='utf-8'))
t=json.loads((D/'TOKENIZER.json').read_text(encoding='utf-8'))
rich=rows('rich_sft.jsonl'); ctx=rows('context_sft.jsonl'); replay=rows('causal_replay.jsonl'); val=rows('pira_validation.jsonl')
assert len(rich)==2563 and len(ctx)==52500 and len(replay)==55063 and len(val)==140
m=p['materialized']
assert m['richSft']==len(rich) and m['contextSft']==len(ctx) and m['causalReplay']==len(replay) and m['validation']==len(val)
assert sha('rich_sft.jsonl')==m['richSftSha256']
assert sha('context_sft.jsonl')==m['contextSftSha256']
assert sha('causal_replay.jsonl')==m['replaySha256']
assert sha('pira_validation.jsonl')==m['validationSha256']
g=p['governance']
assert g['globalQuestionCrossSplitLeakage']==0
assert g['validationUsedForTraining'] is False and g['validationUsedForTokenizerFit'] is False
assert g['historicalAuthored48']=='NOT_RECOVERED_DO_NOT_FABRICATE'
assert g['historicalHoldoutExactPromptLeakage']==0
assert t['validationFitRecords']==0 and t['vocab']==512
assert hashlib.sha256((D/'tokenizer-v2.ndtk').read_bytes()).hexdigest()==t['sha256']
reserved={norm(x.get('question','')) for x in val}
for collection in (rich,ctx):
    for row in collection:
        q=norm(row.get('question',''))
        if q: assert q not in reserved
probes=json.loads(H.read_text(encoding='utf-8'))['probes']
train_text='\n'.join([r.get('question',r.get('text','')) for r in rich+ctx+replay])
tn=norm(train_text)
for probe in probes: assert norm(probe['prompt']) not in tn
print(f'GENERATIVE_CORPUS_V2_VERIFY PASS rich={len(rich)} context={len(ctx)} replay={len(replay)} validation={len(val)} leakage=0 holdoutLeakage=0')
