package com.example.engine.core

data class LetraInfo(
    val nome: String,
    val caractere: String,
    val gematria: Int,
    val frequenciaHz: Double,
    val milui: List<String>,
    val atbash: String
)

object MatrizLetras {
    val MATRIZ_22 = mapOf(
        "Alef" to LetraInfo("Alef", "א", 1, 1.618, listOf("Alef", "Lamed", "Pei"), "Tav"),
        "Bet" to LetraInfo("Bet", "ב", 2, 3.236, listOf("Bet", "Yud", "Tav"), "Shin"),
        "Gimel" to LetraInfo("Gimel", "ג", 3, 4.854, listOf("Gimel", "Mem", "Lamed"), "Reish"),
        "Dalet" to LetraInfo("Dalet", "ד", 4, 6.472, listOf("Dalet", "Lamed", "Tav"), "Cof"),
        "Hei" to LetraInfo("Hei", "ה", 5, 8.090, listOf("Hei", "Yud"), "Tsadi"),
        "Vav" to LetraInfo("Vav", "ו", 6, 9.708, listOf("Vav", "Yud", "Vav"), "Pei"),
        "Zayin" to LetraInfo("Zayin", "ז", 7, 11.326, listOf("Zayin", "Yud", "Nun"), "Ayin"),
        "Chet" to LetraInfo("Chet", "ח", 8, 12.944, listOf("Chet", "Yud", "Tav"), "Samech"),
        "Tet" to LetraInfo("Tet", "ט", 9, 14.562, listOf("Tet", "Yud", "Tav"), "Nun"),
        "Yud" to LetraInfo("Yud", "י", 10, 16.180, listOf("Yud", "Vav", "Dalet"), "Mem"),
        "Chaf" to LetraInfo("Chaf", "כ", 20, 32.360, listOf("Chaf", "Pei"), "Lamed"),
        "Lamed" to LetraInfo("Lamed", "ל", 30, 48.540, listOf("Lamed", "Mem", "Dalet"), "Chaf"),
        "Mem" to LetraInfo("Mem", "מ", 40, 64.720, listOf("Mem", "Mem"), "Yud"),
        "Nun" to LetraInfo("Nun", "נ", 50, 80.900, listOf("Nun", "Vav", "Nun"), "Tet"),
        "Samech" to LetraInfo("Samech", "ס", 60, 97.080, listOf("Samech", "Mem", "Chaf"), "Chet"),
        "Ayin" to LetraInfo("Ayin", "ע", 70, 113.260, listOf("Ayin", "Yud", "Nun"), "Zayin"),
        "Pei" to LetraInfo("Pei", "פ", 80, 129.440, listOf("Pei", "Alef"), "Vav"),
        "Tsadi" to LetraInfo("Tsadi", "צ", 90, 145.620, listOf("Tsadi", "Dalet", "Yud"), "Hei"),
        "Cof" to LetraInfo("Cof", "ק", 100, 161.803, listOf("Cof", "Vav", "Pei"), "Dalet"),
        "Reish" to LetraInfo("Reish", "ר", 200, 323.606, listOf("Reish", "Yud", "Shin"), "Gimel"),
        "Shin" to LetraInfo("Shin", "ש", 300, 485.410, listOf("Shin", "Yud", "Nun"), "Bet"),
        "Tav" to LetraInfo("Tav", "ת", 400, 647.213, listOf("Tav", "Vav"), "Alef")
    )

    val TRANSICOES_PERMITIDAS = mapOf(
        "Alef" to listOf("Lamed", "Pei", "Yud", "Tav"),
        "Bet" to listOf("Yud", "Tav", "Shin", "Mem"),
        "Gimel" to listOf("Mem", "Lamed", "Reish", "Dalet"),
        "Dalet" to listOf("Lamed", "Tav", "Cof", "Yud"),
        "Hei" to listOf("Yud", "Tsadi", "Vav", "Dalet"),
        "Vav" to listOf("Yud", "Vav", "Pei", "Tav"),
        "Zayin" to listOf("Yud", "Nun", "Ayin", "Lamed"),
        "Chet" to listOf("Yud", "Tav", "Samech", "Mem"),
        "Tet" to listOf("Yud", "Tav", "Nun", "Vav"),
        "Yud" to listOf("Vav", "Dalet", "Mem", "Alef"),
        "Chaf" to listOf("Pei", "Lamed", "Mem", "Nun"),
        "Lamed" to listOf("Mem", "Dalet", "Chaf", "Tav"),
        "Mem" to listOf("Mem", "Dalet", "Yud", "Nun"),
        "Nun" to listOf("Vav", "Nun", "Tet", "Samech"),
        "Samech" to listOf("Mem", "Chaf", "Chet", "Ayin"),
        "Ayin" to listOf("Yud", "Nun", "Zayin", "Pei"),
        "Pei" to listOf("Alef", "Vav", "Tsadi", "Lamed"),
        "Tsadi" to listOf("Dalet", "Yud", "Hei", "Cof"),
        "Cof" to listOf("Vav", "Pei", "Dalet", "Reish"),
        "Reish" to listOf("Yud", "Shin", "Gimel", "Tav"),
        "Shin" to listOf("Yud", "Nun", "Bet", "Alef"),
        "Tav" to listOf("Vav", "Yud", "Alef", "Shin")
    )
}
