<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Workflow — Evoluir Autonomous Assistant Experience Template

## Scope
Interface/template only.

## Required sequence
1. Read memory and current Chat/App Shell manifests.
2. Preserve `autonomous-assistant-experience-v1` truthfulness boundary.
3. Add/modify only visual surfaces and local UI interactions.
4. Never add real planning, agent/tool execution, persistent memory, background tasks or live microphone capture in this workflow.
5. Update visual contracts, docs, tests and previews.
6. Run release gates.

## Visual states
Project: active / paused / archived.
Task: queued / planning / running / waiting / waiting approval / paused / completed / failed / cancelled.
Modes: Chat / Research / Agent / Project / Voice / Multimodal / Deep Work.
