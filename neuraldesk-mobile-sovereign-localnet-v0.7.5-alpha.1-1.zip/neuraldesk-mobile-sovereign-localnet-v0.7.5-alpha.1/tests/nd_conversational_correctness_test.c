#include "nd_assistant.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int contains(const char *s, const char *needle) {
    return strstr(s, needle) != NULL;
}

static int require_contains(const char *name, const char *out, const char *needle) {
    if (contains(out, needle)) return 0;
    fprintf(stderr, "%s missing [%s] in [%s]\n", name, needle, out);
    return 1;
}

static int require_not_contains(const char *name, const char *out, const char *needle) {
    if (!contains(out, needle)) return 0;
    fprintf(stderr, "%s unexpectedly contains [%s] in [%s]\n", name, needle, out);
    return 1;
}

int main(int argc, char **argv) {
    if (argc != 6) {
        fprintf(stderr, "usage: %s RETRIEVER KB CONTEXT_QA RELATION OPEN_SHARD\n", argv[0]);
        return 2;
    }
    const char *memory_path = "/tmp/neuraldesk-v061-conversation-memory.ndm";
    remove(memory_path);

    NDAssistant a;
    NDAnswerMeta m;
    char err[256];
    char out[65536];
    int bad = 0;
    if (nd_assistant_load_ex(&a, argv[1], argv[2], argv[3], argv[4], argv[5],
                             memory_path, err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }

    if (nd_assistant_answer(&a, "Quanto é (37 × 19) + 15?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_CALCULATOR) bad++;
    bad += require_contains("compound-math", out, "718");

    if (nd_assistant_answer(&a,
                            "Lembre que o projeto Solis-9 usa bateria de sódio e a responsável é Helena.",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_MEMORY) bad++;
    if (nd_assistant_answer(&a, "Que tipo de bateria o projeto Solis-9 usa?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err)) ||
        m.source != ND_ANSWER_MEMORY) bad++;
    bad += require_contains("memory-attribute", out, "sódio");
    bad += require_not_contains("memory-attribute", out, "Resposta direta: Helena");

    if (nd_assistant_answer(&a,
                            "Nas fases 1 e 2 do Parque das Conchas, quais campos de petróleo aparecem?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("preamble", out, "Abalone");
    bad += require_contains("preamble", out, "Ostra");
    bad += require_not_contains("preamble", out, "Berlim");
    if (m.goal_count != 1u || m.covered_goals != 1u) {
        fprintf(stderr, "preamble coverage=%zu/%zu\n", m.covered_goals, m.goal_count);
        bad++;
    }

    if (nd_assistant_answer(&a,
                            "Se eu usar quantização e KV cache na inferência, o que cada técnica tende a economizar?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("distributive", out, "Quantização");
    bad += require_contains("distributive", out, "KV cache");
    if (m.goal_count != 2u || m.covered_goals != 2u) {
        fprintf(stderr, "distributive coverage=%zu/%zu\n", m.covered_goals, m.goal_count);
        bad++;
    }

    if (nd_assistant_answer(&a, "Qual é a capital do país fictício Noveria-999?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("sparse-entity-negative", out, "Não sei com segurança");
    if (m.source != ND_ANSWER_UNCERTAIN) bad++;

    if (nd_assistant_answer(&a, "O que é RAG e por que separar recuperação de geração?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("rag", out, "Retrieval-Augmented Generation");
    bad += require_contains("rag", out, "Separar recuperação de geração");
    if (m.goal_count != 2u || m.covered_goals != 2u) bad++;

    if (nd_assistant_answer(&a,
                            "Explique com suas palavras por que uma loss menor não prova que um modelo ficou mais inteligente.",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("loss-paraphrase", out, "loss menor");
    bad += require_contains("loss-paraphrase", out, "generalização");

    const char *ctx = "O Atlas-77 está sob responsabilidade de Caio. O documento não informa a versão atual.";
    if (nd_assistant_answer(&a,
                            "Com base apenas neste contexto, qual é a versão e o responsável do Atlas-77?",
                            ctx, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("late-anchor", out, "Caio");
    bad += require_contains("late-anchor", out, "Não encontrei evidência suficiente");
    bad += require_not_contains("late-anchor", out, "internet");
    if (m.goal_count != 2u || m.covered_goals != 1u) {
        fprintf(stderr, "late-anchor coverage=%zu/%zu\n", m.covered_goals, m.goal_count);
        bad++;
    }

    if (nd_assistant_answer(&a,
                            "Qual arquitetura é melhor em qualquer situação: Transformer ou RNN?",
                            NULL, 1, out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("absolute-comparison", out, "Não existe");
    bad += require_contains("absolute-comparison", out, "depende");

    if (nd_assistant_answer(&a, "Olá! Como você está e o que consegue fazer?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("greeting", out, "operacional");
    bad += require_contains("greeting", out, "local");

    if (nd_assistant_answer(&a, "O que é RAG?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    if (nd_assistant_answer(&a, "E por que isso importa na prática?", NULL, 1,
                            out, sizeof(out), &m, err, sizeof(err))) bad++;
    bad += require_contains("followup", out, "recuper");
    bad += require_not_contains("followup", out, "capital de");

    nd_assistant_free(&a);
    remove(memory_path);
    if (bad) {
        fprintf(stderr, "conversational correctness failures=%d\n", bad);
        return 1;
    }
    puts("conversational_correctness PASS cases=12");
    return 0;
}
