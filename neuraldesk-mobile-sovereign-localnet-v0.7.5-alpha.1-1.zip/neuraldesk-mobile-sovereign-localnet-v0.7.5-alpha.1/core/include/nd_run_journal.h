#ifndef ND_RUN_JOURNAL_H
#define ND_RUN_JOURNAL_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    char path[1024];
    uint64_t next_id;
} NDRunJournal;

void nd_run_journal_init(NDRunJournal *journal);
int nd_run_journal_set_path(NDRunJournal *journal, const char *path, char *err, size_t errcap);
int nd_run_journal_recover(NDRunJournal *journal, size_t *abandoned, char *err, size_t errcap);
int nd_run_journal_begin(NDRunJournal *journal, const char *profile, uint64_t *run_id, char *err, size_t errcap);
int nd_run_journal_progress(NDRunJournal *journal, uint64_t run_id, const char *phase, const char *source,
                            char *err, size_t errcap);
int nd_run_journal_drain(NDRunJournal *journal, uint64_t run_id, const char *status,
                         char *err, size_t errcap);
int nd_run_journal_end(NDRunJournal *journal, uint64_t run_id, const char *status, const char *source,
                       char *err, size_t errcap);

#endif
