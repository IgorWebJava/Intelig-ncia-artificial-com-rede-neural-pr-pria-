#!/usr/bin/env python3
from pathlib import Path
import struct
p=Path('models/neuraldesk-knowledge-v0.5.ndkb')
b=p.read_bytes(); off=0
magic,version,count=struct.unpack_from('<3I',b,off); off+=12
assert magic==0x314b444e and version==1 and count==201,(hex(magic),version,count)
for _ in range(count):
    sizes=struct.unpack_from('<4I',b,off); off+=16
    assert all(0<n<=65536 for n in sizes)
    for n in sizes:
        b[off:off+n].decode('utf-8'); off+=n
assert off==len(b),(off,len(b))
print('knowledge-base-format PASS',count,'records')
