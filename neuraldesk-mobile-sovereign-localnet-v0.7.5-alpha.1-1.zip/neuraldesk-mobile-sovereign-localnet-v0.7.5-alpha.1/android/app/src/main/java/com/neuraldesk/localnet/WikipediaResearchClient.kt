package com.neuraldesk.localnet

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URLEncoder
import org.json.JSONObject

/**
 * Optional first-party research adapter for Portuguese Wikipedia text.
 *
 * It fetches public textual evidence only. The answer itself is still produced
 * by the local NeuralDesk C runtime from the returned context.
 */
class WikipediaResearchClient {
    data class Result(val sourceUrl: String, val title: String, val context: String)

    private fun get(url: String, maxBytes: Int = 256 * 1024): String {
        val connection = (java.net.URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 7_000
            readTimeout = 9_000
            instanceFollowRedirects = false
            setRequestProperty("User-Agent", "${RuntimeIdentity.USER_AGENT} (local research)")
        }
        require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }

        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8_192)
        var total = 0
        connection.inputStream.use { input ->
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= maxBytes) { "resposta grande demais" }
                output.write(buffer, 0, count)
            }
        }
        connection.disconnect()
        return output.toString(Charsets.UTF_8.name())
    }

    fun research(question: String): Result {
        val encoded = URLEncoder.encode(question, Charsets.UTF_8.name())
        val searchJson = get(
            "https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded" +
                "&format=json&utf8=1&srlimit=1&origin=*"
        )
        val results = JSONObject(searchJson).getJSONObject("query").getJSONArray("search")
        require(results.length() > 0) { "nenhum resultado" }

        val first = results.getJSONObject(0)
        val pageId = first.getLong("pageid")
        val title = first.getString("title")
        val extractJson = get(
            "https://pt.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1" +
                "&pageids=$pageId&format=json&utf8=1&origin=*"
        )
        val page = JSONObject(extractJson)
            .getJSONObject("query")
            .getJSONObject("pages")
            .getJSONObject(pageId.toString())
        val extract = page.optString("extract", "").replace(Regex("\\s+"), " ").trim()
        require(extract.isNotBlank()) { "página sem extrato" }

        val context = ContextSelector.select(question, extract)
        val source = "https://pt.wikipedia.org/?curid=$pageId"
        return Result(source, title, context)
    }
}
