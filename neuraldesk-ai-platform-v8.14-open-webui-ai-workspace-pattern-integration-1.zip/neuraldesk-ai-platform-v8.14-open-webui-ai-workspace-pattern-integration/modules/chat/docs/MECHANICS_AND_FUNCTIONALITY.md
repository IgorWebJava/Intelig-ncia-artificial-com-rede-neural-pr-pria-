<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: neuraldesk.chat; current: modules/chat/docs/MECHANICS_AND_FUNCTIONALITY.md -->
# Mechanics and Functionality — Autonomous Assistant Workspace Template

## Scope

This document is the authoritative functional map for the current `chat` template UI. It distinguishes visual/template behavior from future executable engine behavior.

## Specialized mechanic

**Adaptive Conversation + Artifact Workspace**

## Mechanic → future engine traceability

| UI mechanic | Current template status | Future engine status | Future engine owners |
|---|---|---|---|
| Conversation | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.conversation-runtime`, `neural-engine.assistant-orchestrator`, `neural-engine.planner-runtime`, `neural-engine.context-compiler`, `neural-engine.memory-runtime`, `neural-engine.task-runtime`, `neural-engine.checkpoint-resume-runtime`, `neural-engine.artifact-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Plan & Tasks | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.planner-runtime`, `neural-engine.task-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Activity | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Context & Memory | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.context-compiler`, `neural-engine.project-runtime`, `neural-engine.memory-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Checkpoints | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.checkpoint-resume-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Mission Control | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.assistant-orchestrator`, `neural-engine.task-runtime`, `neural-engine.agent-runtime`, `neural-engine.tool-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Research Workspace | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.web-research-runtime`, `neural-engine.knowledge-rag-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Document Workspace | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.artifact-runtime`, `neural-engine.media-asset-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Data Workspace | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.artifact-runtime`, `neural-engine.persistence-storage-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Code Workspace | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.artifact-runtime`, `neural-engine.evaluation-verification-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Planning Workspace | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.planner-runtime`, `neural-engine.task-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Artifact Workspace | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.artifact-runtime`, `neural-engine.evaluation-verification-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Assistant Modes | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.conversation-runtime`, `neural-engine.assistant-orchestrator`, `neural-engine.planner-runtime`, `neural-engine.context-compiler`, `neural-engine.memory-runtime`, `neural-engine.task-runtime`, `neural-engine.checkpoint-resume-runtime`, `neural-engine.artifact-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Multimodal Composer | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.multimodal-runtime`, `neural-engine.media-asset-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Context Lens | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.context-compiler`, `neural-engine.project-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Provenance | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.observability-audit-runtime`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |
| Trust Layer | `IMPLEMENTED-TEMPLATE-UI` | `NOT-IMPLEMENTED` | `neural-engine.approval-policy-guardrails`, `neural-engine.runtime-kernel`, `neural-engine.api-bff-runtime` |

## Truthfulness rule

A visible control, status, timeline, agent/tool indicator or result card must not be documented as executable unless the corresponding future engine modules are actually implemented and integration tests prove the capability.

## Source of truth

- UI: module canonical HTML/CSS/JS.
- Capability contracts: `module.manifest.json` and `contracts/`.
- Future engine traceability: `neural-engine/registry/ui-mechanic-traceability.json`.


## V8.11 Cooperative Engine/UI compatibility
This document is synchronized with `cooperative-engine-bridge-v1`. Existing V8.10 mechanics are preserved; new engine-facing surfaces are additive and remain template-only until the corresponding Neural Engine module is executable. See `ENGINE_COMPATIBILITY.md`.


<!-- neuraldesk-documentation-sync: V8.14 -->
neuraldesk-documentation-sync: V8.14
