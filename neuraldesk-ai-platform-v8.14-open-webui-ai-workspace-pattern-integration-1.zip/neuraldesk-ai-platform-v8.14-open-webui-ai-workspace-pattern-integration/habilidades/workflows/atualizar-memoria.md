<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Atualizar Memória

Atualize quando mudar:
- arquitetura;
- versão;
- invariantes;
- módulos;
- contracts/capabilities;
- data ownership;
- UI profile;
- test profile;
- skills profile.

Arquivos: MEMORIA_MESTRE, ESTADO_ATUAL, ADRs, HISTORICO, MAPA_VERSOES, CHECKLIST.
