<!-- neuraldesk-documentation-sync: V8.12 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.frontier-readiness -->
# Competitive Gap Matrix

This matrix separates **current reality** from **future target**.

| Capability area | NeuralDesk current state | Required parity target | Differentiation target |
|---|---|---|---|
| Frontier model intelligence | Not implemented | Route to leading external models | Own specialized + optional frontier models |
| Real inference | Not implemented | Streaming, cancellation, structured outputs | Multi-provider/local routing with policy |
| Persistent projects | UI/template only | Durable project state | Work Graph across all resources |
| Memory | UI/template only | Scoped persistent memory | Explainable memory provenance + controls |
| Agents | UI/template only | Real agent/tool execution | Full lifecycle/eval/deploy/audit |
| Tools/MCP | UI/template only | Safe function/tool execution | Capability-first marketplace + policy |
| Knowledge/RAG | UI/template only | Retrieval, reranking, citations | Retrieval Lab + provenance + eval |
| Deep research | UI/template only | Web research with citations | Multi-source research + project memory |
| Voice realtime | UI/template only | Low-latency duplex voice | Project-aware multimodal work mode |
| Vision/multimodal | UI/template only | Image/audio/video/doc understanding | Cross-modal project context |
| Artifacts | UI/template only | Real file/work-product generation | Versioned artifact lineage + validation |
| Background work | UI/template only | Durable queued jobs | Pause/resume/checkpoint across projects |
| Computer use | Documentation only | Sandboxed UI interaction | Policy-driven fallback behind APIs |
| Evaluation | UI + docs | Executable benchmark/eval harness | Promotion gates for every component |
| Training | UI + docs | Fine-tuning/post-training | Full model research platform |
| Serving | Documentation only | Reliable scalable serving | Multi-engine optimized serving portfolio |
| Security | Documentation only for engine | Authz, secrets, isolation | Trust Layer and approval provenance |
| SRE/operations | UI/template only | Metrics/traces/SLOs | Unified AI cost-quality-reliability plane |
| Audit | UI/template only | Immutable action/event trail | End-to-end provenance and evidence bundles |

## Interpretation

The largest current gap is execution, not interface breadth.

The first competitive milestone is therefore **usable parity using existing frontier models**, not training a giant model from scratch.


## V8.11 coordinated compatibility
Current documentation is synchronized with `cooperative-engine-bridge-v1` and the preserve→extend→bridge non-regression policy.
