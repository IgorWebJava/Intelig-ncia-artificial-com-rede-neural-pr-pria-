#ifndef ND_GENERATIVE_H
#define ND_GENERATIVE_H

#include <stddef.h>
#include <stdint.h>
#include "nd_tokenizer.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ND_GEN_VOCAB 512u
#define ND_GEN_DIM 320u
#define ND_GEN_LAYERS 10u
#define ND_GEN_Q_HEADS 10u
#define ND_GEN_KV_HEADS 2u
#define ND_GEN_HEAD_DIM 32u
#define ND_GEN_KV_DIM 64u
#define ND_GEN_FFN 896u
#define ND_GEN_CONTEXT 256u
#define ND_GEN_PARAMS 11229760u
#define ND_GEN_PAGE_TOKENS 16u
#define ND_GEN_MAX_PAGES (ND_GEN_CONTEXT / ND_GEN_PAGE_TOKENS)

typedef enum NDGenFormat {
    ND_GEN_FP32 = 1,
    ND_GEN_Q8 = 2,
    ND_GEN_Q4 = 3
} NDGenFormat;

typedef struct NDGenerativeModel NDGenerativeModel;
typedef struct NDGenKVPage NDGenKVPage;

typedef struct NDGenKVCache {
    NDGenKVPage *pages[ND_GEN_MAX_PAGES];
    size_t length;
} NDGenKVCache;

typedef struct NDGenSpecStats {
    size_t proposed;
    size_t accepted;
    size_t rejected;
    size_t rollbacks;
} NDGenSpecStats;

typedef enum NDGenStreamStatus {
    ND_GEN_STREAM_ERROR = -1,
    ND_GEN_STREAM_DONE = 0,
    ND_GEN_STREAM_MORE = 1,
    ND_GEN_STREAM_PAUSED = 2,
    ND_GEN_STREAM_CANCELLED = 3,
    ND_GEN_STREAM_DEADLINE = 4,
    ND_GEN_STREAM_ABORTED = 5
} NDGenStreamStatus;

typedef int (*NDGenStreamTokenCallback)(uint32_t token, size_t output_index, void *user);
typedef int (*NDGenStreamShouldStop)(void *user);
typedef uint64_t (*NDGenStreamNowMs)(void *user);

typedef struct NDGenStreamControl {
    size_t prefill_chunk_tokens;
    size_t decode_chunk_tokens;
    uint64_t deadline_at_ms;
    NDGenStreamShouldStop should_stop;
    void *stop_user;
    NDGenStreamNowMs now_ms;
    void *clock_user;
} NDGenStreamControl;

typedef struct NDGenStreamStats {
    size_t prefill_rounds;
    size_t prefill_tokens;
    size_t decode_rounds;
    size_t emitted_tokens;
    size_t pause_events;
    size_t cancellation_checks;
    size_t deadline_checks;
} NDGenStreamStats;

typedef struct NDGenStreamSession {
    const NDGenerativeModel *model;
    NDGenKVCache cache;
    uint32_t prompt[ND_GEN_CONTEXT];
    size_t prompt_count;
    size_t prefill_cursor;
    size_t max_steps;
    size_t generated;
    uint32_t next_token;
    uint32_t pending_step_token;
    int next_ready;
    int pending_step;
    int initialized;
    NDGenStreamStats stats;
} NDGenStreamSession;


typedef int (*NDGenStreamTextCallback)(const unsigned char *utf8_delta, size_t byte_count, void *user);

typedef struct NDGenTextStreamSession {
    NDGenStreamSession token_stream;
    const NDTokenizer *tokenizer;
    unsigned char pending_utf8[8];
    size_t pending_utf8_bytes;
    int text_terminated;
    NDGenStreamTextCallback on_text;
    void *text_user;
} NDGenTextStreamSession;

int nd_gen_load(const char *path, NDGenerativeModel **out_model);
void nd_gen_free(NDGenerativeModel *model);
NDGenFormat nd_gen_format(const NDGenerativeModel *model);
int nd_gen_mmap_active(const NDGenerativeModel *model);
size_t nd_gen_parameter_count(const NDGenerativeModel *model);

void nd_gen_kv_init(NDGenKVCache *cache);
void nd_gen_kv_free(NDGenKVCache *cache);
int nd_gen_kv_clone(const NDGenKVCache *source, NDGenKVCache *clone);
size_t nd_gen_kv_shared_pages(const NDGenKVCache *a, const NDGenKVCache *b);

int nd_gen_full_forward(const NDGenerativeModel *model,
                        const uint32_t *tokens,
                        size_t token_count,
                        float *logits,
                        size_t logits_count);
int nd_gen_incremental_step(const NDGenerativeModel *model,
                            NDGenKVCache *cache,
                            uint32_t token,
                            float *logits,
                            size_t logits_count);
int nd_gen_greedy_generate(const NDGenerativeModel *model,
                           const uint32_t *prompt,
                           size_t prompt_count,
                           uint32_t *output,
                           size_t output_capacity,
                           size_t steps);

void nd_gen_stream_session_init(NDGenStreamSession *session);
void nd_gen_stream_session_free(NDGenStreamSession *session);
int nd_gen_stream_begin(NDGenStreamSession *session,
                        const NDGenerativeModel *model,
                        const uint32_t *prompt,
                        size_t prompt_count,
                        size_t steps);
NDGenStreamStatus nd_gen_stream_advance(NDGenStreamSession *session,
                                        const NDGenStreamControl *control,
                                        NDGenStreamTokenCallback on_token,
                                        void *token_user);
const NDGenStreamStats *nd_gen_stream_stats(const NDGenStreamSession *session);

void nd_gen_text_stream_session_init(NDGenTextStreamSession *session);
void nd_gen_text_stream_session_free(NDGenTextStreamSession *session);
int nd_gen_text_stream_begin(NDGenTextStreamSession *session,
                             const NDGenerativeModel *model,
                             const NDTokenizer *tokenizer,
                             const uint32_t *prompt,
                             size_t prompt_count,
                             size_t steps);
NDGenStreamStatus nd_gen_text_stream_advance(NDGenTextStreamSession *session,
                                             const NDGenStreamControl *control,
                                             NDGenStreamTextCallback on_text,
                                             void *text_user);

int nd_gen_speculative_greedy(const NDGenerativeModel *model,
                              const uint32_t *prompt,
                              size_t prompt_count,
                              uint32_t *output,
                              size_t output_capacity,
                              size_t steps,
                              int force_first_rejection,
                              NDGenSpecStats *stats);

#ifdef __cplusplus
}
#endif
#endif
