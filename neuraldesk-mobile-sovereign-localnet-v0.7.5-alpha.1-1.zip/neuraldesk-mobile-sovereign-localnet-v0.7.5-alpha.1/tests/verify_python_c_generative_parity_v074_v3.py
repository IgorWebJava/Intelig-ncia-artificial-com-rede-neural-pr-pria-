#!/usr/bin/env python3
import importlib.util,subprocess,tempfile
from pathlib import Path
import numpy as np,torch
R=Path(__file__).resolve().parents[1];T=R/'training/train_generative_micro_v074_v3.py';B=R/'build/nd_generative_logits'
spec=importlib.util.spec_from_file_location('v2',T);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.backends.mkldnn.enabled=False;torch.manual_seed(7422);np.random.seed(7422)
model=m.MicroV3().eval();tokens=[257,81,117,97,110,116,105,122,97,99,97,111,259]
with torch.no_grad():py=model(torch.tensor(tokens)[None,:])[0,-1].numpy()
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'v3.ndgm';m.export(model,p,'fp32');r=subprocess.run([str(B),str(p),*map(str,tokens)],cwd=R,text=True,capture_output=True,check=True);c=np.array([float(x.split()[1]) for x in r.stdout.splitlines()]);d=np.abs(c-py);assert int(c.argmax())==int(py.argmax()) and float(d.max())<=2e-5
 print(f'PYTHON_C_GENERATIVE_V3_PARITY PASS maxAbs={float(d.max()):.9g} top1={int(py.argmax())} params={m.PARAMS}')
