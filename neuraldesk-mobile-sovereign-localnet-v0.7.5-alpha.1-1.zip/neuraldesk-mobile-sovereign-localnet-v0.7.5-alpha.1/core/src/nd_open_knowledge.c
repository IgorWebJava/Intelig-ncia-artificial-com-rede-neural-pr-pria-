#include "nd_open_knowledge.h"

#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NDOS_MAGIC "NDOSV001"
#define NDOS_HEADER_BYTES 52u
#define NDOS_MAX_RECORDS 100000u
#define NDOS_MAX_BUCKETS 1048576u
#define NDOS_MAX_IDF 1048576u
#define NDOS_MAX_ENTRIES 20000000u
#define NDOS_MAX_TEXT (1u << 20)
#define NDOS_FLAG_ASCII_FOLD 1u
#define ND_FNV_OFFSET UINT64_C(14695981039346656037)
#define ND_FNV_PRIME UINT64_C(1099511628211)

typedef struct {
    const unsigned char *data;
    size_t size;
    size_t pos;
} NDReader;

typedef struct {
    uint32_t bucket;
    uint32_t count;
    double weight;
} NDQueryFeature;

static void seterr(char *err, size_t cap, const char *msg) {
    if (err && cap) (void)snprintf(err, cap, "%s", msg ? msg : "open knowledge error");
}

static int take(NDReader *r, size_t n, const unsigned char **out) {
    if (!r || r->pos > r->size || n > r->size - r->pos) return -1;
    *out = r->data + r->pos;
    r->pos += n;
    return 0;
}

static uint32_t u32le(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint64_t u64le(const unsigned char *p) {
    return (uint64_t)u32le(p) | ((uint64_t)u32le(p + 4) << 32);
}

static float f32le(const unsigned char *p) {
    uint32_t bits = u32le(p);
    float v = 0.0f;
    memcpy(&v, &bits, sizeof(v));
    return v;
}

static double f64le(const unsigned char *p) {
    uint64_t bits = u64le(p);
    double v = 0.0;
    memcpy(&v, &bits, sizeof(v));
    return v;
}

static char *copy_string(const unsigned char *p, uint32_t n) {
    char *s = (char *)malloc((size_t)n + 1u);
    if (!s) return NULL;
    if (n) memcpy(s, p, n);
    s[n] = 0;
    return s;
}

static int u32_cmp(const void *a, const void *b) {
    const uint32_t x = *(const uint32_t *)a;
    const uint32_t y = *(const uint32_t *)b;
    return (x > y) - (x < y);
}

static uint64_t fnv_update(uint64_t h, const unsigned char *p, size_t n) {
    for (size_t i = 0; i < n; i++) {
        h ^= (uint64_t)p[i];
        h *= ND_FNV_PRIME;
    }
    return h;
}

static uint32_t bucket_prefixed(const NDOpenKnowledgeShard *shard,
                                const char *prefix,
                                const unsigned char *p,
                                size_t n) {
    uint64_t h = ND_FNV_OFFSET;
    h = fnv_update(h, (const unsigned char *)prefix, strlen(prefix));
    h = fnv_update(h, p, n);
    return (uint32_t)(h & (uint64_t)(shard->bucket_count - 1u));
}

static int emit_ascii(unsigned char *dst, size_t cap, size_t *w, unsigned char c, int *sep) {
    int keep = ((c >= (unsigned char)'a' && c <= (unsigned char)'z') ||
                (c >= (unsigned char)'0' && c <= (unsigned char)'9'));
    if (keep) {
        if (*w >= cap) return -1;
        dst[(*w)++] = c;
        *sep = 0;
    } else if (!*sep && *w) {
        if (*w >= cap) return -1;
        dst[(*w)++] = (unsigned char)' ';
        *sep = 1;
    }
    return 0;
}

/* Deterministic Portuguese/Latin-1 UTF-8 -> ASCII fold used by both builder and runtime. */
static int fold_c3(unsigned char b, unsigned char *out) {
    switch (b) {
        case 0x80: case 0x81: case 0x82: case 0x83: case 0x84: case 0x85:
        case 0xA0: case 0xA1: case 0xA2: case 0xA3: case 0xA4: case 0xA5: *out = 'a'; return 1;
        case 0x87: case 0xA7: *out = 'c'; return 1;
        case 0x88: case 0x89: case 0x8A: case 0x8B:
        case 0xA8: case 0xA9: case 0xAA: case 0xAB: *out = 'e'; return 1;
        case 0x8C: case 0x8D: case 0x8E: case 0x8F:
        case 0xAC: case 0xAD: case 0xAE: case 0xAF: *out = 'i'; return 1;
        case 0x91: case 0xB1: *out = 'n'; return 1;
        case 0x92: case 0x93: case 0x94: case 0x95: case 0x96:
        case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: *out = 'o'; return 1;
        case 0x99: case 0x9A: case 0x9B: case 0x9C:
        case 0xB9: case 0xBA: case 0xBB: case 0xBC: *out = 'u'; return 1;
        case 0x9D: case 0xBD: case 0xBF: *out = 'y'; return 1;
        default: return 0;
    }
}

static int normalize_query(const char *query, unsigned char **out, size_t *outlen, char *err, size_t errcap) {
    const unsigned char *src = (const unsigned char *)query;
    size_t n = strlen(query);
    if (n == 0u || n > 65536u) {
        seterr(err, errcap, "open knowledge query length invalid");
        return -1;
    }
    unsigned char *dst = (unsigned char *)malloc(n + 1u);
    if (!dst) {
        seterr(err, errcap, "open knowledge normalize allocation failed");
        return -1;
    }
    size_t w = 0u;
    int sep = 1;
    for (size_t i = 0; i < n; i++) {
        unsigned char x = src[i];
        if (x >= 'A' && x <= 'Z') x = (unsigned char)(x + ('a' - 'A'));
        if (x < 0x80u) {
            if (emit_ascii(dst, n, &w, x, &sep)) goto overflow;
            continue;
        }
        if (x == 0xC3u && i + 1u < n) {
            unsigned char folded = 0u;
            if (fold_c3(src[i + 1u], &folded)) {
                if (emit_ascii(dst, n, &w, folded, &sep)) goto overflow;
                i++;
                continue;
            }
        }
        /* Unsupported Unicode codepoints are deterministic separators. */
        if (!sep && w) {
            if (w >= n) goto overflow;
            dst[w++] = (unsigned char)' ';
            sep = 1;
        }
        /* Skip UTF-8 continuation bytes for the unsupported codepoint. */
        if ((x & 0xE0u) == 0xC0u && i + 1u < n) i += 1u;
        else if ((x & 0xF0u) == 0xE0u && i + 2u < n) i += 2u;
        else if ((x & 0xF8u) == 0xF0u && i + 3u < n) i += 3u;
    }
    if (w && dst[w - 1u] == (unsigned char)' ') w--;
    dst[w] = 0;
    if (!w) {
        free(dst);
        seterr(err, errcap, "open knowledge query has no searchable content");
        return -1;
    }
    *out = dst;
    *outlen = w;
    return 0;

overflow:
    free(dst);
    seterr(err, errcap, "open knowledge normalized query exceeds bounds");
    return -1;
}

static int push_bucket(uint32_t *v, size_t cap, size_t *count, uint32_t b) {
    if (*count >= cap) return -1;
    v[(*count)++] = b;
    return 0;
}

static int make_query_buckets(const NDOpenKnowledgeShard *shard,
                              const unsigned char *norm,
                              size_t n,
                              uint32_t **out,
                              size_t *out_count,
                              char *err,
                              size_t errcap) {
    size_t cap = n * 6u + 64u;
    uint32_t *v = (uint32_t *)malloc(cap * sizeof(*v));
    if (!v) { seterr(err, errcap, "open knowledge feature allocation failed"); return -1; }
    size_t count = 0u, prev_start = 0u, prev_len = 0u;
    int have_prev = 0;
    size_t i = 0u;
    while (i < n) {
        while (i < n && norm[i] == ' ') i++;
        if (i >= n) break;
        size_t start = i;
        while (i < n && norm[i] != ' ') i++;
        size_t len = i - start;
        if (push_bucket(v, cap, &count, bucket_prefixed(shard, "w:", norm + start, len))) goto overflow;
        if (have_prev) {
            size_t pair_len = prev_len + 1u + len;
            unsigned char *pair = (unsigned char *)malloc(pair_len);
            if (!pair) { free(v); seterr(err, errcap, "open knowledge bigram allocation failed"); return -1; }
            memcpy(pair, norm + prev_start, prev_len);
            pair[prev_len] = ' ';
            memcpy(pair + prev_len + 1u, norm + start, len);
            uint32_t b = bucket_prefixed(shard, "b:", pair, pair_len);
            free(pair);
            if (push_bucket(v, cap, &count, b)) goto overflow;
        }
        prev_start = start;
        prev_len = len;
        have_prev = 1;
    }
    unsigned char *compact = (unsigned char *)malloc(n ? n : 1u);
    if (!compact) { free(v); seterr(err, errcap, "open knowledge compact allocation failed"); return -1; }
    for (size_t j = 0; j < n; j++) compact[j] = norm[j] == ' ' ? '_' : norm[j];
    for (size_t gram = 3u; gram <= 5u; gram++) {
        if (n < gram) continue;
        char prefix[4] = {'c', (char)('0' + gram), ':', 0};
        for (size_t j = 0; j + gram <= n; j++) {
            if (push_bucket(v, cap, &count, bucket_prefixed(shard, prefix, compact + j, gram))) {
                free(compact);
                goto overflow;
            }
        }
    }
    free(compact);
    qsort(v, count, sizeof(*v), u32_cmp);
    *out = v;
    *out_count = count;
    return 0;

overflow:
    free(v);
    seterr(err, errcap, "open knowledge feature capacity exceeded");
    return -1;
}

static const NDOpenKnowledgeFeature *find_idf(const NDOpenKnowledgeShard *shard, uint32_t bucket) {
    size_t lo = 0u, hi = shard->idf_count;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2u;
        if (shard->idf[mid].bucket < bucket) lo = mid + 1u; else hi = mid;
    }
    return (lo < shard->idf_count && shard->idf[lo].bucket == bucket) ? &shard->idf[lo] : NULL;
}

static double query_weight_for(const NDQueryFeature *q, size_t n, uint32_t bucket) {
    size_t lo = 0u, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2u;
        if (q[mid].bucket < bucket) lo = mid + 1u; else hi = mid;
    }
    return (lo < n && q[lo].bucket == bucket) ? q[lo].weight : 0.0;
}

static int make_query_vector(const NDOpenKnowledgeShard *shard,
                             const char *query,
                             NDQueryFeature **out,
                             size_t *out_count,
                             double *out_norm,
                             char *err,
                             size_t errcap) {
    unsigned char *norm = NULL;
    size_t normlen = 0u;
    uint32_t *buckets = NULL;
    size_t bucket_count = 0u;
    if (normalize_query(query, &norm, &normlen, err, errcap)) return -1;
    int rc = make_query_buckets(shard, norm, normlen, &buckets, &bucket_count, err, errcap);
    free(norm);
    if (rc) return -1;
    NDQueryFeature *q = (NDQueryFeature *)calloc(bucket_count ? bucket_count : 1u, sizeof(*q));
    if (!q) { free(buckets); seterr(err, errcap, "open knowledge query vector allocation failed"); return -1; }
    size_t used = 0u;
    double norm2 = 0.0;
    for (size_t i = 0; i < bucket_count;) {
        size_t j = i + 1u;
        while (j < bucket_count && buckets[j] == buckets[i]) j++;
        const NDOpenKnowledgeFeature *idf = find_idf(shard, buckets[i]);
        if (idf) {
            double w = (double)(j - i) * (double)idf->value;
            q[used].bucket = buckets[i];
            q[used].count = (uint32_t)(j - i);
            q[used].weight = w;
            norm2 += w * w;
            used++;
        }
        i = j;
    }
    free(buckets);
    if (!used || norm2 <= 0.0) {
        free(q);
        *out = NULL; *out_count = 0u; *out_norm = 0.0;
        return 0;
    }
    *out = q; *out_count = used; *out_norm = sqrt(norm2);
    return 0;
}

int nd_open_knowledge_load(const char *path, NDOpenKnowledgeShard *shard, char *err, size_t errcap) {
    if (!path || !shard) return -1;
    memset(shard, 0, sizeof(*shard));
    FILE *fp = fopen(path, "rb");
    if (!fp) { seterr(err, errcap, "cannot open open knowledge shard"); return -1; }
    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); seterr(err, errcap, "cannot size shard"); return -1; }
    long flen = ftell(fp);
    if (flen < (long)NDOS_HEADER_BYTES || fseek(fp, 0, SEEK_SET) != 0) { fclose(fp); seterr(err, errcap, "invalid shard size"); return -1; }
    unsigned char *buf = (unsigned char *)malloc((size_t)flen);
    if (!buf) { fclose(fp); seterr(err, errcap, "shard allocation failed"); return -1; }
    size_t got = fread(buf, 1u, (size_t)flen, fp);
    fclose(fp);
    if (got != (size_t)flen) { free(buf); seterr(err, errcap, "short shard read"); return -1; }

    NDReader rd = {buf, (size_t)flen, 0u};
    const unsigned char *p = NULL;
    if (take(&rd, 8u, &p) || memcmp(p, NDOS_MAGIC, 8u) != 0) goto corrupt;
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->version = u32le(p);
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->record_count = u32le(p);
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->bucket_count = u32le(p);
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->idf_count = u32le(p);
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->sparse_entries = u32le(p);
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->top_k = u32le(p);
    if (take(&rd, 4u, &p)) goto corrupt;
    shard->flags = u32le(p);
    if (take(&rd, 8u, &p)) goto corrupt;
    shard->accept_score = f64le(p);
    if (take(&rd, 8u, &p)) goto corrupt;
    shard->accept_margin = f64le(p);

    if (shard->version != 1u || !shard->record_count || shard->record_count > NDOS_MAX_RECORDS ||
        shard->bucket_count < 1024u || shard->bucket_count > NDOS_MAX_BUCKETS ||
        (shard->bucket_count & (shard->bucket_count - 1u)) != 0u ||
        !shard->idf_count || shard->idf_count > NDOS_MAX_IDF || !shard->sparse_entries ||
        shard->sparse_entries > NDOS_MAX_ENTRIES || !shard->top_k || shard->top_k > 4096u ||
        shard->flags != NDOS_FLAG_ASCII_FOLD ||
        !(shard->accept_score > 0.0 && shard->accept_score <= 1.0) ||
        !(shard->accept_margin >= 0.0 && shard->accept_margin <= 1.0)) goto corrupt;

    shard->idf = (NDOpenKnowledgeFeature *)calloc(shard->idf_count, sizeof(*shard->idf));
    shard->records = (NDOpenKnowledgeRecord *)calloc(shard->record_count, sizeof(*shard->records));
    if (!shard->idf || !shard->records) goto oom;
    for (uint32_t i = 0; i < shard->idf_count; i++) {
        if (take(&rd, 8u, &p)) goto corrupt;
        shard->idf[i].bucket = u32le(p);
        shard->idf[i].value = f32le(p + 4u);
        if (shard->idf[i].bucket >= shard->bucket_count || !isfinite(shard->idf[i].value) || shard->idf[i].value <= 0.0f) goto corrupt;
        if (i && shard->idf[i - 1u].bucket >= shard->idf[i].bucket) goto corrupt;
    }
    uint64_t entries = 0u;
    for (uint32_t i = 0; i < shard->record_count; i++) {
        NDOpenKnowledgeRecord *r = &shard->records[i];
        if (take(&rd, 28u, &p)) goto corrupt;
        r->split = u32le(p);
        uint32_t ilen = u32le(p + 4u), qlen = u32le(p + 8u), alen = u32le(p + 12u);
        r->feature_count = u32le(p + 16u);
        r->norm = f64le(p + 20u);
        if (r->split > 1u || !ilen || !qlen || !alen || ilen > NDOS_MAX_TEXT || qlen > NDOS_MAX_TEXT || alen > NDOS_MAX_TEXT ||
            !r->feature_count || r->feature_count > shard->top_k || !isfinite(r->norm) || r->norm <= 0.0) goto corrupt;
        if (take(&rd, ilen, &p)) goto corrupt;
        r->source_id = copy_string(p, ilen);
        if (!r->source_id) goto oom;
        if (take(&rd, qlen, &p)) goto corrupt;
        r->question = copy_string(p, qlen);
        if (!r->question) goto oom;
        if (take(&rd, alen, &p)) goto corrupt;
        r->answer = copy_string(p, alen);
        if (!r->answer) goto oom;
        r->features = (NDOpenKnowledgeFeature *)calloc(r->feature_count, sizeof(*r->features));
        if (!r->features) goto oom;
        for (uint32_t j = 0; j < r->feature_count; j++) {
            if (take(&rd, 8u, &p)) goto corrupt;
            r->features[j].bucket = u32le(p);
            r->features[j].value = f32le(p + 4u);
            if (r->features[j].bucket >= shard->bucket_count || !isfinite(r->features[j].value) || r->features[j].value <= 0.0f) goto corrupt;
            if (j && r->features[j - 1u].bucket >= r->features[j].bucket) goto corrupt;
        }
        entries += r->feature_count;
    }
    if (entries != shard->sparse_entries || rd.pos != rd.size) goto corrupt;
    free(buf);
    return 0;

corrupt:
    free(buf);
    nd_open_knowledge_free(shard);
    seterr(err, errcap, "open knowledge shard corrupt or incompatible");
    return -1;
oom:
    free(buf);
    nd_open_knowledge_free(shard);
    seterr(err, errcap, "open knowledge shard allocation failed");
    return -1;
}

void nd_open_knowledge_free(NDOpenKnowledgeShard *shard) {
    if (!shard) return;
    if (shard->records) {
        for (uint32_t i = 0; i < shard->record_count; i++) {
            free(shard->records[i].source_id);
            free(shard->records[i].question);
            free(shard->records[i].answer);
            free(shard->records[i].features);
        }
    }
    free(shard->records);
    free(shard->idf);
    memset(shard, 0, sizeof(*shard));
}

int nd_open_knowledge_search(const NDOpenKnowledgeShard *shard,
                             const char *query,
                             NDOpenKnowledgeResult *result,
                             char *err,
                             size_t errcap) {
    if (!shard || !query || !result || !shard->records || !shard->idf) return -1;
    memset(result, 0, sizeof(*result));
    NDQueryFeature *q = NULL;
    size_t qn = 0u;
    double qnorm = 0.0;
    if (make_query_vector(shard, query, &q, &qn, &qnorm, err, errcap)) return -1;
    if (!qn || qnorm <= 0.0) { free(q); return 0; }

    double best = -1.0, second = -1.0;
    uint32_t best_i = 0u;
    for (uint32_t i = 0; i < shard->record_count; i++) {
        const NDOpenKnowledgeRecord *r = &shard->records[i];
        double dot = 0.0;
        for (uint32_t j = 0; j < r->feature_count; j++) {
            double qw = query_weight_for(q, qn, r->features[j].bucket);
            if (qw != 0.0) dot += qw * (double)r->features[j].value;
        }
        double s = dot > 0.0 ? dot / (qnorm * r->norm) : 0.0;
        if (s > best) { second = best; best = s; best_i = i; }
        else if (s > second) second = s;
    }
    free(q);
    if (second < 0.0) second = 0.0;
    result->record_index = best_i;
    result->score = best > 0.0 ? best : 0.0;
    result->margin = best > second ? best - second : 0.0;
    const NDOpenKnowledgeRecord *r = &shard->records[best_i];
    result->source_id = r->source_id;
    result->question = r->question;
    result->answer = r->answer;
    result->split = r->split;
    result->found = result->score >= shard->accept_score && result->margin >= shard->accept_margin;
    return 0;
}
