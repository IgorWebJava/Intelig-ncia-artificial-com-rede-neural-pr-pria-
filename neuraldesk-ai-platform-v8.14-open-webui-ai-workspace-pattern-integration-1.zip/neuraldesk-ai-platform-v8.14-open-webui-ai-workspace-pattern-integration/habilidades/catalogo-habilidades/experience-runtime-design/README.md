<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->
# Adaptive Intelligence Design System & Module UI Runtime

Skill ID: `neuraldesk.experience-runtime-design.v1`

Introduced in V8.0 after the user explicitly requested implementation of the next-generation interactive experience.

## Responsibilities

- NeuralDesk Adaptive Intelligence Design System source;
- readable typography and progressive disclosure;
- consistent shell / workspace / inspector / task surfaces;
- module-owned JavaScript runtime;
- command palette, universal create, global search, tabs, drawers and notifications;
- keyboard/touch/remote interaction;
- browser interaction and responsive validation.

## Invariant

There is **no global runtime JavaScript dependency**. `platform/experience-runtime/` defines the contract/reference behavior, while each module owns `ui/runtime/module-runtime.js`.
