import unittest
import sys
import os
import math

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from qcnn.plugins.hyperdimensional_computing import HyperdimensionalComputingPlugin
from qcnn.plugins.fractal_grammar import FractalGrammarPlugin
from qcnn.core.context import QcnnExecutionContext

class TestHdcAndGrammar(unittest.TestCase):
    def test_hdc_vector_operations(self):
        hdc = HyperdimensionalComputingPlugin(dimension=10000)
        
        # Test vector projection
        v_universo = hdc.get_or_create_vector("universo")
        self.assertEqual(len(v_universo), 10000)
        self.assertTrue(set(v_universo).issubset({-1, 1}))
        
        # Test Binding (Element-wise multiplication in bipolar representation)
        v_mente = hdc.get_or_create_vector("mente")
        v_bound = hdc.bind(v_universo, v_mente)
        self.assertEqual(len(v_bound), 10000)
        
        # Test Cosine Similarity of identical vectors is 1.0
        sim_self = hdc.similarity(v_universo, v_universo)
        self.assertAlmostEqual(sim_self, 1.0, places=4)
        
        # Test Quasi-orthogonality of random hypervectors in D=10,000 (|sim| < 0.08)
        sim_random = hdc.similarity(v_universo, v_mente)
        self.assertLess(abs(sim_random), 0.08)

    def test_hdc_plugin_execution(self):
        hdc = HyperdimensionalComputingPlugin(dimension=10000)
        ctx = QcnnExecutionContext(prompt="Qual a relação entre mente, tempo e universo?")
        ctx = hdc.execute(ctx)
        
        self.assertIn("hdc_dimension", ctx.metadata)
        self.assertEqual(ctx.metadata["hdc_dimension"], 10000)
        self.assertIn("hdc_resonance_score", ctx.metadata)
        self.assertGreaterEqual(ctx.metadata["hdc_resonance_score"], 0.0)

    def test_fractal_grammar_plugin(self):
        grammar = FractalGrammarPlugin()
        
        # Test direct articulation synthesis
        synth2 = grammar.sintetizar_articulacao(["universo", "mente"])
        self.assertIsNotNone(synth2)
        self.assertIn("Universo", synth2)
        self.assertIn("Mente", synth2)
        
        synth3 = grammar.sintetizar_articulacao(["mente", "tempo", "universo"])
        self.assertIsNotNone(synth3)
        self.assertIn("Mente", synth3)
        self.assertIn("Tempo", synth3)
        self.assertIn("Universo", synth3)
        
        # Test plugin context execution
        ctx = QcnnExecutionContext(prompt="universo e mente")
        ctx.metadata["active_concepts"] = ["universo", "mente"]
        
        ctx = grammar.execute(ctx)
        self.assertIn("synthesized_grammar", ctx.metadata)
        self.assertIn("Universo", ctx.metadata["synthesized_grammar"])

if __name__ == "__main__":
    unittest.main()
