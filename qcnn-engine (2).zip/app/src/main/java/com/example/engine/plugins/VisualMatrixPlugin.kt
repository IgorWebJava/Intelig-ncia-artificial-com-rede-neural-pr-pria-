package com.example.engine.plugins

import com.example.engine.core.IQcnnPlugin
import com.example.engine.core.QcnnExecutionContext
import kotlin.math.cos
import kotlin.math.sin

/**
 * Plugin Kotlin para Síntese e Processamento Visual/Vetorial (SVG e Matrizes) 100% Offline no Android.
 */
class VisualMatrixPlugin : IQcnnPlugin {
    override val pluginId: String = "visual_matrix"
    override var isEnabled: Boolean = true

    override fun execute(context: QcnnExecutionContext): QcnnExecutionContext {
        val entrada = context.prompt.trim().lowercase()

        if (entrada.contains("gerar imagem") || entrada.contains("criar imagem") || entrada.contains("gerar svg") || entrada.contains("desenhar")) {
            val svg = gerarDiagramaSvg(context.totalFrequencyHz)
            context.metadata["imagem_svg"] = svg
            context.metadata["formato_visual"] = "image/svg+xml"
            context.metadata["modulo_visual"] = pluginId

            if (entrada.contains("gerar imagem") || entrada.contains("criar imagem") || entrada.contains("gerar svg")) {
                context.customResponse = "🎨 **[Multi-V Visual Matrix]** Gráfico Vetorial Sintetizado!\n\n```xml\n$svg\n```\n\n✨ *Frequência: ${String.format("%.2f", context.totalFrequencyHz)} Hz.*"
            }
        }
        return context
    }

    fun gerarDiagramaSvg(frequencia: Double, largura: Int = 500, altura: Int = 350): String {
        val cx = largura / 2
        val cy = altura / 2
        val nosSvg = StringBuilder()

        for (i in 0 until 6) {
            val ang = (2.0 * Math.PI / 6.0) * i
            val dist = 90.0 * 1.618
            val ox = cx + dist * cos(ang)
            val oy = cy + dist * sin(ang)
            nosSvg.append("<circle cx=\"${String.format("%.1f", ox)}\" cy=\"${String.format("%.1f", oy)}\" r=\"12\" fill=\"#00f0ff\" stroke=\"#ffffff\" stroke-width=\"1.5\"/>\n")
        }

        return """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 $largura $altura" width="100%" height="100%" style="background:#0a0e17; border-radius:12px;">
  <defs>
    <radialGradient id="gradCentral" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#9d4edd" />
      <stop offset="100%" stop-color="#3a0ca3" />
    </radialGradient>
  </defs>
  <circle cx="$cx" cy="$cy" r="45" fill="url(#gradCentral)" stroke="#c77dff" stroke-width="2"/>
  <text x="$cx" y="${cy + 5}" fill="#ffffff" font-size="12" font-family="monospace" text-anchor="middle">${String.format("%.1f", frequencia)}Hz</text>
  $nosSvg
</svg>
        """.trimIndent()
    }
}
