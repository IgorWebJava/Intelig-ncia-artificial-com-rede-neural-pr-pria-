"""
Plugin de Visão Computacional Simbólica e Geração Gráfica Matriz/Vetorial do QCNN Engine.
Opera 100% offline via matemática matricial, decomposição de gradientes e exportação SVG/BMP.
"""

from typing import Dict, Any, List, Tuple
import math
import os
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext


class VisualMatrixPlugin(BaseQcnnPlugin):
    """
    Plugin responsável pelo processamento visual simbólico, análise de matrizes de pixels,
    extração de bordas/formas e síntese de imagens em SVG e mapas de bits procedurais.
    """

    @property
    def plugin_id(self) -> str:
        return "visual_matrix"

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        entrada = context.prompt.strip() if context.prompt else ""
        lower = entrada.lower()

        # Identificar comandos de geração visual / imagens / diagramas
        if any(term in lower for term in ["gerar imagem", "crie uma imagem", "criar imagem", "desenhar", "gerar svg", "gerar diagrama", "grafico"]):
            svg_content = self.gerar_diagrama_svg(entrada, context.total_frequency_hz)
            context.metadata["imagem_svg"] = svg_content
            context.metadata["formato_visual"] = "image/svg+xml"
            context.metadata["modulo_visual"] = "VisualMatrixPlugin"
            
            if "gerar imagem" in lower or "criar imagem" in lower or "gerar svg" in lower:
                context.custom_response = (
                    f"🎨 **[Multi-V Visual Matrix]** Gráfico/Imagem Vetorial Sintetizado com Sucesso!\n\n"
                    f"```xml\n{svg_content}\n```\n\n"
                    f"✨ *Renderizado matematicamente sob frequência harmônica de {context.total_frequency_hz:.2f} Hz.*"
                )

        return context

    def gerar_diagrama_svg(self, descricao: str, frequencia: float = 432.0, largura: int = 500, altura: int = 350) -> str:
        fator_phi = 1.618033988749895
        freq = frequencia if frequencia > 0 else 432.0
        raio_central = 40.0 * (fator_phi if freq > 500 else 1.2)
        cx, cy = largura // 2, altura // 2

        num_orbitais = 6
        nos_svg = []
        conexoes_svg = []

        for i in range(num_orbitais):
            ang = (2 * math.pi / num_orbitais) * i
            dist = 90.0 * fator_phi
            ox = cx + dist * math.cos(ang)
            oy = cy + dist * math.sin(ang)
            
            conexoes_svg.append(
                f'<line x1="{cx}" y1="{cy}" x2="{ox:.1f}" y2="{oy:.1f}" stroke="rgba(0, 240, 255, 0.4)" stroke-width="1.5" stroke-dasharray="4,4" />'
            )
            nos_svg.append(
                f'<circle cx="{ox:.1f}" cy="{oy:.1f}" r="14" fill="url(#gradOrbital)" stroke="#00f0ff" stroke-width="2" />\n'
                f'    <text x="{ox:.1f}" y="{oy + 4:.1f}" fill="#ffffff" font-size="10" font-family="monospace" text-anchor="middle">v{i+1}</text>'
            )

        conexoes_str = "\n    ".join(conexoes_svg)
        nos_str = "\n    ".join(nos_svg)

        svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {largura} {altura}" width="100%" height="100%" style="background:#0a0e17; border-radius:12px; font-family:sans-serif;">
  <defs>
    <radialGradient id="gradCentral" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#9d4edd" />
      <stop offset="100%" stop-color="#3a0ca3" />
    </radialGradient>
    <radialGradient id="gradOrbital" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#00f0ff" />
      <stop offset="100%" stop-color="#0077b6" />
    </radialGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="4" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <g opacity="0.15">
    <line x1="0" y1="{cy}" x2="{largura}" y2="{cy}" stroke="#00f0ff" stroke-width="1" />
    <line x1="{cx}" y1="0" x2="{cx}" y2="{altura}" stroke="#00f0ff" stroke-width="1" />
    <circle cx="{cx}" cy="{cy}" r="145" fill="none" stroke="#9d4edd" stroke-width="1" />
  </g>

  {conexoes_str}

  <circle cx="{cx}" cy="{cy}" r="{raio_central:.1f}" fill="url(#gradCentral)" stroke="#c77dff" stroke-width="3" filter="url(#glow)" />
  <text x="{cx}" y="{cy + 5}" fill="#ffffff" font-size="12" font-weight="bold" font-family="monospace" text-anchor="middle">{freq:.1f} Hz</text>

  {nos_str}

  <text x="20" y="30" fill="#00f0ff" font-size="14" font-weight="bold" font-family="monospace">MULTI-V // SYNTHETIC VISUAL MATRIX</text>
  <text x="20" y="{altura - 15}" fill="#7209b7" font-size="11" font-family="monospace">ENTROPIA RESSONANTE: ESTÁVEL | D=10.000</text>
</svg>"""
        return svg
