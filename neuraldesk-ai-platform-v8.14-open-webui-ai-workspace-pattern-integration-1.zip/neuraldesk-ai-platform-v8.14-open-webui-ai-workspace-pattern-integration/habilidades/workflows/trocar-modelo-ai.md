<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Workflow — Trocar Modelo / Provider de IA

Nunca alterar consumidores para apontar diretamente ao provider.

Register adapter/model
→ capability tests
→ golden dataset
→ quality
→ safety
→ tool tests
→ multimodal tests
→ shadow
→ canary
→ profile binding switch
→ observability
→ rollback.
