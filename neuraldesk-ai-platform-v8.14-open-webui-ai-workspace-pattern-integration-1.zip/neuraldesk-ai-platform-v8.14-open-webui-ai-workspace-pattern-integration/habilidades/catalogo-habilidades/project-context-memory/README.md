<!-- neuraldesk-documentation-reviewed: V8.7 -->
<!-- neuraldesk-document-status: REFERENCE-DETAIL; owner: project.skills; current: habilidades/AI_HANDOFF.md -->

# Continuidade de Projeto

    Skill ID: `neuraldesk.project-context-memory.v1`

    ## Category

    `continuity`

    ## Introduced

    `V6.2`

    ## Required development capabilities

    - `project.memory.read.v1`
- `project.memory.update.v1`
- `project.skills.read.v1`
- `project.skills.update.v1`

    ## Used by

    - `all-modules`

    ## Related project artifacts

    - `memória/`
- `habilidades/`

    ## Portability rule

    This skill describes reproducible project knowledge and capabilities.
    It must not depend on one specific AI product or one specific tool implementation.

    ## Security

    This skill documentation must never contain real passwords, API keys, tokens, private credentials or private chain-of-thought.
