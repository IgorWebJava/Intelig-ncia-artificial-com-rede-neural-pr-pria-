<!-- neuraldesk-documentation-sync: V8.8 -->

# adapter.ai.local-runtime-template

    Replaceable adapter template.

    Provides:
    - `ai.text.generate.v1`
- `ai.embedding.create.v1`

    Domain modules must never import this adapter implementation directly.
    Binding occurs through the corresponding platform gateway/registry.
