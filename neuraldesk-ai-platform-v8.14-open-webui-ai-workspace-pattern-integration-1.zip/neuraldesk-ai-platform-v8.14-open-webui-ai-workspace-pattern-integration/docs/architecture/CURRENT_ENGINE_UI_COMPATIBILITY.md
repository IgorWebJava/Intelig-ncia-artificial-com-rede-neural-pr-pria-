<!-- neuraldesk-documentation-sync: V8.14 -->
<!-- neuraldesk-document-status: CURRENT; owner: platform.architecture -->
# Current Engine ↔ UI Compatibility Architecture

Profile: `cooperative-engine-bridge-v1`.

All **94** future engine modules map to at least one of the **10** canonical UI modules. The UI exposes status/control/readiness surfaces but cannot claim execution while engine maturity is documentation-only.

## Compatibility layers
1. Existing UI contracts and mechanics (preserved).
2. Additive UI bridge capabilities (extended).
3. Engine-module ownership mapping (bridged).
4. Future adapters/migrations when executable providers arrive.

## Critical future state families now representable
Session replay; turn/step/inbox/cancel; checkpoint/resume; context compaction/spill; guarded tool effects; unknown outcome; subagent federation; invariant diagnostics; durable jobs; dynamic extensions; schema evolution; sandbox dimensions; direct human commands.


## V8.12 Agent Platform bridge
125/145 future engine modules are mapped. AutoBuild, Graph Compile/Simulation, Marketplace/Library, Trigger/Schedule, Connector/Credential, Node Timeline and Graph Cost surfaces are additive and truthfully marked engine-not-connected.


## V8.14 Coding Intelligence bridge
125/145 future engine modules are mapped, with 199 UI↔Engine mechanics tracked. The new Coding Intelligence surface is additive and uses `coding-intelligence-patterns-v1`; it does not imply executable shell/Git/LSP/MCP behavior.

## AI Workspace V8.14
Profile: `open-webui-ai-workspace-patterns-v1`; 20 additive future modules are mapped through the same bridge.
