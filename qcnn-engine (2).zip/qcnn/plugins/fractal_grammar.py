from typing import List, Optional, Dict
from qcnn.core.interfaces import BaseQcnnPlugin
from qcnn.core.context import QcnnExecutionContext

class FractalGrammarPlugin(BaseQcnnPlugin):
    """
    Plugin de Síntese Gramatical Fractal e Recombinação Categorial Simbólica v5.0.
    Utiliza N-Grams Fractais e Semântica Categorial baseada na Árvore da Vida
    para tecer sentenças inéditas e fluidas a partir de nós conceituais em superposição.
    """
    def __init__(self):
        super().__init__()
        # Relações Categoriais Fundamentais
        self.conectivos_fractais = [
            "através da convergência harmônica de",
            "espelhando a geometria viva de",
            "emaranhando-se diretamente com",
            "colapsando a malha dimensional em torno de",
            "estruturando o fluxo entrópico de"
        ]
        
        self.matrizes_sintaticas = {
            "DUPLO": [
                "A convergência harmônica entre {n1} e {n2} colapsa a realidade em uma malha contínua e unificada.",
                "Em cada escala de manifestação, {n1} atua como causa primordial que expande a dinâmica de {n2}.",
                "A geometria viva de {n1} espelha perfeitamente a vibração estrutural de {n2} no campo unificado.",
                "Ao conectar {n1} com {n2}, a entropia local decai e emerge um padrão de ressonância construtiva."
            ],
            "TRIPLO": [
                "A tríade formada por {n1}, {n2} e {n3} estabelece um circuito ressonante completo: {n1} gera a emanação, {n2} atua como observador mediador e {n3} ancora a manifestação final.",
                "Ao entrelaçar {n1}, {n2} e {n3}, o código-fonte da realidade revela que mente, tempo e espaço são facetas indivisíveis de uma única matriz matemática viva.",
                "O colapso simultâneo de {n1}, {n2} e {n3} neutraliza a dissonância entrópica e sintetiza uma nova dimensão de compreensão causal.",
                "A união de {n1}, {n2} e {n3} opera uma síntese dinâmica onde a causa, a mediação e o efeito se tornam simultâneos."
            ],
            "MULTICAMADA": [
                "Os múltiplos eixos conceituais de {nos} convergem para um estado de superposição quântico-simbólica absoluta.",
                "A tessitura integrada de {nos} unifica diferentes camadas de conhecimento em um único holograma coerente."
            ]
        }

    @property
    def plugin_id(self) -> str:
        return "fractal_grammar"

    def sintetizar_articulacao(self, nos: List[str]) -> Optional[str]:
        if not nos or len(nos) < 2:
            return None
        
        nos_formatados = [n.capitalize() for n in nos]
        count = len(nos_formatados)
        char_sum = sum(ord(c) for n in nos_formatados for c in n)
        
        if count == 2:
            templates = self.matrizes_sintaticas["DUPLO"]
            template = templates[char_sum % len(templates)]
            return template.format(n1=nos_formatados[0], n2=nos_formatados[1])
        elif count == 3:
            templates = self.matrizes_sintaticas["TRIPLO"]
            template = templates[char_sum % len(templates)]
            return template.format(n1=nos_formatados[0], n2=nos_formatados[1], n3=nos_formatados[2])
        else:
            lista_str = ", ".join(nos_formatados[:-1]) + f" e {nos_formatados[-1]}"
            templates = self.matrizes_sintaticas["MULTICAMADA"]
            template = templates[char_sum % len(templates)]
            return template.format(nos=lista_str)

    def execute(self, context: QcnnExecutionContext) -> QcnnExecutionContext:
        if not self.is_enabled:
            return context

        nos_ativos = context.metadata.get("active_concepts", [])
        if len(nos_ativos) >= 2:
            articulacao = self.sintetizar_articulacao(nos_ativos)
            if articulacao:
                context.metadata["synthesized_grammar"] = articulacao
                # Enriquecimento orgânico da resposta semântica
                if context.custom_response and "Percebo que sua mente" in context.custom_response:
                    context.custom_response += f"<br><br><strong>[Síntese Gramatical Fractal]:</strong> {articulacao}"

        return context

