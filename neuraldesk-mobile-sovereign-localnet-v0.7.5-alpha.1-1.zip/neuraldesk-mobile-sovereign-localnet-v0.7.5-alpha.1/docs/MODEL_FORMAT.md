# Binary Model Formats — v0.7.2-alpha.1

Todos os formatos são little-endian e loaders rejeitam header inválido, dimensões incompatíveis, overflow, truncamento e trailing bytes.

## `.ndkr` — Knowledge Retriever

Header: 6 × `uint32_t`: magic `NDR1`, versão 1, feature_dim 4096, hidden_dim 64, classes 202, seed 101.

Payload FP32: `w1[4096,64]`, `b1[64]`, `w2[64,202]`, `b2[202]`. Total: **275.338 floats**.

## `.ndkb` — Knowledge Base

Header: magic `NDK1`, versão 1, `count=201`. Cada registro contém quatro comprimentos `uint32_t` e bytes UTF-8 de pergunta, resposta curta, resposta rica e categoria.

## `.ndrl` — Relation Classifier

Header: 7 × `uint32_t`: magic `NRL1`, versão 1, feature_dim 2048, hidden_dim 64, classes 26, seed 507, reserved 0.

Payload FP32: `w1[2048,64]`, `b1[64]`, `w2[64,26]`, `b2[26]`. Total: **132.826 floats**.

O preprocessamento textual/feature hashing Python↔C é parte do formato lógico e possui gate nativo próprio.

## `.ndqa` — Context Pointer v2

Header: magic `NDQ1`, versão 2, vocab 259, embedding_dim 48, hidden_dim 96, radius 12, max_span_bytes 160.

Payload FP32, em ordem:

1. byte embeddings `[259,48]`;
2. 25 projeções de janela `[48,96]` para offsets -12…+12;
3. projeção da pergunta `[48,96]`;
4. relation embedding `[25,96]`;
5. hidden bias `[96]`;
6. head start `[96]` + bias;
7. head end `[96]` + bias.

Total: **134.930 floats**.

## Memória explícita

Formato separado, bounded, com escrita temporária + rename. Headers, contagens, comprimentos, truncamento e trailing bytes são validados antes de aceitar estado persistido.

## `.ndos` — Open Knowledge Shard v1

Magic de 8 bytes: `NDOSV001`.

Header little-endian:

1. `version` (`uint32_t`, 1);
2. `record_count`;
3. `bucket_count` (power-of-two, 65.536 nesta release);
4. `idf_count`;
5. `sparse_entries`;
6. `top_k`;
7. `flags` (1 = deterministic UTF-8→ASCII fold);
8. `accept_score` (`double`);
9. `accept_margin` (`double`).

Cada IDF entry é `bucket:uint32 + value:float`. Cada record armazena split, comprimentos, feature count, norma, UTF-8 de source/question/answer e features `bucket:uint32 + weight:float` ordenadas. Trailing bytes são proibidos.

Asset alpha.2: **68.177 bytes**, 31 registros, SHA-256 `b4967b52e02daf3dea5833ee5f7df63ecbf4edc3bf88d95b7f407423f44419c7`.


<!-- neuraldesk-v071-sync -->
## v0.7.1-alpha.1 synchronization

Este documento permanece parte da documentação canônica. O estado corrente da release é v0.7.2-alpha.1; `HISTORICAL_CONVERGENCE_V071.md` e `MODEL_AUTHORITY_V071.md` permanecem como lineage, enquanto `CURRENT_STATE.md`, `OFFLINE_CONTINUITY_V072.md`, `MODEL_AUTHORITY_V072.md` e `COMPREHENSIVE_AUDIT.md` descrevem a autoridade corrente. Seções de versões anteriores abaixo/acima são preservadas como lineage histórico e não sobrepõem o manifest corrente.


<!-- neuraldesk-v072-sync -->
## v0.7.2-alpha.1 synchronization

Este documento foi incluído na auditoria histórica profunda v0.7.2. Seções antigas permanecem como lineage e não sobrepõem `PROJECT_MANIFEST.json`, `CURRENT_STATE.md` e a evidence versionada corrente.
