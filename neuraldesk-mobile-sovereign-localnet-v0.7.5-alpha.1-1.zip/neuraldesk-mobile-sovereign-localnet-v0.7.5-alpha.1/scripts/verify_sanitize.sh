#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
JOBS="${ND_BUILD_JOBS:-2}"
[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || { echo "ND_BUILD_JOBS inválido: $JOBS" >&2; exit 2; }
PHASE="${ND_SANITIZE_PHASE:-all}"
CHECKPOINT=(python3 "$ROOT/scripts/verification_checkpoint.py")

precheck() { python3 "$ROOT/scripts/pre_generation_lessons_check.py"; }
mark() { "${CHECKPOINT[@]}" mark sanitize "$1"; }
require_phases() { "${CHECKPOINT[@]}" require sanitize "$@"; }

phase_build() {
  precheck
  rm -rf build-sanitize
  cmake -S . -B build-sanitize \
    -DCMAKE_BUILD_TYPE=Debug \
    -DCMAKE_C_FLAGS_DEBUG="-O1 -g" \
    -DND_WARNINGS_AS_ERRORS=ON \
    -DND_SANITIZE=ON
  cmake --build build-sanitize -j"$JOBS"
  mark build
}

phase_runtime() {
  precheck
  require_phases build
  test -x build-sanitize/ndassistant || { echo 'build-sanitize/ndassistant missing; rerun sanitize build phase' >&2; exit 2; }
  export ASAN_OPTIONS=detect_leaks=1:halt_on_error=1
  ./build-sanitize/nd_calculator_test
  ./build-sanitize/nd_memory_test
  ./build-sanitize/nd_planner_test
  ./build-sanitize/nd_candidate_acceptance_test \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build-sanitize/nd_assistant_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build-sanitize/nd_multigoal_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build-sanitize/nd_context_batch \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    evaluation/fixtures/context_synthesis_regression.tsv \
    models/neuraldesk-relation-classifier-v0.5.ndrl >/dev/null
  ./build-sanitize/nd_context_batch \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    evaluation/fixtures/context_composition_holdout.tsv \
    models/neuraldesk-relation-classifier-v0.5.ndrl >/dev/null
  ./build-sanitize/nd_context_batch \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    evaluation/fixtures/context_v04_regression.tsv \
    models/neuraldesk-relation-classifier-v0.5.ndrl >/dev/null
  ./build-sanitize/nd_context_batch \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    evaluation/fixtures/relation_assisted_context_holdout.tsv \
    models/neuraldesk-relation-classifier-v0.5.ndrl >/dev/null
  ./build-sanitize/nd_open_knowledge_assistant_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build-sanitize/nd_conversational_correctness_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build-sanitize/nd_dialogue_grounding_v062_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build-sanitize/nd_robust_intent_v063_recovery_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build-sanitize/nd_post_dialogue_holdout_v074_test .
  ./build-sanitize/nd_semantic_test
  ./build-sanitize/nd_safety_test
  ./build-sanitize/nd_resource_test
  ./build-sanitize/nd_hardware_routing_test
  ./build-sanitize/nd_execution_control_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build-sanitize/nd_text_utils_test
  ./build-sanitize/nd_rag_test models/neuraldesk-semantic-ranker-v0.7.1.ndsr
  ./build-sanitize/nd_run_journal_test
  ./build-sanitize/nd_historical_convergence_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos
  ./build-sanitize/nd_network_policy_test
  ./build-sanitize/nd_pilot_test
  ./build-sanitize/nd_model_acquisition_test
  ./build-sanitize/nd_outbox_test
  ./build-sanitize/nd_project_test
  ./build-sanitize/nd_benchmark_test
  python3 tests/build_generative_fixture_v074.py --out-dir build-sanitize/generative-fixtures
  ./build-sanitize/nd_generative_mechanics_test \
    build-sanitize/generative-fixtures/fixture-fp32.ndgm \
    build-sanitize/generative-fixtures/fixture-q8.ndgm \
    build-sanitize/generative-fixtures/fixture-q4.ndgm --core
  for start in 0 5 10 15; do
    ./build-sanitize/nd_generative_mechanics_test \
      build-sanitize/generative-fixtures/fixture-fp32.ndgm \
      build-sanitize/generative-fixtures/fixture-q8.ndgm \
      build-sanitize/generative-fixtures/fixture-q4.ndgm --quant "$start" 5
  done
  ./build-sanitize/nd_generative_stream_test build-sanitize/generative-fixtures/fixture-fp32.ndgm
  python3 tests/build_generative_text_fixture_v075.py --out build-sanitize/generative-fixtures/text-fp32.ndgm
  ./build-sanitize/nd_generative_text_stream_test \
    build-sanitize/generative-fixtures/text-fp32.ndgm \
    training/data/generative_v074_v2/tokenizer-v2.ndtk
  ./build-sanitize/nd_tokenizer_test training/data/generative_v074/tokenizer-v1.ndtk
  ./build-sanitize/nd_offline_continuity_test \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl
  ./build-sanitize/ndassistant \
    models/neuraldesk-knowledge-retriever-v0.5.ndkr \
    models/neuraldesk-knowledge-v0.5.ndkb \
    models/neuraldesk-context-pointer-v0.5.ndqa \
    models/neuraldesk-relation-classifier-v0.5.ndrl \
    'Quanto é 17 vezes 23?' '' 1 - \
    models/neuraldesk-open-knowledge-pira-v0.6.ndos >/dev/null
  mark runtime
}

phase_final() {
  precheck
  require_phases build runtime
  VERSION="$(python3 -c 'import json; print(json.load(open("PROJECT_MANIFEST.json", encoding="utf-8"))["version"])')"
  DIGEST="$("${CHECKPOINT[@]}" digest)"
  printf 'SANITIZER RECEIPTS PASS version=%s digest=%s phases=build,runtime\n' "$VERSION" "$DIGEST"
  printf 'SANITIZER PASS version=%s\n' "$VERSION"
}

case "$PHASE" in
  all)
    "${CHECKPOINT[@]}" reset sanitize
    phase_build
    phase_runtime
    phase_final
    ;;
  build) phase_build ;;
  runtime) phase_runtime ;;
  final) phase_final ;;
  *) echo "ND_SANITIZE_PHASE inválido: $PHASE" >&2; exit 2 ;;
esac
