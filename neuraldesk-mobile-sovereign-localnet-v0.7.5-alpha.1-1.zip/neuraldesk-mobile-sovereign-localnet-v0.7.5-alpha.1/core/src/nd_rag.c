#include "nd_rag.h"

#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ND_RAG_TERM_MAX ND_RAG_TOKEN_HASHES
#define ND_RAG_TERM_BYTES 48u
#define ND_RAG_RERANK_MAX 16u
#define ND_RAG_FILE_VERSION 1u

static const unsigned char ND_RAG_MAGIC[8] = {'N','D','R','A','G','0','0','1'};

typedef struct { char s[ND_RAG_TERM_BYTES]; } Term;

static unsigned char lo(unsigned char c) {
    return (c >= 'A' && c <= 'Z') ? (unsigned char)(c + 32) : c;
}

static int stop(const char *s) {
    static const char *sw[] = {
        "para", "com", "sem", "que", "qual", "quais", "quem", "como", "por", "sobre",
        "uma", "um", "do", "da", "dos", "das", "de", "em", "no", "na", "e", "ou",
        "o", "a", "os", "as", "ser", "pode", "podem", "usar", "usa", "usado", "usada",
        "usados", "usadas", "entre", "ter", "tem", "tende", "tendem"
    };
    for (size_t i = 0u; i < sizeof(sw) / sizeof(sw[0]); i++) {
        if (strcmp(s, sw[i]) == 0) return 1;
    }
    return 0;
}

static size_t tokenize(const char *s, Term *out, size_t cap) {
    size_t n = strlen(s);
    size_t i = 0u;
    size_t k = 0u;
    while (i < n && k < cap) {
        while (i < n && !(isalnum((unsigned char)s[i]) || (unsigned char)s[i] >= 128u)) i++;
        size_t j = i;
        while (j < n && (isalnum((unsigned char)s[j]) || s[j] == '-' || s[j] == '_' ||
                         (unsigned char)s[j] >= 128u)) j++;
        if (j > i && j - i >= 2u && j - i < ND_RAG_TERM_BYTES) {
            size_t z = j - i;
            for (size_t x = 0u; x < z; x++) out[k].s[x] = (char)lo((unsigned char)s[i + x]);
            out[k].s[z] = 0;
            if (!stop(out[k].s)) k++;
        }
        i = j > i ? j : i + 1u;
    }
    return k;
}

static int term_has_structured_entity_shape(const char *s) {
    int digit = 0;
    int separator = 0;
    int alpha = 0;
    while (*s) {
        unsigned char c = (unsigned char)*s++;
        if (isdigit(c)) digit = 1;
        else if (isalpha(c) || c >= 128u) alpha = 1;
        else if (c == '-' || c == '_') separator = 1;
    }
    return alpha && digit && separator;
}

static uint32_t term_hash(const char *s) {
    uint32_t h = 2166136261u;
    while (*s) {
        h ^= (unsigned char)*s++;
        h *= 16777619u;
    }
    return h ? h : 1u;
}

static uint64_t bytes_hash64(const void *data, size_t n) {
    const unsigned char *p = (const unsigned char *)data;
    uint64_t h = UINT64_C(1469598103934665603);
    for (size_t i = 0u; i < n; i++) {
        h ^= p[i];
        h *= UINT64_C(1099511628211);
    }
    return h;
}

static void index_chunk_tokens(NDRagChunk *chunk) {
    Term terms[ND_RAG_TERM_MAX];
    size_t n = tokenize(chunk->text, terms, ND_RAG_TERM_MAX);
    memset(chunk->token_hashes, 0, sizeof(chunk->token_hashes));
    chunk->token_count = n;
    for (size_t i = 0u; i < n; i++) chunk->token_hashes[i] = term_hash(terms[i].s);
}

static size_t count_hash(const NDRagChunk *chunk, uint32_t hash) {
    size_t n = 0u;
    for (size_t i = 0u; i < chunk->token_count && i < ND_RAG_TOKEN_HASHES; i++) {
        if (chunk->token_hashes[i] == hash) n++;
    }
    return n;
}

static uint64_t tick(NDRagIndex *index) {
    index->logical_clock++;
    if (index->logical_clock == 0u) {
        index->logical_clock = 1u;
        for (size_t i = 0u; i < index->count; i++) index->chunks[i].last_access = 1u;
    }
    return index->logical_clock;
}

void nd_rag_init(NDRagIndex *index) {
    if (index) memset(index, 0, sizeof(*index));
}

void nd_rag_clear(NDRagIndex *index) {
    if (index) memset(index, 0, sizeof(*index));
}

static size_t document_count(const NDRagIndex *index) {
    size_t docs = 0u;
    for (size_t i = 0u; i < index->count; i++) {
        int seen = 0;
        for (size_t j = 0u; j < i; j++) {
            if (strcmp(index->chunks[i].doc_id, index->chunks[j].doc_id) == 0) {
                seen = 1;
                break;
            }
        }
        if (!seen) docs++;
    }
    return docs;
}

void nd_rag_stats(const NDRagIndex *index, NDRagStats *stats) {
    if (!stats) return;
    memset(stats, 0, sizeof(*stats));
    if (!index) return;
    stats->chunks = index->count;
    stats->documents = document_count(index);
    stats->logical_clock = index->logical_clock;
}

static void remove_document(NDRagIndex *index, const char *doc_id) {
    size_t w = 0u;
    for (size_t r = 0u; r < index->count; r++) {
        if (strcmp(index->chunks[r].doc_id, doc_id) == 0) continue;
        if (w != r) index->chunks[w] = index->chunks[r];
        w++;
    }
    if (w < index->count) {
        memset(&index->chunks[w], 0, (index->count - w) * sizeof(index->chunks[0]));
        index->count = w;
    }
}

static int evict_oldest_document(NDRagIndex *index) {
    if (!index || !index->count) return 0;
    size_t oldest = 0u;
    for (size_t i = 1u; i < index->count; i++) {
        if (index->chunks[i].last_access < index->chunks[oldest].last_access) oldest = i;
    }
    char id[ND_RAG_DOC_ID];
    snprintf(id, sizeof(id), "%s", index->chunks[oldest].doc_id);
    remove_document(index, id);
    return 1;
}

static int build_document_chunks(const char *id, const char *text, NDRagChunk *out,
                                 size_t *out_count, char *err, size_t errcap) {
    const size_t target = 800u;
    const size_t overlap = 120u;
    size_t n = strlen(text);
    size_t start = 0u;
    size_t count = 0u;
    uint64_t hash = bytes_hash64(text, n);
    while (start < n) {
        if (count >= ND_RAG_MAX_CHUNKS_PER_DOC) {
            if (err && errcap) snprintf(err, errcap, "rag document exceeds per-document chunk budget");
            return -1;
        }
        size_t end = start + target;
        if (end > n) end = n;
        if (end < n) {
            size_t p = end;
            while (p > start + target / 2u && text[p] != '.' && text[p] != '\n' && text[p] != ' ') p--;
            if (p > start + target / 2u) end = p + 1u;
        }
        size_t len = end - start;
        if (len >= ND_RAG_CHUNK_TEXT) len = ND_RAG_CHUNK_TEXT - 1u;
        NDRagChunk *chunk = &out[count++];
        memset(chunk, 0, sizeof(*chunk));
        snprintf(chunk->doc_id, sizeof(chunk->doc_id), "%s", id);
        memcpy(chunk->text, text + start, len);
        chunk->text[len] = 0;
        chunk->document_hash = hash;
        index_chunk_tokens(chunk);
        if (end >= n) break;
        start = end > overlap ? end - overlap : end;
    }
    *out_count = count;
    return 0;
}

int nd_rag_add_document(NDRagIndex *index, const char *id, const char *text, char *err, size_t errcap) {
    if (!index || !id || !*id || !text || !*text || strlen(id) >= ND_RAG_DOC_ID) {
        if (err && errcap) snprintf(err, errcap, "invalid rag document");
        return -1;
    }
    NDRagChunk pending[ND_RAG_MAX_CHUNKS_PER_DOC];
    size_t pending_count = 0u;
    if (build_document_chunks(id, text, pending, &pending_count, err, errcap)) return -1;
    if (!pending_count || pending_count > ND_RAG_MAX_CHUNKS) return -1;

    uint64_t hash = pending[0].document_hash;
    int same = 0;
    for (size_t i = 0u; i < index->count; i++) {
        if (strcmp(index->chunks[i].doc_id, id) == 0 && index->chunks[i].document_hash == hash) {
            same = 1;
            break;
        }
    }
    if (same) {
        uint64_t now = tick(index);
        for (size_t i = 0u; i < index->count; i++) {
            if (strcmp(index->chunks[i].doc_id, id) == 0) index->chunks[i].last_access = now;
        }
        return 0;
    }

    remove_document(index, id);
    while (index->count + pending_count > ND_RAG_MAX_CHUNKS) {
        if (!evict_oldest_document(index)) {
            if (err && errcap) snprintf(err, errcap, "rag capacity cannot be reclaimed");
            return -1;
        }
    }
    uint64_t now = tick(index);
    for (size_t i = 0u; i < pending_count; i++) {
        pending[i].last_access = now;
        index->chunks[index->count++] = pending[i];
    }
    return 0;
}

static int score_chunks(const NDRagIndex *index, const char *query, float scores[ND_RAG_MAX_CHUNKS]) {
    Term terms[ND_RAG_TERM_MAX];
    uint32_t query_hashes[ND_RAG_TERM_MAX];
    size_t query_count = tokenize(query, terms, ND_RAG_TERM_MAX);
    if (!query_count || !index->count) return 0;
    size_t unique_query_terms = 0u;
    size_t structured_query_terms = 0u;
    for (size_t i = 0u; i < query_count; i++) {
        query_hashes[i] = term_hash(terms[i].s);
        int duplicate = 0;
        for (size_t j = 0u; j < i; j++) {
            if (query_hashes[j] == query_hashes[i]) {
                duplicate = 1;
                break;
            }
        }
        if (!duplicate) {
            unique_query_terms++;
            if (term_has_structured_entity_shape(terms[i].s)) structured_query_terms++;
        }
    }
    memset(scores, 0, ND_RAG_MAX_CHUNKS * sizeof(float));
    double average = 0.0;
    for (size_t i = 0u; i < index->count; i++) {
        average += (double)(index->chunks[i].token_count ? index->chunks[i].token_count : 1u);
    }
    average /= (double)index->count;
    for (size_t i = 0u; i < index->count; i++) {
        double document_length = (double)(index->chunks[i].token_count ? index->chunks[i].token_count : 1u);
        double score = 0.0;
        size_t distinct_matches = 0u;
        size_t structured_matches = 0u;
        for (size_t t = 0u; t < query_count; t++) {
            size_t tf = count_hash(&index->chunks[i], query_hashes[t]);
            if (!tf) continue;
            int already_counted = 0;
            for (size_t prev = 0u; prev < t; prev++) {
                if (query_hashes[prev] == query_hashes[t]) {
                    already_counted = 1;
                    break;
                }
            }
            if (!already_counted) {
                distinct_matches++;
                if (term_has_structured_entity_shape(terms[t].s)) structured_matches++;
            }
            size_t df = 0u;
            for (size_t d = 0u; d < index->count; d++) {
                if (count_hash(&index->chunks[d], query_hashes[t])) df++;
            }
            double idf = log(1.0 + ((double)index->count - (double)df + 0.5) / ((double)df + 0.5));
            const double k1 = 1.2;
            const double b = 0.75;
            score += idf * ((double)tf * (k1 + 1.0)) /
                     ((double)tf + k1 * (1.0 - b + b * document_length / average));
        }
        size_t required_matches = unique_query_terms > 1u ? 2u : 1u;
        int entity_ok = structured_query_terms == 0u || structured_matches > 0u;
        scores[i] = entity_ok && distinct_matches >= required_matches ? (float)score : 0.0f;
    }
    return 1;
}

static size_t sparse_top(const NDRagIndex *index, const float *scores, size_t limit,
                         size_t chosen[ND_RAG_RERANK_MAX]) {
    size_t chosen_count = 0u;
    while (chosen_count < limit) {
        size_t best = (size_t)-1;
        float best_score = 0.0f;
        for (size_t i = 0u; i < index->count; i++) {
            int used = 0;
            for (size_t j = 0u; j < chosen_count; j++) {
                if (chosen[j] == i) used = 1;
            }
            if (!used && scores[i] > best_score) {
                best_score = scores[i];
                best = i;
            }
        }
        if (best == (size_t)-1 || best_score <= 0.0f) break;
        chosen[chosen_count++] = best;
    }
    return chosen_count;
}

static void semantic_reorder(const NDRagIndex *index, const char *query,
                             const NDSemanticRanker *ranker, size_t *chosen, size_t count) {
    if (!ranker || !ranker->loaded || count < 2u) return;
    float semantic[ND_RAG_RERANK_MAX];
    for (size_t i = 0u; i < count; i++) {
        semantic[i] = nd_semantic_ranker_similarity(ranker, query, index->chunks[chosen[i]].text);
    }
    for (size_t i = 0u; i + 1u < count; i++) {
        size_t best = i;
        for (size_t j = i + 1u; j < count; j++) {
            if (semantic[j] > semantic[best]) best = j;
        }
        if (best != i) {
            float semantic_tmp = semantic[i];
            semantic[i] = semantic[best];
            semantic[best] = semantic_tmp;
            size_t chosen_tmp = chosen[i];
            chosen[i] = chosen[best];
            chosen[best] = chosen_tmp;
        }
    }
}

int nd_rag_query_ranked(NDRagIndex *index, const char *query, size_t top_k,
                        const NDSemanticRanker *ranker, char *out, size_t outcap,
                        NDRagResult *result, char *err, size_t errcap) {
    if (!index || !query || !out || !outcap || !result) {
        if (err && errcap) snprintf(err, errcap, "invalid rag query");
        return -1;
    }
    memset(result, 0, sizeof(*result));
    out[0] = 0;
    if (!index->count) return 0;
    if (top_k == 0u) top_k = 1u;
    if (top_k > 8u) top_k = 8u;
    float scores[ND_RAG_MAX_CHUNKS];
    if (!score_chunks(index, query, scores)) return 0;
    size_t candidates = top_k * 3u;
    if (candidates < 4u) candidates = 4u;
    if (candidates > ND_RAG_RERANK_MAX) candidates = ND_RAG_RERANK_MAX;
    if (candidates > index->count) candidates = index->count;
    size_t chosen[ND_RAG_RERANK_MAX];
    size_t chosen_count = sparse_top(index, scores, candidates, chosen);
    if (!chosen_count) return 0;
    semantic_reorder(index, query, ranker, chosen, chosen_count);
    if (chosen_count > top_k) chosen_count = top_k;
    result->best_score = scores[chosen[0]];
    uint64_t now = tick(index);
    size_t used = 0u;
    for (size_t i = 0u; i < chosen_count; i++) {
        NDRagChunk *chunk = &index->chunks[chosen[i]];
        chunk->last_access = now;
        int written = snprintf(out + used, outcap - used, "[RAG:%s] %s%s",
                               chunk->doc_id, chunk->text, i + 1u < chosen_count ? "\n" : "");
        if (written < 0 || (size_t)written >= outcap - used) {
            if (err && errcap) snprintf(err, errcap, "rag output buffer too small");
            return -1;
        }
        used += (size_t)written;
    }
    result->found = 1;
    result->hit_count = chosen_count;
    return 0;
}

int nd_rag_query(NDRagIndex *index, const char *query, size_t top_k,
                 char *out, size_t outcap, NDRagResult *result, char *err, size_t errcap) {
    return nd_rag_query_ranked(index, query, top_k, NULL, out, outcap, result, err, errcap);
}

static int write_bytes(FILE *file, const void *data, size_t n, uint64_t *hash) {
    if (fwrite(data, 1u, n, file) != n) return -1;
    const unsigned char *p = (const unsigned char *)data;
    for (size_t i = 0u; i < n; i++) {
        *hash ^= p[i];
        *hash *= UINT64_C(1099511628211);
    }
    return 0;
}

static int write_u16(FILE *file, uint16_t value, uint64_t *hash) {
    unsigned char b[2] = {(unsigned char)value, (unsigned char)(value >> 8u)};
    return write_bytes(file, b, sizeof(b), hash);
}

static int write_u32(FILE *file, uint32_t value, uint64_t *hash) {
    unsigned char b[4] = {
        (unsigned char)value, (unsigned char)(value >> 8u),
        (unsigned char)(value >> 16u), (unsigned char)(value >> 24u)
    };
    return write_bytes(file, b, sizeof(b), hash);
}

static int write_u64(FILE *file, uint64_t value, uint64_t *hash) {
    unsigned char b[8];
    for (size_t i = 0u; i < 8u; i++) b[i] = (unsigned char)(value >> (8u * i));
    return write_bytes(file, b, sizeof(b), hash);
}

static int read_bytes(FILE *file, void *data, size_t n, uint64_t *hash) {
    if (fread(data, 1u, n, file) != n) return -1;
    const unsigned char *p = (const unsigned char *)data;
    for (size_t i = 0u; i < n; i++) {
        *hash ^= p[i];
        *hash *= UINT64_C(1099511628211);
    }
    return 0;
}

static int read_u16(FILE *file, uint16_t *value, uint64_t *hash) {
    unsigned char b[2];
    if (read_bytes(file, b, sizeof(b), hash)) return -1;
    *value = (uint16_t)b[0] | ((uint16_t)b[1] << 8u);
    return 0;
}

static int read_u32(FILE *file, uint32_t *value, uint64_t *hash) {
    unsigned char b[4];
    if (read_bytes(file, b, sizeof(b), hash)) return -1;
    *value = (uint32_t)b[0] | ((uint32_t)b[1] << 8u) |
             ((uint32_t)b[2] << 16u) | ((uint32_t)b[3] << 24u);
    return 0;
}

static int read_u64(FILE *file, uint64_t *value, uint64_t *hash) {
    unsigned char b[8];
    if (read_bytes(file, b, sizeof(b), hash)) return -1;
    uint64_t v = 0u;
    for (size_t i = 0u; i < 8u; i++) v |= ((uint64_t)b[i]) << (8u * i);
    *value = v;
    return 0;
}

static int read_u64_raw(FILE *file, uint64_t *value) {
    unsigned char b[8];
    if (fread(b, 1u, sizeof(b), file) != sizeof(b)) return -1;
    uint64_t v = 0u;
    for (size_t i = 0u; i < 8u; i++) v |= ((uint64_t)b[i]) << (8u * i);
    *value = v;
    return 0;
}

int nd_rag_save(const NDRagIndex *index, const char *path, char *err, size_t errcap) {
    if (!index || !path || !*path || index->count > ND_RAG_MAX_CHUNKS) {
        if (err && errcap) snprintf(err, errcap, "invalid rag save request");
        return -1;
    }
    FILE *file = fopen(path, "wb");
    if (!file) {
        if (err && errcap) snprintf(err, errcap, "cannot open rag file for write");
        return -1;
    }
    uint64_t hash = UINT64_C(1469598103934665603);
    int rc = write_bytes(file, ND_RAG_MAGIC, sizeof(ND_RAG_MAGIC), &hash) ||
             write_u32(file, ND_RAG_FILE_VERSION, &hash) ||
             write_u32(file, (uint32_t)index->count, &hash) ||
             write_u64(file, index->logical_clock, &hash);
    for (size_t i = 0u; !rc && i < index->count; i++) {
        const NDRagChunk *chunk = &index->chunks[i];
        size_t id_len = strlen(chunk->doc_id);
        size_t text_len = strlen(chunk->text);
        if (!id_len || id_len >= ND_RAG_DOC_ID || text_len >= ND_RAG_CHUNK_TEXT ||
            id_len > UINT16_MAX || text_len > UINT16_MAX) {
            rc = -1;
            break;
        }
        rc = write_u16(file, (uint16_t)id_len, &hash) ||
             write_u16(file, (uint16_t)text_len, &hash) ||
             write_u64(file, chunk->document_hash, &hash) ||
             write_u64(file, chunk->last_access, &hash) ||
             write_bytes(file, chunk->doc_id, id_len, &hash) ||
             write_bytes(file, chunk->text, text_len, &hash);
    }
    if (!rc) {
        unsigned char final_hash[8];
        for (size_t i = 0u; i < 8u; i++) final_hash[i] = (unsigned char)(hash >> (8u * i));
        if (fwrite(final_hash, 1u, sizeof(final_hash), file) != sizeof(final_hash)) rc = -1;
    }
    if (fclose(file) != 0) rc = -1;
    if (rc && err && errcap) snprintf(err, errcap, "rag save failed");
    return rc ? -1 : 0;
}

int nd_rag_load(NDRagIndex *index, const char *path, char *err, size_t errcap) {
    if (!index || !path || !*path) {
        if (err && errcap) snprintf(err, errcap, "invalid rag load request");
        return -1;
    }
    FILE *file = fopen(path, "rb");
    if (!file) {
        if (err && errcap) snprintf(err, errcap, "cannot open rag file");
        return -1;
    }
    NDRagIndex *tmp = (NDRagIndex *)calloc(1u, sizeof(*tmp));
    if (!tmp) {
        fclose(file);
        if (err && errcap) snprintf(err, errcap, "rag load allocation failed");
        return -1;
    }
    uint64_t hash = UINT64_C(1469598103934665603);
    unsigned char magic[8];
    uint32_t version = 0u;
    uint32_t count = 0u;
    int rc = read_bytes(file, magic, sizeof(magic), &hash) ||
             read_u32(file, &version, &hash) ||
             read_u32(file, &count, &hash) ||
             read_u64(file, &tmp->logical_clock, &hash);
    if (!rc && (memcmp(magic, ND_RAG_MAGIC, sizeof(magic)) != 0 ||
                version != ND_RAG_FILE_VERSION || count > ND_RAG_MAX_CHUNKS)) rc = -1;
    for (uint32_t i = 0u; !rc && i < count; i++) {
        uint16_t id_len = 0u;
        uint16_t text_len = 0u;
        NDRagChunk *chunk = &tmp->chunks[i];
        rc = read_u16(file, &id_len, &hash) ||
             read_u16(file, &text_len, &hash) ||
             read_u64(file, &chunk->document_hash, &hash) ||
             read_u64(file, &chunk->last_access, &hash);
        if (rc || id_len == 0u || id_len >= ND_RAG_DOC_ID || text_len >= ND_RAG_CHUNK_TEXT) {
            rc = -1;
            break;
        }
        if (read_bytes(file, chunk->doc_id, id_len, &hash) ||
            read_bytes(file, chunk->text, text_len, &hash)) {
            rc = -1;
            break;
        }
        chunk->doc_id[id_len] = 0;
        chunk->text[text_len] = 0;
        index_chunk_tokens(chunk);
    }
    tmp->count = rc ? 0u : (size_t)count;
    uint64_t stored_hash = 0u;
    if (!rc && read_u64_raw(file, &stored_hash)) rc = -1;
    if (!rc && stored_hash != hash) rc = -1;
    if (!rc && fgetc(file) != EOF) rc = -1;
    fclose(file);
    if (rc) {
        free(tmp);
        if (err && errcap) snprintf(err, errcap, "rag file corrupt or incompatible");
        return -1;
    }
    *index = *tmp;
    free(tmp);
    return 0;
}
