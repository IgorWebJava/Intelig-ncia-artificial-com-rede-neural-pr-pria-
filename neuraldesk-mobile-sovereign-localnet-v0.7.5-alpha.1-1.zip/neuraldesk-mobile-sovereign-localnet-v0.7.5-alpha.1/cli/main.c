#include "nd_assistant.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *source_name(NDAnswerSource source) {
    switch (source) {
        case ND_ANSWER_CONTEXT: return "context";
        case ND_ANSWER_CALCULATOR: return "calculator";
        case ND_ANSWER_KNOWLEDGE: return "knowledge";
        case ND_ANSWER_UNCERTAIN: return "uncertain";
        case ND_ANSWER_MEMORY: return "memory";
        case ND_ANSWER_OPEN_KNOWLEDGE: return "open_knowledge";
        case ND_ANSWER_COMPOSED: return "composed";
        case ND_ANSWER_CONVERSATION: return "conversation";
        default: return "none";
    }
}

static const char *optional_path(const char *s) {
    return (s && s[0] && strcmp(s, "-") != 0) ? s : NULL;
}

int main(int argc, char **argv) {
    /* v0.5 compatible prefix; v0.6 adds only a final optional OPEN_SHARD. */
    if (argc < 6 || argc > 10) {
        fprintf(stderr,
                "usage: %s RETRIEVER KB CONTEXT_QA RELATION QUESTION [CONTEXT] [RICH=1] [MEMORY_PATH] [OPEN_SHARD]\n",
                argv[0]);
        return 2;
    }

    const char *context = argc >= 7 ? argv[6] : NULL;
    int rich = argc >= 8 ? atoi(argv[7]) != 0 : 1;
    const char *memory_path = argc >= 9 ? optional_path(argv[8]) : NULL;
    const char *open_shard = argc >= 10 ? optional_path(argv[9]) : NULL;
    char err[256];
    char out[65536];
    NDAssistant assistant;
    NDAnswerMeta meta;

    if (nd_assistant_load_ex(&assistant, argv[1], argv[2], argv[3], argv[4],
                             open_shard, memory_path, err, sizeof(err))) {
        fprintf(stderr, "load: %s\n", err);
        return 1;
    }
    int rc = nd_assistant_answer(&assistant, argv[5], context, rich,
                                 out, sizeof(out), &meta, err, sizeof(err));
    nd_assistant_free(&assistant);
    if (rc) {
        fprintf(stderr, "answer: %s\n", err);
        return 1;
    }

    puts(out);
    fprintf(stderr,
            "source=%s confidence=%.6f margin=%.6f evidence=%zu goals=%zu/%zu "
            "tools=%zu memory=%zu open_knowledge=%zu sources=0x%08x context=%d\n",
            source_name(meta.source), meta.confidence, meta.margin,
            meta.evidence_count, meta.covered_goals, meta.goal_count,
            meta.tool_calls, meta.memory_hits, meta.open_knowledge_hits,
            meta.sources_mask, meta.context_considered);
    return 0;
}
